# Cardboard Carnival Canyon

A first-person arena shooter in a world that looks hand-made from corrugated cardboard, tape and marker ink.
Three.js (WebGL2) + TypeScript + Vite + React (menus/HUD). Everything — textures, models, sound, music — is generated in code.
`npm run build` produces a single self-contained `dist/index.html` (fonts and code inlined).

## Run / build

```bash
npm install
npm run dev      # development server
npm run build    # -> dist/index.html (single file, works offline)
```

## Controls

| Action | Keyboard / mouse (rebindable in Options) | Gamepad | Touch |
|---|---|---|---|
| Move | WASD | Left stick | Left virtual stick |
| Look | Mouse (pointer lock) · arrow keys always turn | Right stick | Drag right side |
| Fire | Left click (hold) | RT | Fire button · optional auto-fire (fires only when a target is under the crosshair) |
| Jump / Dash | Space / Shift (dash = brief invulnerability + two ink ghosts) | A / B | Jump / Dash |
| Parry | Right click or V — deflects nearby projectiles back, 2.5× damage | LT | Parry |
| Reload | R (capsule-refill animation) | X | Load |
| Swap weapon | 1-0, wheel, Z / X | LB / RB | Swap |
| Inspect | F | Y | – |
| EX (3 coins) | E — 5 s of perfect aim, free ammo | R3 | EX |
| Super (5 coins) | Q — carnival finale blast | L3 | Super |
| Pause | P / Esc (pointer-lock release) | Start | Pause |

The game auto-pauses when the tab is hidden or the window loses focus, and releases every held key.

## The capsule reel

Every shot spins three drums in the transparent tube on the blaster. Triple flower = burning petal burst (x1.4 + splash + burn),
triple bullseye = perfect-aim crit (x2.2), triple star = jackpot super shot (x3, pierce, big blast, slow-mo, bonus coins). Fast weapons roll
the special results less often per shot.

## Modes

Story Campaign (5 stages, 3 bosses) · Endless Survival (maps swap, bosses return) · Boss Rush (King → Dome → UFO) ·
Daily Challenge (date-seeded waves + a twist modifier, one score per day) · Time Attack (6 waves, +2 s per hit).

## Content

* **Weapons (all unlocked):** Popcorn Gatling, Sticker Slinger, Confetti Bazooka, Rubber-Band Crossbow (charge, pierce, ricochet), Tape-Gun Grappler
  (pull enemies / yank yourself, tape traps), Glitter Shotgun (blinds), Yo-Yo Buzzsaw (boomerang), Party-Horn Blaster (push cone, breaks crates, deflects),
  Pinwheel Launcher (homing fire/ice), Gold Spring Cannon (huge recoil).
* **Enemies:** Leaf Bot (flanks, takes cover, groups), Angry Sunflower (petal turret), Blue Smiley Blob (rolls, telegraphs, leaps, confetti burst), armored,
  spiked, fire-petal, ice and sniper variants, three mini-bosses. Bosses: Sunflower King, Crowned Dome (jump the neon laser), UFO Mothership (beam drops crates and enemies).
* **Maps:** Golden-Hour Canyon (slow time-of-day drift) and Neon Night Carnival (wet reflective floor, star arch, moon, UFO, rocket, floating islands).
  Boundaries are visible cliffs / a floating rim with a neon fence.
* **Progression:** coins, perk upgrades, per-weapon tuning, charms, achievements, high scores, corruption-safe `localStorage` saves
  (every field is validated; unreadable data is kept under a `.bak` key).
* **Options:** quality presets + auto-downgrade, resolution scale, FOV, sensitivity, shake, difficulty, colour-blind-safe cues (warning triangles, larger markers),
  captions, reduced motion, rebinding, fullscreen.

## Architecture (`src/game`)

`core` math/RNG/collision · `textures` procedural paper textures + toon materials · `models` outline hulls and props · `fx` pooled particles/decals/ribbons ·
`audio` WebAudio SFX + music · `input` unified input · `maps` arenas · `enemies` models + AI + bosses · `weapons` stats + viewmodels · `combat` projectiles/explosions ·
`director` wave composition · `post` bloom + tilt-shift + vignette + grain · `game` fixed-timestep engine · `save`/`progression` data · `selftest` diagnostics.
UI lives in `src/ui` (React). Simulation runs at a fixed 60 Hz with render interpolation.

## 1.1 content update

**18 weapons now** (keys 1-0 for the first ten; press the key of the weapon in hand again to flip to its second-bank partner 11-18; wheel / Z / X also cycle).
Every weapon has its own prop model, muzzle effect, sound and impact effect:

| # | Weapon | Signature |
|---|---|---|
| 11 (1′) | Paper-Plane Volley | three folded planes that glide, curve and home; paper-flutter muzzle, unfolding-paper impact |
| 12 (2′) | Giant Marker | rapid hitscan ink beam, ink flecks, ink blots on every surface it touches; the nib drip shrinks with ammo |
| 13 (3′) | Balloon Pump | lobbed balloon bursts into a sticky, damaging puddle (slows + damage over time); pump handle animates |
| 14 (4′) | Rubber Stamp Slammer | huge stamp, heavy thump, red ring and a big red stamp mark on the wall; lens-punch recoil |
| 15 (5′) | Firework Rack | four-rocket salvo with sparkler trails and spherical starburst detonations |
| 16 (6′) | Paperclip Zapper | chain lightning that arcs through up to five enemies (nine on a jackpot) |
| 17 (7′) | Pencil Sniper | long-range graphite beam that pierces three targets and hits harder with distance; shavings kick back |
| 18 (8′) | Bubble-Wrap Mines | slow bubbles that drift, hover and pop when an enemy comes near |

**9 new enemy types, each with a unique mechanic:** Paper Moth (flying dive-bomber), Cherry Bomb Bot (fuse + chain-reaction blast that also hurts other enemies),
Jack-in-the-Box (near-immune until it pops open), Mimic Crate (disguised as a crate until you get close), Crayon Tank (arcing mortar with ground markers),
Tissue Ghost (blinks, intangible while fading), Corrugate Knight (frontal shield blocks everything except explosions; lowers it to charge), Tin-Drum Bot (hastes + heals allies;
kill it first) and the mini-boss Sir Corrugate.

**Map dressing.** Canyon: climbable stair-and-platform lookout, market stalls, windmill, campfire with flickering light, barrels, signposts, ring of giant sunflowers,
bunting, painted cliff doodles, tumbleweeds, hot-air balloons, paper birds, sun rays, wooden fence, ink emblem on the floor.
Night: neon floor emblem with chevrons, stair platform, stalls with bulbs, a ring of floating carnival-city blocks with lit windows / neon signs / banners / blinking masts,
a rotating ferris wheel, crane with string lights, sweeping spotlights, banner poles, string lights, beach balls bouncing around the rim, distant fireworks.

## 1.2 content update: arenas, enemies and fun

**Five arenas, chosen from the menu.** Endless Survival and Time Attack use the arena picker on the mode screen ("Surprise me" cycles through all five); the campaign now has eight stages across them; Daily picks a seeded arena.

| Arena | Look | Hazard |
|---|---|---|
| Golden-Hour Canyon | warm mesas, windmill, saloon stalls, sunflower rim | trampolines, TNT crates |
| Neon Night Carnival | wet neon floor, ferris wheel, floating city, UFO | trampolines, TNT crates |
| Frostbite Fold (new) | aurora dusk, igloo, snowmen, penguins patrolling, ski lift, falling snow | slippery ice patches, trampolines |
| Toybox Takeover (new) | walls of giant alphabet blocks, giant crayons, teddy bears, rainbow arch, a toy train circling the arena | four trampolines |
| Ember Foundry (new) | lava moat, glowing floor cracks, foundry hall, spinning gears, chimneys with smoke, volcano | four lava vents that flash, then erupt |

**8 more enemies** (each arena favours its residents): Snow Globe Bot (shakes up an ice-shard nova, leaves a frost puddle), Glue Bottle Goon (lobs glue that slows you), Scissor Spinner (homing spin-dash, then dizzy and extra vulnerable),
Paper Snake (the whole body hurts, aim for the head), Origami Crane (flying orbiter with dart volleys and wide crescents), Magnet Bot (drags you in unless you break line of sight), plus mini-bosses Blizzard Globe and Paper Wyrm.

**Fun-factor systems.** Power-up gift boxes (Rapid Reels, Double Dip, Paper Shield, Slow-Mo Syrup, Coin Vacuum, Confetti Bomb) drop from defeated creatures and after every cleared wave. From wave 2 some waves roll a twist
(Swarm, Sugar Rush, Armor Parade, Gold Rush). Red TNT crates chain-explode, trampolines launch you, kill streaks get call-outs.

## 1.3 update: lighting, looks, guns and creatures

**Lighting and grading.** Every arena now has its own split-tone colour grade (cool shadows, warm highlights in the canyon; magenta shadows at night; and so on), exposure, and a fresnel **rim light** on every toon material
tinted per arena (warm orange, neon magenta, icy blue, candy pink, lava orange). Sun/moon/volcano **shafts** are raymarched in the lens pass. Muzzle flashes, explosions and kills **light the world** through a pooled set of point lights,
the viewmodel rim light kicks on every shot, lava vents glow while erupting, and every point light flickers. Props and creatures get soft **contact shadows** (flyers show their height through them).

**Map looks.** Layered terraced cut-paper horizon ridges (canyon and snow), a rolling cloud sea and shooting stars under the night carnival, wind-swept grass tufts, rocks, flowers, runway studs and confetti litter,
ice crystals and snow mounds, scattered toy blocks and marbles, ash, embers and rocks around the foundry, plus floor decals (ink blots, neon spills, crayon scribbles, scorch marks).

**Guns.** All 18 guns were rebuilt with their own silhouette and moving parts: spinning barrel cluster and hand crank (Gatling), peeling sticker roll (Slinger), pressure gauge and sliding sleeve (Bazooka),
bow limbs that flex while the rubber band and bolt draw back (Crossbow), tape roll and cutter teeth (Grappler), sliding pump and glitter canister (Shotgun), disc that leaves the launcher and returns (Yo-Yo),
squeezing bulb and fluttering streamers (Horn), always-spinning pinwheel, compressing giant coil (Spring) and more.

**Weaknesses and resistances.** Every gun deals one element (impact, blast, pierce, fire, ice, shock). Every creature is weak to one (x1.6, gold "WEAK!" numbers) and resists another (x0.55, grey "resist").
The HUD shows the current gun's damage type, hurt creatures show a health bar with a weakness badge, and the Armory screen has a full Bestiary with field notes.

**Elites.** From wave 2, rising with difficulty, some creatures spawn as **Golden** (tougher, 4x coins), **Volatile** (explodes on death), **Regenerating**, **Swift** or **Shielded** (a bubble soaks the first chunk of damage).
Each has a coloured aura and name tag. Max three alive at once; never on bosses.

**Reload mini-game.** While reloading, tap reload inside the gold zone of the bar to finish instantly and gain +25% damage for 6 s. Tap outside it and the gun jams for a moment.

**Readability fixes.** Every enemy projectile leaves an ink trail, creatures have varied death effects (glass shards, tissue drift, armour clatter, mortar crayons, magnetic sparks), floating damage numbers, hit-confirm sounds for weakness hits.

## Tests

Options → Diagnostics → **Run self-tests** runs, in the browser, tests for the RNG, save sanitising, settings clamping, bindings, collision, segment queries,
wave composition, enemy/weapon tables, and a collision perf probe. See CHANGELOG for what has and has not been verified.

## Known limitations (honest)

* This build was produced without a browser available to the author: it compiles and bundles, but it has **not been playtested**, the self-tests have **not been executed**,
  and no screenshots were captured. Expect some tuning/visual bugs on first run.
* Depth of field is a screen-space tilt-shift with focus pulls, not a true depth-buffer bokeh. Foreground blur is approximate.
* Animation is procedural (squash/stretch, lean, waddle, spring) rather than skeletal.
* LOD meshes and texture atlases are not implemented; performance relies on instancing, pooling, frustum culling, quality presets and auto-downgrade.
* The sniper's laser line is not drawn (it uses the warning marker and long wind-up). Enemy pathing is steering + stuck-detour, not a navmesh.
* Music is a simple generative sequencer; mobile layout and gamepad mapping are untested on real devices.
* Pointer lock may be blocked inside sandboxed iframes; the game then falls back to mouse-move look (and arrow keys).
