import { useEffect, useReducer, useRef, useState } from 'react';
import { Game, type GameState, type HudState, type RunResult } from './game/game';
import { Hud } from './ui/Hud';
import { Menu, type Screen } from './ui/Menu';
import { Options } from './ui/Options';
import { Touch } from './ui/Touch';
import { Btn, Ticket } from './ui/kit';

interface Power { rapid: number; damage: number; slow: number }
interface Snap { state: GameState; hud: HudState; result: RunResult | null; power: Power; twist: string }

/** Active power-up timers and the current wave twist. */
function PowerBar({ power, twist }: { power: Power; twist: string }) {
  const chips: { label: string; t: number; cls: string }[] = [];
  if (power.rapid > 0) chips.push({ label: '⚡ Rapid Reels', t: power.rapid, cls: 'bg-[#ff9a2e]' });
  if (power.damage > 0) chips.push({ label: '★ Double Dip', t: power.damage, cls: 'bg-[#e0384a] text-[#f3e7cc]' });
  if (power.slow > 0) chips.push({ label: '❄ Slow-Mo Syrup', t: power.slow, cls: 'bg-[#33d6ff]' });
  if (!chips.length && !twist) return null;
  return (
    <div className="pointer-events-none absolute left-[max(12px,env(safe-area-inset-left))] top-[176px] z-[5] flex flex-col items-start gap-1">
      {twist && <div className="ticket ticket-dark pop-in py-0.5 text-xs font-bold uppercase text-[#ffd54a]">Twist: {twist}</div>}
      {chips.map((c) => (
        <div key={c.label} className={`pop-in border-2 border-[#141016] px-2 py-0.5 text-xs font-bold uppercase text-[#141016] shadow-[3px_3px_0_#000] ${c.cls}`}>{c.label} {Math.ceil(c.t)}s</div>
      ))}
    </div>
  );
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const hostRef = useRef<HTMLDivElement>(null);
  const [game, setGame] = useState<Game | null>(null);
  const [snap, setSnap] = useState<Snap | null>(null);
  const [screen, setScreen] = useState<Screen>('main');
  const [optionsOpen, setOptionsOpen] = useState(false);
  const [error, setError] = useState('');
  const [, refresh] = useReducer((n: number) => n + 1, 0);

  useEffect(() => {
    let g: Game;
    try { g = new Game(canvasRef.current!, hostRef.current!); }
    catch (e) { setError(e instanceof Error ? e.message : String(e)); return; }
    setGame(g);
    const id = window.setInterval(() => setSnap({ state: g.state, hud: { ...g.hud }, result: g.result, power: { ...g.extras.pw }, twist: g.extras.twist?.name ?? '' }), 80);
    return () => { window.clearInterval(id); g.dispose(); };
  }, []);

  const state = snap?.state ?? 'menu';
  const playing = state === 'playing';
  const touch = !!game && game.isTouch();

  return (
    <div ref={hostRef} data-game-surface className={`relative h-full w-full overflow-hidden bg-[#07060a] ${game?.settings.reducedMotion ? 'reduced' : ''}`} style={{ cursor: playing ? 'none' : 'default' }}>
      <canvas ref={canvasRef} className="absolute inset-0 block h-full w-full" aria-label="Game view" />
      {error && (
        <div className="absolute inset-0 flex items-center justify-center p-6">
          <Ticket className="max-w-md"><h2 className="font-display text-3xl">WebGL is not available</h2><p className="mt-2 text-sm">This game needs a WebGL2-capable browser. Details: {error}</p></Ticket>
        </div>
      )}

      {game && snap && (playing || state === 'paused' || state === 'stageclear' || state === 'gameover' || state === 'victory') && <Hud h={snap.hud} colorblind={game.settings.colorblind} />}
      {game && snap && (playing || state === 'paused') && <PowerBar power={snap.power} twist={snap.twist} />}
      {game && playing && touch && <Touch game={game} />}

      {game && state === 'menu' && <Menu game={game} screen={screen} setScreen={setScreen} openOptions={() => setOptionsOpen(true)} refresh={refresh} />}

      {game && state === 'paused' && !optionsOpen && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/60 p-3">
          <Ticket className="pop-in flex w-full max-w-sm flex-col gap-3 text-center">
            <h2 className="font-display text-5xl leading-none">Paused</h2>
            <Btn primary onClick={() => game.resume()}>Resume</Btn>
            <Btn onClick={() => setOptionsOpen(true)}>Options</Btn>
            <Btn onClick={() => game.quitToMenu()}>Quit to menu</Btn>
            <p className="text-xs opacity-70">Progress and banked coins are saved when you quit.</p>
          </Ticket>
        </div>
      )}

      {game && snap?.result && (state === 'stageclear' || state === 'gameover' || state === 'victory') && (
        <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/60 p-3">
          <Ticket className="pop-in flex w-full max-w-md flex-col gap-3 text-center">
            <h2 className={`font-display text-6xl leading-none ${snap.result.win ? '' : 'text-[#c92b2b]'}`}>{snap.result.title}</h2>
            {snap.result.note && <p className="font-script text-2xl">{snap.result.note}</p>}
            <div className="grid grid-cols-2 gap-2 text-left text-sm font-bold uppercase">
              <span>Score</span><span className="text-right tabular-nums">{snap.result.score.toLocaleString()}</span>
              <span>Defeated</span><span className="text-right tabular-nums">{snap.result.kills}</span>
              <span>Time</span><span className="text-right tabular-nums">{snap.result.time.toFixed(1)}s</span>
              <span>Coins collected</span><span className="text-right tabular-nums">{snap.result.coins}</span>
            </div>
            {snap.result.best && <div className="font-display text-2xl text-[#c92b2b]">★ New personal best ★</div>}
            {snap.result.canContinue && <Btn primary onClick={() => game.nextStage()}>Next stage</Btn>}
            {!snap.result.canContinue && <Btn primary onClick={() => game.start(game.lastStart.mode, game.lastStart.mode === 'campaign' ? game.stageIndex : 0)}>{snap.result.win ? 'Play again' : 'Try again'}</Btn>}
            <Btn onClick={() => { game.quitToMenu(); setScreen('shop'); }}>Spend coins</Btn>
            <Btn onClick={() => { game.quitToMenu(); setScreen('main'); }}>Main menu</Btn>
          </Ticket>
        </div>
      )}

      {game && optionsOpen && <Options game={game} onClose={() => setOptionsOpen(false)} refresh={refresh} />}
    </div>
  );
}
