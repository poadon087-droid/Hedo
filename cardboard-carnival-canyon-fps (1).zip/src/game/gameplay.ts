/**
 * Fun-factor systems layered on top of the core loop:
 *  - power-up gift boxes (rapid fire, double damage, shield, slow-mo, coin vacuum, confetti bomb)
 *  - wave twists (swarm, sugar rush, armor parade, gold rush)
 *  - arena hazards: trampolines, slippery ice, erupting lava vents, sticky glue / frost zones, TNT crates
 *  - kill-streak call-outs
 * The engine only has to call `update` once per simulation step and forward banner text.
 */
import * as THREE from 'three';
import type { HurtKind, Rng } from './core';
import type { MapData } from './maps';
import './maps2';
import type { Fx } from './fx';
import type { Sfx } from './audio';
import type { Enemy } from './enemies';
import { MAP_ORDER, POWERS } from './progression';
import { M, T } from './textures';
import { mk } from './models';

export interface Twist { id: string; name: string; blurb: string; hp: number; spd: number; coin: number; power: number; count: number }
export const TWISTS: Twist[] = [
  { id: 'swarm', name: 'SWARM!', blurb: '+50% creatures, but they are fragile', hp: 0.65, spd: 1, coin: 1, power: 1, count: 1.5 },
  { id: 'sugar', name: 'SUGAR RUSH', blurb: 'Everything is faster and drops more power-ups', hp: 1, spd: 1.25, coin: 1, power: 3, count: 1 },
  { id: 'armor', name: 'ARMOR PARADE', blurb: 'Tougher creatures, fatter coin purses', hp: 1.5, spd: 0.9, coin: 2, power: 1, count: 0.8 },
  { id: 'gold', name: 'GOLD RUSH', blurb: 'Double coins this wave', hp: 1, spd: 1, coin: 2, power: 1, count: 1 },
];

/** What the extras need from the engine. */
export interface ExtrasHost {
  playerPos: THREE.Vector3; playerVel: THREE.Vector3;
  enemies: Enemy[]; fx: Fx; sfx: Sfx; time: number; rng: Rng;
  hurtPlayer(dmg: number, from: THREE.Vector3, kind: HurtKind): void;
  damageEnemy(e: Enemy, dmg: number, silent?: boolean): void;
  launchPlayer(vy: number): void;
  slowPlayer(t: number): void;
  grantShield(n: number): void;
  vacuumCoins(): void;
  powerBlast(): void;
  isGrounded(): boolean;
  shake(a: number): void;
  toast(text: string): void;
  caption(text: string): void;
  blast(x: number, y: number, z: number, radius: number, dmg: number, hurtEnemies?: boolean, color?: number): void;
  dropCoins(x: number, y: number, z: number, n: number): void;
  getCombo(): number;
  reshapeQueue(f: (q: string[]) => string[]): void;
}

interface Zone { active: boolean; x: number; z: number; r: number; t: number; mesh: THREE.Mesh }
interface Pow { active: boolean; kind: number; mesh: THREE.Group; pos: THREE.Vector3; vel: THREE.Vector3; ttl: number; t: number }

const hex = (c: number) => '#' + c.toString(16).padStart(6, '0');

/** Gift box with a ribbon, a bow and a glow, tinted per power-up. */
function powerMesh(color: number): THREE.Group {
  const g = new THREE.Group();
  const box = mk(new THREE.BoxGeometry(0.6, 0.6, 0.6), M.paper(hex(color)), { outline: 0.03 }); g.add(box);
  const rib = M.paper('#f3e7cc');
  const r1 = mk(new THREE.BoxGeometry(0.64, 0.64, 0.14), rib, { cast: false }); const r2 = mk(new THREE.BoxGeometry(0.14, 0.64, 0.64), rib, { cast: false }); g.add(r1, r2);
  for (const s of [-1, 1]) { const b = mk(new THREE.SphereGeometry(0.14, 8, 6), rib, { cast: false }); b.position.set(s * 0.12, 0.38, 0); b.scale.set(1.2, 0.8, 0.8); g.add(b); }
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
  glow.scale.setScalar(2.2); g.add(glow);
  return g;
}

export class Extras {
  /** Seconds remaining of each timed power-up. */
  readonly pw = { rapid: 0, damage: 0, slow: 0 };
  twist: Twist | null = null;
  onIce = false;
  private zones: Zone[] = [];
  private pows: Pow[] = [];
  private padCd = 0;
  private lastVx = 0; private lastVz = 0;
  private tmp = new THREE.Vector3();

  constructor(scene: THREE.Scene, private host: ExtrasHost) {
    const zg = new THREE.CircleGeometry(1, 30); zg.rotateX(-Math.PI / 2);
    for (let i = 0; i < 8; i++) {
      const mesh = new THREE.Mesh(zg, new THREE.MeshBasicMaterial({ color: 0xd8e04a, transparent: true, opacity: 0.55, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -3, polygonOffsetUnits: -3 }));
      mesh.visible = false; mesh.position.y = 0.04; scene.add(mesh);
      this.zones.push({ active: false, x: 0, z: 0, r: 1, t: 0, mesh });
    }
    POWERS.forEach((p, kind) => {
      for (let n = 0; n < 2; n++) {
        const mesh = powerMesh(p.color); mesh.visible = false; scene.add(mesh);
        this.pows.push({ active: false, kind, mesh, pos: new THREE.Vector3(), vel: new THREE.Vector3(), ttl: 0, t: 0 });
      }
    });
  }

  reset() {
    this.pw.rapid = this.pw.damage = this.pw.slow = 0; this.twist = null; this.onIce = false;
    for (const z of this.zones) { z.active = false; z.mesh.visible = false; }
    for (const p of this.pows) { p.active = false; p.mesh.visible = false; }
  }

  /** Arena used for stage `i` when cycling through every map. */
  mapOrder(i: number) { return MAP_ORDER[i % MAP_ORDER.length]; }

  // ------------------------------------------------------------ twists
  private rollTwist(wave: number): Twist | null {
    this.twist = wave >= 2 && this.host.rng.chance(0.4) ? TWISTS[this.host.rng.int(0, TWISTS.length - 1)] : null;
    return this.twist;
  }
  private shapeQueue(q: string[]): string[] {
    const t = this.twist;
    if (!t) return q;
    if (t.count > 1) return q.concat(q.slice(0, Math.floor(q.length * (t.count - 1))));
    if (t.count < 1) return q.slice(0, Math.max(3, Math.floor(q.length * t.count)));
    return q;
  }

  /** Called with every HUD banner so waves can roll twists and clears can drop a gift. */
  onBanner(text: string) {
    const h = this.host;
    if (text.startsWith('WAVE ')) {
      const tw = this.rollTwist(parseInt(text.slice(5), 10) || 1);
      if (tw) {
        h.reshapeQueue((q) => this.shapeQueue(q));
        h.toast('TWIST: ' + tw.name + ' — ' + tw.blurb); h.caption('[Wave twist: ' + tw.name + ']'); h.sfx.play('telegraph', 0.5);
      }
    } else if (text === 'CLEARED!') {
      this.twist = null;
      this.spawnPower(h.playerPos.x + 2, 1.4, h.playerPos.z - 3);
    }
  }

  // ------------------------------------------------------------ power-ups
  spawnPower(x: number, y: number, z: number) {
    let total = 0;
    for (const p of POWERS) total += p.weight;
    let r = this.host.rng.next() * total, kind = 0;
    for (let i = 0; i < POWERS.length; i++) { r -= POWERS[i].weight; if (r <= 0) { kind = i; break; } }
    const p = this.pows.find((q) => !q.active && q.kind === kind);
    if (!p) return;
    p.active = true; p.ttl = 22; p.t = Math.random() * 6; p.pos.set(x, Math.max(0.8, y), z);
    p.vel.set((Math.random() - 0.5) * 4, 6, (Math.random() - 0.5) * 4); p.mesh.visible = true;
  }

  private apply(kind: number) {
    const def = POWERS[kind], h = this.host;
    switch (def.id) {
      case 'rapid': this.pw.rapid = def.dur; break;
      case 'damage': this.pw.damage = def.dur; break;
      case 'slow': this.pw.slow = def.dur; break;
      case 'shield': h.grantShield(35); break;
      case 'vacuum': h.vacuumCoins(); break;
      case 'bomb': h.powerBlast(); break;
    }
    h.sfx.play('jackpot'); h.toast(def.name + ' — ' + def.desc); h.caption('[Power-up: ' + def.name + ']');
    h.fx.confetti(h.playerPos.x, 1.4, h.playerPos.z, 30, 7);
  }

  // ------------------------------------------------------------ zones
  /** Sticky glue (or frost) puddle that slows the player standing in it. */
  stickyZone(x: number, z: number, r: number, life: number, ice = false) {
    const zn = this.zones.find((q) => !q.active) ?? this.zones[0];
    zn.active = true; zn.x = x; zn.z = z; zn.r = r; zn.t = life;
    zn.mesh.position.set(x, 0.04, z); zn.mesh.scale.set(r, 1, r); zn.mesh.visible = true;
    (zn.mesh.material as THREE.MeshBasicMaterial).color.setHex(ice ? 0x9fe0ff : 0xd8e04a);
    this.host.fx.ring(x, 0.1, z, ice ? 0x9fe0ff : 0xd8e04a, r, 0.4);
  }

  // ------------------------------------------------------------ enemy hooks
  private handleDeaths(h: ExtrasHost) {
    for (const e of h.enemies) {
      if (!e.dead || e.ex.k) continue;
      e.ex.k = 1;
      const d = e.def, cx = e.pos.x, cz = e.pos.z;
      if (this.host.rng.chance((d.boss ? 0 : d.mini ? 1 : 0.06) * (this.twist?.power ?? 1))) this.spawnPower(cx, e.pos.y + e.hitCenterY, cz);
      if (this.twist && this.twist.coin > 1) h.dropCoins(cx, e.pos.y + e.hitCenterY, cz, Math.round(d.coins * (this.twist.coin - 1)));
      if (d.kind === 'globe') this.stickyZone(cx, cz, d.mini ? 4.2 : 3, 6, true);
      else if (d.kind === 'glue') this.stickyZone(cx, cz, 2.6, 6, false);
      const c = h.getCombo();
      if (c === 5 || c === 10 || c === 20 || c === 30 || c === 45) { h.toast(c + ' KILL STREAK!'); h.sfx.play('jackpot'); h.fx.confetti(h.playerPos.x, 1.6, h.playerPos.z, 40, 8); }
    }
  }

  // ------------------------------------------------------------ update
  update(dt: number, map: MapData) {
    const h = this.host, pp = h.playerPos, pw = this.pw;
    map.simTime = h.time;
    pw.rapid = Math.max(0, pw.rapid - dt); pw.damage = Math.max(0, pw.damage - dt); pw.slow = Math.max(0, pw.slow - dt);
    this.handleDeaths(h);

    for (const e of h.enemies) {
      if (!e.alive) continue;
      if (e.state === 'spawn' && !e.ex.tw && this.twist) { e.ex.tw = 1; e.hp *= this.twist.hp; e.maxHp *= this.twist.hp; e.spdMul *= this.twist.spd; }
      if (pw.slow > 0) e.addSlow(0.3);
    }

    // glue / frost zones
    const grounded = h.isGrounded();
    for (const z of this.zones) {
      if (!z.active) continue;
      z.t -= dt;
      if (z.t <= 0) { z.active = false; z.mesh.visible = false; continue; }
      if (grounded && Math.hypot(pp.x - z.x, pp.z - z.z) < z.r) h.slowPlayer(0.4);
    }

    // trampolines + slippery ice
    this.padCd -= dt;
    let ice = false;
    if (grounded) {
      if (this.padCd <= 0) {
        for (const pad of map.pads) {
          if (pp.y < 0.7 && Math.hypot(pp.x - pad.x, pp.z - pad.z) < pad.r) {
            h.launchPlayer(15.5); this.padCd = 0.4; h.sfx.play('bounce', 1.5);
            h.fx.ring(pad.x, 0.1, pad.z, 0x33d6ff, 2.4, 0.4); h.fx.confetti(pad.x, 0.4, pad.z, 14, 4);
            break;
          }
        }
      }
      for (const z of map.ice) if (Math.hypot(pp.x - z.x, pp.z - z.z) < z.r) { ice = true; break; }
    }
    if (ice && this.onIce) {
      // low friction: the stored velocity only follows the input at a fraction of the usual rate
      const v = h.playerVel;
      v.x = this.lastVx + (v.x - this.lastVx) * 0.1; v.z = this.lastVz + (v.z - this.lastVz) * 0.1;
    }
    this.onIce = ice; this.lastVx = h.playerVel.x; this.lastVz = h.playerVel.z;

    // lava vents
    for (const g of map.geysers) {
      const ph = (h.time + g.offset) % g.period;
      const st: 0 | 1 | 2 = ph > g.period - 0.55 ? 2 : ph > g.period - 1.5 ? 1 : 0;
      if (st === 1 && g.state === 0) h.sfx.play('telegraph', 0.7);
      if (st === 2 && g.state !== 2) {
        g.hit = false; h.sfx.play('boom', 0.8); h.shake(0.1);
        h.fx.burst(g.x, 0.4, g.z, 40, [0xff6a1a, 0xffd54a, 0x141016], 9, 2.2, 0.14, 1.2, 9); h.fx.ring(g.x, 0.1, g.z, 0xff6a1a, g.r * 1.6, 0.4);
      }
      g.state = st;
      if (st !== 2) continue;
      if (!g.hit && pp.y < 2.4 && Math.hypot(pp.x - g.x, pp.z - g.z) < g.r) { g.hit = true; h.hurtPlayer(14, this.tmp.set(g.x, 0, g.z), 'fire'); h.launchPlayer(11); }
      for (const e of h.enemies) if (e.alive && e.pos.y < 2 && Math.hypot(e.pos.x - g.x, e.pos.z - g.z) < g.r + e.def.radius * 0.5) h.damageEnemy(e, 70 * dt, true);
    }

    // TNT crates
    for (const c of map.crates) {
      if (!c.explosive || c.spent || c.collider.alive) continue;
      c.spent = true;
      h.blast(c.mesh.position.x, 0.8, c.mesh.position.z, 4.6, 26, true, 0xff5a1a);
    }

    // power-up boxes
    for (const p of this.pows) {
      if (!p.active) continue;
      p.t += dt; p.ttl -= dt;
      if (p.ttl <= 0) { p.active = false; p.mesh.visible = false; continue; }
      p.vel.y -= 20 * dt; p.pos.addScaledVector(p.vel, dt);
      if (p.pos.y < 0.8) { p.pos.y = 0.8; p.vel.y *= -0.35; p.vel.x *= 0.7; p.vel.z *= 0.7; }
      const rr = Math.hypot(p.pos.x, p.pos.z), lim = map.radius - 1;
      if (rr > lim) { p.pos.x *= lim / rr; p.pos.z *= lim / rr; }
      p.mesh.position.set(p.pos.x, p.pos.y + Math.sin(p.t * 3) * 0.12, p.pos.z);
      p.mesh.rotation.y = p.t * 2.4; p.mesh.visible = p.ttl > 4 || Math.floor(p.t * 8) % 2 === 0;
      if (Math.hypot(pp.x - p.pos.x, pp.y + 1 - p.pos.y, pp.z - p.pos.z) < 1.5) { this.apply(p.kind); p.active = false; p.mesh.visible = false; }
    }
    for (const z of this.zones) if (z.active) (z.mesh.material as THREE.MeshBasicMaterial).opacity = (0.4 + 0.15 * Math.sin(h.time * 4 + z.x)) * Math.min(1, z.t);
  }
}
