/**
 * Per-creature presentation and "elite" variants:
 *  - soft contact shadow so creatures sit on the floor (and flyers read their height)
 *  - floating health bar with a weakness badge, shown once a creature is hurt (or is an elite)
 *  - elite affixes: Golden, Volatile, Regenerating, Swift, Shielded
 * plus pooled floating damage numbers (gold = weakness hit, grey = resisted).
 */
import * as THREE from 'three';
import type { GameApi, Rng } from './core';
import type { Enemy, EnemyDef } from './enemies';
import { AFFINITY, ELEM_INFO, type Elem } from './elements';
import { aoTexture } from './models';
import { T } from './textures';

export type AffixId = 'golden' | 'volatile' | 'regen' | 'swift' | 'shielded';
export const AFFIXES: Record<AffixId, { name: string; css: string; hex: number; desc: string; tint: [number, number, number] }> = {
  golden: { name: 'GOLDEN', css: '#ffd54a', hex: 0xffd54a, desc: 'Tougher, drops four times the coins', tint: [0.5, 0.38, 0.04] },
  volatile: { name: 'VOLATILE', css: '#ff7a1a', hex: 0xff7a1a, desc: 'Explodes when it dies, so keep your distance', tint: [0.7, 0.24, 0.0] },
  regen: { name: 'REGENERATING', css: '#5ad46a', hex: 0x5ad46a, desc: 'Heals if you stop hurting it', tint: [0.05, 0.3, 0.1] },
  swift: { name: 'SWIFT', css: '#33d6ff', hex: 0x33d6ff, desc: 'Faster, and shoots more often', tint: [0.0, 0.25, 0.35] },
  shielded: { name: 'SHIELDED', css: '#7fc8ff', hex: 0x7fc8ff, desc: 'A bubble soaks up the first chunk of damage', tint: [0.05, 0.12, 0.4] },
};
const AFFIX_IDS = Object.keys(AFFIXES) as AffixId[];

/** Chance rises with difficulty; never on bosses or mini-bosses, never in wave 1, and at most three elites at once. */
export function rollAffix(rng: Rng, diff: number, wave: number, def: EnemyDef, elitesAlive: number): AffixId | '' {
  if (def.boss || def.mini || wave < 2 || elitesAlive >= 3) return '';
  if (!rng.chance(Math.min(0.32, 0.04 + (diff - 1) * 0.16))) return '';
  return rng.pick(AFFIX_IDS);
}

// ------------------------------------------------------------------ health bar sprite
class Bar {
  readonly sprite: THREE.Sprite;
  private cv = document.createElement('canvas');
  private g: CanvasRenderingContext2D;
  private tex: THREE.CanvasTexture;
  private key = '';

  constructor() {
    this.cv.width = 160; this.cv.height = 48;
    this.g = this.cv.getContext('2d')!;
    this.tex = new THREE.CanvasTexture(this.cv); this.tex.colorSpace = THREE.SRGBColorSpace;
    this.sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: this.tex, transparent: true, depthWrite: false, fog: false, toneMapped: false }));
    this.sprite.scale.set(1.6, 0.48, 1); this.sprite.renderOrder = 15; this.sprite.visible = false;
  }

  draw(frac: number, shield: number, label: string, css: string, weak?: Elem) {
    const key = `${Math.round(frac * 40)}|${Math.round(shield * 20)}|${label}|${weak ?? ''}`;
    if (key === this.key) return;
    this.key = key;
    const g = this.g;
    g.clearRect(0, 0, 160, 48);
    if (label) { g.font = 'bold 15px Oswald, Impact, sans-serif'; g.textAlign = 'center'; g.lineWidth = 4; g.strokeStyle = '#141016'; g.fillStyle = css; g.strokeText(label, 90, 15); g.fillText(label, 90, 15); }
    const x0 = weak ? 30 : 10, w = 150 - x0;
    g.fillStyle = '#141016'; g.fillRect(x0 - 3, 20, w + 6, 20);
    g.fillStyle = '#3a2f3a'; g.fillRect(x0, 23, w, 14);
    g.fillStyle = frac > 0.5 ? '#5ad46a' : frac > 0.25 ? '#ffd54a' : '#e0384a';
    g.fillRect(x0, 23, w * Math.max(0, Math.min(1, frac)), 14);
    if (shield > 0) { g.fillStyle = '#7fc8ff'; g.fillRect(x0, 23, w * Math.min(1, shield), 5); }
    if (weak) {
      const info = ELEM_INFO[weak];
      g.beginPath(); g.arc(15, 30, 12, 0, Math.PI * 2); g.fillStyle = '#' + info.hex.toString(16).padStart(6, '0'); g.fill(); g.lineWidth = 3; g.strokeStyle = '#141016'; g.stroke();
      g.fillStyle = '#141016'; g.font = 'bold 15px Impact, sans-serif'; g.textAlign = 'center'; g.fillText(info.tag, 15, 36);
    }
    this.tex.needsUpdate = true;
  }
}

// ------------------------------------------------------------------ shared shadow
const shadowGeo = new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
let shadowMat: THREE.MeshBasicMaterial | null = null;

export class EnemyFx {
  private built = false;
  private bar: Bar | null = null;
  private shadow!: THREE.Mesh;
  private aura: THREE.Sprite | null = null;
  private shield: THREE.Mesh | null = null;
  private base = 1;

  constructor(private e: Enemy) {}

  /** Meshes are created on first use because the creature's definition is not available while fields initialise. */
  private build() {
    const e = this.e, d = e.def;
    this.built = true;
    shadowMat ??= new THREE.MeshBasicMaterial({ map: aoTexture(), transparent: true, opacity: 0.6, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    this.shadow = new THREE.Mesh(shadowGeo, shadowMat); this.shadow.renderOrder = 1;
    this.base = Math.max(d.radius, d.height * 0.35) * 2.6;
    e.root.add(this.shadow);
    if (!e.isBoss) { this.bar = new Bar(); this.bar.sprite.position.y = d.height + 0.55; e.root.add(this.bar.sprite); }
  }

  reset() {
    const e = this.e;
    e.affix = ''; e.shieldHp = 0; e.sinceHit = 99; e.shieldBroke = false;
    if (this.aura) this.aura.visible = false;
    if (this.shield) this.shield.visible = false;
  }

  /** Applies an elite affix: stat changes plus the aura / shield visuals. Call right after `reset`. */
  setAffix(id: AffixId) {
    const e = this.e, d = e.def, a = AFFIXES[id];
    if (!this.built) this.build();
    e.affix = id;
    if (id === 'golden') { e.maxHp *= 1.5; e.hp = e.maxHp; }
    else if (id === 'swift') { e.spdMul *= 1.35; e.cdMul *= 1.3; }
    else if (id === 'shielded') {
      e.shieldHp = e.maxHp * 0.45;
      if (!this.shield) {
        this.shield = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 12), new THREE.MeshBasicMaterial({ color: 0x7fc8ff, transparent: true, opacity: 0.26, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false, fog: false }));
        e.root.add(this.shield);
      }
      const r = Math.max(d.radius * 1.2, d.height * 0.58);
      this.shield.scale.setScalar(r); this.shield.position.y = d.height * 0.5; this.shield.visible = true;
    }
    if (!this.aura) {
      this.aura = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color: a.hex, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, fog: false }));
      e.root.add(this.aura);
    }
    (this.aura.material as THREE.SpriteMaterial).color.setHex(a.hex);
    this.aura.scale.setScalar(Math.max(2.4, d.radius * 3.6 + 1)); this.aura.position.y = d.height * 0.45; this.aura.visible = true;
  }

  /** Routes incoming damage through the shield bubble; returns what is left for the health bar. */
  absorb(dmg: number): number {
    const e = this.e;
    e.sinceHit = 0;
    if (e.shieldHp <= 0) return dmg;
    const a = Math.min(e.shieldHp, dmg);
    e.shieldHp -= a;
    if (e.shieldHp <= 0) e.shieldBroke = true;
    return dmg - a;
  }

  /** Fixed-step behaviour for affixes. */
  update(dt: number, g: GameApi) {
    const e = this.e, py = e.pos.y;
    e.sinceHit += dt;
    if (e.shieldBroke) {
      e.shieldBroke = false;
      g.fx.ring(e.pos.x, py + e.hitCenterY, e.pos.z, 0x7fc8ff, 2.6, 0.35); g.fx.sparks(e.pos.x, py + e.hitCenterY, e.pos.z, 18, 0x7fc8ff); g.sfx.play('parry', 0.8); g.caption('[Shield shatters]');
    }
    if (!e.affix) return;
    const h = e.def.height, jx = (Math.random() - 0.5) * e.def.radius * 2;
    switch (e.affix) {
      case 'regen':
        if (e.sinceHit > 2 && e.hp < e.maxHp) { e.hp = Math.min(e.maxHp, e.hp + e.maxHp * 0.05 * dt); if (Math.random() < dt * 5) g.fx.sparks(e.pos.x + jx, py + h * 0.7, e.pos.z, 2, 0x5ad46a); }
        break;
      case 'swift': if (Math.hypot(e.vel.x, e.vel.z) > 2 && Math.random() < dt * 12) g.fx.sparks(e.pos.x, py + 0.3, e.pos.z, 1, 0x33d6ff); break;
      case 'golden': if (Math.random() < dt * 7) g.fx.sparks(e.pos.x + jx, py + Math.random() * h, e.pos.z + jx, 1, 0xffd54a); break;
      case 'volatile': if (Math.random() < dt * 6) g.fx.sparks(e.pos.x + jx, py + h * 0.8, e.pos.z, 1, 0xff7a1a); break;
      default: break;
    }
  }

  /** Per-frame visuals; runs after the creature's own animation. */
  sync() {
    const e = this.e;
    if (!this.built) this.build();
    const alive = e.active && !e.dead, h = Math.max(0, e.root.position.y);
    this.shadow.visible = e.active && (alive || e.t < 0.3);
    this.shadow.position.y = 0.03 - e.root.position.y;
    this.shadow.scale.setScalar(this.base / (1 + h * 0.14));
    if (this.bar) {
      const show = alive && e.state !== 'spawn' && (e.hp < e.maxHp || e.affix !== '');
      this.bar.sprite.visible = show;
      if (show) this.bar.draw(e.hp / e.maxHp, e.maxHp > 0 ? e.shieldHp / e.maxHp : 0, e.affix ? AFFIXES[e.affix as AffixId].name : '', e.affix ? AFFIXES[e.affix as AffixId].css : '#fff', AFFINITY[e.def.id]?.weak);
    }
    if (this.aura) { this.aura.visible = alive && e.affix !== ''; if (this.aura.visible) (this.aura.material as THREE.SpriteMaterial).opacity = 0.55 + 0.25 * Math.sin(e.visT * 4); }
    if (this.shield) { this.shield.visible = alive && e.shieldHp > 0; if (this.shield.visible) this.shield.rotation.y = e.visT; }
    // elite tint, unless a hit flash / burn is currently using the emissive channel
    if (e.affix && alive && e.flashT <= 0 && e.burn <= 0) {
      const c = AFFIXES[e.affix as AffixId].tint, p = 0.6 + 0.4 * Math.sin(e.visT * (e.affix === 'volatile' ? 9 : 3));
      for (const m of e.parts.flash) m.emissive.setRGB(c[0] * p, c[1] * p, c[2] * p);
    }
  }
}

// ------------------------------------------------------------------ floating damage numbers
interface Num { s: THREE.Sprite; cv: HTMLCanvasElement; g: CanvasRenderingContext2D; tex: THREE.CanvasTexture; t: number; life: number; vx: number; vy: number; vz: number; size: number }

export class DamageNumbers {
  private pool: Num[] = [];
  private next = 0;

  constructor(scene: THREE.Scene, n = 28) {
    for (let i = 0; i < n; i++) {
      const cv = document.createElement('canvas'); cv.width = 192; cv.height = 80;
      const tex = new THREE.CanvasTexture(cv); tex.colorSpace = THREE.SRGBColorSpace;
      const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false, depthWrite: false, fog: false, toneMapped: false }));
      s.visible = false; s.renderOrder = 30; scene.add(s);
      this.pool.push({ s, cv, g: cv.getContext('2d')!, tex, t: 99, life: 1, vx: 0, vy: 0, vz: 0, size: 1 });
    }
  }

  spawn(x: number, y: number, z: number, text: string, css: string, size = 1, life = 0.9, sub = '') {
    const n = this.pool[this.next]; this.next = (this.next + 1) % this.pool.length;
    const g = n.g;
    g.clearRect(0, 0, 192, 80);
    g.textAlign = 'center'; g.lineJoin = 'round'; g.lineWidth = 8; g.strokeStyle = '#141016';
    g.font = 'bold 46px Impact, "Arial Black", sans-serif'; g.strokeText(text, 96, sub ? 44 : 56); g.fillStyle = css; g.fillText(text, 96, sub ? 44 : 56);
    if (sub) { g.font = 'bold 20px Oswald, Impact, sans-serif'; g.lineWidth = 5; g.strokeText(sub, 96, 70); g.fillText(sub, 96, 70); }
    n.tex.needsUpdate = true;
    n.t = 0; n.life = life; n.size = size; n.vx = (Math.random() - 0.5) * 1.4; n.vy = 2.6; n.vz = (Math.random() - 0.5) * 1.4;
    n.s.position.set(x, y, z); n.s.visible = true;
  }

  update(dt: number) {
    for (const n of this.pool) {
      if (!n.s.visible) continue;
      n.t += dt;
      if (n.t >= n.life) { n.s.visible = false; continue; }
      n.vy -= 3.2 * dt; n.s.position.x += n.vx * dt; n.s.position.y += n.vy * dt; n.s.position.z += n.vz * dt;
      const k = n.t / n.life, pop = 1 + 0.45 * Math.max(0, 1 - n.t * 7);
      n.s.scale.set(1.5 * n.size * pop, 0.625 * n.size * pop, 1);
      (n.s.material as THREE.SpriteMaterial).opacity = 1 - k * k;
    }
  }

  clear() { for (const n of this.pool) n.s.visible = false; }
}
