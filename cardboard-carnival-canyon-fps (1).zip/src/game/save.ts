/**
 * Corruption-safe persistence. Every field is validated and falls back to a default;
 * a broken payload is kept under a ".bak" key so nothing is silently destroyed.
 */
export type Quality = 'low' | 'medium' | 'high' | 'auto';

export interface Settings {
  master: number; music: number; sfx: number; muted: boolean;
  quality: Quality; resScale: number; fov: number; sens: number; shake: number;
  colorblind: boolean; subtitles: boolean; reducedMotion: boolean; autofire: boolean;
  difficulty: 'easy' | 'normal' | 'hard';
  bindings: Record<string, string[]>;
}
export interface SaveData {
  v: 1;
  coins: number;
  upgrades: Record<string, number>;
  weaponLv: Record<string, number>;
  charms: string[]; ownedCharms: string[];
  achievements: string[];
  scores: Record<string, number>;
  stats: { kills: number; jackpots: number; dashes: number; parries: number; bosses: number; runs: number; coinsEver: number };
  campaign: number;
  daily: { date: string; score: number };
}

export const DEFAULT_BINDINGS: Record<string, string[]> = {
  forward: ['KeyW'], back: ['KeyS'], left: ['KeyA'], right: ['KeyD'],
  jump: ['Space'], dash: ['ShiftLeft', 'ShiftRight'], fire: ['Mouse0'], parry: ['Mouse2', 'KeyV'], reload: ['KeyR'],
  ex: ['KeyE'], super: ['KeyQ'], inspect: ['KeyF'], next: ['KeyX'], prev: ['KeyZ'], pause: ['KeyP'],
};

export const defaultSettings = (): Settings => ({
  master: 0.8, music: 0.6, sfx: 0.9, muted: false, quality: 'auto', resScale: 1, fov: 85, sens: 1, shake: 1,
  colorblind: false, subtitles: false, reducedMotion: false, autofire: false, difficulty: 'normal',
  bindings: JSON.parse(JSON.stringify(DEFAULT_BINDINGS)),
});
export const defaultSave = (): SaveData => ({
  v: 1, coins: 0, upgrades: {}, weaponLv: {}, charms: [], ownedCharms: [], achievements: [], scores: {},
  stats: { kills: 0, jackpots: 0, dashes: 0, parries: 0, bosses: 0, runs: 0, coinsEver: 0 },
  campaign: 0, daily: { date: '', score: 0 },
});

const SAVE_KEY = 'cardboard-carnival-save-v1';
const SET_KEY = 'cardboard-carnival-settings-v1';

const num = (v: unknown, d: number, lo: number, hi: number) => (typeof v === 'number' && Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d);
const bool = (v: unknown, d: boolean) => (typeof v === 'boolean' ? v : d);
const strArr = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === 'string').slice(0, 64) : []);
const numRec = (v: unknown, hi = 1e9): Record<string, number> => {
  const out: Record<string, number> = {};
  if (v && typeof v === 'object') for (const [k, val] of Object.entries(v as Record<string, unknown>)) if (typeof val === 'number' && Number.isFinite(val)) out[k] = Math.min(hi, Math.max(0, val));
  return out;
};

export function sanitizeSave(raw: unknown): SaveData {
  const d = defaultSave();
  if (!raw || typeof raw !== 'object') return d;
  const r = raw as Record<string, unknown>;
  const st = (r.stats && typeof r.stats === 'object' ? r.stats : {}) as Record<string, unknown>;
  const dl = (r.daily && typeof r.daily === 'object' ? r.daily : {}) as Record<string, unknown>;
  return {
    v: 1,
    coins: Math.floor(num(r.coins, 0, 0, 1e9)),
    upgrades: numRec(r.upgrades, 50), weaponLv: numRec(r.weaponLv, 50),
    charms: strArr(r.charms).slice(0, 2), ownedCharms: strArr(r.ownedCharms),
    achievements: strArr(r.achievements),
    scores: numRec(r.scores),
    stats: {
      kills: num(st.kills, 0, 0, 1e9), jackpots: num(st.jackpots, 0, 0, 1e9), dashes: num(st.dashes, 0, 0, 1e9), parries: num(st.parries, 0, 0, 1e9),
      bosses: num(st.bosses, 0, 0, 1e9), runs: num(st.runs, 0, 0, 1e9), coinsEver: num(st.coinsEver, 0, 0, 1e9),
    },
    campaign: Math.floor(num(r.campaign, 0, 0, 99)),
    daily: { date: typeof dl.date === 'string' ? dl.date : '', score: num(dl.score, 0, 0, 1e9) },
  };
}

export function sanitizeSettings(raw: unknown): Settings {
  const d = defaultSettings();
  if (!raw || typeof raw !== 'object') return d;
  const r = raw as Record<string, unknown>;
  const q = r.quality;
  const b: Record<string, string[]> = JSON.parse(JSON.stringify(DEFAULT_BINDINGS));
  if (r.bindings && typeof r.bindings === 'object') {
    for (const [k, v] of Object.entries(r.bindings as Record<string, unknown>)) if (k in b) { const a = strArr(v).slice(0, 3); if (a.length) b[k] = a; }
  }
  return {
    master: num(r.master, d.master, 0, 1), music: num(r.music, d.music, 0, 1), sfx: num(r.sfx, d.sfx, 0, 1), muted: bool(r.muted, false),
    quality: q === 'low' || q === 'medium' || q === 'high' || q === 'auto' ? q : 'auto',
    resScale: num(r.resScale, 1, 0.5, 1.5), fov: num(r.fov, 85, 60, 110), sens: num(r.sens, 1, 0.2, 3), shake: num(r.shake, 1, 0, 1.5),
    colorblind: bool(r.colorblind, false), subtitles: bool(r.subtitles, false), reducedMotion: bool(r.reducedMotion, false), autofire: bool(r.autofire, false),
    difficulty: r.difficulty === 'easy' || r.difficulty === 'hard' ? r.difficulty : 'normal',
    bindings: b,
  };
}

function readJson(key: string): unknown {
  try {
    const s = localStorage.getItem(key);
    if (!s) return null;
    return JSON.parse(s);
  } catch {
    try { const s = localStorage.getItem(key); if (s) localStorage.setItem(key + '.bak', s); } catch { /* storage unavailable */ }
    return null;
  }
}
function writeJson(key: string, v: unknown): boolean {
  try { localStorage.setItem(key, JSON.stringify(v)); return true; } catch { return false; }
}

export const loadSave = (): SaveData => sanitizeSave(readJson(SAVE_KEY));
export const storeSave = (s: SaveData) => writeJson(SAVE_KEY, s);
export const loadSettings = (): Settings => sanitizeSettings(readJson(SET_KEY));
export const storeSettings = (s: Settings) => writeJson(SET_KEY, s);
