/**
 * The extra creature roster, each with a unique mechanic:
 *  Paper Moth (flying dive-bomber), Cherry Bomb Bot (fuse + chain blast), Jack-in-the-Box (armoured until it pops),
 *  Mimic Crate (disguised ambusher), Crayon Tank (arcing mortar), Tissue Ghost (blinks + shoots),
 *  Corrugate Knight (frontal shield + charge), Tin-Drum Bot (hastes and heals allies).
 */
import * as THREE from 'three';
import { TAU, angleDiff, clamp, damp, hasLOS, type GameApi } from './core';
import { M, T, boxGeo, gradientMap } from './textures';
import { disc, extrude, mk, petalShape } from './models';
import { brow, cloneToon, crownMesh, makeMarker, type Enemy, type EnemyDef, type Parts } from './enemies';

const EXTRA_KINDS = ['moth', 'bomb', 'jack', 'mimic', 'tank', 'ghost', 'knight', 'drummer'];
export const isExtra = (k: string) => EXTRA_KINDS.includes(k);
export const initialExtraState = (k: string) => (k === 'mimic' ? 'idle' : 'chase');

// ------------------------------------------------------------------ model helpers
const ball = (r: number, color: number) => new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), new THREE.MeshBasicMaterial({ color }));
const eye = (x: number, y: number, z: number, r = 0.07) => {
  const g = new THREE.Group(), w = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), new THREE.MeshToonMaterial({ color: 0xffffff, gradientMap: gradientMap() })), p = ball(r * 0.5, 0x141016);
  p.position.z = r * 0.7; g.add(w, p); g.position.set(x, y, z); return g;
};
const glowSprite = (color: number, size: number) => {
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })); s.scale.setScalar(size); return s;
};
function vhelix(radius: number, height: number, turns: number, tube: number, mat: THREE.Material) {
  const pts: THREE.Vector3[] = [], n = turns * 12;
  for (let i = 0; i <= n; i++) { const a = (i / 12) * TAU; pts.push(new THREE.Vector3(Math.cos(a) * radius, (i / n) * height, Math.sin(a) * radius)); }
  return mk(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), n * 2, tube, 6, false), mat);
}
const cyl = (r0: number, r1: number, len: number, seg = 10) => { const g = new THREE.CylinderGeometry(r0, r1, len, seg); g.rotateX(Math.PI / 2); return g; };

// ------------------------------------------------------------------ builders
function buildMoth(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group(), fur = cloneToon(M.paper('#b08a5a'), flash);
  const body = mk(new THREE.CapsuleGeometry(0.13, 0.34, 4, 8), fur, { outline: 0.02 }); body.rotation.x = Math.PI / 2; body.position.y = 0.45; pivot.add(body);
  const collar = mk(new THREE.SphereGeometry(0.16, 10, 8), M.paper('#f3e7cc'), { outline: 0.02 }); collar.position.set(0, 0.45, 0.2); pivot.add(collar);
  const head = mk(new THREE.SphereGeometry(0.15, 10, 8), fur, { outline: 0.02 }); head.position.set(0, 0.5, 0.36); pivot.add(head);
  pivot.add(eye(-0.07, 0.55, 0.47, 0.055), eye(0.07, 0.55, 0.47, 0.055));
  const brows = [brow(-0.07, 0.63, 0.49, 0.1), brow(0.07, 0.63, 0.49, 0.1)]; pivot.add(...brows);
  for (const s of [-1, 1]) {
    const a = mk(new THREE.CylinderGeometry(0.01, 0.01, 0.35, 4), M.paper('#33353a')); a.position.set(s * 0.1, 0.72, 0.4); a.rotation.set(0.3, 0, -s * 0.5); pivot.add(a);
    const tip = ball(0.03, 0xffd54a); tip.position.set(s * 0.19, 0.88, 0.45); pivot.add(tip);
  }
  const extra: Record<string, THREE.Object3D> = {};
  for (const s of [-1, 1]) {
    const g = new THREE.Group(); g.position.set(s * 0.1, 0.5, 0.05);
    const big = extrude(petalShape(), 0.03, cloneToon(M.paper(def.tint), flash), 0.02); big.scale.set(0.9, 1.0, 1); big.rotation.z = -s * Math.PI / 2; g.add(big);
    const small = extrude(petalShape(), 0.03, cloneToon(M.paper('#f3e7cc'), flash), 0.02); small.scale.set(0.5, 0.65, 1); small.rotation.z = -s * (Math.PI / 2 + 0.7); g.add(small);
    const spot = new THREE.Mesh(new THREE.CircleGeometry(0.11, 12), M.paper('#141016')); spot.position.set(s * 0.55, 0.04, 0.03); g.add(spot);
    const spot2 = new THREE.Mesh(new THREE.CircleGeometry(0.06, 10), M.paper('#f3e7cc')); spot2.position.set(s * 0.55, 0.04, 0.035); g.add(spot2);
    pivot.add(g); extra[s < 0 ? 'wl' : 'wr'] = g;
  }
  return { pivot, flash, brows, marker: makeMarker(), extra };
}

function buildBomb(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group(), body = new THREE.Group(); body.position.y = 0.55; pivot.add(body);
  body.add(mk(new THREE.SphereGeometry(0.46, 16, 12), cloneToon(M.paper(def.tint), flash), { outline: 0.03 }));
  const band = mk(new THREE.TorusGeometry(0.46, 0.05, 6, 24), M.paper('#f3e7cc'), { outline: 0.01 }); band.rotation.x = Math.PI / 2; band.position.y = -0.12; body.add(band);
  const face = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.62), M.tex(T.leafFace(), 'leafFace', { transparent: true })); face.position.set(0, 0.04, 0.47); body.add(face);
  for (const s of [-1, 1]) { const gl = ball(0.1, 0xffffff); gl.position.set(s * 0.52, -0.05, 0.05); body.add(gl); }
  const fuse = mk(new THREE.CylinderGeometry(0.03, 0.03, 0.3, 6), M.paper('#9c703a')); fuse.position.set(0.05, 1.08, 0); fuse.rotation.z = -0.4; pivot.add(fuse);
  const spark = glowSprite(0xffaa33, 0.45); spark.position.set(0.15, 1.24, 0); pivot.add(spark);
  for (const s of [-1, 1]) { const f = mk(new THREE.BoxGeometry(0.2, 0.12, 0.3), M.paper('#2a2d33'), { outline: 0.02 }); f.position.set(s * 0.2, 0.06, 0.04); pivot.add(f); }
  const brows = [brow(-0.14, 0.82, 0.5, 0.2), brow(0.14, 0.82, 0.5, 0.2)]; pivot.add(...brows);
  return { pivot, flash, brows, marker: makeMarker(), extra: { body, spark } };
}

function buildJack(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group();
  const box = mk(boxGeo(0.9, 0.7, 0.9, 0.9), cloneToon(M.paper(def.tint), flash), { outline: 0.03 }); box.position.y = 0.35; pivot.add(box);
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const p = mk(new THREE.BoxGeometry(0.1, 0.7, 0.1), M.paper('#e8b830'), { outline: 0.02 }); p.position.set(sx * 0.45, 0.35, sz * 0.45); pivot.add(p); }
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(0.5, 0.5), M.tex(T.flowerSticker(), 'flower', { transparent: true })); fl.position.set(0, 0.35, 0.46); pivot.add(fl);
  const lid = new THREE.Group(); lid.position.set(0, 0.7, -0.45);
  const lidMesh = mk(boxGeo(0.96, 0.12, 0.96, 0.96), cloneToon(M.paper('#c92b2b'), flash), { outline: 0.03 }); lidMesh.position.set(0, 0.06, 0.45); lid.add(lidMesh); pivot.add(lid);
  const spring = new THREE.Group(); spring.position.y = 0.7; spring.add(vhelix(0.2, 1.0, 6, 0.035, M.paper('#e8b830'))); pivot.add(spring);
  const head = new THREE.Group(); head.position.y = 1.0; pivot.add(head);
  head.add(disc(0.34, 0.24, M.tex(T.jackFace(), 'jackFace'), M.edge('#9a6a3a')));
  for (const [s, col] of [[-1, '#c92b2b'], [1, '#3f6fd0']] as [number, string][]) {
    const hat = mk(new THREE.ConeGeometry(0.16, 0.5, 8), M.paper(col), { outline: 0.02 }); hat.position.set(s * 0.2, 0.42, 0); hat.rotation.z = -s * 0.7; head.add(hat);
    const bell = ball(0.05, 0xffd54a); bell.position.set(s * 0.46, 0.6, 0); head.add(bell);
  }
  const brows = [brow(-0.13, 0.19, 0.2, 0.2), brow(0.13, 0.19, 0.2, 0.2)]; head.add(...brows);
  return { pivot, flash, brows, head, marker: makeMarker(), extra: { lid, spring, head } };
}

function buildMimic(): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group(), crateMat = cloneToon(M.tex(T.crate(), 'crate', { bump: true }), flash);
  const base = mk(boxGeo(1.1, 0.6, 1.1, 1.1), crateMat, { outline: 0.035 }); base.position.y = 0.3; pivot.add(base);
  const mouth = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.04, 1.0), new THREE.MeshBasicMaterial({ color: 0x2a0a0e })); mouth.position.y = 0.6; pivot.add(mouth);
  const tongue = mk(new THREE.BoxGeometry(0.5, 0.05, 0.5), M.paper('#e0587a'), { cast: false }); tongue.position.set(0, 0.62, 0.15); pivot.add(tongue);
  const toothGeo = new THREE.ConeGeometry(0.07, 0.2, 5), toothMat = M.paper('#ffffff');
  for (let i = 0; i < 5; i++) { const x = -0.4 + i * 0.2; for (const z of [-0.5, 0.5]) { const t = new THREE.Mesh(toothGeo, toothMat); t.position.set(x, 0.7, z); pivot.add(t); } }
  const lid = new THREE.Group(); lid.position.set(0, 0.6, -0.55);
  const lidMesh = mk(boxGeo(1.14, 0.28, 1.14, 1.14), crateMat, { outline: 0.035 }); lidMesh.position.set(0, 0.14, 0.55); lid.add(lidMesh);
  const tape = mk(new THREE.BoxGeometry(0.18, 0.02, 1.16), M.tex(T.tape('#d9b45a'), 'tapeTan'), { cast: false }); tape.position.set(0, 0.29, 0.55); lid.add(tape);
  for (let i = 0; i < 5; i++) { const t = new THREE.Mesh(toothGeo, toothMat); t.position.set(-0.4 + i * 0.2, -0.04, 1.02); t.rotation.x = Math.PI; lid.add(t); }
  const eyes = new THREE.Group(); eyes.position.set(0, 0.32, 0.8); eyes.add(eye(-0.2, 0, 0, 0.12), eye(0.2, 0, 0, 0.12));
  const brows = [brow(-0.2, 0.17, 0.1, 0.24), brow(0.2, 0.17, 0.1, 0.24)]; eyes.add(...brows); lid.add(eyes); pivot.add(lid);
  const legs = new THREE.Group();
  for (const sx of [-1, 1]) for (const sz of [-1, 1]) { const l = mk(new THREE.BoxGeometry(0.16, 0.22, 0.16), M.paper('#2a2d33'), { outline: 0.02 }); l.position.set(sx * 0.4, 0.05, sz * 0.4); legs.add(l); }
  pivot.add(legs);
  return { pivot, flash, brows, marker: makeMarker(), extra: { lid, eyes, legs } };
}

function buildTank(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group(), wheels: THREE.Object3D[] = [];
  const hull = mk(boxGeo(1.5, 0.55, 2.1, 1.2), cloneToon(M.paper(def.tint), flash), { outline: 0.03 }); hull.position.y = 0.55; pivot.add(hull);
  const stripe = mk(new THREE.BoxGeometry(0.3, 0.03, 2.12), M.tex(T.tape('#e0b84a'), 'tapeY'), { cast: false }); stripe.position.y = 0.84; pivot.add(stripe);
  for (const s of [-1, 1]) {
    const tr = mk(new THREE.BoxGeometry(0.4, 0.45, 2.3), M.paper('#2a2d33'), { outline: 0.03 }); tr.position.set(s * 0.85, 0.3, 0); pivot.add(tr);
    for (let i = 0; i < 4; i++) { const w = mk(new THREE.CylinderGeometry(0.19, 0.19, 0.44, 10), M.paper('#9a9aa0'), { outline: 0.01 }); w.rotation.z = Math.PI / 2; w.position.set(s * 0.85, 0.28, -0.8 + i * 0.53); pivot.add(w); wheels.push(w); }
  }
  const turret = new THREE.Group(); turret.position.y = 0.95; pivot.add(turret);
  turret.add(mk(new THREE.SphereGeometry(0.62, 14, 10, 0, TAU, 0, Math.PI / 2), cloneToon(M.paper('#d09f66'), flash), { outline: 0.03 }));
  const barrel = new THREE.Group(); barrel.position.set(0, 0.22, 0.85); turret.add(barrel);
  barrel.add(mk(cyl(0.1, 0.1, 1.2, 12), [M.tex(T.stripesRW(), 'rwRocket'), M.edge(), M.edge()], { outline: 0.02 }));
  const tip = mk(cyl(0.13, 0.13, 0.12, 12), M.paper('#e8b830'), { outline: 0.02 }); tip.position.z = 0.62; barrel.add(tip);
  const hatch = disc(0.2, 0.1, M.tex(T.blobFace(), 'blobFace'), M.edge('#5a6f9a')); hatch.position.set(0, 0.6, -0.12); hatch.rotation.x = -Math.PI / 2 + 0.5; turret.add(hatch);
  const ant = mk(new THREE.CylinderGeometry(0.015, 0.015, 0.7, 4), M.paper('#33353a')); ant.position.set(0.3, 0.8, -0.2); turret.add(ant);
  const flag = mk(new THREE.BoxGeometry(0.3, 0.18, 0.02), M.paper('#c92b2b'), { outline: 0.01 }); flag.position.set(0.45, 1.05, -0.2); turret.add(flag);
  turret.add(eye(-0.2, 0.27, 0.57, 0.08), eye(0.2, 0.27, 0.57, 0.08));
  const brows = [brow(-0.2, 0.4, 0.57, 0.2), brow(0.2, 0.4, 0.57, 0.2)]; turret.add(...brows);
  return { pivot, flash, brows, wheels, marker: makeMarker(), extra: { turret, barrel } };
}

function buildGhost(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group();
  const prof = ([[0, 1.55], [0.22, 1.5], [0.38, 1.32], [0.46, 1.0], [0.5, 0.6], [0.6, 0.25], [0.52, 0.0]] as [number, number][]).map(([x, y]) => new THREE.Vector2(x, y));
  const geo = new THREE.LatheGeometry(prof, 18), pa = geo.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pa.count; i++) { const y = pa.getY(i); if (y < 0.3) { const a = Math.atan2(pa.getZ(i), pa.getX(i)); pa.setY(i, y - (0.5 + 0.5 * Math.sin(a * 6)) * 0.14 * (1 - y / 0.3)); } }
  geo.computeVertexNormals();
  const mat = cloneToon(new THREE.MeshToonMaterial({ color: def.tint, transparent: true, opacity: 0.88, gradientMap: gradientMap(), side: THREE.DoubleSide }), flash);
  pivot.add(new THREE.Mesh(geo, mat));
  const face = new THREE.Group(); pivot.add(face);
  for (const s of [-1, 1]) { const e = ball(0.07, 0x141016); e.scale.set(1, 1.7, 0.4); e.position.set(s * 0.17, 1.0, 0.43); face.add(e); }
  const mouth = ball(0.08, 0x141016); mouth.scale.set(1.2, 1.6, 0.4); mouth.position.set(0, 0.72, 0.47); face.add(mouth);
  const brows = [brow(-0.17, 1.16, 0.44, 0.18), brow(0.17, 1.16, 0.44, 0.18)]; face.add(...brows);
  const arms: Record<string, THREE.Object3D> = {};
  for (const s of [-1, 1]) { const a = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.45, 6), mat); a.position.set(s * 0.5, 0.75, 0.1); a.rotation.z = s * 1.1; pivot.add(a); arms[s < 0 ? 'al' : 'ar'] = a; }
  return { pivot, flash, brows, marker: makeMarker(), extra: { face, ...arms } };
}

function buildKnight(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group(), steel = cloneToon(M.paper(def.tint), flash);
  for (const s of [-1, 1]) { const l = mk(new THREE.BoxGeometry(0.22, 0.5, 0.28), M.paper('#6a5a4a'), { outline: 0.02 }); l.position.set(s * 0.2, 0.25, 0); pivot.add(l); }
  const body = mk(boxGeo(0.85, 0.9, 0.55, 0.9), steel, { outline: 0.03 }); body.position.y = 0.95; pivot.add(body);
  const belt = mk(new THREE.BoxGeometry(0.88, 0.1, 0.58), M.tex(T.tape('#e0b84a'), 'tapeY'), { cast: false }); belt.position.y = 0.7; pivot.add(belt);
  const head = mk(new THREE.SphereGeometry(0.33, 12, 10), steel, { outline: 0.03 }); head.position.y = 1.7; pivot.add(head);
  const visor = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.08, 0.06), new THREE.MeshBasicMaterial({ color: 0x141016 })); visor.position.set(0, 1.68, 0.31); pivot.add(visor);
  for (const s of [-1, 1]) { const w = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.04, 0.02), new THREE.MeshBasicMaterial({ color: 0xffffff })); w.position.set(s * 0.1, 1.68, 0.345); pivot.add(w); }
  const brows = [brow(-0.11, 1.78, 0.33, 0.15), brow(0.11, 1.78, 0.33, 0.15)]; pivot.add(...brows);
  const plume = extrude(petalShape(), 0.04, M.paper('#c92b2b'), 0.02); plume.scale.set(0.35, 0.7, 1); plume.position.set(0, 1.95, -0.05); plume.rotation.x = -0.4; pivot.add(plume);
  if (def.crown) { const c = crownMesh(1.0); c.position.set(0, 2.08, 0); pivot.add(c); }
  const shield = new THREE.Group(); shield.position.set(0, 1.0, 0.5); pivot.add(shield);
  shield.add(mk(boxGeo(1.0, 1.3, 0.12, 0.6), M.tex(T.stripesRW(), 'rwShield'), { outline: 0.03 }));
  const emb = new THREE.Mesh(new THREE.PlaneGeometry(0.55, 0.55), M.tex(T.crownDoodle(), 'crownD', { transparent: true })); emb.position.z = 0.065; shield.add(emb);
  const spear = new THREE.Group(); spear.position.set(0.6, 1.0, 0.15); pivot.add(spear);
  const shaft = mk(cyl(0.03, 0.03, 1.8, 6), M.paper('#9c6a3a'), { outline: 0.01 }); shaft.position.z = 0.7; spear.add(shaft);
  const sg = new THREE.ConeGeometry(0.07, 0.3, 6); sg.rotateX(Math.PI / 2); const tip = mk(sg, M.paper('#e8b830'), { outline: 0.01 }); tip.position.z = 1.7; spear.add(tip);
  return { pivot, flash, brows, marker: makeMarker(), extra: { shield, spear } };
}

function buildDrummer(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group();
  const drum = mk(new THREE.CylinderGeometry(0.5, 0.5, 0.6, 20), [cloneToon(M.tex(T.stripesRW(), 'rwDrum'), flash), M.paper('#f3e7cc'), M.paper('#f3e7cc')], { outline: 0.03 }); drum.position.y = 0.75; pivot.add(drum);
  for (const y of [0.45, 1.05]) { const r = mk(new THREE.TorusGeometry(0.5, 0.04, 6, 24), M.paper('#e8b830'), { outline: 0.01 }); r.rotation.x = Math.PI / 2; r.position.y = y; pivot.add(r); }
  for (const s of [-1, 1]) { const l = mk(new THREE.BoxGeometry(0.2, 0.3, 0.26), M.paper('#2a2d33'), { outline: 0.02 }); l.position.set(s * 0.22, 0.15, 0.03); pivot.add(l); }
  const face = new THREE.Mesh(new THREE.PlaneGeometry(0.52, 0.52), M.tex(T.domeFace(), 'domeFace', { transparent: true })); face.position.set(0, 0.78, 0.505); pivot.add(face);
  const hat = mk(new THREE.CylinderGeometry(0.2, 0.24, 0.4, 12), M.paper(def.tint), { outline: 0.02 }); hat.position.y = 1.28; pivot.add(hat);
  const band = mk(new THREE.CylinderGeometry(0.245, 0.245, 0.06, 12), M.paper('#e8b830')); band.position.y = 1.18; pivot.add(band);
  const plume = extrude(petalShape(), 0.03, M.paper('#f3e7cc'), 0.01); plume.scale.set(0.2, 0.4, 1); plume.position.set(0, 1.45, 0); pivot.add(plume);
  const arms: THREE.Object3D[] = [];
  for (const s of [-1, 1]) {
    const a = new THREE.Group(); a.position.set(s * 0.56, 0.9, 0.1);
    a.add(ball(0.1, 0xffffff));
    const stick = mk(cyl(0.02, 0.02, 0.5, 6), M.paper('#9c6a3a')); stick.position.z = 0.28; a.add(stick);
    const tip = ball(0.045, 0xf3e7cc); tip.position.z = 0.55; a.add(tip);
    pivot.add(a); arms.push(a);
  }
  return { pivot, flash, arms, marker: makeMarker() };
}

export function buildExtra(def: EnemyDef): Parts {
  switch (def.kind) {
    case 'moth': return buildMoth(def);
    case 'bomb': return buildBomb(def);
    case 'jack': return buildJack(def);
    case 'mimic': return buildMimic();
    case 'tank': return buildTank(def);
    case 'ghost': return buildGhost(def);
    case 'knight': return buildKnight(def);
    default: return buildDrummer(def);
  }
}

// ------------------------------------------------------------------ AI
const cooldown = (e: Enemy) => (e.def.cooldown * (0.8 + Math.random() * 0.5)) / e.cdMul;
const faceSmooth = (e: Enemy, want: number, rate: number, dt: number) => { e.yaw = damp(e.yaw, e.yaw + angleDiff(e.yaw, want), rate, dt); };
const eyeLos = (e: Enemy, g: GameApi) => hasLOS({ x: e.pos.x, y: 1, z: e.pos.z }, { x: g.playerPos.x, y: 1, z: g.playerPos.z }, g.colliders);

/** Paper Moth: orbits at head height, rears up, then dive-bombs the spot where you stood. */
function moth(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex, pp = g.playerPos;
  faceSmooth(e, want, 8, dt);
  const hoverY = 2.3 + Math.sin(e.age * 2.1 + e.id) * 0.5;
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / d.windup, 0, 1); e.vel.multiplyScalar(0.9); e.pos.y = damp(e.pos.y, 3.6, 4, dt); e.integrate(g, dt, false);
      if (e.t >= d.windup) { e.state = 'atk'; e.t = 0; ex.tx = pp.x; ex.tz = pp.z; ex.hit = 0; e.windupAmt = 0; g.sfx.play('dash', 1.4); }
      break;
    case 'atk': {
      const dx = ex.tx - e.pos.x, dz = ex.tz - e.pos.z, dy = 0.9 - e.pos.y, l = Math.hypot(dx, dy, dz) || 1, sp = d.speed * 2.6;
      e.vel.set((dx / l) * sp, 0, (dz / l) * sp); e.pos.y += (dy / l) * sp * dt; e.integrate(g, dt, false);
      if (!ex.hit && Math.hypot(pp.x - e.pos.x, pp.z - e.pos.z) < 0.95 && Math.abs(pp.y + 0.9 - e.pos.y) < 1.3) { ex.hit = 1; g.hurtPlayer(d.dmg * e.dmgMul, e.pos, 'contact'); }
      if (l < 0.9 || e.t > 1.1) { e.radial(g, 8, Math.random() * TAU, 'seed', 7, d.dmg * 0.5 * e.dmgMul, 0.3); e.state = 'recover'; e.t = 0; }
      break;
    }
    case 'recover':
      e.vel.multiplyScalar(0.9); e.pos.y = damp(e.pos.y, hoverY, 3, dt); e.integrate(g, dt, false);
      if (e.t > 0.6) { e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); }
      break;
    default: {
      ex.orb = (ex.orb ?? e.id) + dt * (0.6 + 0.25 * Math.sin(e.age + e.id));
      const R = 7 + Math.sin(e.age * 0.7 + e.id * 2) * 2;
      e.steer(g, pp.x + Math.cos(ex.orb) * R - e.pos.x, pp.z + Math.sin(ex.orb) * R - e.pos.z, e.speedNow(), dt);
      e.pos.y = damp(e.pos.y, hoverY, 3, dt); e.integrate(g, dt, false);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 26) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 1.5); }
    }
  }
}

/** Cherry Bomb Bot: sprints at you, lights its fuse up close and explodes. Killing it blasts nearby foes too. */
function bomb(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp;
  faceSmooth(e, want, 10, dt);
  if (e.state === 'windup') {
    e.windupAmt = clamp(e.t / d.windup, 0, 1); e.steer(g, p.x, p.z, e.speedNow() * 0.85, dt); e.integrate(g, dt);
    if (e.t >= d.windup || p.d < 1.3) g.damageEnemy(e, 1e9, true); // detonation is handled by the kill hook
    return;
  }
  const zig = Math.sin(e.age * 3 + e.id) * 0.5;
  e.steer(g, p.x - p.z * zig, p.z + p.x * zig, e.speedNow(), dt); e.integrate(g, dt); e.checkStuck(dt, true);
  if (e.state === 'recover' && e.t > 0.3) { e.state = 'chase'; e.t = 0; }
  if (p.d < 4.2) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 1.8); g.caption('[Fuse hissing]'); }
}

/** Jack-in-the-Box: nearly immune while shut; pops open to shoot, and is only vulnerable then. */
function jack(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex;
  faceSmooth(e, want, 5, dt);
  ex.open = damp(ex.open ?? 0, e.state === 'fire' ? 1 : 0, e.state === 'fire' ? 22 : 7, dt);
  e.takeMul = ex.open > 0.6 ? 1 : 0.15;
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / d.windup, 0, 1); e.vel.multiplyScalar(0.8); e.integrate(g, dt);
      if (e.t >= d.windup) { e.state = 'fire'; e.t = 0; ex.shots = 2; e.shotT = 0; e.windupAmt = 0; g.sfx.play('bounce', 0.5); g.caption('[Jack pops open!]'); }
      break;
    case 'fire':
      e.shotT -= dt;
      if (ex.shots > 0 && e.shotT <= 0) {
        const dmg = d.dmg * e.dmgMul;
        for (const o of [-0.28, 0, 0.28]) e.aimShot(g, o, 'orb', 9, dmg, 1.5);
        e.radial(g, 8, Math.random() * TAU, 'orb', 6.5, dmg * 0.8, 1.5); ex.shots--; e.shotT = 0.7;
      }
      e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t > 2.2) { e.state = 'recover'; e.t = 0; }
      break;
    case 'recover':
      e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t > 0.5) { e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); }
      break;
    default: {
      const far = p.d > 9;
      e.steer(g, p.x, p.z, far ? e.speedNow() : e.speedNow() * 0.2, dt); e.integrate(g, dt); e.checkStuck(dt, far);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 26 && eyeLos(e, g)) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 0.9); }
    }
  }
}

/** Mimic Crate: sits like a normal crate until you get close (or hurt it), then sprouts legs and lunges. */
function mimic(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex, pp = g.playerPos;
  if (e.state === 'idle') {
    e.takeMul = 0.6; ex.awake = 0; e.vel.multiplyScalar(0.8);
    if (p.d < 7 || e.hp < e.maxHp || e.age > 7) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 0.6); g.caption('[The crate has teeth!]'); g.fx.scraps(e.pos.x, 0.8, e.pos.z, 14, 0xc4935a, 4); }
    return;
  }
  e.takeMul = 1; ex.awake = damp(ex.awake ?? 0, 1, 10, dt); faceSmooth(e, want, 9, dt);
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / 0.5, 0, 1);
      if (e.t >= 0.5) { e.state = 'chase'; e.t = 0; e.windupAmt = 0; e.fireT = 0.2; }
      break;
    case 'leap':
      e.vy -= 24 * dt; e.pos.y += e.vy * dt; e.integrate(g, dt);
      if (!ex.hit && p.d < d.radius + g.playerRadius + 0.3 && pp.y < e.pos.y + 1.2) { ex.hit = 1; g.hurtPlayer(d.dmg * 1.2 * e.dmgMul, e.pos, 'contact'); }
      if (e.pos.y <= 0 && e.vy < 0) { e.pos.y = 0; e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); e.sqV -= 6; g.fx.scraps(e.pos.x, 0.1, e.pos.z, 8, 0xc4935a, 3.5); g.shake(0.06); }
      break;
    default:
      e.steer(g, p.x, p.z, e.speedNow(), dt); e.integrate(g, dt); e.checkStuck(dt, true);
      if (p.d < d.radius + g.playerRadius + 0.2 && e.contactCd <= 0) { g.hurtPlayer(d.dmg * e.dmgMul, e.pos, 'contact'); e.contactCd = 0.8; }
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 8 && p.d > 1.5) { e.state = 'leap'; e.t = 0; e.vy = 7; ex.hit = 0; const sp = Math.min(p.d / 0.7, 13); e.vel.x = p.x * sp; e.vel.z = p.z * sp; g.sfx.play('bounce', 0.6); }
  }
}

/** Throws an arcing shell that lands on (tx,tz). */
function lob(e: Enemy, g: GameApi, tx: number, tz: number, dmg: number) {
  const ox = e.pos.x, oy = e.pos.y + 1.5, oz = e.pos.z, dx = tx - ox, dz = tz - oz, D = Math.hypot(dx, dz), G = 14;
  const T2 = clamp(D / 13, 0.9, 2.2), vx = dx / T2, vz = dz / T2, vy = (0.15 - oy) / T2 + 0.5 * G * T2, sp = Math.hypot(vx, vy, vz);
  g.fireEnemyProj({ x: ox, y: oy, z: oz, dx: vx / sp, dy: vy / sp, dz: vz / sp, speed: sp, dmg, kind: 'fire', gravity: G, explode: 3.2, life: T2 + 2.5 });
  g.sfx.play('enemyShoot', 0.5);
}

/** Crayon Tank: keeps its distance, marks the ground and lobs mortar shells at where you are heading. */
function tank(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex, pp = g.playerPos;
  e.yaw = damp(e.yaw, e.yaw + angleDiff(e.yaw, want), 1.6, dt);
  ex.rec = damp(ex.rec ?? 0, 0, 9, dt);
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / d.windup, 0, 1); e.vel.multiplyScalar(0.8); e.integrate(g, dt);
      if (e.t >= d.windup) { e.state = 'fire'; e.t = 0; ex.shots = g.difficulty > 1.6 ? 2 : 1; e.shotT = 0; e.windupAmt = 0; }
      break;
    case 'fire':
      e.shotT -= dt;
      if (ex.shots > 0 && e.shotT <= 0) {
        lob(e, g, ex.tx, ex.tz, d.dmg * e.dmgMul); ex.rec = 0.35; ex.shots--; e.shotT = 0.5;
        if (ex.shots > 0) { ex.tx = pp.x; ex.tz = pp.z; g.groundMarker(ex.tx, ex.tz, 3.2, 1.6, 'warn'); }
      }
      e.vel.multiplyScalar(0.8); e.integrate(g, dt);
      if (ex.shots <= 0 && e.shotT <= 0) { e.state = 'recover'; e.t = 0; }
      break;
    case 'recover':
      e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t > 0.7) { e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); }
      break;
    default: {
      const sp = p.d > 20 ? 1 : p.d < 12 ? -0.8 : 0;
      e.steer(g, Math.sin(e.yaw) * sp, Math.cos(e.yaw) * sp, e.speedNow(), dt); e.integrate(g, dt); e.checkStuck(dt, sp !== 0);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 34) {
        e.state = 'windup'; e.t = 0; ex.tx = pp.x + g.playerVel.x * 0.7; ex.tz = pp.z + g.playerVel.z * 0.7;
        g.groundMarker(ex.tx, ex.tz, 3.2, d.windup + 0.5, 'warn'); g.sfx.play('telegraph', 0.6); g.caption('[Tank is aiming a mortar]');
      }
    }
  }
}

/** Tissue Ghost: hovers, wails a three-way volley, then fades and reappears somewhere else. Intangible while blinking. */
function ghost(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex, pp = g.playerPos;
  faceSmooth(e, want, 8, dt);
  e.pos.y = damp(e.pos.y, 0.55 + Math.sin(e.age * 2 + e.id) * 0.12, 4, dt);
  if (ex.alpha === undefined) ex.alpha = 1;
  switch (e.state) {
    case 'windup':
      e.takeMul = 1; e.windupAmt = clamp(e.t / d.windup, 0, 1); ex.alpha = 0.75 + 0.25 * Math.sin(e.t * 40); e.vel.multiplyScalar(0.9); e.integrate(g, dt, false);
      if (e.t >= d.windup) { e.state = 'fire'; e.t = 0; ex.alpha = 1; e.windupAmt = 0; }
      break;
    case 'fire': {
      const dmg = d.dmg * e.dmgMul;
      for (const o of [-0.22, 0, 0.22]) e.aimShot(g, o, 'plasma', d.projSpeed, dmg, 0.9);
      e.state = 'idle'; e.t = 0; ex.moved = 0; g.caption('[Ghost wails and vanishes]');
      break;
    }
    case 'idle':
      e.takeMul = 0; ex.alpha = e.t < 0.3 ? 1 - e.t / 0.3 : e.t < 0.7 ? 0 : clamp((e.t - 0.7) / 0.3, 0, 1);
      if (e.t >= 0.3 && !ex.moved) {
        ex.moved = 1; const a = Math.random() * TAU, R = 9 + Math.random() * 3; let nx = pp.x + Math.cos(a) * R, nz = pp.z + Math.sin(a) * R;
        const l = Math.hypot(nx, nz), lim = g.mapRadius - 1.5; if (l > lim) { nx *= lim / l; nz *= lim / l; }
        e.pos.x = nx; e.pos.z = nz; e.prev.copy(e.pos); g.fx.confetti(nx, 1, nz, 8, 3);
      }
      if (e.t >= 1.0) { e.state = 'chase'; e.t = 0; e.takeMul = 1; ex.alpha = 1; e.fireT = cooldown(e); }
      break;
    default: {
      e.takeMul = 1; ex.alpha = damp(ex.alpha, 1, 8, dt);
      if (p.d > 11) e.steer(g, p.x, p.z, e.speedNow(), dt); else if (p.d < 7) e.steer(g, -p.x, -p.z, e.speedNow(), dt); else e.steer(g, -p.z * e.strafe, p.x * e.strafe, e.speedNow() * 0.6, dt);
      e.integrate(g, dt, false);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 24) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 1.1); }
    }
  }
}

/** Corrugate Knight: shield blocks everything from the front. Lowers it to wind up a charge, then is exposed. */
function knight(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex;
  switch (e.state) {
    case 'windup':
      e.shieldUp = false; e.windupAmt = clamp(e.t / d.windup, 0, 1); if (e.t < d.windup * 0.6) faceSmooth(e, want, 12, dt); e.vel.multiplyScalar(0.8); e.integrate(g, dt);
      if (e.t >= d.windup) { e.state = 'atk'; e.t = 0; ex.dx = Math.sin(e.yaw); ex.dz = Math.cos(e.yaw); ex.hit = 0; e.windupAmt = 0; e.shieldUp = true; g.sfx.play('dash', 0.8); }
      break;
    case 'atk':
      e.vel.x = ex.dx * 15; e.vel.z = ex.dz * 15; e.integrate(g, dt);
      if (!ex.hit && p.d < d.radius + g.playerRadius + 0.6) { ex.hit = 1; g.hurtPlayer(d.dmg * 1.3 * e.dmgMul, e.pos, 'contact'); g.playerVel.x += ex.dx * 14; g.playerVel.z += ex.dz * 14; g.shake(0.25); }
      if (e.t > 0.5 || (ex.hit && e.t > 0.2)) { e.state = 'recover'; e.t = 0; e.shieldUp = false; e.sqV -= 5; }
      break;
    case 'recover':
      e.shieldUp = false; e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t > 1.1) { e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); }
      break;
    default:
      e.shieldUp = true; faceSmooth(e, want, 6, dt);
      e.steer(g, p.x, p.z, p.d > 4 ? e.speedNow() : e.speedNow() * 0.4, dt); e.integrate(g, dt); e.checkStuck(dt, true);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 10 && p.d > 2.5 && eyeLos(e, g)) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 0.7); g.caption('[Knight lowers its shield to charge]'); }
  }
}

/** Tin-Drum Bot: hangs back and beats a rally that hastes and heals nearby allies. Fires seeds if alone. */
function drummer(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex;
  faceSmooth(e, want, 6, dt);
  ex.beat = (ex.beat ?? 0) + dt * (e.state === 'windup' ? 12 : 4);
  switch (e.state) {
    case 'windup':
      e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t >= d.windup) { e.state = 'fire'; e.t = 0; }
      break;
    case 'fire': {
      let n = 0;
      for (const o of g.enemies) {
        if (o === e || !o.alive || o.isBoss || Math.hypot(o.pos.x - e.pos.x, o.pos.z - e.pos.z) > 12) continue;
        o.haste = 5; o.hp = Math.min(o.maxHp, o.hp + o.maxHp * 0.12); n++; g.fx.ring(o.pos.x, 0.1, o.pos.z, 0xffd54a, 1.2, 0.4);
      }
      g.fx.ring(e.pos.x, 0.12, e.pos.z, 0xffd54a, 12, 0.6); g.fx.ring(e.pos.x, 0.12, e.pos.z, 0xff3b5c, 8, 0.5); g.sfx.play('waveStart', 0.8); e.sqV += 6;
      if (n > 0) g.caption('[Drum rally: allies speed up]'); else for (const o of [-0.25, 0, 0.25]) e.aimShot(g, o, 'seed', d.projSpeed, d.dmg * e.dmgMul, 1.0);
      e.state = 'recover'; e.t = 0;
      break;
    }
    case 'recover':
      e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t > 0.5) { e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); }
      break;
    default:
      if (p.d < 11) e.steer(g, -p.x, -p.z, e.speedNow(), dt); else if (p.d > 17) e.steer(g, p.x, p.z, e.speedNow(), dt); else e.steer(g, -p.z * e.strafe, p.x * e.strafe, e.speedNow() * 0.5, dt);
      e.integrate(g, dt); e.checkStuck(dt, true);
      e.fireT -= dt;
      if (e.fireT <= 0) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 0.6); }
  }
}

export function updateExtra(e: Enemy, dt: number, g: GameApi, want: number) {
  switch (e.def.kind) {
    case 'moth': moth(e, dt, g, want); break;
    case 'bomb': bomb(e, dt, g, want); break;
    case 'jack': jack(e, dt, g, want); break;
    case 'mimic': mimic(e, dt, g, want); break;
    case 'tank': tank(e, dt, g, want); break;
    case 'ghost': ghost(e, dt, g, want); break;
    case 'knight': knight(e, dt, g, want); break;
    case 'drummer': drummer(e, dt, g, want); break;
  }
}

// ------------------------------------------------------------------ animation
const R = { lean: 0, waddle: 0, hop: 0 };

/** Per-frame procedural animation for the extra roster; returns lean / waddle / hop for the shared transform code. */
export function syncExtra(e: Enemy, dt: number, speed: number) {
  const ex = e.ex, t = e.visT, w = e.windupAmt, x = e.parts.extra ?? {};
  let lean = 0, waddle = 0, hop = 0;
  switch (e.def.kind) {
    case 'moth': {
      const f = Math.sin(t * (26 + w * 14)) * (0.75 + w * 0.3);
      x.wr.rotation.z = f + 0.2; x.wl.rotation.z = -f - 0.2; lean = clamp(speed / 18, 0, 0.4) - w * 0.3; hop = Math.sin(t * 9) * 0.06; break;
    }
    case 'bomb': {
      x.body.scale.setScalar(1 + w * 0.25 * (0.5 + 0.5 * Math.sin(t * 30)));
      x.spark.scale.setScalar(0.35 + Math.random() * 0.2 + w * 0.4);
      const run = clamp(speed / 5, 0, 1); waddle = Math.sin(t * 18) * 0.15 * run; hop = Math.abs(Math.sin(t * 18)) * 0.08 * run; break;
    }
    case 'jack': {
      const o = ex.open ?? 0, sc = 0.12 + o * 0.95;
      x.lid.rotation.x = -o * 2.0; x.spring.scale.set(1, sc, 1); x.head.position.y = 0.7 + sc + 0.3; x.head.rotation.z = Math.sin(t * 6) * 0.12 * o;
      waddle = Math.sin(t * 45) * 0.05 * w; hop = e.state === 'chase' ? Math.abs(Math.sin(t * 6)) * 0.1 * clamp(speed, 0, 1) : 0; break;
    }
    case 'mimic': {
      const a = ex.awake ?? 0;
      x.lid.rotation.x = -(a * (0.25 + 0.5 * (0.5 + 0.5 * Math.sin(t * 13))) + w * 0.9);
      x.legs.scale.setScalar(Math.max(0.001, a)); x.eyes.scale.setScalar(Math.max(0.001, a));
      hop = e.state === 'chase' ? Math.abs(Math.sin(t * 10)) * 0.12 : 0; waddle = a > 0.5 ? Math.sin(t * 10) * 0.06 : 0; break;
    }
    case 'tank': {
      for (const wh of e.parts.wheels ?? []) wh.rotation.x += speed * dt * 3;
      x.turret.rotation.y = clamp(angleDiff(e.yaw, Math.atan2(e.tmp.x, e.tmp.z)), -1.8, 1.8);
      x.barrel.position.z = 0.85 - (ex.rec ?? 0); lean = -w * 0.08; break;
    }
    case 'ghost': {
      const a = ex.alpha ?? 1;
      for (const m of e.parts.flash) m.opacity = 0.88 * a;
      x.face.visible = a > 0.35; x.al.rotation.z = -1.1 - Math.sin(t * 3) * 0.25; x.ar.rotation.z = 1.1 + Math.sin(t * 3 + 1) * 0.25;
      waddle = Math.sin(t * 2) * 0.05; lean = clamp(speed / 10, 0, 0.25) - w * 0.15; break;
    }
    case 'knight': {
      const up = e.shieldUp;
      x.shield.position.z = damp(x.shield.position.z, up ? 0.5 : 0.02, 14, dt); x.shield.position.y = damp(x.shield.position.y, up ? 1.0 : 0.55, 14, dt); x.shield.rotation.x = damp(x.shield.rotation.x, up ? 0 : 0.6, 14, dt);
      x.spear.rotation.x = damp(x.spear.rotation.x, w > 0.05 ? -0.9 : e.state === 'atk' ? 0.1 : 0, 12, dt);
      const run = clamp(speed / 3, 0, 1); waddle = Math.sin(t * 9) * 0.08 * run; hop = Math.abs(Math.sin(t * 9)) * 0.04 * run; lean = e.state === 'atk' ? 0.3 : -w * 0.2; break;
    }
    case 'drummer': {
      const b = ex.beat ?? 0, arms = e.parts.arms ?? [];
      if (arms[0]) arms[0].rotation.x = -0.4 - Math.abs(Math.sin(b)) * 0.9;
      if (arms[1]) arms[1].rotation.x = -0.4 - Math.abs(Math.cos(b)) * 0.9;
      hop = Math.abs(Math.sin(b)) * 0.07; waddle = Math.sin(b * 0.5) * 0.05; break;
    }
  }
  R.lean = lean; R.waddle = waddle; R.hop = hop;
  return R;
}
