/**
 * The game engine: fixed-timestep simulation with render interpolation, player controller,
 * weapons + capsule reel, wave director, modes, pickups, camera and render orchestration.
 */
import * as THREE from 'three';
import {
  Rng, TAU, clamp, damp, groundAt, hashString, lerp, makeCollider, resolveCircle, segAABB, segSphere,
  type Crate, type EProjSpec, type GameApi, type HurtKind,
} from './core';
import { Fx } from './fx';
import { Sfx } from './audio';
import { Input } from './input';
import { Combat, type CombatHost } from './combat';
import { Enemy, EnemyPool, ENEMY_DEFS } from './enemies';
import { buildMap, type MapData, type MapId } from './maps';
import { WEAPONS, buildWeaponView, symbolAngle, type WeaponView } from './weapons';
import { muzzleFx } from './weaponfx';
import { Extras } from './gameplay';
import './scenery';
import { DynLights } from './lights';
import { DamageNumbers, AFFIXES, rollAffix } from './enemyfx';
import { WEAPON_ELEM, elemMult, RELOAD_ZONE } from './elements';
import { Post } from './post';
import { composeWave } from './director';
import { loadSave, loadSettings, storeSave, storeSettings, type SaveData, type Settings } from './save';
import { ACHIEVEMENTS, CAMPAIGN, DAILY_MODS, todayKey, type ModeId, type StageCfg } from './progression';
import { coinMesh, heartMesh, makeCrate, setOutlineEnabled, outlineTime } from './models';
import { T } from './textures';

const STEP = 1 / 60;
const EYE = 1.62;
const BOSSES = ['kingSun', 'domeBoss', 'ufo'];
export type GameState = 'menu' | 'playing' | 'paused' | 'stageclear' | 'gameover' | 'victory';
type Level = 'low' | 'medium' | 'high';

export interface HudState {
  hp: number; maxHp: number; shield: number; ammo: number; mag: number; reload: number; weapon: number; weaponName: string; charge: number;
  coins: number; score: number; combo: number; comboT: number; wave: number; waves: number; stage: string; time: number; mode: string;
  boss: { name: string; frac: number; phase: number } | null;
  dashCd: number; parryCd: number; exT: number; canSuper: boolean; canEx: boolean;
  reel: number[]; reelLabel: string; reelT: number;
  /** Damage type of the weapon in hand ("fire+ice" for the pinwheel) and the seconds left on the perfect-load buff. */
  elem?: string; perfect?: number;
  hitT: number; killT: number; critHit: boolean;
  hurt: { ang: number; t: number }[]; hurtFlash: number; parryT: number;
  banner: string; bannerSub: string; bannerT: number;
  toasts: { text: string; t: number }[]; captions: { text: string; t: number }[];
  fps: number; level: string; pad: boolean; over: boolean; modName: string;
}
export interface RunResult { title: string; win: boolean; mode: ModeId; score: number; kills: number; time: number; coins: number; best: boolean; note: string; canContinue: boolean }

interface Pickup { active: boolean; type: 'coin' | 'heart'; mesh: THREE.Mesh; pos: THREE.Vector3; vel: THREE.Vector3; ttl: number; float: boolean; t: number }
interface Run {
  mode: ModeId; stageIdx: number; stageStart: number; cfg: StageCfg; wave: number; queue: string[]; spawnT: number; intermission: number; bossDone: boolean; phase: 'wave' | 'boss' | 'idle';
  score: number; kills: number; time: number; coins: number; coinsGot: number; penalty: number; waveHurt: boolean; diff: number; rng: Rng; seed: number; mod: string; won: boolean;
}

const approach = (v: number, t: number, d: number) => (v < t ? Math.min(t, v + d) : Math.max(t, v - d));

export class Game implements GameApi, CombatHost {
  settings: Settings = loadSettings();
  save: SaveData = loadSave();
  state: GameState = 'menu';
  result: RunResult | null = null;
  lastStart: { mode: ModeId; stage: number } = { mode: 'campaign', stage: 0 };
  get stageIndex() { return this.run?.stageIdx ?? 0; }
  hud: HudState;
  // GameApi / CombatHost surface
  fx: Fx; sfx = new Sfx(); input: Input;
  enemies: Enemy[] = [];
  rng = new Rng(Date.now());
  time = 0;
  playerPos = new THREE.Vector3(); playerVel = new THREE.Vector3();
  playerRadius = 0.4; playerHeight = 1.75;
  eye = new THREE.Vector3();
  get colliders() { return this.map.colliders; }
  get crates() { return this.map.crates; }
  get mapRadius() { return this.map.radius; }
  get difficulty() { return this.run?.diff ?? 1; }
  get captionsOn() { return this.settings.subtitles; }

  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private camera = new THREE.PerspectiveCamera(85, 1, 0.05, 700);
  private wScene = new THREE.Scene();
  private wCam = new THREE.PerspectiveCamera(55, 1, 0.01, 10);
  private wRoot = new THREE.Group();
  private wHemi = new THREE.HemisphereLight(0xfff0d0, 0x806040, 2.2);
  private wKey = new THREE.DirectionalLight(0xffe0b0, 2.4);
  private wRim = new THREE.PointLight(0x60a0ff, 3, 4, 2);
  private post: Post;
  private combat: Combat;
  private pool: EnemyPool;
  private map!: MapData;
  private run!: Run;
  private raf = 0; private last = 0; private acc = 0; private disposed = false;
  private vt = 0; private hitStop = 0; private slowT = 0; private timeScale = 1;
  private level: Level = 'high'; private maxAlive = 24; private shadowSize = 2048; private pixelRatio = 1;
  private fpsAcc = 0; private fpsN = 0; private slowWindows = 0; private qualityLocked = false;
  private menuCast: Enemy[] = [];

  // player
  private yaw = 0; private pitch = 0; private prevPos = new THREE.Vector3();
  private grounded = true; private coyote = 0; private jumpBuf = 0;
  private hp = 100; private maxHp = 100; private shield = 0; private invuln = 0;
  private dashT = 0; private dashCd = 0; private dashDir = new THREE.Vector3(); private fovKick = 0;
  private parryT = 0; private parryCd = 0; private parryFlash = 0;
  private burnT = 0; private burnAcc = 0; private slowDebuff = 0;
  private landDip = 0; private recoil = 0; private kick = 0; private trauma = 0; private roll = 0;
  private grappleT = 0; private grappleTarget = new THREE.Vector3();
  private exT = 0; private combo = 0; private comboT = 0; private hurtFlash = 0;
  // weapons
  private w = 0; private ammo: number[] = WEAPONS.map((d) => d.mag); private cd = 0; private reloadT = 0; private reloading = false;
  private charge = 0; private swapT = 0; private swapTo = -1; private inspectT = 0;
  private views: (WeaponView | null)[] = WEAPONS.map(() => null);
  private reelAng = [0, 0, 0]; private reelTarget = [0, 0, 0]; private reelPending: { t: number; label: string; syms: number[] } | null = null;
  private bobPhase = 0; private swayX = 0; private swayY = 0; private flashT = 0; private lastReelTick = 0;
  private pickups: Pickup[] = [];
  private ghosts: { mesh: THREE.Mesh; t: number }[] = [];
  private falling: { mesh: THREE.Object3D; y: number; vy: number; crate: Crate }[] = [];
  private autofire = false;
  private tv1 = new THREE.Vector3(); private tv2 = new THREE.Vector3(); private tv3 = new THREE.Vector3(); private fwd = new THREE.Vector3();
  private lastCaption = '';
  private cleanup: (() => void)[] = [];

  constructor(private canvas: HTMLCanvasElement, private host: HTMLElement) {
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = 1.05;
    this.camera.rotation.order = 'YXZ';
    this.wScene.add(this.wRoot, this.wHemi, this.wKey, this.wRim);
    this.wKey.position.set(1, 2, 1); this.wRim.position.set(-0.6, 0.3, -0.2);
    this.fx = new Fx(this.scene);
    this.input = new Input(canvas);
    this.input.onPadChange = (c) => this.toast(c ? 'Gamepad connected' : 'Gamepad disconnected');
    this.pool = new EnemyPool(this.scene);
    this.combat = new Combat(this.scene, this);
    this.post = new Post(this.renderer, this.scene, this.camera, this.wScene, this.wCam);
    this.hud = this.freshHud();
    this.buildPools();
    const touch = typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches;
    this.level = touch ? 'medium' : 'high';
    this.loadMap('canyon', 7);
    this.spawnMenuCast();
    this.applySettings();
    this.bindEvents();
    this.resize();
    this.last = performance.now();
    this.raf = requestAnimationFrame(this.tick);
  }

  // ================================================================ setup
  private freshHud(): HudState {
    return {
      hp: 100, maxHp: 100, shield: 0, ammo: 0, mag: 0, reload: 0, weapon: 0, weaponName: '', charge: 0, coins: 0, score: 0, combo: 0, comboT: 0, wave: 0, waves: 0, stage: '', time: 0, mode: '',
      boss: null, dashCd: 0, parryCd: 0, exT: 0, canSuper: false, canEx: false, reel: [3, 3, 3], reelLabel: '', reelT: 0, hitT: 0, killT: 0, critHit: false, hurt: [], hurtFlash: 0, parryT: 0,
      banner: '', bannerSub: '', bannerT: 0, toasts: [], captions: [], fps: 60, level: 'high', pad: false, over: false, modName: '',
    };
  }

  private buildPools() {
    for (let i = 0; i < 90; i++) { const m = coinMesh(); m.visible = false; this.scene.add(m); this.pickups.push({ active: false, type: 'coin', mesh: m, pos: new THREE.Vector3(), vel: new THREE.Vector3(), ttl: 0, float: false, t: 0 }); }
    for (let i = 0; i < 8; i++) { const m = heartMesh(); m.visible = false; this.scene.add(m); this.pickups.push({ active: false, type: 'heart', mesh: m, pos: new THREE.Vector3(), vel: new THREE.Vector3(), ttl: 0, float: false, t: 0 }); }
    for (let i = 0; i < 4; i++) {
      const g = new THREE.Mesh(new THREE.PlaneGeometry(1.1, 2.2), new THREE.MeshBasicMaterial({ map: T.ghost(), transparent: true, depthWrite: false, opacity: 0 }));
      g.visible = false; this.scene.add(g); this.ghosts.push({ mesh: g, t: 0 });
    }
  }

  private bindEvents() {
    const on = <K extends keyof WindowEventMap>(t: K, f: (e: WindowEventMap[K]) => void) => { window.addEventListener(t, f as EventListener); this.cleanup.push(() => window.removeEventListener(t, f as EventListener)); };
    const ro = new ResizeObserver(() => this.resize());
    ro.observe(this.host); this.cleanup.push(() => ro.disconnect());
    on('resize', () => this.resize());
    on('orientationchange', () => { setTimeout(() => this.resize(), 150); });
    on('blur', () => { if (this.state === 'playing') this.pause(); });
    const vis = () => { if (document.hidden) { if (this.state === 'playing') this.pause(); this.input.releaseAll(); this.sfx.suspend(); } else if (this.state !== 'menu' || this.settings.music > 0) this.sfx.resume(); };
    document.addEventListener('visibilitychange', vis); this.cleanup.push(() => document.removeEventListener('visibilitychange', vis));
    const lock = () => { if (this.state === 'playing' && !this.input.locked && !this.input.softLook && !this.isTouch()) this.pause(); };
    document.addEventListener('pointerlockchange', lock); this.cleanup.push(() => document.removeEventListener('pointerlockchange', lock));
  }

  isTouch() { return typeof matchMedia === 'function' && matchMedia('(pointer: coarse)').matches; }

  resize() {
    const w = Math.max(2, this.host.clientWidth), h = Math.max(2, this.host.clientHeight);
    this.renderer.setPixelRatio(this.pixelRatio); this.renderer.setSize(w, h, false);
    this.canvas.style.width = '100%'; this.canvas.style.height = '100%';
    this.camera.aspect = w / h; this.camera.updateProjectionMatrix();
    this.wCam.aspect = w / h; this.wCam.updateProjectionMatrix();
    this.post.setSize(w, h, this.pixelRatio);
  }

  applySettings() {
    const s = this.settings;
    this.sfx.setVolumes({ master: s.master, music: s.music, sfx: s.sfx, muted: s.muted });
    this.input.bindings = s.bindings;
    Enemy.bigMarkers = s.colorblind; this.combat.bigProj = s.colorblind;
    this.autofire = s.autofire;
    if (s.quality !== 'auto') this.level = s.quality;
    this.qualityLocked = s.quality !== 'auto';
    this.applyLevel(this.level);
    storeSettings(s);
  }

  private applyLevel(l: Level) {
    this.level = l;
    const dpr = window.devicePixelRatio || 1;
    const q = { low: { pr: Math.min(dpr, 1), sh: 0, bloom: false, lens: false, ol: false, fx: 0.35, amb: false, max: 12, post: false }, medium: { pr: Math.min(dpr, 1.5), sh: 1024, bloom: true, lens: true, ol: true, fx: 0.7, amb: true, max: 18, post: true }, high: { pr: Math.min(dpr, 2), sh: 2048, bloom: true, lens: true, ol: true, fx: 1, amb: true, max: 24, post: true } }[l];
    this.pixelRatio = q.pr * this.settings.resScale;
    this.post.enabled = q.post; this.post.setEffects(q.bloom, q.lens);
    setOutlineEnabled(q.ol); this.fx.setCap(q.fx); this.maxAlive = q.max; this.shadowSize = q.sh;
    this.applyShadow(); this.applyMapFx();
    this.resize();
    this.hud.level = l;
  }
  private applyShadow() {
    const sun = this.map.sun;
    sun.castShadow = this.shadowSize > 0;
    if (this.shadowSize > 0 && sun.shadow.mapSize.x !== this.shadowSize) { sun.shadow.mapSize.set(this.shadowSize, this.shadowSize); sun.shadow.map?.dispose(); sun.shadow.map = null; }
  }
  private applyMapFx() {
    const k = this.map.look;
    this.fx.setAmbient(k.dust, true, this.level !== 'low');
    this.post.setBloom(k.bloom, k.thr);
    this.wHemi.color.set(k.wh); this.wHemi.groundColor.set(k.wg);
    this.wKey.color.set(k.wk); this.wRim.color.set(k.wr);
    this.renderer.toneMappingExposure = this.map.exposure ?? 1.05;
    if (this.map.grade) this.post.setGrade(this.map.grade);
    this.lights.setEnabled(this.level !== 'low');
  }

  private loadMap(id: MapId, seed: number) {
    if (this.map) this.map.dispose();
    this.map = buildMap(id, this.scene, this.renderer, seed);
    this.scene.fog = this.map.fog; this.scene.background = new THREE.Color(this.map.bg);
    this.applyShadow(); this.applyMapFx();
    this.sfx.startMusic(this.map.mood);
  }

  setQuality(q: Settings['quality']) { this.settings.quality = q; this.applySettings(); }

  // ================================================================ run control
  start(mode: ModeId, stage = 0) {
    this.sfx.unlock();
    this.lastStart = { mode, stage };
    const seed = hashString(todayKey());
    const daily = mode === 'daily';
    const up = (id: string) => this.save.upgrades[id] ?? 0;
    const mod = daily ? DAILY_MODS[seed % DAILY_MODS.length].id : '';
    this.maxHp = Math.round((100 + 10 * up('hp')) * (mod === 'glass' ? 0.6 : 1));
    this.run = {
      mode, stageIdx: stage, stageStart: stage, cfg: CAMPAIGN[0], wave: 0, queue: [], spawnT: 0, intermission: 2.5, bossDone: false, phase: 'idle',
      score: 0, kills: 0, time: 0, coins: 0, coinsGot: 0, penalty: 0, waveHurt: false, diff: 1, rng: daily ? new Rng(seed) : new Rng(Date.now()), seed, mod, won: false,
    };
    this.hp = this.maxHp; this.shield = this.save.charms.includes('shield') ? 20 : 0;
    this.ammo = WEAPONS.map((d) => d.mag); this.w = 0; this.cd = 0; this.reloading = false; this.reloadT = 0; this.charge = 0; this.swapTo = -1; this.exT = 0;
    this.combo = 0; this.comboT = 0; this.burnT = 0; this.slowDebuff = 0; this.invuln = 1; this.result = null; this.hud = this.freshHud(); this.hud.level = this.level;
    this.hud.mode = mode; this.hud.modName = mod ? DAILY_MODS.find((m) => m.id === mod)!.name : '';
    this.save.stats.runs++;
    this.loadStage(stage);
    this.state = 'playing';
    this.input.capture = true; this.input.releaseAll();
    if (!this.isTouch()) this.input.requestLock();
    this.acc = 0; this.last = performance.now();
  }

  private stageCfg(i: number): StageCfg | null {
    const m = this.run.mode;
    if (m === 'campaign') return CAMPAIGN[i] ?? null;
    if (m === 'endless') return { name: `Endless Stage ${i + 1}`, map: i % 2 ? 'night' : 'canyon', waves: 5, boss: i % 2 ? BOSSES[(i >> 1) % 3] : undefined, blurb: i % 2 ? 'A boss crashes the party.' : 'Survive.' };
    if (m === 'bossrush') return i < 3 ? { name: ['Sunflower King', 'Crowned Dome', 'UFO Mothership'][i], map: i === 0 ? 'canyon' : 'night', waves: 0, boss: BOSSES[i], blurb: 'Boss ' + (i + 1) + ' of 3' } : null;
    if (m === 'daily') return i === 0 ? { name: 'Daily Challenge', map: this.run.seed % 2 ? 'night' : 'canyon', waves: 6, blurb: this.hud.modName || 'Same seed for everyone' } : null;
    return i === 0 ? { name: 'Time Attack', map: 'canyon', waves: 6, blurb: 'Six waves. Hits cost 2 seconds.' } : null;
  }

  private loadStage(i: number) {
    const cfg = this.pickMap(this.stageCfg(i), i);
    if (!cfg) { this.endRun(true); return; }
    const r = this.run;
    r.stageIdx = i; r.cfg = cfg; r.wave = 0; r.queue = []; r.bossDone = false; r.phase = 'idle'; r.intermission = 3;
    this.clearWorld();
    this.loadMap(cfg.map, r.seed + i * 31); // fresh crates and props every stage
    this.playerPos.copy(this.map.start); this.prevPos.copy(this.playerPos); this.playerVel.set(0, 0, 0); this.yaw = 0; this.pitch = 0;
    this.map.coinSpots.forEach((p) => this.spawnPickup('coin', p.x, p.y, p.z, true));
    this.hp = Math.min(this.maxHp, this.hp + this.maxHp * (i === r.stageStart ? 0 : 0.5));
    this.banner(cfg.name, cfg.blurb, 3);
    this.hud.stage = cfg.name; this.hud.waves = cfg.waves + (cfg.boss ? 1 : 0);
  }

  private clearWorld() {
    for (const e of this.enemies) this.pool.release(e);
    this.enemies.length = 0;
    for (const p of this.pickups) { p.active = false; p.mesh.visible = false; }
    for (const f of this.falling) f.mesh.removeFromParent();
    this.falling.length = 0;
    this.combat.clear(); this.fx.clear(); this.numbers.clear(); this.lights.clear();
    for (const e of this.menuCast) this.pool.release(e);
    this.menuCast.length = 0;
  }

  private spawnMenuCast() {
    const defs = ['leaf', 'sun', 'blob', 'knight', 'sunFire', 'bomb', 'leafIce', 'drummer', 'leafArmor', 'jack', 'tank', 'mimic', 'snake', 'globe', 'magnet', 'scissors', 'glue'];
    defs.forEach((id, i) => {
      const e = this.pool.acquire(id), a = (i / defs.length) * TAU + 0.4, r = 8 + (i % 3) * 2.5;
      e.reset(Math.cos(a) * r, Math.sin(a) * r, 1, 1, 1, 1);
      e.state = 'idle'; e.t = 1; e.yaw = Math.atan2(-Math.cos(a), -Math.sin(a)); e.pos.y = 0; e.prev.copy(e.pos);
      this.menuCast.push(e);
    });
  }

  pause() { if (this.state !== 'playing') return; this.state = 'paused'; this.input.capture = false; this.input.releaseAll(); this.input.exitLock(); }
  resume() { if (this.state !== 'paused') return; this.state = 'playing'; this.input.capture = true; this.input.releaseAll(); if (!this.isTouch()) this.input.requestLock(); this.last = performance.now(); this.acc = 0; }
  quitToMenu() {
    if (this.state === 'playing' || this.state === 'paused') this.bank(false);
    this.state = 'menu'; this.input.capture = false; this.input.exitLock(); this.input.releaseAll();
    this.clearWorld(); this.hud.boss = null; this.loadMap('canyon', 7); this.spawnMenuCast();
  }
  nextStage() {
    if (this.state !== 'stageclear') return;
    this.state = 'playing'; this.input.capture = true; this.input.releaseAll(); if (!this.isTouch()) this.input.requestLock();
    this.loadStage(this.run.stageIdx + 1); this.last = performance.now();
  }

  private bank(win: boolean) {
    const r = this.run; if (!r) return;
    this.save.coins += r.coins; r.coins = 0;
    const key = r.mode;
    let best = false;
    if (r.mode === 'timeattack') {
      const t = Math.round((r.time + r.penalty) * 10) / 10;
      const prev = this.save.scores.timeattack_best ?? 0;
      if (win && (prev === 0 || t < prev)) { this.save.scores.timeattack_best = t; best = true; }
    }
    if (r.score > (this.save.scores[key] ?? 0)) { this.save.scores[key] = r.score; best = best || r.mode !== 'timeattack'; }
    if (r.mode === 'daily') { const d = todayKey(); if (this.save.daily.date !== d || r.score > this.save.daily.score) this.save.daily = { date: d, score: r.score }; }
    if (r.mode === 'campaign' && win) this.save.campaign = Math.max(this.save.campaign, CAMPAIGN.length);
    if (win && r.mode === 'campaign') this.unlock('campaign');
    storeSave(this.save);
    return best;
  }

  private endRun(win: boolean) {
    const r = this.run;
    if (this.state === 'gameover' || this.state === 'victory') return;
    const best = !!this.bank(win);
    const t = r.time + r.penalty;
    this.result = {
      title: win ? 'VICTORY!' : 'GAME OVER', win, mode: r.mode, score: Math.floor(r.score), kills: r.kills, time: t, coins: r.coinsGot, best,
      note: r.mode === 'timeattack' ? `Final time ${t.toFixed(1)}s (includes ${r.penalty}s of penalties)` : r.mode === 'endless' ? `Reached stage ${r.stageIdx + 1}, wave ${r.wave}` : '', canContinue: false,
    };
    this.state = win ? 'victory' : 'gameover';
    this.input.capture = false; this.input.exitLock(); this.input.releaseAll();
    if (!win) { this.slowT = 1; this.sfx.play('boom'); }
  }

  // ================================================================ main loop
  private tick = (now: number) => {
    if (this.disposed) return;
    this.raf = requestAnimationFrame(this.tick);
    let dt = (now - this.last) / 1000; this.last = now;
    if (!Number.isFinite(dt) || dt < 0) dt = STEP;
    dt = Math.min(dt, 0.1);
    this.trackFps(dt);
    this.input.poll(dt);
    if (this.state === 'playing') {
      if (this.input.pressed.pause) this.pause();
      this.applyLook();
      if (this.hitStop > 0) this.hitStop -= dt;
      else {
        if (this.slowT > 0) { this.slowT -= dt; this.timeScale = damp(this.timeScale, 0.35, 10, dt); } else this.timeScale = damp(this.timeScale, 1, 6, dt);
        this.acc += dt * this.timeScale;
        let n = 0;
        while (this.acc >= STEP && n++ < 5) { this.simulate(STEP); this.acc -= STEP; if (n === 1) this.input.consumePressed(); }
        if (n >= 5) this.acc = 0;
      }
    } else this.input.consumePressed();
    this.renderFrame(this.state === 'paused' ? 0 : dt, this.acc / STEP);
    this.input.endFrame();
  };

  private trackFps(dt: number) {
    this.fpsAcc += dt; this.fpsN++;
    if (this.fpsAcc >= 1) {
      const fps = this.fpsN / this.fpsAcc; this.hud.fps = Math.round(fps); this.fpsAcc = 0; this.fpsN = 0;
      if (this.state === 'playing' && !this.qualityLocked && this.level !== 'low') {
        this.slowWindows = fps < 42 ? this.slowWindows + 1 : 0;
        if (this.slowWindows >= 3) { this.slowWindows = 0; this.applyLevel(this.level === 'high' ? 'medium' : 'low'); this.toast('Quality lowered to keep the framerate smooth'); }
      }
    }
  }

  private applyLook() {
    const i = this.input, k = 0.0022 * this.settings.sens;
    this.yaw -= i.lookX * k; this.pitch = clamp(this.pitch - i.lookY * k, -1.5, 1.5);
    if (this.yaw > Math.PI) this.yaw -= TAU; else if (this.yaw < -Math.PI) this.yaw += TAU;
    this.swayX = damp(this.swayX, clamp(i.lookX * 0.0009, -0.06, 0.06), 12, 1 / 60); this.swayY = damp(this.swayY, clamp(i.lookY * 0.0009, -0.06, 0.06), 12, 1 / 60);
  }

  // ================================================================ simulation
  private simulate(dt: number) {
    this.time += dt; this.run.time += dt;
    this.prevPos.copy(this.playerPos);
    this.updatePlayer(dt);
    this.updateWeapon(dt);
    this.updateDirector(dt);
    for (let i = this.enemies.length - 1; i >= 0; i--) {
      const e = this.enemies[i];
      e.update(dt, this);
      if (!e.active) { this.pool.release(e); this.enemies[i] = this.enemies[this.enemies.length - 1]; this.enemies.pop(); }
    }
    this.combat.update(dt);
    this.updatePickups(dt);
    this.updateFalling(dt);
    this.updateTimers(dt);
  }

  private forward(out: THREE.Vector3) {
    const cp = Math.cos(this.pitch);
    return out.set(-Math.sin(this.yaw) * cp, Math.sin(this.pitch), -Math.cos(this.yaw) * cp);
  }

  private upg(id: string) { return this.save.upgrades[id] ?? 0; }
  private charm(id: string) { return this.save.charms.includes(id); }

  private updatePlayer(dt: number) {
    const i = this.input, p = this.playerPos, v = this.playerVel;
    this.invuln = Math.max(0, this.invuln - dt); this.dashCd = Math.max(0, this.dashCd - dt); this.parryCd = Math.max(0, this.parryCd - dt);
    this.parryFlash = Math.max(0, this.parryFlash - dt); this.landDip = Math.max(0, this.landDip - dt * 0.8); this.fovKick = Math.max(0, this.fovKick - dt * 3.5);
    if (this.slowDebuff > 0) this.slowDebuff -= dt;
    if (this.burnT > 0) { this.burnT -= dt; this.burnAcc += dt; if (this.burnAcc >= 0.7) { this.burnAcc = 0; this.hurtPlayer(3, p, 'contact', true); } }
    const sy = Math.sin(this.yaw), cy = Math.cos(this.yaw);
    const wx = cy * i.moveX - sy * i.moveY, wz = -sy * i.moveX - cy * i.moveY;
    const maxSp = 7.4 * (this.charm('soles') ? 1.12 : 1) * (this.slowDebuff > 0 ? 0.6 : 1);
    const acc = (this.grounded ? 75 : 22) * dt;
    v.x = approach(v.x, wx * maxSp, acc); v.z = approach(v.z, wz * maxSp, acc);

    // dash
    if (i.pressed.dash && this.dashCd <= 0 && this.dashT <= 0) {
      if (Math.abs(wx) + Math.abs(wz) > 0.1) this.dashDir.set(wx, 0, wz).normalize(); else this.dashDir.set(-sy, 0, -cy);
      this.dashT = 0.2; this.invuln = Math.max(this.invuln, 0.3); this.dashCd = 1.1 * (1 - 0.08 * this.upg('dash'));
      this.fovKick = 1; this.save.stats.dashes++; this.sfx.play('dash'); this.spawnGhost(); this.ghostAt = 0.1; this.checkAch();
    }
    if (this.ghostAt > 0) { this.ghostAt -= dt; if (this.ghostAt <= 0) this.spawnGhost(); }
    if (this.dashT > 0) { this.dashT -= dt; v.x = this.dashDir.x * 26; v.z = this.dashDir.z * 26; if (this.dashT <= 0) { v.x *= 0.35; v.z *= 0.35; } }

    // jump with coyote time + buffer
    this.coyote = this.grounded ? 0.1 : this.coyote - dt; this.jumpBuf = i.pressed.jump ? 0.12 : this.jumpBuf - dt;
    const grav = this.run.mod === 'lowgrav' ? 15 : 28;
    if (this.jumpBuf > 0 && this.coyote > 0) { v.y = this.run.mod === 'lowgrav' ? 7.5 : 9.4; this.jumpBuf = 0; this.coyote = 0; this.grounded = false; }

    // grapple pull
    if (this.grappleT > 0) {
      this.grappleT -= dt;
      this.tv1.set(this.grappleTarget.x - p.x, this.grappleTarget.y - (p.y + 1), this.grappleTarget.z - p.z);
      const d = this.tv1.length();
      if (d < 1.8 || this.grappleT <= 0) { this.grappleT = 0; v.multiplyScalar(0.4); }
      else { this.tv1.multiplyScalar(34 / d); v.x = this.tv1.x; v.z = this.tv1.z; v.y = this.tv1.y; }
    } else v.y -= grav * dt;

    // integrate + collide
    p.x += v.x * dt; p.z += v.z * dt;
    resolveCircle(p, this.playerRadius, this.playerHeight, this.colliders, 0.45);
    const lim = this.map.radius - this.playerRadius, r = Math.hypot(p.x, p.z);
    if (r > lim) { p.x *= lim / r; p.z *= lim / r; }
    const feet = p.y; p.y += v.y * dt;
    const g = groundAt(p.x, p.z, this.playerRadius, feet, this.colliders, 0.45);
    if (p.y <= g && v.y <= 0) {
      if (!this.grounded && v.y < -7) { this.landDip = 0.14; this.fx.scraps(p.x, g + 0.1, p.z, 6, 0xb98a52, 2.5); this.sfx.play('bounce', 0.6); }
      p.y = g; v.y = 0; this.grounded = true;
    } else this.grounded = false;
    if (p.y < 0) p.y = 0;
    this.eye.set(p.x, p.y + EYE - this.landDip, p.z);

    // parry window
    if (i.pressed.parry && this.parryCd <= 0) {
      this.parryT = 0.28; this.parryCd = 0.9; this.parryFlash = 0.28; this.sfx.play('click', 0.7);
      this.forward(this.fwd); this.fx.ring(this.eye.x + this.fwd.x * 1.2, this.eye.y + this.fwd.y * 1.2, this.eye.z + this.fwd.z * 1.2, 0xffffff, 1.6, 0.25, this.fwd.clone());
    }
    if (this.parryT > 0) {
      this.parryT -= dt; this.forward(this.fwd);
      const n = this.combat.parry(this.eye, this.fwd, 3.6);
      for (const e of this.enemies) if (e.alive && !e.isBoss && Math.hypot(e.pos.x - p.x, e.pos.z - p.z) < 2.6 + e.def.radius && e.state === 'leap') { e.addStun(1.2); e.knock(e.pos.x - p.x, e.pos.z - p.z, 14); }
      if (n > 0) { this.save.stats.parries += n; this.parryT = 0; this.parryCd = 0.35; this.hitStop = 0.07; this.shake(0.25); this.sfx.play('parry'); this.toast('PARRY!'); this.caption('[Projectile deflected]'); this.checkAch(); }
    }
    this.hud.parryT = this.parryFlash;

    // EX & Super
    if (i.pressed.ex && this.run.coins >= 3 && this.exT <= 0) { this.run.coins -= 3; this.exT = 5; this.sfx.play('jackpot'); this.banner('EX: PERFECT AIM', 'Every shot is a bullseye, no ammo used', 1.5); }
    if (i.pressed.super && this.run.coins >= 5) this.castSuper();
    if (this.exT > 0) this.exT -= dt;
    // weapon swap
    if (i.slotPressed >= 0) {
      // number keys 1-0 pick weapons 1-10; pressing the key of the weapon in hand flips to its second-bank partner (11-18)
      const s = i.slotPressed, target = this.w === s && s + 10 < WEAPONS.length ? s + 10 : s;
      if (target < WEAPONS.length) this.swapWeapon(target);
    }
    if (i.pressed.next || i.wheel > 0) this.swapWeapon((this.w + 1) % WEAPONS.length);
    if (i.pressed.prev || i.wheel < 0) this.swapWeapon((this.w + WEAPONS.length - 1) % WEAPONS.length);
    if (i.pressed.inspect && this.inspectT <= 0) this.inspectT = 1.6;
  }
  private ghostAt = 0; private fwT = 1; private blastV = new THREE.Vector3();

  private spawnGhost() {
    const gh = this.ghosts.find((g) => g.t <= 0) ?? this.ghosts[0];
    gh.t = 0.55; gh.mesh.visible = true; gh.mesh.position.set(this.playerPos.x, this.playerPos.y + 1.1, this.playerPos.z);
  }

  private castSuper() {
    this.run.coins -= 5;
    const p = this.playerPos;
    this.fx.ring(p.x, 0.15, p.z, 0xffd54a, 20, 0.7); this.fx.ring(p.x, 0.15, p.z, 0xff3b5c, 15, 0.55); this.fx.ring(p.x, 0.15, p.z, 0x33d6ff, 10, 0.45);
    this.fx.confetti(p.x, 1.5, p.z, 260, 16);
    for (const e of this.enemies) if (e.alive && Math.hypot(e.pos.x - p.x, e.pos.z - p.z) < 20) { this.damageEnemy(e, e.isBoss ? 70 : 140, false, true); if (e.alive) { e.addStun(2); e.knock(e.pos.x - p.x, e.pos.z - p.z, 20); } }
    for (const c of this.crates) if (c.collider.alive && Math.hypot(c.mesh.position.x - p.x, c.mesh.position.z - p.z) < 14) this.damageCrate(c, 100);
    this.combat.clearHostile();
    this.hp = Math.min(this.maxHp, this.hp + 15);
    this.hitStop = 0.12; this.slowT = 0.8; this.shake(0.9); this.sfx.play('super');
    this.banner('CARNIVAL FINALE!', '', 1.2); this.caption('[Confetti finale]');
  }

  hurtPlayer(dmg: number, from: THREE.Vector3, kind: HurtKind, silent = false) {
    if (this.state !== 'playing' || (this.invuln > 0 && !silent) || this.hp <= 0) return;
    const diff = this.settings.difficulty === 'easy' ? 0.6 : this.settings.difficulty === 'hard' ? 1.4 : 1;
    let d = dmg * diff;
    if (this.shield > 0) { const a = Math.min(this.shield, d); this.shield -= a; d -= a; }
    this.hp -= d;
    if (!silent) {
      this.invuln = 0.45; this.hurtFlash = 1; this.shake(0.35); this.sfx.play('hurt'); this.run.waveHurt = true;
      if (this.run.mode === 'timeattack') this.run.penalty += 2;
      const dx = from.x - this.playerPos.x, dz = from.z - this.playerPos.z, l = Math.hypot(dx, dz) || 1, sx = dx / l, sz = dz / l;
      const sy = Math.sin(this.yaw), cy = Math.cos(this.yaw);
      this.hud.hurt.push({ ang: Math.atan2(sx * cy - sz * sy, -sx * sy - sz * cy), t: 1.2 });
      if (this.hud.hurt.length > 4) this.hud.hurt.shift();
      if (kind === 'fire') { this.burnT = 2.1; this.caption('[You are on fire]'); }
      if (kind === 'ice') { this.slowDebuff = 2; this.caption('[Frozen — slowed]'); }
      if (kind === 'contact') { this.playerVel.x += -sx * 8; this.playerVel.z += -sz * 8; }
      this.combo = 0; this.comboT = 0;
    }
    if (this.hp <= 0) { this.hp = 0; this.endRun(false); }
  }

  shake(a: number) { this.trauma = Math.min(1, this.trauma + a * this.settings.shake); }

  /** Area blast (bombs, mortar shells): hurts the player in range; optionally hurts other enemies and crates too. */
  blast(x: number, y: number, z: number, R: number, dmg: number, hurtEnemies = true, color = 0xff9a2e) {
    const p = this.playerPos, dp = Math.hypot(p.x - x, p.y + 0.9 - y, p.z - z);
    if (dp < R + 0.4) this.hurtPlayer(dmg * (1 - clamp(dp / (R + 0.4), 0, 1) * 0.5), this.blastV.set(x, y, z), 'shock');
    if (hurtEnemies) {
      for (const e of this.enemies) {
        if (!e.alive) continue;
        const dist = Math.hypot(e.pos.x - x, e.pos.y + e.hitCenterY - y, e.pos.z - z) - e.hitR;
        if (dist < R) this.damageEnemy(e, dmg * 1.5 * (1 - clamp(dist / R, 0, 1) * 0.6), false, false);
      }
    }
    for (const c of this.crates) if (c.collider.alive && Math.hypot(c.mesh.position.x - x, c.mesh.position.z - z) < R + 0.8) this.damageCrate(c, dmg * 1.5);
    this.fx.confetti(x, y, z, 50, 9); this.fx.ring(x, Math.max(0.1, y), z, color, R, 0.45); this.fx.ring(x, Math.max(0.1, y), z, 0xffffff, R * 0.6, 0.3); this.fx.sparks(x, y, z, 18, color);
    this.sfx.play('boom'); this.shake(clamp(0.5 * (1 - dp / 28), 0, 0.6));
  }
  grapple(target: THREE.Vector3) { this.grappleTarget.copy(target); this.grappleT = 0.8; this.playerVel.y = Math.max(this.playerVel.y, 2); this.caption('[Tape yanks you forward]'); }

  caption(text: string) {
    if (!this.settings.subtitles || text === this.lastCaption && this.hud.captions.length) return;
    this.lastCaption = text; this.hud.captions.push({ text, t: 3 }); if (this.hud.captions.length > 3) this.hud.captions.shift();
  }
  toast(text: string) { this.hud.toasts.push({ text, t: 2.6 }); if (this.hud.toasts.length > 4) this.hud.toasts.shift(); }

  // ---------------------------------------------------------------- extras: power-ups, hazards, twists
  /** Fun-factor systems (power-ups, wave twists, trampolines, ice, lava vents, sticky zones, TNT crates). */
  readonly extras = new Extras(this.scene, this);
  /** Arena chosen in the menu for Endless Survival and Time Attack ('auto' cycles through every arena). */
  mapPick: MapId | 'auto' = 'auto';

  // ---------------------------------------------------------------- lighting, damage feedback, reload timing
  /** Pooled point lights for muzzle flashes, blasts and kills. */
  readonly lights = new DynLights(this.scene);
  readonly numbers = new DamageNumbers(this.scene);
  /** Element of the damage being dealt right now (set by the combat system around its damage calls). */
  hitElem = '';
  private sinceShot = 9; private perfectT = 0; private reloadTried = false;
  flash(x: number, y: number, z: number, color: number, intensity: number, dur: number, range = 18) { this.lights.flash(x, y, z, color, intensity, dur, range); }

  /** Applies the arena picker and per-mode rotation on top of the base stage table. */
  private pickMap(cfg: StageCfg | null, i: number): StageCfg | null {
    this.extras.reset();
    if (!cfg) return null;
    const pick = this.mapPick;
    switch (this.run.mode) {
      case 'endless': return { ...cfg, map: pick !== 'auto' ? pick : this.extras.mapOrder(i), boss: i % 3 === 2 ? BOSSES[Math.floor(i / 3) % 3] : undefined, blurb: i % 3 === 2 ? 'A boss crashes the party.' : 'Survive.' };
      case 'timeattack': return pick !== 'auto' ? { ...cfg, map: pick } : cfg;
      case 'daily': return { ...cfg, map: this.extras.mapOrder(this.run.seed) };
      default: return cfg;
    }
  }
  launchPlayer(vy: number) { this.playerVel.y = vy; this.grounded = false; this.coyote = 0; }
  slowPlayer(t: number) { this.slowDebuff = Math.max(this.slowDebuff, t); }
  grantShield(n: number) { this.shield = Math.min(60, this.shield + n); }
  isGrounded() { return this.grounded; }
  getCombo() { return this.combo; }
  powerBlast() { this.combat.explode(this.playerPos.x, 1, this.playerPos.z, 10, 160, 1.5, 0xffd54a, true); }
  stickyZone(x: number, z: number, r: number, life: number, ice = false) { this.extras.stickyZone(x, z, r, life, ice); }
  reshapeQueue(f: (q: string[]) => string[]) { this.run.queue = f(this.run.queue); }
  dropCoins(x: number, y: number, z: number, n: number) { for (let k = 0; k < Math.min(n, 12); k++) this.spawnPickup('coin', x, Math.max(0.6, y), z, false); }
  vacuumCoins() {
    let n = 0;
    for (const p of this.pickups) if (p.active && p.type === 'coin') { p.active = false; p.mesh.visible = false; n++; }
    this.run.coins += n; this.run.coinsGot += n; this.save.stats.coinsEver += n;
    if (n > 0) this.sfx.play('coin', 1.2);
  }
  private banner(text: string, sub = '', t = 2.2) { this.hud.banner = text; this.hud.bannerSub = sub; this.hud.bannerT = t; this.extras.onBanner(text); }

  // ---------------------------------------------------------------- weapons
  private view(i: number): WeaponView { return (this.views[i] ??= buildWeaponView(WEAPONS[i])); }

  private swapWeapon(to: number) {
    if (to === this.w || this.swapTo >= 0) return;
    this.swapTo = to; this.swapT = 0; this.reloading = false; this.reloadT = 0; this.charge = 0; this.sfx.play('click', 0.8);
  }

  private dmgMul() {
    return (1 + 0.12 * (this.save.weaponLv[WEAPONS[this.w].id] ?? 0)) * (1 + 0.06 * this.upg('dmg')) * (this.run.mod === 'glass' ? 1.5 : 1) * (this.extras.pw.damage > 0 ? 1.8 : 1) * (this.perfectT > 0 ? 1.25 : 1);
  }

  private updateWeapon(dt: number) {
    const i = this.input, def = WEAPONS[this.w];
    this.extras.update(dt, this.map); // power-ups, hazards, twists: runs once per simulation step
    this.cd -= dt * (this.extras.pw.rapid > 0 ? 2 : 1); this.kick = damp(this.kick, 0, 14, dt); this.recoil = damp(this.recoil, 0, 9, dt); this.inspectT = Math.max(0, this.inspectT - dt);
    if (this.swapTo >= 0) {
      this.swapT += dt;
      if (this.swapT >= 0.14 && this.w !== this.swapTo) { this.w = this.swapTo; this.cd = Math.max(this.cd, 0.1); this.mountView(); }
      if (this.swapT >= 0.3) this.swapTo = -1;
      return;
    }
    if (this.reloading) {
      if (this.reloadT === 0) this.reloadTried = false;
      this.reloadT += dt;
      const total = def.reload * (1 - 0.08 * this.upg('reload'));
      if (i.pressed.reload && !this.reloadTried) {
        // reload mini-game: tap inside the gold zone to finish instantly with a damage buff; tap outside and it jams
        const kk = this.reloadT / total;
        if (kk >= RELOAD_ZONE[0] && kk <= RELOAD_ZONE[1]) { this.reloadT = total; this.perfectT = 6; this.toast('PERFECT LOAD! +25% damage'); this.sfx.play('parry', 1.3); this.fx.sparks(this.eye.x, this.eye.y, this.eye.z, 10, 0xffd54a); }
        else { this.reloadTried = true; this.reloadT = Math.max(0, this.reloadT - 0.4); this.sfx.play('empty'); this.toast('Jammed! Wait it out'); }
      }
      const k = clamp(this.reloadT / total, 0, 1);
      const shown = Math.floor(k * def.mag);
      if (shown > this.ammo[this.w]) { this.ammo[this.w] = shown; if (shown % Math.max(1, Math.floor(def.mag / 8)) === 0) this.sfx.play('reload', 0.8 + k * 0.6); }
      if (k >= 1) { this.reloading = false; this.ammo[this.w] = def.mag; this.sfx.play('reloadDone'); this.caption('[Capsules clack into place]'); }
      return;
    }
    if (i.pressed.reload && this.ammo[this.w] < def.mag) { this.startReload(); return; }
    // auto-fire toggle: only fires while an enemy is under the crosshair
    const over = this.autofire && this.enemyUnderCrosshair();
    const held = i.down.fire || over;
    this.hud.over = this.enemyUnderCrosshair();
    if (def.charge) {
      if (held && this.cd <= 0 && this.ammo[this.w] > 0) this.charge = Math.min(def.charge, this.charge + dt);
      else if (this.charge > 0.04 && !held) { this.shoot(clamp(this.charge / def.charge, 0, 1)); this.charge = 0; }
      else if (!held) this.charge = 0;
    } else if (held && this.cd <= 0) {
      if (this.ammo[this.w] > 0 || this.exT > 0) this.shoot(0);
      else { this.sfx.play('empty'); this.cd = 0.25; this.startReload(); }
    }
    if (this.ammo[this.w] <= 0 && !this.reloading && this.exT <= 0) this.startReload();
  }

  private startReload() {
    if (this.reloading) return;
    this.reloading = true; this.reloadT = 0; this.charge = 0;
    this.sfx.play('reload'); this.caption('[Reloading]');
  }

  private enemyUnderCrosshair(): boolean {
    this.forward(this.fwd);
    const o = this.eye, d = this.fwd;
    const worldD = this.rayWorld(o, d, 70);
    for (const e of this.enemies) {
      if (!e.alive) continue;
      const t = segSphere(o.x, o.y, o.z, d.x * worldD, d.y * worldD, d.z * worldD, e.pos.x, e.pos.y + e.hitCenterY, e.pos.z, e.hitR);
      if (t >= 0) return true;
    }
    return false;
  }

  private rayWorld(o: THREE.Vector3, d: THREE.Vector3, max: number): number {
    let best = 1;
    const dx = d.x * max, dy = d.y * max, dz = d.z * max;
    for (const c of this.colliders) { if (!c.alive) continue; const t = segAABB(o.x, o.y, o.z, dx, dy, dz, c); if (t >= 0 && t < best) best = t; }
    if (dy < 0) { const t = o.y / -dy; if (t >= 0 && t < best) best = t; }
    return best * max;
  }

  private muzzleWorld(out: THREE.Vector3) {
    const v = this.view(this.w).muzzle.getWorldPosition(this.tv1);
    v.project(this.wCam);
    this.tv2.set(v.x, v.y, 0.5).unproject(this.camera);
    return out.copy(this.tv2).sub(this.camera.position).normalize().multiplyScalar(0.8).add(this.camera.position);
  }

  /** Roll the capsule reel. Returns the symbols and the shot modifier. */
  private rollReel(def: (typeof WEAPONS)[number]) {
    const k = clamp(def.interval / 0.35, 0.18, 1);
    const luck = 0.015 * this.upg('luck') + (this.charm('glitter') ? 0.04 : 0);
    const r = Math.random();
    const pStar = (0.025 + luck * 0.5) * k, pBull = pStar + (0.07 + luck) * k, pFlower = pBull + (0.08 + luck) * k;
    let kind: 'star' | 'bull' | 'flower' | 'mixed' = r < pStar ? 'star' : r < pBull ? 'bull' : r < pFlower ? 'flower' : 'mixed';
    if (this.exT > 0) kind = 'bull';
    const syms = kind === 'star' ? [2, 2, 2] : kind === 'bull' ? [1, 1, 1] : kind === 'flower' ? [0, 0, 0] : [Math.floor(Math.random() * 4), Math.floor(Math.random() * 4), Math.floor(Math.random() * 4)];
    if (kind === 'mixed' && syms[0] === syms[1] && syms[1] === syms[2]) syms[2] = (syms[2] + 1) % 4;
    return { kind, syms };
  }

  private shoot(charge: number) {
    const def = WEAPONS[this.w];
    const reel = this.rollReel(def);
    this.cd = def.interval * (this.exT > 0 ? 0.55 : 1);
    if (this.exT <= 0) this.ammo[this.w]--;
    let mul = this.dmgMul(), crit = false, flower = false, jackpot = false, label = '';
    if (reel.kind === 'bull') { crit = true; mul *= 2.2; label = 'BULLSEYE CRIT x2.2'; }
    else if (reel.kind === 'flower') { flower = true; mul *= 1.4; label = 'FLOWER BURST — burning petals'; }
    else if (reel.kind === 'star') { jackpot = true; mul *= 3; label = 'JACKPOT! TRIPLE STAR x3'; this.slowT = 0.7; this.save.stats.jackpots++; this.sfx.play('jackpot'); this.run.coins += 3; this.checkAch(); this.banner('JACKPOT!', 'Triple star super shot', 1.1); }
    // spin the three drums: stagger so they land one after another
    for (let n = 0; n < 3; n++) {
      const tgt = symbolAngle(reel.syms[n]), min = this.reelAng[n] + Math.PI * (2 + n);
      this.reelTarget[n] = tgt + TAU * Math.ceil((min - tgt) / TAU);
    }
    this.reelPending = { t: 0.28, label, syms: reel.syms };
    this.sfx.play('click');
    this.forward(this.fwd);
    const aimD = this.rayWorld(this.eye, this.fwd, 90);
    this.tv3.copy(this.fwd).multiplyScalar(Math.min(aimD, 90)).add(this.eye);
    const muzzle = this.muzzleWorld(this.tv1);
    this.tv2.copy(this.tv3).sub(muzzle);
    if (this.tv2.lengthSq() < 0.5) this.tv2.copy(this.fwd); else this.tv2.normalize();
    const dir = this.tv2.clone();
    this.combat.fire(def, { muzzle: muzzle.clone(), dir, dmgMul: mul, crit, flower, jackpot, charge });
    this.sfx.play(def.sfx);
    muzzleFx(def.id, this.fx, muzzle, dir, charge);
    this.sinceShot = 0;
    this.lights.flash(muzzle.x + dir.x, muzzle.y + dir.y, muzzle.z + dir.z, jackpot ? 0xffd54a : def.color, 70 + def.kick * 35, 0.09, 13 + def.kick * 2); // the shot lights up the world
    if (def.kick >= 2) this.fovKick = Math.max(this.fovKick, Math.min(1, def.kick * 0.18)); // heavy weapons punch the lens (chromatic kick)
    this.recoil += def.kick * 0.0175; this.kick = Math.min(1.6, this.kick + 0.6 + def.kick * 0.25);
    this.shake(def.shake); this.flashT = 0.06;
    if (def.id === 'spring') { this.playerVel.x -= dir.x * 9; this.playerVel.z -= dir.z * 9; this.hitStop = 0.05; this.caption('[Spring cannon boings]'); }
    if (def.id === 'bazooka') this.caption('[Confetti rocket launched]');
    if (jackpot) this.fx.confetti(muzzle.x, muzzle.y, muzzle.z, 40, 9); else if (crit) this.fx.sparks(muzzle.x, muzzle.y, muzzle.z, 12, 0xff3b5c); else if (flower) this.fx.burst(muzzle.x, muzzle.y, muzzle.z, 14, [0xffb02e, 0xff7a1a], 6, 0.5, 0.08, 0.7, 6);
    if (this.ammo[this.w] <= 0 && this.exT <= 0) this.startReload();
  }

  // ---------------------------------------------------------------- enemies
  spawnEnemy(id: string, x: number, z: number, opts?: { fromSky?: boolean }): Enemy | null {
    if (this.enemies.length >= 60) return null;
    const e = this.pool.acquire(id), d = this.difficulty, fast = this.run.mod === 'fastfoes' ? 1.25 : 1;
    e.reset(x, z, 1 + (d - 1) * 0.9, Math.min(1.35, 1 + (d - 1) * 0.15) * fast, 1 + (d - 1) * 0.35, 1 + (d - 1) * 0.25, !!opts?.fromSky);
    this.enemies.push(e);
    const aff = rollAffix(this.rng, d, this.run.wave, e.def, this.enemies.filter((o) => o.alive && o.affix !== '').length);
    if (aff) { e.efx.setAffix(aff); this.caption('[Elite ' + AFFIXES[aff].name.toLowerCase() + ' ' + e.def.name + ': ' + AFFIXES[aff].desc + ']'); }
    this.fx.ring(x, 0.1, z, aff ? AFFIXES[aff].hex : 0xffd54a, 1.6, 0.4); this.fx.confetti(x, 0.3, z, 10, 4);
    return e;
  }

  /** Per-species death effects on top of the generic confetti burst. */
  private deathFx(e: Enemy, cx: number, cy: number, cz: number) {
    const f = this.fx;
    switch (e.def.kind) {
      case 'ghost': f.burst(cx, cy, cz, 30, [0xffffff, 0xf5f0ff, 0xdfe8ff], 5, 0.8, 0.16, 1.6, -1.5); break; // tissue drifts upwards
      case 'knight': f.scraps(cx, cy, cz, 40, 0x8e9bb0, 7); f.sparks(cx, cy, cz, 16, 0xffffff); break; // armour plates clatter
      case 'globe': f.burst(cx, cy, cz, 50, [0xcfeeff, 0xffffff, 0x7fe0ff], 9, 0.6, 0.12, 1.2, 10); f.ring(cx, 0.1, cz, 0x7fe0ff, 3.4, 0.4); break; // glass shatters
      case 'snake': f.burst(cx, cy, cz, 34, [0x34c3b0, 0xf3e7cc], 7, 0.5, 0.14, 1.1, 10); break;
      case 'scissors': f.sparks(cx, cy, cz, 34, 0xffffff); f.scraps(cx, cy, cz, 16, 0xc0c4cc, 6); break;
      case 'crane': f.burst(cx, cy, cz, 26, [0xf3e7cc, 0xc92b2b, 0xffffff], 4, 0.5, 0.16, 2.2, 2.5); break; // folded paper floats down
      case 'magnet': f.ring(cx, cy, cz, 0x7fc8ff, 3, 0.35); f.sparks(cx, cy, cz, 28, 0x7fc8ff); break;
      case 'tank': f.scraps(cx, cy, cz, 40, 0xb0623a, 8); f.burst(cx, cy, cz, 30, [0xe0384a, 0xffd54a, 0x3f8cf0, 0x34c3b0], 8, 0.7, 0.12, 1.3, 9); this.shake(0.15); break; // crayons everywhere
      case 'jack': f.burst(cx, cy, cz, 30, [0xe8b830, 0xffd54a, 0xc92b2b], 8, 0.9, 0.12, 1.2, 8); break; // springs and bells
      case 'mimic': f.scraps(cx, cy, cz, 34, 0xc4935a, 7); break;
      case 'drummer': f.sparks(cx, cy, cz, 24, 0xffd54a); f.ring(cx, 0.1, cz, 0xffd54a, 4, 0.4); break;
      case 'moth': f.burst(cx, cy, cz, 26, [0xe8a04a, 0xf3e7cc], 3, 0.4, 0.1, 1.8, 3); break; // wing dust
      case 'glue': f.burst(cx, cy, cz, 24, [0xd8e04a, 0xf3e7cc], 5, 0.5, 0.14, 1.0, 6); break;
      default: break;
    }
  }

  fireEnemyProj(spec: EProjSpec) { this.combat.fireEnemy(spec); }
  groundMarker(x: number, z: number, r: number, life: number, kind: 'warn' | 'beam') { this.fx.ring(x, 0.1, z, kind === 'warn' ? 0xff3b5c : 0x4aa8ff, r, life, undefined, true); }

  damageEnemy(e: Enemy, dmg: number, silent = false, crit = false, at?: THREE.Vector3) {
    if (!e.alive) return;
    const m = this.hitElem ? elemMult(e.def.id, this.hitElem) : 1; // weakness x1.6, resistance x0.55
    dmg *= m;
    const killed = e.hurt(dmg);
    if (!silent) {
      this.hud.hitT = m > 1 ? 0.3 : 0.18; this.hud.critHit = crit || m > 1;
      const x = at?.x ?? e.pos.x, y = at?.y ?? e.pos.y + e.hitCenterY, z = at?.z ?? e.pos.z;
      this.fx.burst(x, y, z, crit ? 12 : 6, [0x141016, 0x141016, e.def.kind === 'blob' ? 0x3f8cf0 : 0xb98a52], crit ? 6 : 4, 0.4, 0.1, 0.8, 9);
      this.sfx.play(m > 1 || crit ? 'parry' : 'crunch', m > 1 ? 1.7 : crit ? 1.4 : 1);
      if (dmg >= 6 || m !== 1 || crit) this.numbers.spawn(x, y + 0.3, z, String(Math.max(1, Math.round(dmg))), m > 1 ? '#ffd54a' : m < 1 ? '#a8a0b0' : crit ? '#ff6a5a' : '#ffffff', m > 1 ? 1.35 : crit ? 1.2 : 1, 0.9, m > 1 ? 'WEAK!' : m < 1 ? 'resist' : '');
      if (m > 1) this.fx.sparks(x, y, z, 8, 0xffd54a);
    }
    if (killed) this.killEnemy(e);
  }

  private killEnemy(e: Enemy) {
    const r = this.run, d = e.def;
    e.die(); // first: later area damage (popper charm, boss wipe) must not re-kill this enemy
    this.combo = Math.min(50, this.combo + 1); this.comboT = 3.2;
    r.score += d.score * (1 + Math.min(this.combo, 40) * 0.1);
    r.kills++; this.save.stats.kills++;
    this.hud.killT = 0.3;
    const cx = e.pos.x, cy = e.pos.y + e.hitCenterY, cz = e.pos.z;
    if (d.kind === 'bomb') this.blast(cx, cy, cz, 4.4, d.dmg * 1.6 * e.dmgMul, true, 0xff5a1a); // chain reaction
    if (e.affix === 'volatile') this.blast(cx, cy, cz, 3.8, 16 * e.dmgMul, true, 0xff7a1a); // elite: explodes when it dies
    this.fx.burst(cx, cy, cz, d.boss ? 150 : d.mini ? 70 : 28, e.burstColors, d.boss ? 14 : 8, 0.7, 0.14, 1.6, 8);
    this.deathFx(e, cx, cy, cz);
    this.lights.flash(cx, cy + 0.5, cz, e.burstColors[0] ?? 0xffffff, d.boss ? 200 : 70, 0.2, d.boss ? 22 : 11);
    this.sfx.play('confetti'); this.sfx.play('pop', 0.8);
    const rich = (this.charm('penny') ? 1.4 : 1) * (r.mod === 'richcoins' ? 2 : 1);
    const n = Math.min(18, Math.round(d.coins * rich * (e.affix === 'golden' ? 4 : 1)));
    for (let k = 0; k < n; k++) this.spawnPickup('coin', cx, Math.max(0.6, cy), cz, false);
    if (this.rng.chance(d.boss ? 1 : 0.07)) this.spawnPickup('heart', cx, 0.8, cz, false);
    if (this.charm('heart')) this.hp = Math.min(this.maxHp, this.hp + 2);
    if (this.charm('popper')) this.combat.explode(cx, cy, cz, 3, 25, 0.3, 0xffd54a, false);
    if (d.id === 'miniBlob') for (let k = 0; k < 3; k++) { const a = (k / 3) * TAU; this.spawnEnemy('blob', cx + Math.cos(a) * 2, cz + Math.sin(a) * 2); }
    if (d.boss) { this.save.stats.bosses++; this.slowT = 1.4; this.hitStop = 0.15; this.shake(0.9); this.sfx.play('boom'); this.banner(d.name.toUpperCase() + ' DEFEATED', '', 2.5); this.unlock('boss'); for (const o of this.enemies) if (o !== e && o.alive) this.damageEnemy(o, 9999, true); }
    this.checkAch();
  }

  private spawnPickup(type: 'coin' | 'heart', x: number, y: number, z: number, float: boolean) {
    const p = this.pickups.find((q) => !q.active && q.type === type);
    if (!p) return;
    p.active = true; p.float = float; p.ttl = float ? 1e9 : 22; p.t = Math.random() * 6; p.pos.set(x, y, z); p.mesh.visible = true;
    if (float) p.vel.set(0, 0, 0); else p.vel.set((Math.random() - 0.5) * 7, 5 + Math.random() * 4, (Math.random() - 0.5) * 7);
  }

  private updatePickups(dt: number) {
    const pp = this.playerPos, magnet = 3 + 1.5 * this.upg('magnet');
    for (const p of this.pickups) {
      if (!p.active) continue;
      p.t += dt;
      if (!p.float) {
        p.vel.y -= 22 * dt; p.pos.addScaledVector(p.vel, dt);
        if (p.pos.y < 0.5) { p.pos.y = 0.5; p.vel.y *= -0.4; p.vel.x *= 0.7; p.vel.z *= 0.7; }
        const lim = this.map.radius - 0.5, r = Math.hypot(p.pos.x, p.pos.z); if (r > lim) { p.pos.x *= lim / r; p.pos.z *= lim / r; }
        p.ttl -= dt; if (p.ttl <= 0) { p.active = false; p.mesh.visible = false; continue; }
      }
      const dx = pp.x - p.pos.x, dy = pp.y + 1 - p.pos.y, dz = pp.z - p.pos.z, d = Math.hypot(dx, dy, dz);
      if (d < magnet && (p.ttl < 21 || p.float)) { const s = (16 * dt) / Math.max(d, 0.2); p.pos.x += dx * s; p.pos.y += dy * s; p.pos.z += dz * s; p.float = false; p.vel.set(0, 0, 0); }
      if (d < 1.1) {
        p.active = false; p.mesh.visible = false;
        if (p.type === 'coin') { this.run.coins++; this.run.coinsGot++; this.save.stats.coinsEver++; this.sfx.play('coin', 1 + Math.min(this.run.coinsGot % 8, 7) * 0.05); this.checkAchSoft(); }
        else { this.hp = Math.min(this.maxHp, this.hp + 20); this.sfx.play('heal'); this.toast('+20 health'); }
      }
    }
  }

  damageCrate(c: Crate, dmg: number) {
    if (!c.collider.alive) return;
    c.hp -= dmg; c.shake = 0.25;
    if (c.hp > 0) { this.sfx.play('crunch', 0.8); return; }
    c.collider.alive = false; c.mesh.visible = false;
    const x = c.mesh.position.x, z = c.mesh.position.z;
    this.fx.scraps(x, 0.7, z, 30, 0xc4935a, 6); this.fx.confetti(x, 0.8, z, 12, 5); this.sfx.play('crunch'); this.shake(0.12);
    this.run.score += 10; this.caption('[Cardboard crate crunches]');
    if (c.loot) { for (let k = 0; k < 3; k++) this.spawnPickup('coin', x, 0.8, z, false); if (this.rng.chance(0.25)) this.spawnPickup('heart', x, 0.8, z, false); }
  }

  spawnCrateDrop(x: number, z: number) {
    const size = 1.3, mesh = makeCrate(size);
    mesh.position.set(x, 14, z); this.map.root.add(mesh);
    const collider = makeCollider(x, z, size, size, 0, size, 'crate'); collider.alive = false;
    const crate: Crate = { collider, mesh, hp: 30, maxHp: 30, shake: 0, loot: true };
    collider.crate = crate; this.map.colliders.push(collider); this.map.crates.push(crate);
    this.falling.push({ mesh, y: 14, vy: 0, crate });
  }

  private updateFalling(dt: number) {
    for (let i = this.falling.length - 1; i >= 0; i--) {
      const f = this.falling[i];
      f.vy -= 24 * dt; f.y += f.vy * dt; f.mesh.position.y = Math.max(0, f.y); f.mesh.rotation.y += dt * 2;
      if (f.y <= 0) {
        f.mesh.position.y = 0; f.crate.collider.alive = true;
        const x = f.mesh.position.x, z = f.mesh.position.z;
        this.fx.scraps(x, 0.2, z, 20, 0xc4935a, 5); this.shake(0.15); this.sfx.play('bounce', 0.5);
        if (Math.hypot(this.playerPos.x - x, this.playerPos.z - z) < 1.3 && this.playerPos.y < 1) this.hurtPlayer(15, f.mesh.position, 'hit');
        resolveCircle(this.playerPos, this.playerRadius, this.playerHeight, [f.crate.collider], 0.2);
        this.falling.splice(i, 1);
      }
    }
  }

  // ---------------------------------------------------------------- director
  private updateDirector(dt: number) {
    const r = this.run;
    let alive = 0;
    for (const e of this.enemies) if (e.alive) alive++;
    if (r.phase === 'idle') {
      r.intermission -= dt;
      if (r.intermission <= 0) this.startNextWave();
      return;
    }
    if (r.queue.length) {
      r.spawnT -= dt;
      if (r.spawnT <= 0 && alive < this.maxAlive) { this.spawnFromQueue(); r.spawnT = 0.45; }
    } else if (alive === 0) this.waveClear();
  }

  private startNextWave() {
    const r = this.run, cfg = r.cfg;
    r.wave++;
    r.diff = 1 + (r.stageIdx * 3 + Math.max(0, r.wave - 1)) * 0.07;
    if (r.mode === 'endless') r.diff += r.stageIdx * 0.05;
    r.waveHurt = false;
    if (this.charm('shield')) this.shield = Math.max(this.shield, 20);
    if (r.wave <= cfg.waves) {
      r.queue = composeWave(r.rng, r.wave, r.stageIdx, r.cfg.map); r.phase = 'wave'; r.spawnT = 0.5;
      this.banner(`WAVE ${r.wave}`, `${r.queue.length} creatures incoming`, 2); this.sfx.play('waveStart');
    } else if (cfg.boss && !r.bossDone) {
      r.phase = 'boss'; r.queue = []; r.spawnT = 0;
      const b = this.spawnEnemy(cfg.boss, 0, cfg.boss === 'domeBoss' ? -14 : cfg.boss === 'ufo' ? -4 : -10);
      if (b) { this.banner(ENEMY_DEFS[cfg.boss].name.toUpperCase(), 'BOSS FIGHT', 3); this.sfx.play('bossRoar'); this.shake(0.5); this.caption('[Boss appears]'); }
      if (this.map.domeProp && cfg.boss === 'domeBoss') this.map.domeProp.visible = false;
    } else this.stageClear();
    this.hud.wave = Math.min(r.wave, this.hud.waves);
  }

  private spawnFromQueue() {
    const r = this.run, id = r.queue.pop()!;
    const spawns = this.map.spawns, px = this.playerPos.x, pz = this.playerPos.z;
    let pt: THREE.Vector3 | null = null;
    for (let tries = 0; tries < 8 && spawns.length; tries++) { const c = spawns[r.rng.int(0, spawns.length - 1)]; if (Math.hypot(c.x - px, c.z - pz) > 11) { pt = c; break; } }
    const a = r.rng.range(0, TAU), rr = r.rng.range(14, 26);
    const x = pt ? pt.x + r.rng.range(-1, 1) : Math.cos(a) * rr, z = pt ? pt.z + r.rng.range(-1, 1) : Math.sin(a) * rr;
    this.spawnEnemy(id, x, z);
  }

  private waveClear() {
    const r = this.run;
    if (!r.waveHurt && r.wave > 0) this.unlock('flawless');
    if (r.phase === 'boss') r.bossDone = true;
    r.phase = 'idle'; r.intermission = 3.5;
    this.hp = Math.min(this.maxHp, this.hp + this.maxHp * 0.2);
    r.score += 100 * r.wave;
    this.banner('CLEARED!', r.cfg.boss && r.bossDone ? '' : 'Catch your breath', 2); this.sfx.play('heal');
    for (let k = 0; k < 5; k++) this.spawnPickup('coin', this.playerPos.x + (Math.random() - 0.5) * 6, 1, this.playerPos.z + (Math.random() - 0.5) * 6 - 2, false);
  }

  private stageClear() {
    const r = this.run;
    r.phase = 'idle'; r.intermission = 9999;
    if (r.mode === 'endless') { this.loadStage(r.stageIdx + 1); return; }
    if (r.mode === 'campaign') this.save.campaign = Math.max(this.save.campaign, r.stageIdx + 1);
    if (!this.stageCfg(r.stageIdx + 1)) { this.endRun(true); return; }
    r.score += 500;
    this.bank(true);
    this.result = { title: 'STAGE CLEAR!', win: true, mode: r.mode, score: Math.floor(r.score), kills: r.kills, time: r.time, coins: r.coinsGot, best: false, note: r.cfg.name + ' complete', canContinue: true };
    this.state = 'stageclear'; this.input.capture = false; this.input.exitLock(); this.input.releaseAll();
  }

  // ---------------------------------------------------------------- progress
  private unlock(id: string) {
    if (this.save.achievements.includes(id)) return;
    this.save.achievements.push(id);
    const a = ACHIEVEMENTS.find((x) => x.id === id);
    if (a) { this.toast('Achievement: ' + a.name); this.sfx.play('jackpot'); }
    storeSave(this.save);
  }
  private checkAchSoft() { if (this.save.stats.coinsEver >= 300) this.unlock('rich'); }
  private checkAch() {
    const s = this.save.stats;
    if (s.kills >= 1) this.unlock('first'); if (s.kills >= 100) this.unlock('kills100'); if (s.kills >= 1000) this.unlock('kills1000');
    if (s.jackpots >= 1) this.unlock('jackpot'); if (s.parries >= 10) this.unlock('parry10'); if (s.dashes >= 50) this.unlock('dash50');
  }

  private updateTimers(dt: number) {
    const h = this.hud;
    this.comboT -= dt; if (this.comboT <= 0 && this.combo > 0) this.combo = 0;
    this.hurtFlash = Math.max(0, this.hurtFlash - dt * 2.2);
    h.hitT = Math.max(0, h.hitT - dt); h.killT = Math.max(0, h.killT - dt); h.bannerT = Math.max(0, h.bannerT - dt);
    for (const a of [h.toasts, h.captions, h.hurt]) for (let i = a.length - 1; i >= 0; i--) { a[i].t -= dt; if (a[i].t <= 0) a.splice(i, 1); }
    if (this.reelPending) { this.reelPending.t -= dt; if (this.reelPending.t <= 0) { h.reel = this.reelPending.syms; h.reelLabel = this.reelPending.label; h.reelT = 1.6; this.reelPending = null; } }
    h.reelT = Math.max(0, h.reelT - dt);
    for (const c of this.crates) if (c.shake > 0) c.shake = Math.max(0, c.shake - dt);
    if (Math.floor(this.time * 2) !== this.lastReelTick) {
      this.lastReelTick = Math.floor(this.time * 2);
      let alive = 0; for (const e of this.enemies) if (e.alive) alive++;
      this.sfx.setIntensity(this.run.phase === 'boss' ? 1 : alive / 10);
    }
    if (this.run.phase === 'boss') { const b = this.enemies.find((e) => e.isBoss && e.alive); h.boss = b ? { name: b.def.name, frac: b.hp / b.maxHp, phase: b.phase } : null; } else h.boss = null;
  }

  // ================================================================ render
  private renderFrame(dt: number, alpha: number) {
    this.vt += dt;
    outlineTime.value = this.vt; // also the wind clock for swaying grass
    this.lights.update(dt); this.numbers.update(dt);
    const s = this.settings, reduced = s.reducedMotion;
    this.map.update(dt, this.vt, this.playerPos);
    if (this.map.id === 'night' && this.level !== 'low' && dt > 0) {
      // distant fireworks over the carnival
      this.fwT -= dt;
      if (this.fwT <= 0) {
        this.fwT = 1.3 + Math.random() * 2.4;
        const a = Math.random() * TAU, r = 48 + Math.random() * 30, hex = [0xff3b5c, 0xffd54a, 0x33d6ff, 0xff35c8][Math.floor(Math.random() * 4)];
        this.fx.burst(Math.cos(a) * r, 24 + Math.random() * 22, Math.sin(a) * r, 70, [hex, 0xffffff], 15, 0, 0.55, 2.2, 2.5);
      }
    }
    const cam = this.camera;

    if (this.state === 'menu') {
      const a = this.vt * 0.12, r = 17;
      cam.position.set(Math.cos(a) * r, 4.2, Math.sin(a) * r); cam.lookAt(0, 1.6, 0); cam.fov = 70; cam.updateProjectionMatrix();
      for (const e of this.menuCast) e.sync(1, dt, cam.position);
      this.fx.update(dt, cam.position);
      this.post.u.hurt.value = 0; this.post.u.dash.value = 0; this.post.u.focusY.value = 0.45; this.post.u.focusW.value = 0.12;
      this.syncWeaponView(dt, 0, true);
      this.post.render(dt, this.vt);
      return;
    }

    // camera pose from interpolated player state
    this.trauma = Math.max(0, this.trauma - dt * 1.6);
    const sh = this.trauma * this.trauma * (reduced ? 0.3 : 1);
    cam.position.set(lerp(this.prevPos.x, this.playerPos.x, alpha), lerp(this.prevPos.y, this.playerPos.y, alpha) + EYE - this.landDip, lerp(this.prevPos.z, this.playerPos.z, alpha));
    const t = this.vt;
    cam.position.x += Math.sin(t * 61) * sh * 0.08; cam.position.y += Math.sin(t * 53 + 1) * sh * 0.08;
    const moveRoll = clamp(-this.input.moveX * 0.012 + this.playerVel.x * 0.0, -0.03, 0.03) * (reduced ? 0 : 1);
    this.roll = damp(this.roll, moveRoll + this.hurtFlash * 0.015, 10, dt || 0.016);
    cam.rotation.set(this.pitch + this.recoil + Math.sin(t * 47) * sh * 0.03, this.yaw + Math.sin(t * 39 + 2) * sh * 0.03, this.roll + Math.sin(t * 43 + 4) * sh * 0.03);
    const fov = s.fov + (reduced ? 0 : this.fovKick * 14 + (this.exT > 0 ? 3 : 0));
    if (Math.abs(cam.fov - fov) > 0.05) { cam.fov = fov; cam.updateProjectionMatrix(); }
    cam.updateMatrixWorld();

    for (const e of this.enemies) e.sync(alpha, dt, cam.position);
    this.combat.render(alpha, cam.position, t);
    this.fx.update(dt, cam.position);
    this.updatePickupVisuals(t);
    for (const c of this.crates) if (c.shake > 0 && c.collider.alive) { c.mesh.rotation.z = Math.sin(t * 70) * c.shake * 0.12; c.mesh.rotation.x = Math.cos(t * 63) * c.shake * 0.08; } else c.mesh.rotation.z = c.mesh.rotation.x = 0;
    for (const g of this.ghosts) { if (g.t > 0) { g.t -= dt; g.mesh.rotation.y = Math.atan2(cam.position.x - g.mesh.position.x, cam.position.z - g.mesh.position.z); (g.mesh.material as THREE.MeshBasicMaterial).opacity = clamp(g.t / 0.55, 0, 1) * 0.65; if (g.t <= 0) g.mesh.visible = false; } }
    this.syncWeaponView(dt, alpha, false);

    // lens: hurt tint, dash chromatic, focus pull on reload / dash
    const u = this.post.u;
    u.hurt.value = this.hurtFlash * 0.55; u.dash.value = reduced ? 0 : this.fovKick;
    const focusTarget = this.reloading ? 0.34 : 0.5 + Math.sin(this.pitch) * 0.12;
    u.focusY.value = damp(u.focusY.value, focusTarget, 5, dt || 0.016);
    u.focusW.value = damp(u.focusW.value, this.reloading ? 0.1 : 0.17, 4, dt || 0.016);
    u.vig.value = 0.5 + (this.hp / this.maxHp < 0.3 ? 0.35 : 0);
    this.updateHud();
    this.post.render(dt, this.vt);
  }

  private updatePickupVisuals(t: number) {
    for (const p of this.pickups) {
      if (!p.active) continue;
      p.mesh.position.set(p.pos.x, p.pos.y + Math.sin(t * 3 + p.t) * 0.08, p.pos.z);
      p.mesh.rotation.y = t * 3 + p.t;
      p.mesh.visible = p.ttl > 3 || Math.floor(t * 8) % 2 === 0;
    }
  }

  private mounted = -1;
  private mountView() {
    const v = this.view(this.w);
    while (this.wRoot.children.length) this.wRoot.remove(this.wRoot.children[0]);
    this.wRoot.add(v.root); this.mounted = this.w;
    (v.flash.material as THREE.SpriteMaterial).color.setHex(WEAPONS[this.w].color);
  }

  private syncWeaponView(dt: number, alpha: number, menu: boolean) {
    if (this.mounted !== this.w) this.mountView();
    const v = this.view(this.w), def = WEAPONS[this.w], reduced = this.settings.reducedMotion, k = reduced ? 0.25 : 1;
    const t = this.vt, speed = Math.hypot(this.playerVel.x, this.playerVel.z), moving = this.grounded ? clamp(speed / 7, 0, 1) : 0;
    this.bobPhase += dt * (4 + speed * 1.3);
    const aspect = this.camera.aspect, ax = Math.min(1, aspect / 1.6);
    const reloadK = this.reloading ? Math.sin(clamp(this.reloadT / (def.reload * (1 - 0.08 * this.upg('reload'))), 0, 1) * Math.PI) : 0;
    const swapK = this.swapTo >= 0 ? Math.sin(clamp(this.swapT / 0.3, 0, 1) * Math.PI) : 0;
    const insp = this.inspectT > 0 ? Math.sin(clamp(1 - this.inspectT / 1.6, 0, 1) * Math.PI) : 0;
    const chargeK = def.charge ? this.charge / def.charge : 0;
    const sprint = clamp((speed - 6) / 2, 0, 1) * (this.input.moveY > 0.3 ? 1 : 0);
    const w = this.wRoot;
    w.position.set(
      0.3 * ax + 0.02 * ax + Math.cos(this.bobPhase) * 0.01 * moving * k - this.swayX * 0.6 * k + insp * -0.12 + (menu ? 0.5 : 0),
      -0.27 + Math.sin(this.bobPhase * 2) * 0.012 * moving * k + Math.sin(t * 1.6) * 0.003 * k + this.swayY * 0.5 * k - reloadK * 0.22 - swapK * 0.5 + chargeK * 0.02 * Math.sin(t * 60),
      -0.58 + this.kick * 0.11 + sprint * 0.04 + chargeK * 0.06 + (this.dashT > 0 ? 0.08 : 0),
    );
    w.rotation.set(this.kick * 0.18 - reloadK * 0.5 + insp * 0.5 - this.swayY * 0.5 * k - sprint * 0.12 * k, 0.1 + insp * 1.9 - this.swayX * 0.7 * k + sprint * 0.2 * k + reloadK * 0.25, -sprint * 0.18 * k + reloadK * 0.3 + Math.sin(this.bobPhase) * 0.01 * moving * k);
    // capsule reels: drums chase their target angle (always spinning forward)
    for (let i = 0; i < 3; i++) { this.reelAng[i] = damp(this.reelAng[i], this.reelTarget[i], 11 - i, dt || 0.016); v.drums[i].rotation.z = this.reelAng[i]; }
    // ammo capsules visible in the lower tube
    const ratio = this.ammo[this.w] / def.mag;
    for (let i = 0; i < v.capsules.length; i++) { const on = (i + 0.5) / v.capsules.length <= ratio + 0.001; v.capsules[i].scale.setScalar(damp(v.capsules[i].scale.x, on ? 1 : 0.001, 18, dt || 0.016)); }
    this.sinceShot += dt; this.perfectT = Math.max(0, this.perfectT - dt);
    v.tick({ dt, t, kick: this.kick, charge: chargeK, ratio, reload: this.reloading ? clamp(this.reloadT / (def.reload * (1 - 0.08 * this.upg('reload'))), 0, 1) : 0, since: this.sinceShot });
    this.wRim.intensity = 3 + this.kick * 10; // the gun is lit by its own muzzle flash
    this.updateShafts();
    v.flash.visible = this.flashT > 0; if (this.flashT > 0) { this.flashT -= dt; v.flash.scale.setScalar((0.3 + def.kick * 0.12) * (0.7 + Math.random() * 0.6)); }
    void alpha;
    this.wCam.position.set(0, 0, 0);
  }

  /** Projects the arena's light onto the screen for the lens pass's sun shafts. */
  private updateShafts() {
    const m = this.map, cam = this.camera;
    if (!m.shaft || !m.lightDir || this.level === 'low') { this.post.setShafts(0, 0.5, 0.5, 0xffffff); return; }
    cam.updateMatrixWorld();
    const v = this.tv1.copy(m.lightDir).multiplyScalar(200).add(cam.position).project(cam);
    const vis = v.z > 1 ? 0 : clamp(1.3 - Math.hypot(v.x, v.y) * 0.6, 0, 1);
    this.post.setShafts(m.shaft.k * vis, v.x * 0.5 + 0.5, v.y * 0.5 + 0.5, m.shaft.color);
  }

  private updateHud() {
    const h = this.hud, def = WEAPONS[this.w], r = this.run;
    h.elem = def.id === 'pinwheel' ? 'fire+ice' : WEAPON_ELEM[def.id]; h.perfect = this.perfectT;
    h.hp = this.hp; h.maxHp = this.maxHp; h.shield = this.shield; h.ammo = this.ammo[this.w]; h.mag = def.mag; h.weapon = this.w; h.weaponName = def.name;
    h.reload = this.reloading ? clamp(this.reloadT / (def.reload * (1 - 0.08 * this.upg('reload'))), 0, 1) : 0;
    h.charge = def.charge ? this.charge / def.charge : 0;
    h.coins = r.coins; h.score = Math.floor(r.score); h.combo = this.combo; h.comboT = clamp(this.comboT / 3.2, 0, 1);
    h.time = r.time + r.penalty; h.wave = Math.min(r.wave, h.waves);
    h.dashCd = this.dashCd / (1.1 * (1 - 0.08 * this.upg('dash'))); h.parryCd = this.parryCd / 0.9; h.exT = this.exT;
    h.canSuper = r.coins >= 5; h.canEx = r.coins >= 3 && this.exT <= 0; h.hurtFlash = this.hurtFlash; h.pad = this.input.padConnected;
  }

  // ================================================================ misc API for the UI
  setAutofire(on: boolean) { this.autofire = on; this.settings.autofire = on; storeSettings(this.settings); }
  persist() { storeSave(this.save); }
  getWeaponCount() { return WEAPONS.length; }

  dispose() {
    this.disposed = true; cancelAnimationFrame(this.raf);
    this.cleanup.forEach((f) => f()); this.input.dispose(); this.sfx.stopMusic(); this.sfx.suspend();
    this.post.dispose(); this.renderer.dispose();
  }
}
