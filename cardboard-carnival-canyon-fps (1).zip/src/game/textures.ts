/**
 * Procedural cardboard-craft textures and materials. Nothing is loaded from disk:
 * every texture is painted onto a canvas the first time it is requested.
 */
import * as THREE from 'three';
import { Rng, TAU } from './core';

type G = CanvasRenderingContext2D;
const cache = new Map<string, THREE.CanvasTexture>();
export const INK = '#141016';

function make(key: string, w: number, h: number, draw: (g: G, w: number, h: number) => void, opt: { repeat?: boolean; data?: boolean } = {}): THREE.CanvasTexture {
  const hit = cache.get(key);
  if (hit) return hit;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const g = c.getContext('2d')!;
  draw(g, w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = opt.data ? THREE.NoColorSpace : THREE.SRGBColorSpace;
  if (opt.repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.anisotropy = 4;
  cache.set(key, t);
  return t;
}

// ------------------------------------------------------------ drawing bits
function fibers(g: G, w: number, h: number, rng: Rng, n: number, alpha: number) {
  for (let i = 0; i < n; i++) {
    const x = rng.range(0, w), y = rng.range(0, h), a = rng.range(0, TAU), l = rng.range(3, 14);
    g.strokeStyle = rng.chance(0.5) ? `rgba(255,240,200,${alpha})` : `rgba(60,30,0,${alpha})`;
    g.lineWidth = rng.range(0.5, 1.4);
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * l, y + Math.sin(a) * l); g.stroke();
  }
}
function stripes(g: G, w: number, h: number, period: number, alpha: number) {
  for (let x = 0; x < w; x += period) {
    g.fillStyle = `rgba(0,0,0,${alpha})`; g.fillRect(x, 0, period * 0.28, h);
    g.fillStyle = `rgba(255,255,255,${alpha * 0.6})`; g.fillRect(x + period * 0.5, 0, period * 0.2, h);
  }
}
function inkLine(g: G, pts: number[][], width = 3) {
  g.strokeStyle = INK; g.lineWidth = width; g.lineCap = 'round'; g.lineJoin = 'round';
  g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); g.stroke();
}
function crack(g: G, rng: Rng, x: number, y: number, len: number, width: number) {
  let px = x, py = y, a = rng.range(0, TAU);
  const pts = [[px, py]];
  for (let i = 0; i < len; i++) {
    a += rng.range(-0.8, 0.8);
    px += Math.cos(a) * rng.range(6, 16); py += Math.sin(a) * rng.range(6, 16);
    pts.push([px, py]);
  }
  inkLine(g, pts, width);
}

export function drawSmiley(g: G, cx: number, cy: number, r: number, face = '#ffd54a') {
  g.fillStyle = '#fff'; g.beginPath(); g.arc(cx, cy, r * 1.12, 0, TAU); g.fill();
  g.fillStyle = face; g.strokeStyle = INK; g.lineWidth = r * 0.09;
  g.beginPath(); g.arc(cx, cy, r, 0, TAU); g.fill(); g.stroke();
  g.fillStyle = INK;
  g.beginPath(); g.ellipse(cx - r * 0.35, cy - r * 0.2, r * 0.09, r * 0.15, 0, 0, TAU); g.fill();
  g.beginPath(); g.ellipse(cx + r * 0.35, cy - r * 0.2, r * 0.09, r * 0.15, 0, 0, TAU); g.fill();
  g.lineWidth = r * 0.1; g.beginPath(); g.arc(cx, cy + r * 0.05, r * 0.52, 0.15 * Math.PI, 0.85 * Math.PI); g.stroke();
}
export function drawFlower(g: G, cx: number, cy: number, r: number, petal = '#ffb02e') {
  g.strokeStyle = INK; g.lineWidth = r * 0.06;
  for (let i = 0; i < 8; i++) {
    const a = (i / 8) * TAU;
    g.fillStyle = petal; g.beginPath(); g.ellipse(cx + Math.cos(a) * r * 0.62, cy + Math.sin(a) * r * 0.62, r * 0.34, r * 0.2, a, 0, TAU); g.fill(); g.stroke();
  }
  drawSmiley(g, cx, cy, r * 0.42, '#fff0b0');
}
export function drawStar(g: G, cx: number, cy: number, r: number, fill = '#ffd54a') {
  g.fillStyle = fill; g.strokeStyle = INK; g.lineWidth = r * 0.1; g.lineJoin = 'round';
  g.beginPath();
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i / 10) * TAU, rr = i % 2 ? r * 0.45 : r;
    g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr);
  }
  g.closePath(); g.fill(); g.stroke();
}
export function drawBullseye(g: G, cx: number, cy: number, r: number) {
  const cols = ['#c92b2b', '#f3e7cc', '#c92b2b', '#f3e7cc', '#c92b2b'];
  cols.forEach((c, i) => { g.fillStyle = c; g.strokeStyle = INK; g.lineWidth = r * 0.05; g.beginPath(); g.arc(cx, cy, r * (1 - i * 0.2), 0, TAU); g.fill(); g.stroke(); });
}
export function drawCrown(g: G, cx: number, cy: number, s: number, color = INK, fill?: string) {
  const pts: number[][] = [[-1, 0.7], [-1, -0.5], [-0.5, 0.1], [0, -0.8], [0.5, 0.1], [1, -0.5], [1, 0.7]];
  g.beginPath();
  pts.forEach((p, i) => (i ? g.lineTo(cx + p[0] * s, cy + p[1] * s) : g.moveTo(cx + p[0] * s, cy + p[1] * s)));
  g.closePath();
  if (fill) { g.fillStyle = fill; g.fill(); }
  g.strokeStyle = color; g.lineWidth = s * 0.14; g.lineJoin = 'round'; g.stroke();
}

// ------------------------------------------------------------ texture set
export const T = {
  /** Flat painted kraft paper in any colour: fibers, corrugation hint, stains. */
  paper(color: string): THREE.CanvasTexture {
    return make('paper' + color, 256, 256, (g, w, h) => {
      const rng = new Rng(color.length * 977 + color.charCodeAt(1) * 13 + color.charCodeAt(color.length - 1));
      g.fillStyle = color; g.fillRect(0, 0, w, h);
      for (let i = 0; i < 6; i++) {
        const gr = g.createRadialGradient(rng.range(0, w), rng.range(0, h), 4, rng.range(0, w), rng.range(0, h), rng.range(40, 120));
        gr.addColorStop(0, rng.chance(0.5) ? 'rgba(255,255,255,0.10)' : 'rgba(40,20,0,0.10)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
        g.fillStyle = gr; g.fillRect(0, 0, w, h);
      }
      stripes(g, w, h, 16, 0.07);
      fibers(g, w, h, rng, 700, 0.1);
      for (let i = 0; i < 80; i++) { g.fillStyle = `rgba(30,15,0,${rng.range(0.05, 0.18)})`; g.fillRect(rng.range(0, w), rng.range(0, h), rng.range(1, 2.5), rng.range(1, 2.5)); }
    }, { repeat: true });
  },
  /** Corrugation height field used as bump map. */
  corrBump(): THREE.CanvasTexture {
    return make('corrBump', 128, 128, (g, w, h) => {
      for (let x = 0; x < w; x++) {
        const v = 128 + Math.sin((x / 8) * TAU) * 90;
        g.fillStyle = `rgb(${v},${v},${v})`; g.fillRect(x, 0, 1, h);
      }
      const rng = new Rng(5);
      for (let i = 0; i < 300; i++) { g.fillStyle = `rgba(${rng.chance(0.5) ? 255 : 0},0,0,0.05)`; g.fillRect(rng.range(0, w), rng.range(0, h), 2, 2); }
    }, { repeat: true, data: true });
  },
  /** Cut edge of corrugated board: dark flutes between kraft layers. */
  edge(color = '#b98a52'): THREE.CanvasTexture {
    return make('edge' + color, 64, 64, (g, w, h) => {
      g.fillStyle = color; g.fillRect(0, 0, w, h);
      g.fillStyle = 'rgba(30,15,0,0.55)';
      for (let x = 0; x < w; x += 8) { g.beginPath(); g.arc(x + 4, h * 0.5, 3, 0, TAU); g.fill(); }
      g.fillStyle = 'rgba(30,15,0,0.35)'; g.fillRect(0, 0, w, 6); g.fillRect(0, h - 6, w, 6);
    }, { repeat: true });
  },
  crate(): THREE.CanvasTexture {
    return make('crate', 256, 256, (g, w, h) => {
      const rng = new Rng(11);
      g.fillStyle = '#c4935a'; g.fillRect(0, 0, w, h);
      stripes(g, w, h, 16, 0.08); fibers(g, w, h, rng, 600, 0.1);
      g.strokeStyle = 'rgba(40,20,0,0.65)'; g.lineWidth = 6; g.strokeRect(8, 8, w - 16, h - 16);
      inkLine(g, [[18, 18], [w - 18, h - 18]], 3); inkLine(g, [[w - 18, 18], [18, h - 18]], 3);
      g.fillStyle = '#c4935a'; g.fillRect(w / 2 - 34, h / 2 - 30, 68, 60);
      drawCrown(g, w / 2, h / 2, 22);
      for (let i = 0; i < 6; i++) crack(g, rng, rng.range(0, w), rng.range(0, h), 3, 1.5);
    });
  },
  floorDay(): THREE.CanvasTexture {
    return make('floorDay', 512, 512, (g, w, h) => {
      const rng = new Rng(21);
      const n = 2, s = w / n;
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
        const l = 62 + rng.range(-5, 6);
        g.fillStyle = `hsl(32,48%,${l}%)`; g.fillRect(i * s, j * s, s, s);
      }
      stripes(g, w, h, 12, 0.09); fibers(g, w, h, rng, 2500, 0.1);
      g.strokeStyle = 'rgba(60,30,5,0.7)'; g.lineWidth = 4;
      for (let i = 0; i <= n; i++) { g.beginPath(); g.moveTo(i * s, 0); g.lineTo(i * s, h); g.stroke(); g.beginPath(); g.moveTo(0, i * s); g.lineTo(w, i * s); g.stroke(); }
      for (let i = 0; i < 5; i++) crack(g, rng, rng.range(0, w), rng.range(0, h), rng.int(4, 9), 2);
      for (let i = 0; i < 9; i++) {
        const x = rng.range(20, w - 20), y = rng.range(20, h - 20);
        if (i % 3 === 0) { inkLine(g, [[x - 8, y - 8], [x + 8, y + 8]], 3); inkLine(g, [[x + 8, y - 8], [x - 8, y + 8]], 3); }
        else if (i % 3 === 1) inkLine(g, [[x - 14, y], [x + 14, y], [x + 6, y - 7], [x + 14, y], [x + 6, y + 7]], 2.5);
        else { g.strokeStyle = INK; g.lineWidth = 2.5; g.beginPath(); g.arc(x, y, 9, 0, TAU * 0.85); g.stroke(); }
      }
    }, { repeat: true });
  },
  floorNight(): THREE.CanvasTexture {
    return make('floorNight', 512, 512, (g, w, h) => {
      const rng = new Rng(33);
      g.fillStyle = '#4a2430'; g.fillRect(0, 0, w, h);
      const n = 2, s = w / n;
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { g.fillStyle = `hsl(${345 + rng.range(-8, 8)},35%,${20 + rng.range(-3, 4)}%)`; g.fillRect(i * s + 3, j * s + 3, s - 6, s - 6); }
      stripes(g, w, h, 12, 0.1); fibers(g, w, h, rng, 1800, 0.07);
      g.strokeStyle = '#ff3b5c'; g.lineWidth = 2; g.globalAlpha = 0.5;
      for (let i = 0; i <= n; i++) { g.beginPath(); g.moveTo(i * s, 0); g.lineTo(i * s, h); g.stroke(); g.beginPath(); g.moveTo(0, i * s); g.lineTo(w, i * s); g.stroke(); }
      g.globalAlpha = 1;
      for (let i = 0; i < 4; i++) crack(g, rng, rng.range(0, w), rng.range(0, h), rng.int(4, 8), 2);
    }, { repeat: true });
  },
  stripesRW(): THREE.CanvasTexture {
    return make('stripesRW', 128, 128, (g, w, h) => {
      for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#f3e7cc' : '#c92b2b'; g.fillRect((i * w) / 8, 0, w / 8, h); }
      const rng = new Rng(9); fibers(g, w, h, rng, 200, 0.12);
    }, { repeat: true });
  },
  tape(color: string): THREE.CanvasTexture {
    return make('tape' + color, 128, 64, (g, w, h) => {
      g.fillStyle = color; g.fillRect(0, 0, w, h);
      g.fillStyle = 'rgba(255,255,255,0.2)'; for (let x = 0; x < w; x += 16) g.fillRect(x, 0, 6, h);
      const rng = new Rng(3); fibers(g, w, h, rng, 60, 0.12);
      g.fillStyle = 'rgba(0,0,0,0.25)'; g.fillRect(0, 0, w, 3); g.fillRect(0, h - 3, w, 3);
    }, { repeat: true });
  },
  smiley: () => make('smiley', 128, 128, (g) => drawSmiley(g, 64, 64, 52)),
  flowerSticker: () => make('flower', 128, 128, (g) => drawFlower(g, 64, 64, 56)),
  popcornSticker: () => make('popcorn', 128, 128, (g) => {
    g.fillStyle = '#fff3c0'; g.strokeStyle = INK; g.lineWidth = 4;
    [[44, 70], [64, 52], [84, 70], [54, 88], [76, 90], [64, 74]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 20, 0, TAU); g.fill(); g.stroke(); });
    g.fillStyle = '#ffd54a'; [[54, 62], [76, 64], [64, 84]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 6, 0, TAU); g.fill(); });
  }),
  crownDoodle: () => make('crownDoodle', 128, 128, (g) => { g.fillStyle = 'rgba(0,0,0,0)'; drawCrown(g, 64, 64, 36, INK); }),
  bullseye: () => make('bullseye', 128, 128, (g) => drawBullseye(g, 64, 64, 56)),
  star: () => make('star', 128, 128, (g) => drawStar(g, 64, 66, 58)),
  /** Face decals: transparent PNG-style planes pasted over the paper bodies. */
  leafFace: () => make('leafFace', 256, 256, (g) => {
    g.strokeStyle = INK; g.lineWidth = 7;
    [[88, 96], [168, 96]].forEach(([x, y]) => {
      g.fillStyle = '#fff'; g.beginPath(); g.ellipse(x, y, 32, 38, 0, 0, TAU); g.fill(); g.stroke();
      g.fillStyle = INK; g.beginPath(); g.ellipse(x + 3, y + 4, 15, 19, 0, 0, TAU); g.fill();
      g.fillStyle = '#fff'; g.beginPath(); g.arc(x + 8, y - 4, 5, 0, TAU); g.fill();
    });
    g.fillStyle = INK; g.beginPath(); g.moveTo(52, 150); g.quadraticCurveTo(128, 205, 204, 150); g.quadraticCurveTo(128, 232, 52, 150); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.moveTo(62, 156); g.quadraticCurveTo(128, 198, 194, 156); g.quadraticCurveTo(128, 218, 62, 156); g.fill();
    g.lineWidth = 4; for (let x = 82; x < 190; x += 22) inkLine(g, [[x, 160], [x, 196 - Math.abs(x - 128) * 0.25]], 4);
  }),
  sunFace: () => make('sunFace', 256, 256, (g) => {
    g.fillStyle = '#e9b97a'; g.beginPath(); g.arc(128, 128, 120, 0, TAU); g.fill();
    g.strokeStyle = INK; g.lineWidth = 8; g.stroke();
    g.fillStyle = INK;
    [[88, 118], [168, 118]].forEach(([x, y]) => { g.beginPath(); g.arc(x, y, 12, 0, TAU); g.fill(); });
    g.lineWidth = 9; inkLine(g, [[84, 178], [108, 166], [148, 166], [172, 178]], 9);
  }),
  blobFace: () => make('blobFace', 256, 256, (g) => {
    g.fillStyle = '#3f8cf0'; g.beginPath(); g.arc(128, 128, 126, 0, TAU); g.fill();
    const rng = new Rng(2);
    for (let i = 0; i < 12; i++) { g.fillStyle = `rgba(255,255,255,${rng.range(0.08, 0.25)})`; g.beginPath(); g.ellipse(rng.range(30, 226), rng.range(30, 226), rng.range(20, 50), rng.range(10, 25), rng.range(0, 3), 0, TAU); g.fill(); }
    g.fillStyle = INK; g.beginPath(); g.ellipse(88, 104, 11, 20, 0, 0, TAU); g.fill(); g.beginPath(); g.ellipse(168, 104, 11, 20, 0, 0, TAU); g.fill();
    g.fillStyle = 'rgba(255,110,170,0.8)'; g.beginPath(); g.arc(58, 150, 20, 0, TAU); g.fill(); g.beginPath(); g.arc(198, 150, 20, 0, TAU); g.fill();
    g.strokeStyle = INK; g.lineWidth = 9; g.lineCap = 'round'; g.beginPath(); g.arc(128, 142, 46, 0.18 * Math.PI, 0.82 * Math.PI); g.stroke();
  }),
  domeFace: () => make('domeFace', 256, 256, (g) => {
    g.fillStyle = '#e9b97a'; g.beginPath(); g.arc(128, 128, 120, 0, TAU); g.fill(); g.strokeStyle = INK; g.lineWidth = 8; g.stroke();
    g.fillStyle = INK; g.beginPath(); g.ellipse(88, 108, 12, 22, 0, 0, TAU); g.fill(); g.beginPath(); g.ellipse(168, 108, 12, 22, 0, 0, TAU); g.fill();
    g.fillStyle = 'rgba(255,110,120,0.55)'; g.beginPath(); g.arc(60, 152, 18, 0, TAU); g.fill(); g.beginPath(); g.arc(196, 152, 18, 0, TAU); g.fill();
    g.strokeStyle = INK; g.lineWidth = 9; g.lineCap = 'round'; g.beginPath(); g.arc(128, 138, 54, 0.15 * Math.PI, 0.85 * Math.PI); g.stroke();
  }),
  coin: () => make('coin', 128, 128, (g) => {
    g.fillStyle = '#e8b830'; g.beginPath(); g.arc(64, 64, 62, 0, TAU); g.fill();
    g.strokeStyle = '#8a5a00'; g.lineWidth = 6; g.beginPath(); g.arc(64, 64, 52, 0, TAU); g.stroke();
    g.fillStyle = '#8a5a00'; g.font = 'bold 70px Oswald, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('C', 64, 68);
    g.fillStyle = 'rgba(255,255,255,0.35)'; g.beginPath(); g.ellipse(40, 36, 20, 10, -0.6, 0, TAU); g.fill();
  }),
  neonArrow(color: string): THREE.CanvasTexture {
    return make('neon' + color, 128, 128, (g, w, h) => {
      g.fillStyle = 'rgba(10,6,20,0.9)'; g.fillRect(0, 0, w, h);
      g.strokeStyle = color; g.lineWidth = 9; g.lineCap = 'round'; g.lineJoin = 'round'; g.shadowColor = color; g.shadowBlur = 14;
      for (let k = 0; k < 2; k++) { g.beginPath(); g.moveTo(34 + k * 34, 28); g.lineTo(62 + k * 34, 64); g.lineTo(34 + k * 34, 100); g.stroke(); }
      g.strokeRect(6, 6, w - 12, h - 12);
    });
  },
  reelDrum: () => make('reelDrum', 512, 128, (g, w, h) => {
    g.fillStyle = '#fff4d0'; g.fillRect(0, 0, w, h);
    drawFlower(g, 64, 64, 48); drawBullseye(g, 192, 64, 46); drawStar(g, 320, 66, 50); drawSmiley(g, 448, 64, 46);
    g.strokeStyle = INK; g.lineWidth = 3; for (let i = 0; i < 4; i++) { g.beginPath(); g.moveTo(i * 128, 0); g.lineTo(i * 128, h); g.stroke(); }
  }),
  glow: () => make('glow', 64, 64, (g) => {
    const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
    gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.35, 'rgba(255,255,255,0.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  }),
  blot: () => make('blot', 128, 128, (g) => {
    const rng = new Rng(77);
    g.fillStyle = '#fff'; g.beginPath();
    for (let i = 0; i < 24; i++) { const a = (i / 24) * TAU, r = i % 2 ? rng.range(26, 38) : rng.range(44, 58); g.lineTo(64 + Math.cos(a) * r, 64 + Math.sin(a) * r); }
    g.closePath(); g.fill();
    for (let i = 0; i < 7; i++) { g.beginPath(); g.arc(64 + rng.range(-56, 56), 64 + rng.range(-56, 56), rng.range(2, 6), 0, TAU); g.fill(); }
  }),
  ghost: () => make('ghost', 128, 256, (g) => {
    g.fillStyle = INK; g.beginPath(); g.ellipse(64, 54, 26, 34, 0, 0, TAU); g.fill();
    g.beginPath(); g.moveTo(24, 220); g.quadraticCurveTo(30, 100, 64, 92); g.quadraticCurveTo(98, 100, 104, 220); g.closePath(); g.fill();
  }),
  exclaim: () => make('exclaim', 64, 64, (g) => {
    g.fillStyle = '#ffd54a'; g.strokeStyle = INK; g.lineWidth = 5; g.lineJoin = 'round';
    g.beginPath(); g.moveTo(32, 5); g.lineTo(60, 56); g.lineTo(4, 56); g.closePath(); g.fill(); g.stroke();
    g.fillStyle = INK; g.fillRect(29, 20, 6, 20); g.beginPath(); g.arc(32, 47, 4, 0, TAU); g.fill();
  }),
  /** Hand-drawn arena floor emblem: ink crown + sun on kraft, or neon rings + star at night. */
  emblem: (night: boolean) => make('emblem' + night, 512, 512, (g) => {
    g.translate(256, 256); g.lineCap = 'round'; g.lineJoin = 'round';
    if (night) {
      const ring = (r: number, c: string, lw: number, dash: number[] = []) => { g.shadowColor = c; g.shadowBlur = 22; g.strokeStyle = c; g.lineWidth = lw; g.setLineDash(dash); g.beginPath(); g.arc(0, 0, r, 0, TAU); g.stroke(); };
      ring(238, '#ff3b5c', 10); ring(206, '#33d6ff', 6); ring(176, '#ff35c8', 5, [14, 18]);
      g.setLineDash([]); g.shadowColor = '#ffd54a'; g.strokeStyle = '#ffd54a'; g.lineWidth = 9; g.beginPath();
      for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i / 10) * TAU, r = i % 2 ? 62 : 138; g.lineTo(Math.cos(a) * r, Math.sin(a) * r); }
      g.closePath(); g.stroke();
    } else {
      g.strokeStyle = 'rgba(60,30,5,0.62)'; g.lineWidth = 9; g.beginPath(); g.arc(0, 0, 238, 0, TAU); g.stroke();
      g.lineWidth = 5; g.beginPath(); g.arc(0, 0, 214, 0, TAU); g.stroke();
      for (let i = 0; i < 24; i++) { const a = (i / 24) * TAU, r0 = 150, r1 = i % 2 ? 190 : 205; g.beginPath(); g.moveTo(Math.cos(a) * r0, Math.sin(a) * r0); g.lineTo(Math.cos(a) * r1, Math.sin(a) * r1); g.stroke(); }
      g.beginPath(); g.arc(0, 0, 120, 0, TAU); g.stroke();
      drawCrown(g, 0, 8, 62, 'rgba(60,30,5,0.7)');
      g.lineWidth = 6; g.beginPath(); g.arc(0, 52, 46, 0.15 * Math.PI, 0.85 * Math.PI); g.stroke();
    }
  }),
  /** Painted wooden sign board. */
  sign: (text: string) => make('sign' + text, 256, 128, (g, w, h) => {
    const rng = new Rng(text.length * 31 + 7);
    g.fillStyle = '#9c6a3a'; g.fillRect(0, 0, w, h); stripes(g, w, h, 14, 0.12); fibers(g, w, h, rng, 300, 0.12);
    g.strokeStyle = INK; g.lineWidth = 8; g.strokeRect(4, 4, w - 8, h - 8);
    g.font = 'bold 54px Impact, "Arial Black", sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.lineWidth = 9; g.lineJoin = 'round';
    g.strokeStyle = INK; g.strokeText(text, w / 2, h / 2 + 3); g.fillStyle = '#f3e7cc'; g.fillText(text, w / 2, h / 2 + 3);
  }),
  /** Ink doodles drawn on the canyon walls. */
  cliffArt: (v: number) => make('cliff' + v, 256, 128, (g) => {
    g.strokeStyle = 'rgba(20,16,22,0.85)'; g.lineWidth = 5; g.lineCap = 'round'; g.lineJoin = 'round'; g.fillStyle = 'rgba(255,225,150,0.6)';
    if (v === 0) {
      g.beginPath(); g.arc(128, 68, 34, 0, TAU); g.fill(); g.stroke();
      for (let i = 0; i < 14; i++) { const a = (i / 14) * TAU; g.beginPath(); g.moveTo(128 + Math.cos(a) * 42, 68 + Math.sin(a) * 42); g.lineTo(128 + Math.cos(a) * (i % 2 ? 54 : 62), 68 + Math.sin(a) * (i % 2 ? 54 : 62)); g.stroke(); }
      drawCrown(g, 128, 22, 14, INK);
      g.fillStyle = INK; g.beginPath(); g.arc(116, 64, 4, 0, TAU); g.fill(); g.beginPath(); g.arc(140, 64, 4, 0, TAU); g.fill();
      g.beginPath(); g.arc(128, 70, 14, 0.2 * Math.PI, 0.8 * Math.PI); g.stroke();
    } else if (v === 1) {
      g.beginPath(); g.moveTo(30, 52); g.lineTo(150, 52); g.lineTo(150, 28); g.lineTo(226, 70); g.lineTo(150, 112); g.lineTo(150, 88); g.lineTo(30, 88); g.closePath(); g.fill(); g.stroke();
      inkLine(g, [[60, 62], [84, 78]], 5); inkLine(g, [[84, 62], [60, 78]], 5);
    } else {
      g.fillStyle = 'rgba(120,190,120,0.7)';
      [[70, 40, 22, 80], [38, 62, 14, 34], [102, 56, 14, 38]].forEach(([x, y, w, h]) => { g.beginPath(); g.roundRect(x, y, w, h, 8); g.fill(); g.stroke(); });
      drawStar(g, 190, 40, 22, '#ffd54a'); drawStar(g, 220, 90, 12, '#ffd54a');
    }
  }),
  jackFace: () => make('jackFace', 256, 256, (g) => {
    g.fillStyle = '#ffe9a8'; g.beginPath(); g.arc(128, 128, 120, 0, TAU); g.fill(); g.strokeStyle = INK; g.lineWidth = 8; g.stroke();
    g.fillStyle = 'rgba(255,110,140,0.7)'; g.beginPath(); g.arc(54, 150, 20, 0, TAU); g.fill(); g.beginPath(); g.arc(202, 150, 20, 0, TAU); g.fill();
    [[88, 100], [168, 100]].forEach(([x, y]) => { g.fillStyle = '#fff'; g.beginPath(); g.arc(x, y, 26, 0, TAU); g.fill(); g.stroke(); g.fillStyle = INK; g.beginPath(); g.arc(x + 4, y + 4, 11, 0, TAU); g.fill(); });
    g.fillStyle = '#e0384a'; g.beginPath(); g.arc(128, 132, 18, 0, TAU); g.fill(); g.stroke();
    g.fillStyle = INK; g.beginPath(); g.moveTo(66, 168); g.quadraticCurveTo(128, 236, 190, 168); g.quadraticCurveTo(128, 196, 66, 168); g.fill();
    g.fillStyle = '#fff'; for (let x = 84; x < 180; x += 24) g.fillRect(x, 176, 14, 12);
  }),
  chevron: (color: string) => make('chev' + color, 128, 128, (g) => {
    g.strokeStyle = color; g.lineWidth = 12; g.lineCap = 'round'; g.lineJoin = 'round'; g.shadowColor = color; g.shadowBlur = 16;
    for (let k = 0; k < 2; k++) { g.beginPath(); g.moveTo(26 + k * 42, 24); g.lineTo(62 + k * 42, 64); g.lineTo(26 + k * 42, 104); g.stroke(); }
  }),
  ray: () => make('ray', 64, 256, (g, w, h) => {
    const gr = g.createLinearGradient(0, 0, w, 0); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.5, 'rgba(255,255,255,1)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    const v = g.createLinearGradient(0, 0, 0, h); v.addColorStop(0, 'rgba(0,0,0,0)'); v.addColorStop(0.5, 'rgba(0,0,0,0.5)'); v.addColorStop(1, 'rgba(0,0,0,1)');
    g.globalCompositeOperation = 'destination-out'; g.fillStyle = v; g.fillRect(0, 0, w, h);
  }),
  banner: () => make('banner', 128, 256, (g, w, h) => {
    const rng = new Rng(6);
    g.fillStyle = '#c92b2b'; g.fillRect(0, 0, w, h); fibers(g, w, h, rng, 220, 0.12);
    g.strokeStyle = '#c9a45c'; g.lineWidth = 8; g.strokeRect(8, 8, w - 16, h - 16);
    drawFlower(g, 64, 100, 42); drawStar(g, 64, 196, 22);
    g.fillStyle = '#c92b2b'; g.beginPath(); g.moveTo(0, h); g.lineTo(w / 2, h - 28); g.lineTo(w, h); g.lineTo(w, h + 2); g.lineTo(0, h + 2); g.fill();
  }),
  floorSnow: () => make('floorSnow', 512, 512, (g, w, h) => {
    const rng = new Rng(51);
    g.fillStyle = '#e8f0fa'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 9; i++) {
      const gr = g.createRadialGradient(rng.range(0, w), rng.range(0, h), 6, rng.range(0, w), rng.range(0, h), rng.range(50, 150));
      gr.addColorStop(0, 'rgba(255,255,255,0.4)'); gr.addColorStop(1, 'rgba(140,170,215,0)');
      g.fillStyle = gr; g.fillRect(0, 0, w, h);
    }
    stripes(g, w, h, 14, 0.05); fibers(g, w, h, rng, 2200, 0.07);
    g.strokeStyle = 'rgba(80,110,160,0.5)'; g.lineWidth = 4;
    g.beginPath(); g.moveTo(w / 2, 0); g.lineTo(w / 2, h); g.moveTo(0, h / 2); g.lineTo(w, h / 2); g.stroke();
    for (let i = 0; i < 4; i++) crack(g, rng, rng.range(0, w), rng.range(0, h), rng.int(4, 7), 2);
    g.lineCap = 'round'; g.strokeStyle = 'rgba(30,50,120,0.6)'; g.lineWidth = 2.5;
    for (let i = 0; i < 7; i++) {
      const x = rng.range(30, w - 30), y = rng.range(30, h - 30), r = rng.range(10, 17);
      for (let k = 0; k < 6; k++) {
        const a = (k / 6) * TAU;
        g.beginPath(); g.moveTo(x, y); g.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r); g.stroke();
        const mx = x + Math.cos(a) * r * 0.6, my = y + Math.sin(a) * r * 0.6;
        for (const s of [-1, 1]) { g.beginPath(); g.moveTo(mx, my); g.lineTo(mx + Math.cos(a + s * 0.7) * r * 0.35, my + Math.sin(a + s * 0.7) * r * 0.35); g.stroke(); }
      }
    }
  }, { repeat: true }),
  /** Pastel play-mat with crayon doodles. */
  floorToy: () => make('floorToy', 512, 512, (g, w, h) => {
    const rng = new Rng(61), cols = ['#ffd9e0', '#d6ecff', '#fff3c0', '#d9f5df'], s = w / 2;
    for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { g.fillStyle = cols[(i * 2 + j) % 4]; g.fillRect(i * s, j * s, s, s); }
    stripes(g, w, h, 12, 0.05); fibers(g, w, h, rng, 1800, 0.07);
    g.fillStyle = 'rgba(120,125,140,0.55)'; g.fillRect(0, h / 2 - 22, w, 44);
    g.strokeStyle = 'rgba(255,255,255,0.8)'; g.lineWidth = 5; g.setLineDash([26, 22]); g.beginPath(); g.moveTo(0, h / 2); g.lineTo(w, h / 2); g.stroke(); g.setLineDash([]);
    g.strokeStyle = 'rgba(60,40,60,0.55)'; g.lineWidth = 4; g.beginPath(); g.moveTo(s, 0); g.lineTo(s, h); g.stroke();
    drawStar(g, 90, 110, 24, '#ffd54a'); drawFlower(g, 400, 100, 30, '#ff8fb8'); drawSmiley(g, 120, 400, 26); drawStar(g, 410, 410, 20, '#ff9a2e');
    g.strokeStyle = 'rgba(224,56,74,0.7)'; g.lineWidth = 5; g.lineCap = 'round'; g.beginPath(); g.moveTo(220, 330); g.bezierCurveTo(250, 290, 290, 370, 330, 320); g.stroke();
    g.strokeStyle = 'rgba(63,140,240,0.7)'; g.beginPath(); g.moveTo(200, 60); g.bezierCurveTo(230, 20, 270, 100, 320, 50); g.stroke();
  }, { repeat: true }),
  /** Dark foundry plates; with `glow` set it draws only the lava cracks (used as the emissive map). */
  floorEmber: (glow: boolean) => make('floorEmber' + glow, 512, 512, (g, w, h) => {
    const rng = new Rng(71);
    const paths: number[][][] = [];
    for (let i = 0; i < 11; i++) {
      let x = rng.range(0, w), y = rng.range(0, h), a = rng.range(0, TAU);
      const pts = [[x, y]];
      for (let k = rng.int(5, 10); k > 0; k--) { a += rng.range(-0.8, 0.8); x += Math.cos(a) * rng.range(8, 22); y += Math.sin(a) * rng.range(8, 22); pts.push([x, y]); }
      paths.push(pts);
    }
    if (glow) { g.fillStyle = '#000'; g.fillRect(0, 0, w, h); } else {
      g.fillStyle = '#3a2a2e'; g.fillRect(0, 0, w, h);
      for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) { g.fillStyle = `hsl(350,14%,${16 + rng.range(-2, 4)}%)`; g.fillRect(i * 256 + 3, j * 256 + 3, 250, 250); }
      stripes(g, w, h, 12, 0.08); fibers(g, w, h, rng, 1600, 0.07);
    }
    g.lineCap = 'round'; g.lineJoin = 'round';
    g.strokeStyle = glow ? '#ff5a1a' : '#140a0c'; g.lineWidth = glow ? 3 : 5;
    g.beginPath(); g.moveTo(256, 0); g.lineTo(256, h); g.moveTo(0, 256); g.lineTo(w, 256); g.stroke();
    for (const pts of paths) {
      g.strokeStyle = glow ? '#ff7a1a' : '#140a0c'; g.lineWidth = glow ? 5 : 6;
      g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); g.stroke();
      if (glow) { g.strokeStyle = '#ffd54a'; g.lineWidth = 2; g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p[0], p[1]) : g.moveTo(p[0], p[1]))); g.stroke(); }
    }
  }, { repeat: true }),
  lava: () => make('lava', 256, 256, (g, w, h) => {
    const rng = new Rng(81);
    g.fillStyle = '#ff5a14'; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 26; i++) { g.fillStyle = `rgba(255,${rng.int(180, 235)},60,${rng.range(0.25, 0.7)})`; g.beginPath(); g.ellipse(rng.range(0, w), rng.range(0, h), rng.range(14, 44), rng.range(8, 24), rng.range(0, 3), 0, TAU); g.fill(); }
    for (let i = 0; i < 12; i++) { g.fillStyle = `rgba(70,20,10,${rng.range(0.35, 0.7)})`; g.beginPath(); g.ellipse(rng.range(0, w), rng.range(0, h), rng.range(10, 30), rng.range(6, 14), rng.range(0, 3), 0, TAU); g.fill(); }
  }, { repeat: true }),
  /** Alphabet toy-block face. */
  block: (ch: string) => make('block' + ch, 128, 128, (g) => {
    g.fillStyle = 'rgba(255,255,255,0.93)'; g.beginPath(); g.roundRect(14, 14, 100, 100, 14); g.fill();
    g.strokeStyle = INK; g.lineWidth = 6; g.stroke();
    g.fillStyle = INK; g.font = 'bold 78px Impact, "Arial Black", sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(ch, 64, 70);
  }),
  starfield: () => make('starfield', 512, 256, (g, w, h) => {
    const rng = new Rng(4);
    for (let i = 0; i < 260; i++) { g.fillStyle = `rgba(255,255,255,${rng.range(0.3, 1)})`; const s = rng.range(0.6, 2); g.fillRect(rng.range(0, w), rng.range(0, h * 0.9), s, s); }
  }),
};

// ------------------------------------------------------------ materials
let toonGradient: THREE.DataTexture | null = null;
export function gradientMap(): THREE.DataTexture {
  if (!toonGradient) {
    toonGradient = new THREE.DataTexture(new Uint8Array([90, 90, 90, 255, 165, 165, 165, 255, 215, 215, 215, 255, 255, 255, 255, 255]), 4, 1, THREE.RGBAFormat);
    toonGradient.minFilter = toonGradient.magFilter = THREE.NearestFilter;
    toonGradient.needsUpdate = true;
  }
  return toonGradient;
}

/** Shared rim-light uniforms; the engine tints them per arena. */
export const rimU = { color: { value: new THREE.Color(1, 0.75, 0.5) }, strength: { value: 0.3 } };
type Shader = Parameters<THREE.Material['onBeforeCompile']>[0];
/**
 * Soft fresnel rim light for toon materials. Side-facing surfaces catch it and floors barely do,
 * which separates creatures and props from the background and gives every arena its own edge colour.
 */
export function rimPatch(sh: Shader) {
  sh.uniforms.rimColor = rimU.color; sh.uniforms.rimStrength = rimU.strength;
  sh.fragmentShader = 'uniform vec3 rimColor;\nuniform float rimStrength;\n' + sh.fragmentShader.replace(
    '#include <opaque_fragment>',
    'float rimF = pow(1.0 - saturate(dot(normal, normalize(vViewPosition))), 2.6) * (1.0 - 0.85 * saturate(inverseTransformDirection(normal, viewMatrix).y));\n  outgoingLight += rimColor * rimF * rimStrength;\n#include <opaque_fragment>',
  );
}
// every toon material (including clones) gets the rim light
THREE.MeshToonMaterial.prototype.onBeforeCompile = rimPatch;

const matCache = new Map<string, THREE.MeshToonMaterial>();
export const M = {
  /** Toon-shaded painted cardboard of any colour, with corrugation bump. */
  paper(color: string, bump = 0.8): THREE.MeshToonMaterial {
    const k = 'p' + color + bump;
    let m = matCache.get(k);
    if (!m) { m = new THREE.MeshToonMaterial({ map: T.paper(color), bumpMap: T.corrBump(), bumpScale: bump, gradientMap: gradientMap() }); matCache.set(k, m); }
    return m;
  },
  tex(t: THREE.Texture, key: string, opts: { transparent?: boolean; double?: boolean; bump?: boolean; color?: number } = {}): THREE.MeshToonMaterial {
    const k = 't' + key + JSON.stringify(opts);
    let m = matCache.get(k);
    if (!m) {
      m = new THREE.MeshToonMaterial({ map: t, gradientMap: gradientMap(), transparent: !!opts.transparent, alphaTest: opts.transparent ? 0.35 : 0, side: opts.double ? THREE.DoubleSide : THREE.FrontSide, bumpMap: opts.bump ? T.corrBump() : null, bumpScale: 0.6, color: opts.color ?? 0xffffff });
      matCache.set(k, m);
    }
    return m;
  },
  edge(color = '#b98a52'): THREE.MeshToonMaterial { return M.tex(T.edge(color), 'edge' + color); },
  /** Emissive unlit material boosted above 1.0 so the bloom pass picks it up. */
  glow(color: number, boost = 2.2): THREE.MeshBasicMaterial {
    const m = new THREE.MeshBasicMaterial({ color, toneMapped: false });
    m.color.multiplyScalar(boost);
    return m;
  },
};

/** Remap box UVs to world-sized tiles so big mesas don't stretch the texture. */
export function boxGeo(w: number, h: number, d: number, tile = 2): THREE.BoxGeometry {
  const g = new THREE.BoxGeometry(w, h, d);
  const uv = g.attributes.uv as THREE.BufferAttribute, nrm = g.attributes.normal as THREE.BufferAttribute;
  for (let i = 0; i < uv.count; i++) {
    const ax = Math.abs(nrm.getX(i)), ay = Math.abs(nrm.getY(i));
    const [uw, vh] = ax > 0.5 ? [d, h] : ay > 0.5 ? [w, d] : [w, h];
    uv.setXY(i, (uv.getX(i) * uw) / tile, (uv.getY(i) * vh) / tile);
  }
  return g;
}
