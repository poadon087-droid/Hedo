/**
 * The two arenas: Golden-Hour Canyon and Neon Night Carnival.
 * Boundaries are visible geometry (cliff strata / floating-island rim and fence), never plain air.
 */
import * as THREE from 'three';
import { Rng, TAU, makeCollider, resolveCircle, type Collider, type Crate } from './core';
import { M, T, boxGeo, gradientMap } from './textures';
import { cactus, crescentShape, extrude, instanced, makeCrate, mk, palmTree, petalShape, pineForest, starShape } from './models';
import { buildDomeModel } from './enemies';
import { dressCanyon, dressNight } from './decor';

export type MapId = 'canyon' | 'night' | 'snow' | 'toy' | 'ember';

/** Colour / bloom / dust look applied by the engine when an arena loads. */
export interface MapLook { bloom: number; thr: number; dust: number; wh: number; wg: number; wk: number; wr: number }
export interface Zone { x: number; z: number; r: number }
/** Lava vent hazard. `state` (0 idle, 1 warning, 2 erupting) is written by the engine and read by the arena visuals. */
export interface Geyser { x: number; z: number; r: number; period: number; offset: number; state: 0 | 1 | 2; hit: boolean }

export interface MapData {
  id: MapId;
  name: string;
  mood: 'day' | 'night';
  look: MapLook;
  /** Trampolines, slippery ice patches and lava vents. */
  pads: Zone[];
  ice: Zone[];
  geysers: Geyser[];
  /** Simulation clock mirrored from the engine so hazard visuals match hazard damage. */
  simTime: number;
  root: THREE.Group;
  colliders: Collider[];
  crates: Crate[];
  spawns: THREE.Vector3[];
  coinSpots: THREE.Vector3[];
  radius: number;
  start: THREE.Vector3;
  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  fog: THREE.Fog;
  bg: number;
  domeProp: THREE.Object3D | null;
  env: THREE.Texture | null;
  /** Colour grade, light direction, sun shafts, exposure and rim light (filled in by scenery.ts). */
  grade?: { shadow: [number, number, number]; high: [number, number, number]; sat: number; con: number };
  lightDir?: THREE.Vector3;
  shaft?: { k: number; color: number };
  exposure?: number;
  rim?: { color: number; k: number };
  update(dt: number, t: number, player: THREE.Vector3): void;
  dispose(): void;
}

const ARENA_R = 30.5;

interface StackDef { x: number; z: number; w: number; d: number; layers: number }
const STACKS: StackDef[] = [
  { x: -13, z: -6, w: 6, d: 4.5, layers: 2 }, { x: -13, z: -1.4, w: 3, d: 3, layers: 1 },
  { x: 12, z: -9, w: 5, d: 6, layers: 2 }, { x: 7, z: -9, w: 3, d: 3, layers: 1 },
  { x: -3, z: -17, w: 9, d: 3.5, layers: 1 }, { x: 20, z: 7, w: 4, d: 4, layers: 1 },
  { x: -21, z: 9, w: 4, d: 6, layers: 1 }, { x: 3, z: -4, w: 3, d: 3, layers: 1 },
  { x: -7, z: 10, w: 5, d: 3, layers: 1 }, { x: 14, z: 16, w: 3.5, d: 3.5, layers: 2 }, { x: 10.5, z: 16, w: 3, d: 3, layers: 1 },
];
const LAYER_H = 1.2;

function buildCommon(rng: Rng, night: boolean, root: THREE.Group, cols: Collider[], crates: Crate[], anims: ((dt: number, t: number) => void)[]) {
  const colors = night ? ['#8a4a3e', '#7d3f52', '#96593f'] : ['#c4935a', '#d09f66', '#b98550'];
  // --- cardboard mesa stacks (the cover)
  STACKS.forEach((s, si) => {
    const g = new THREE.Group();
    for (let l = 0; l < s.layers; l++) {
      const inset = l * 0.18;
      const b = mk(boxGeo(s.w - inset, LAYER_H, s.d - inset, 2.4), M.paper(colors[(si + l) % 3]), { outline: 0.03 });
      b.position.y = LAYER_H * (l + 0.5);
      g.add(b);
      const tape = mk(new THREE.BoxGeometry(s.w - inset + 0.05, 0.03, 0.4), M.tex(T.tape(night ? '#33d6ff' : '#e0b84a'), night ? 'tapeC' : 'tapeY'), { cast: false });
      tape.position.set(0, LAYER_H * (l + 1) + 0.005, 0);
      g.add(tape);
    }
    if (night) {
      const strip = new THREE.Mesh(new THREE.BoxGeometry(s.w + 0.05, 0.08, 0.08), M.glow(si % 2 ? 0x33d6ff : 0xff3b5c, 2.4));
      strip.position.set(0, s.layers * LAYER_H + 0.02, s.d / 2 + 0.02); g.add(strip);
    }
    g.position.set(s.x, 0, s.z);
    root.add(g);
    cols.push(makeCollider(s.x, s.z, s.w, s.d, 0, s.layers * LAYER_H, 'wall'));
  });
  // --- rolled-paper pillars
  [[-7, -10], [8, 2], [-18, -14], [22, -2]].forEach(([x, z]) => {
    const p = mk(new THREE.CylinderGeometry(0.8, 0.8, 4, 14), [M.edge(), M.paper('#d8b27a'), M.paper('#d8b27a')], { outline: 0.03 });
    p.position.set(x, 2, z);
    const cap = mk(new THREE.CylinderGeometry(0.95, 0.95, 0.2, 14), M.paper(night ? '#c92b2b' : '#e0a040'), { outline: 0.03 });
    cap.position.y = 2.1; p.add(cap);
    root.add(p);
    cols.push(makeCollider(x, z, 1.6, 1.6, 0, 4, 'pillar'));
  });
  // --- destructible crates
  let tries = 0;
  while (crates.length < 16 && tries++ < 400) {
    const a = rng.range(0, TAU), r = rng.range(5, 25), size = rng.range(1.0, 1.5);
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (Math.abs(x) < 3 && z > 12) continue; // keep the player start clear
    const probe = { x, y: 0, z };
    const before = { x, z };
    resolveCircle(probe, size * 0.75 + 0.4, 1, cols, 0);
    if (Math.abs(probe.x - before.x) > 1e-3 || Math.abs(probe.z - before.z) > 1e-3) continue;
    const mesh = makeCrate(size);
    mesh.position.set(x, 0, z); mesh.rotation.y = rng.range(-0.3, 0.3);
    root.add(mesh);
    const collider = makeCollider(x, z, size, size, 0, size, 'crate');
    const crate: Crate = { collider, mesh, hp: 20 + size * 10, maxHp: 20 + size * 10, shake: 0, loot: rng.chance(0.45) };
    collider.crate = crate;
    cols.push(collider); crates.push(crate);
  }
  void anims;
}

function floorSpawns(cols: Collider[], rng: Rng): THREE.Vector3[] {
  const out: THREE.Vector3[] = [];
  for (let i = 0; i < 48 && out.length < 22; i++) {
    const a = (i / 48) * TAU + rng.range(-0.1, 0.1), r = rng.range(15, 28);
    const p = { x: Math.cos(a) * r, y: 0, z: Math.sin(a) * r };
    const q = { ...p };
    resolveCircle(q, 1.0, 1.5, cols, 0.1);
    if (Math.hypot(q.x - p.x, q.z - p.z) < 0.01) out.push(new THREE.Vector3(p.x, 0, p.z));
  }
  return out;
}
function coinSpots(cols: Collider[], rng: Rng): THREE.Vector3[] {
  const out: THREE.Vector3[] = [];
  for (let i = 0; i < 60 && out.length < 14; i++) {
    const a = rng.range(0, TAU), r = rng.range(4, 26), p = { x: Math.cos(a) * r, y: 0, z: Math.sin(a) * r }, q = { ...p };
    resolveCircle(q, 0.8, 1.5, cols, 0.1);
    if (Math.hypot(q.x - p.x, q.z - p.z) < 0.01) out.push(new THREE.Vector3(p.x, 1.1, p.z));
  }
  return out;
}

function skyDome(top: number, horizon: number, sunDir: THREE.Vector3, sunCol: number, glow: number) {
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color(top) }, hor: { value: new THREE.Color(horizon) }, sunDir: { value: sunDir.clone().normalize() }, sunCol: { value: new THREE.Color(sunCol) }, glow: { value: glow } },
    vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
    fragmentShader: 'uniform vec3 top; uniform vec3 hor; uniform vec3 sunDir; uniform vec3 sunCol; uniform float glow; varying vec3 vP; void main(){ float h = clamp(vP.y,0.0,1.0); vec3 c = mix(hor, top, pow(h,0.55)); float s = max(dot(normalize(vP), sunDir),0.0); c += sunCol * (pow(s,6.0)*0.45*glow + pow(s,160.0)*glow); gl_FragColor = vec4(c,1.0); }',
  });
  const m = new THREE.Mesh(new THREE.SphereGeometry(400, 24, 16), mat);
  m.renderOrder = -10;
  return { mesh: m, mat };
}

function glowSprite(color: number, size: number, opacity = 1): THREE.Sprite {
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity, fog: false, toneMapped: false }));
  s.scale.setScalar(size);
  return s;
}

// ====================================================================== CANYON
function buildCanyon(rng: Rng): MapData {
  const root = new THREE.Group();
  const cols: Collider[] = [], crates: Crate[] = [], anims: ((dt: number, t: number) => void)[] = [];

  // lights
  const hemi = new THREE.HemisphereLight(0xa9d0ff, 0xb97a4a, 1.7);
  const sun = new THREE.DirectionalLight(0xffd9a0, 3.4);
  sun.castShadow = true; sun.shadow.camera.left = -32; sun.shadow.camera.right = 32; sun.shadow.camera.top = 32; sun.shadow.camera.bottom = -32;
  sun.shadow.camera.near = 1; sun.shadow.camera.far = 160; sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.05; sun.shadow.mapSize.set(2048, 2048);
  root.add(hemi, sun, sun.target);
  const sunDir = new THREE.Vector3(0.55, 0.5, -0.65).normalize();

  const sky = skyDome(0x4fa7e8, 0xffd9a0, sunDir, 0xffb060, 1);
  root.add(sky.mesh);
  const sunSprite = glowSprite(0xffd890, 170, 0.9); sunSprite.position.copy(sunDir).multiplyScalar(330); root.add(sunSprite);
  const flare = glowSprite(0xffa050, 40, 0.5); flare.position.copy(sunDir).multiplyScalar(130); root.add(flare);

  // floor
  const ft = T.floorDay(); ft.repeat.set(26, 26);
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(210, 210), new THREE.MeshToonMaterial({ map: ft, bumpMap: T.corrBump(), bumpScale: 0.5, gradientMap: gradientMap() }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; root.add(floor);

  buildCommon(rng, false, root, cols, crates, anims);

  // cliff ring: stacked strata that form the real boundary
  const strata = ['#c4753c', '#b0623a', '#d99a5a', '#a85a34', '#e0a868'];
  const N = 26;
  for (let i = 0; i < N; i++) {
    const a = (i / N) * TAU, r = 36 + rng.range(-0.6, 0.6);
    const g = new THREE.Group();
    const layers = rng.int(3, 5);
    let y = 0;
    for (let l = 0; l < layers; l++) {
      const h = rng.range(2.5, 4), w = 10.5 - l * 0.8 + rng.range(-0.6, 0.6), d = 8 - l * 0.9;
      const b = mk(boxGeo(w, h, d, 3), M.paper(strata[(i + l * 2) % strata.length]), { cast: false });
      b.position.set(rng.range(-0.3, 0.3), y + h / 2, rng.range(-0.3, 0.3)); y += h;
      g.add(b);
      if (l === 0 && i % 2 === 0) {
        // hand-inked doodle on the inner face of the cliff (local -z faces the arena)
        const v = (i >> 1) % 3, art = new THREE.Mesh(new THREE.PlaneGeometry(4.6, 2.3), M.tex(T.cliffArt(v), 'cliff' + v, { transparent: true }));
        art.position.set(b.position.x, 1.3, b.position.z - d / 2 - 0.04); art.rotation.y = Math.PI; g.add(art);
      }
    }
    g.position.set(Math.cos(a) * r, 0, Math.sin(a) * r);
    g.rotation.y = -a + Math.PI / 2;
    root.add(g);
  }
  // distant big mesas
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU + 0.2, r = rng.range(62, 85), h = rng.range(18, 34), w = rng.range(14, 24);
    const b = mk(boxGeo(w, h, w * 0.8, 4), M.paper(strata[i % strata.length]), { cast: false, receive: false });
    b.position.set(Math.cos(a) * r, h / 2, Math.sin(a) * r); b.rotation.y = rng.range(0, 3);
    root.add(b);
  }

  // pines (instanced) on the cliff tops and a few at the arena rim, small cacti inside
  const pts: { x: number; z: number; s: number }[] = [];
  for (let i = 0; i < 26; i++) { const a = rng.range(0, TAU), r = rng.range(38, 56); pts.push({ x: Math.cos(a) * r, z: Math.sin(a) * r, s: rng.range(1.4, 2.6) }); }
  const pineRoot = pineForest(pts);
  // lift the instanced pines onto the cliff tops
  pineRoot.position.y = 10; root.add(pineRoot);
  const rimPts: { x: number; z: number; s: number }[] = [];
  for (let i = 0; i < 8; i++) { const a = (i / 8) * TAU + 0.3, r = 29.3; rimPts.push({ x: Math.cos(a) * r, z: Math.sin(a) * r, s: rng.range(0.5, 0.7) }); }
  root.add(pineForest(rimPts));
  for (let i = 0; i < 12; i++) {
    const a = rng.range(0, TAU), r = rng.range(8, 29);
    const c = cactus(rng.range(0.6, 1.4)); c.position.set(Math.cos(a) * r, 0, Math.sin(a) * r);
    const probe = { x: c.position.x, y: 0, z: c.position.z }; resolveCircle(probe, 0.6, 1, cols, 0);
    if (Math.hypot(probe.x - c.position.x, probe.z - c.position.z) > 0.01) continue;
    root.add(c);
  }

  // wooden shelter with slanted roof
  {
    const g = new THREE.Group(); const wood = M.paper('#8a5a32'), roofM = M.paper('#a8703c');
    [[-3.5, -2.5], [3.5, -2.5], [-3.5, 2.5], [3.5, 2.5]].forEach(([x, z], i) => {
      const p = mk(new THREE.BoxGeometry(0.45, i < 2 ? 4.4 : 3.2, 0.45), wood, { outline: 0.03 }); p.position.set(x, (i < 2 ? 4.4 : 3.2) / 2, z); g.add(p);
      cols.push(makeCollider(x - 24, z - 18, 0.5, 0.5, 0, 3, 'pillar'));
    });
    const roof = mk(boxGeo(9.4, 0.3, 7, 2), roofM, { outline: 0.03 }); roof.position.y = 3.9; roof.rotation.x = 0.2; g.add(roof);
    const beam = mk(new THREE.BoxGeometry(8, 0.3, 0.3), wood); beam.position.set(0, 3.1, 0); g.add(beam);
    g.position.set(-24, 0, -18); root.add(g);
  }
  // watchtower with red flag
  {
    const g = new THREE.Group(); const wood = M.paper('#7a4e2a');
    [[-1.3, -1.3], [1.3, -1.3], [-1.3, 1.3], [1.3, 1.3]].forEach(([x, z]) => { const p = mk(new THREE.BoxGeometry(0.34, 6.2, 0.34), wood, { outline: 0.03 }); p.position.set(x, 3.1, z); p.rotation.set(z * 0.03, 0, -x * 0.03); g.add(p); });
    for (let k = 0; k < 3; k++) for (const s of [-1, 1]) { const br = mk(new THREE.BoxGeometry(3, 0.16, 0.16), wood); br.position.set(0, 1 + k * 1.8, s * 1.3); br.rotation.z = k % 2 ? 0.5 : -0.5; g.add(br); }
    const plat = mk(boxGeo(3.6, 0.3, 3.6, 2), M.paper('#b98a52'), { outline: 0.03 }); plat.position.y = 6.2; g.add(plat);
    const cabin = mk(boxGeo(2.6, 1.8, 2.6, 2), M.paper('#c4935a'), { outline: 0.03 }); cabin.position.y = 7.2; g.add(cabin);
    const roofT = mk(new THREE.ConeGeometry(2.2, 1.2, 4), M.paper('#a8703c'), { outline: 0.03 }); roofT.position.y = 8.7; roofT.rotation.y = Math.PI / 4; g.add(roofT);
    const pole = mk(new THREE.CylinderGeometry(0.05, 0.05, 3, 5), wood); pole.position.set(0, 10.2, 0); g.add(pole);
    const flag = new THREE.Group(); flag.position.set(0, 11, 0);
    const cloth = mk(new THREE.BoxGeometry(1.8, 1.2, 0.04), M.paper('#c92b2b'), { outline: 0.04 }); cloth.position.x = 0.95; flag.add(cloth);
    const emblem = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.8), M.tex(T.flowerSticker(), 'flower', { transparent: true, double: true })); emblem.position.set(0.95, 0, 0.03); flag.add(emblem);
    g.add(flag);
    anims.push((_, t) => { flag.rotation.y = Math.sin(t * 2.2) * 0.25; cloth.rotation.z = Math.sin(t * 3) * 0.05; });
    g.position.set(18, 0, -20); root.add(g);
    cols.push(makeCollider(18, -20, 3.4, 3.4, 0, 6.2, 'wall'));
  }

  // roller coaster looping over the canyon
  const ctrl: THREE.Vector3[] = [];
  for (let i = 0; i < 14; i++) { const a = (i / 14) * TAU, r = 44 + Math.sin(i * 1.7) * 6; ctrl.push(new THREE.Vector3(Math.cos(a) * r, 15 + Math.sin(i * 2.3) * 5 + (i % 4 === 0 ? 5 : 0), Math.sin(a) * r)); }
  const curve = new THREE.CatmullRomCurve3(ctrl, true);
  {
    const samples = 240, left: THREE.Vector3[] = [], right: THREE.Vector3[] = [], up = new THREE.Vector3(0, 1, 0);
    const tan = new THREE.Vector3(), side = new THREE.Vector3(), p = new THREE.Vector3();
    const sleepers: { x: number; y: number; z: number; ry: number }[] = [], posts: { x: number; y: number; z: number; sy: number }[] = [];
    for (let i = 0; i < samples; i++) {
      const u = i / samples; curve.getPointAt(u, p); curve.getTangentAt(u, tan); side.crossVectors(tan, up).normalize();
      left.push(p.clone().addScaledVector(side, 0.5)); right.push(p.clone().addScaledVector(side, -0.5));
      if (i % 3 === 0) sleepers.push({ x: p.x, y: p.y - 0.1, z: p.z, ry: Math.atan2(tan.x, tan.z) });
      if (i % 12 === 0) posts.push({ x: p.x, y: (p.y - 0.2) / 2, z: p.z, sy: p.y - 0.2 });
    }
    const railM = M.paper('#c92b2b');
    for (const pts2 of [left, right]) root.add(mk(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts2, true), 260, 0.09, 5, true), railM, { cast: false }));
    root.add(instanced(new THREE.BoxGeometry(1.2, 0.1, 0.22), M.paper('#8a5a32'), sleepers.map((s) => ({ ...s }))));
    root.add(instanced(new THREE.BoxGeometry(0.3, 1, 0.3), M.paper('#7a4e2a'), posts.map((s) => ({ x: s.x, y: s.y, z: s.z, sy: s.sy }))));
    const cart = new THREE.Group();
    const body = mk(boxGeo(1.6, 0.7, 1.1, 1), M.paper('#3f8cf0'), { outline: 0.04 }); body.position.y = 0.45; cart.add(body);
    root.add(cart);
    const q = new THREE.Vector3(), tq = new THREE.Vector3();
    anims.push((_, t) => { const u = (t * 0.02) % 1; curve.getPointAt(u, q); curve.getTangentAt(u, tq); cart.position.copy(q); cart.rotation.y = Math.atan2(tq.x, tq.z); });
    // floating coins along the track
    const coinCount = 18; const coinM = new THREE.Matrix4();
    const coinGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.1, 16); coinGeo.rotateX(Math.PI / 2);
    const face = M.tex(T.coin(), 'coin');
    const im = new THREE.InstancedMesh(coinGeo, [M.paper('#c99a20'), face, face], coinCount);
    root.add(im);
    const cp: THREE.Vector3[] = []; for (let i = 0; i < coinCount; i++) cp.push(curve.getPointAt((i / coinCount) * 0.9, new THREE.Vector3()).add(new THREE.Vector3(0, 1.6, 0)));
    const eu = new THREE.Euler(), qq = new THREE.Quaternion(), sc = new THREE.Vector3(1, 1, 1);
    anims.push((_, t) => { for (let i = 0; i < coinCount; i++) { eu.set(0, t * 2 + i, 0); qq.setFromEuler(eu); coinM.compose(cp[i], qq, sc); im.setMatrixAt(i, coinM); } im.instanceMatrix.needsUpdate = true; });
  }

  // paper clouds
  const clouds: THREE.Group[] = [];
  for (let i = 0; i < 9; i++) {
    const g = new THREE.Group();
    for (let k = 0; k < 5; k++) { const b = mk(new THREE.IcosahedronGeometry(rng.range(3, 5), 1), M.paper('#fff4e6'), { cast: false, receive: false }); b.position.set(k * 4 - 8, rng.range(-0.5, 1), rng.range(-1, 1)); b.scale.y = 0.55; g.add(b); }
    g.position.set(rng.range(-160, 160), rng.range(55, 90), rng.range(-200, -40)); clouds.push(g); root.add(g);
  }
  anims.push((dt) => clouds.forEach((c) => { c.position.x += dt * 1.2; if (c.position.x > 190) c.position.x = -190; }));

  dressCanyon(root, rng, cols, crates, anims, sunDir);
  const fog = new THREE.Fog(0xf5c88e, 55, 190);
  const spawns = floorSpawns(cols, rng);
  const coins = coinSpots(cols, rng);

  // dynamic time of day: golden hour slowly slides towards dusk
  const A = { sun: new THREE.Color(0xffd9a0), sky: new THREE.Color(0xa9d0ff), gnd: new THREE.Color(0xb97a4a), fog: new THREE.Color(0xf5c88e), top: new THREE.Color(0x4fa7e8), hor: new THREE.Color(0xffd9a0) };
  const B = { sun: new THREE.Color(0xff7a4a), sky: new THREE.Color(0x8a78c8), gnd: new THREE.Color(0x7a4a5a), fog: new THREE.Color(0xd08070), top: new THREE.Color(0x4a3f9a), hor: new THREE.Color(0xff9060) };
  let tod = 0, todAcc = 1;
  const dir = new THREE.Vector3();
  const applyTod = () => {
    sun.color.lerpColors(A.sun, B.sun, tod); hemi.color.lerpColors(A.sky, B.sky, tod); hemi.groundColor.lerpColors(A.gnd, B.gnd, tod);
    fog.color.lerpColors(A.fog, B.fog, tod);
    (sky.mat.uniforms.top.value as THREE.Color).lerpColors(A.top, B.top, tod); (sky.mat.uniforms.hor.value as THREE.Color).lerpColors(A.hor, B.hor, tod);
    sun.intensity = 3.4 - tod * 1.4; hemi.intensity = 1.7 - tod * 0.5;
    dir.set(0.55, 0.5 - tod * 0.3, -0.65).normalize(); sky.mat.uniforms.sunDir.value.copy(dir);
    sunSprite.position.copy(dir).multiplyScalar(330); flare.position.copy(dir).multiplyScalar(130);
  };
  applyTod();

  return finish({
    id: 'canyon', root, colliders: cols, crates, spawns, coinSpots: coins, radius: ARENA_R, start: new THREE.Vector3(0, 0, 20), sun, hemi, fog, bg: 0xf5c88e, domeProp: null, env: null,
    update(dt, t, player) {
      anims.forEach((f) => f(dt, t));
      todAcc += dt; tod = Math.min(0.55, tod + dt / 400);
      if (todAcc > 0.5) { todAcc = 0; applyTod(); }
      sun.position.set(player.x + dir.x * 70, dir.y * 70, player.z + dir.z * 70); sun.target.position.set(player.x, 0, player.z);
    },
  });
}

// ====================================================================== NIGHT
function buildNight(rng: Rng, renderer: THREE.WebGLRenderer): MapData {
  const root = new THREE.Group();
  const cols: Collider[] = [], crates: Crate[] = [], anims: ((dt: number, t: number) => void)[] = [];
  const hemi = new THREE.HemisphereLight(0x7a5ab0, 0x40203a, 1.5);
  const moonDir = new THREE.Vector3(-0.4, 0.8, -0.5).normalize();
  const sun = new THREE.DirectionalLight(0x9db0ff, 1.5);
  sun.castShadow = true; sun.shadow.camera.left = -32; sun.shadow.camera.right = 32; sun.shadow.camera.top = 32; sun.shadow.camera.bottom = -32;
  sun.shadow.camera.far = 160; sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.05; sun.shadow.mapSize.set(2048, 2048);
  root.add(hemi, sun, sun.target);
  const pl = [[0xff2a4a, -18, 5, -8], [0x2a7bff, 18, 5, -8], [0xff35c8, 0, 6, 14], [0x20e0ff, 0, 5, -26]] as const;
  pl.forEach(([c, x, y, z]) => { const l = new THREE.PointLight(c, 160, 60, 2); l.position.set(x, y, z); root.add(l); });

  const sky = skyDome(0x0b0626, 0xc83a6c, new THREE.Vector3(0, 0.05, -1), 0xff5a8a, 0.35);
  root.add(sky.mesh);
  const starGeo = new THREE.BufferGeometry(); const sp: number[] = [];
  for (let i = 0; i < 700; i++) { const a = rng.range(0, TAU), e = rng.range(0.05, 1.4), r = 380; sp.push(Math.cos(a) * Math.cos(e) * r, Math.sin(e) * r, Math.sin(a) * Math.cos(e) * r); }
  starGeo.setAttribute('position', new THREE.Float32BufferAttribute(sp, 3));
  const stars = new THREE.Points(starGeo, new THREE.PointsMaterial({ color: 0xffffff, size: 2.2, sizeAttenuation: false, fog: false, toneMapped: false })); root.add(stars);

  // glossy floating platform
  const ft = T.floorNight(); ft.repeat.set(8, 8);
  // environment cube of neon strips gives the wet floor something to reflect
  const envScene = new THREE.Scene();
  envScene.add(new THREE.Mesh(new THREE.SphereGeometry(50, 16, 12), new THREE.MeshBasicMaterial({ color: 0x1a0c33, side: THREE.BackSide })));
  ([[0xff2a4a, -30, 6, 0], [0x2a7bff, 30, 6, 0], [0xff35c8, 0, 8, 30], [0x20e0ff, 0, 8, -30], [0xffe9a0, 0, 40, 0]] as const).forEach(([c, x, y, z]) => {
    const m = new THREE.Mesh(new THREE.BoxGeometry(14, 5, 14), new THREE.MeshBasicMaterial({ color: new THREE.Color(c).multiplyScalar(6) })); m.position.set(x, y, z); envScene.add(m);
  });
  const pm = new THREE.PMREMGenerator(renderer);
  const envRT = pm.fromScene(envScene, 0.03);
  pm.dispose();
  const floor = new THREE.Mesh(new THREE.CircleGeometry(31.2, 72), new THREE.MeshStandardMaterial({ map: ft, roughness: 0.28, metalness: 0.25, envMap: envRT.texture, envMapIntensity: 1.5, bumpMap: T.corrBump(), bumpScale: 0.3 }));
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; root.add(floor);
  const rim = mk(new THREE.CylinderGeometry(31.6, 31.2, 2.4, 64, 1, true), M.edge('#9a6a42'), { cast: false });
  rim.position.y = -1.2; (rim.material as THREE.Material).side = THREE.DoubleSide; root.add(rim);
  const underside = mk(new THREE.ConeGeometry(31.2, 30, 10), M.paper('#6a4a3a'), { cast: false, receive: false });
  underside.rotation.x = Math.PI; underside.position.y = -17; root.add(underside);

  // rail fence ring with neon rails
  const posts: { x: number; y: number; z: number; sy: number }[] = [];
  for (let i = 0; i < 56; i++) { const a = (i / 56) * TAU; posts.push({ x: Math.cos(a) * 30.8, y: 0.6, z: Math.sin(a) * 30.8, sy: 1.2 }); }
  root.add(instanced(new THREE.BoxGeometry(0.3, 1, 0.3), M.paper('#d8b27a'), posts));
  for (const h of [0.55, 1.15]) { const t = new THREE.Mesh(new THREE.TorusGeometry(30.8, 0.06, 6, 120), M.glow(h < 1 ? 0x33d6ff : 0xff3b5c, 2.6)); t.rotation.x = Math.PI / 2; t.position.y = h; root.add(t); }

  buildCommon(rng, true, root, cols, crates, anims);

  // star-bulb arch
  {
    const g = new THREE.Group();
    const arch = mk(new THREE.TorusGeometry(6, 0.9, 10, 32, Math.PI), M.paper('#c92b2b'), { outline: 0.03 }); arch.position.y = 6; g.add(arch);
    for (const s of [-1, 1]) { const leg = mk(boxGeo(2.4, 6, 2.4, 2), M.paper('#9a3a3a'), { outline: 0.03 }); leg.position.set(s * 6, 3, 0); g.add(leg); cols.push(makeCollider(s * 6, -26, 2.4, 2.4, 0, 6, 'wall')); }
    const bulbs: { x: number; y: number; z: number; s: number }[] = [];
    for (let i = 0; i <= 30; i++) { const a = (i / 30) * Math.PI; bulbs.push({ x: Math.cos(a) * 6, y: 6 + Math.sin(a) * 6, z: 1, s: 1 }); }
    const bm = new THREE.InstancedMesh(new THREE.SphereGeometry(0.2, 8, 6), M.glow(0xfff0b0, 2.6), bulbs.length);
    const mm = new THREE.Matrix4(); bulbs.forEach((b, i) => { mm.makeTranslation(b.x, b.y, b.z); bm.setMatrixAt(i, mm); }); g.add(bm);
    const star = extrude(starShape(2.4), 0.6, [M.glow(0xffe08a, 1.6), M.paper('#e8b25a')], 0.04); star.position.set(-1.5, 13.4, 0); star.rotation.z = 0.3; g.add(star);
    anims.push((_, t) => { star.scale.setScalar(1 + Math.sin(t * 3) * 0.03); });
    g.position.set(0, 0, -26); root.add(g);
  }
  // light poles + string lights over the arena
  const poleTop: THREE.Vector3[] = [];
  [[-28, 0], [28, 0], [0, 28], [0, -28]].forEach(([x, z]) => {
    const p = mk(new THREE.CylinderGeometry(0.2, 0.28, 11, 6), M.paper('#8a5a32'), { outline: 0.03 }); p.position.set(x, 5.5, z); root.add(p);
    cols.push(makeCollider(x, z, 0.8, 0.8, 0, 11, 'pillar')); poleTop.push(new THREE.Vector3(x, 10.8, z));
  });
  {
    const lamp = new THREE.InstancedMesh(new THREE.SphereGeometry(0.16, 8, 6), M.glow(0xffffff, 2.2), 60);
    const mm = new THREE.Matrix4(), col = new THREE.Color(); let k = 0;
    const strings: [number, number][] = [[0, 1], [2, 3]];
    strings.forEach(([a, b]) => { for (let i = 0; i < 30; i++) { const u = i / 29, p = poleTop[a].clone().lerp(poleTop[b], u); p.y -= Math.sin(u * Math.PI) * 2.2; mm.makeTranslation(p.x, p.y, p.z); lamp.setMatrixAt(k, mm); lamp.setColorAt(k, col.setHex([0xff3b5c, 0xffd54a, 0x33d6ff, 0xff35c8][i % 4])); k++; } });
    root.add(lamp);
  }
  // neon arrow signs on cliffs/stacks
  ([[-13, 2.6, -3.7, 0xff3b5c, 0], [12, 2.6, -5.8, 0x33d6ff, 0], [-3, 1.6, -15.2, 0xff35c8, 0], [20, 1.6, 9.1, 0x33d6ff, 0], [-21, 1.6, 12.1, 0xff3b5c, 0]] as const).forEach(([x, y, z, c, ry], i) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(1.6, 1.6), new THREE.MeshBasicMaterial({ map: T.neonArrow('#' + c.toString(16).padStart(6, '0')), toneMapped: false, color: new THREE.Color(1.6, 1.6, 1.6) }));
    m.position.set(x, y, z); m.rotation.y = ry + (i % 2 ? Math.PI : 0); root.add(m); if (i % 2) m.position.z -= 0.06; else m.position.z += 0.02;
  });

  // distant set dressing: crescent moon, UFO with beam, rocket, floating islands
  const moon = new THREE.Group();
  moon.add(extrude(crescentShape(1), 0.25, [M.glow(0xffe9a0, 1.3), M.glow(0xffdc80, 1.3)], 0.0));
  const mb = new THREE.InstancedMesh(new THREE.SphereGeometry(0.035, 6, 4), M.glow(0xffffff, 3), 40);
  { const mm = new THREE.Matrix4(); for (let i = 0; i < 40; i++) { const a = 0.896 + (i / 39) * (TAU - 1.792); mm.makeTranslation(Math.cos(a), Math.sin(a), 0.16); mb.setMatrixAt(i, mm); } }
  moon.add(mb);
  const eye = new THREE.Mesh(new THREE.SphereGeometry(0.05, 8, 6), new THREE.MeshBasicMaterial({ color: 0x141016 })); eye.scale.set(1, 1.5, 0.3); eye.position.set(-0.45, 0.2, 0.14); moon.add(eye);
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.25, 0.025, 6, 14, Math.PI), new THREE.MeshBasicMaterial({ color: 0x141016 })); smile.rotation.z = Math.PI; smile.position.set(-0.55, -0.05, 0.14); moon.add(smile);
  moon.scale.setScalar(16); moon.position.set(-26, 46, -85); moon.rotation.y = 0.2; root.add(moon);
  anims.push((_, t) => { moon.position.y = 46 + Math.sin(t * 0.5) * 1.5; });

  const ufo = new THREE.Group();
  const hullU = mk(new THREE.SphereGeometry(4, 20, 10), M.paper('#7a8aa8'), { outline: 0.03 }); hullU.scale.y = 0.3; ufo.add(hullU);
  const domeU = new THREE.Mesh(new THREE.SphereGeometry(1.8, 16, 8, 0, TAU, 0, Math.PI / 2), new THREE.MeshBasicMaterial({ color: new THREE.Color(0.4, 1.0, 1.9), toneMapped: false })); domeU.position.y = 0.6; ufo.add(domeU);
  const ringU = new THREE.Mesh(new THREE.TorusGeometry(3.6, 0.1, 6, 40), M.glow(0xff3b5c, 3)); ringU.rotation.x = Math.PI / 2; ringU.position.y = -0.2; ufo.add(ringU);
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(0.8, 5, 24, 24, 1, true), new THREE.MeshBasicMaterial({ color: 0x4aa8ff, transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
  beam.position.y = -12.5; ufo.add(beam);
  const hang = makeCrate(1.6); hang.position.y = -8; ufo.add(hang);
  ufo.position.set(20, 30, -50); root.add(ufo);
  anims.push((_, t) => { ufo.position.y = 30 + Math.sin(t * 0.8) * 1.2; ufo.rotation.y = t * 0.3; (beam.material as THREE.MeshBasicMaterial).opacity = 0.18 + Math.sin(t * 7) * 0.04; hang.position.y = -8 + Math.sin(t * 1.3) * 0.6; });

  const makeIsland = (r: number, palms: number) => {
    const g = new THREE.Group();
    g.add(mk(new THREE.CylinderGeometry(r, r * 0.92, 1, 18), [M.edge('#8a5f3e'), M.paper('#5aa05a'), M.paper('#7a5a3a')], { outline: 0.03, cast: false }));
    const rock = mk(new THREE.ConeGeometry(r * 0.92, r * 1.7, 8), M.paper('#8a5f3e'), { cast: false }); rock.rotation.x = Math.PI; rock.position.y = -r * 0.85 - 0.5; g.add(rock);
    for (let i = 0; i < palms; i++) { const pa = palmTree(); const a = (i / palms) * TAU + 1; pa.position.set(Math.cos(a) * r * 0.5, 0.5, Math.sin(a) * r * 0.5); g.add(pa); }
    return g;
  };
  const islands: { g: THREE.Group; y: number; ph: number }[] = [];
  ([[-44, 12, -22, 5, 2], [-52, 8, -50, 6, 2], [46, 14, 10, 5, 1], [30, 6, -60, 7, 2], [-30, 10, 44, 5, 2], [8, 16, -78, 9, 1]] as const).forEach(([x, y, z, r, palms], i) => {
    const g = makeIsland(r, palms); g.position.set(x, y, z); root.add(g); islands.push({ g, y, ph: i * 1.3 });
    const lamp = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.5, 0.5), M.glow(i % 2 ? 0xff3b5c : 0x33d6ff, 3)); lamp.position.set(r * 0.7, 1, 0); g.add(lamp);
  });
  // rocket on a scaffold (on the big far island) + crane arm
  {
    const g = new THREE.Group();
    const body = mk(new THREE.CylinderGeometry(1.6, 1.8, 8, 16), [M.tex(T.stripesRW(), 'rwBody'), M.paper('#f3e7cc'), M.paper('#f3e7cc')], { outline: 0.03 }); body.position.y = 5; g.add(body);
    const nose = mk(new THREE.ConeGeometry(1.6, 3, 16), M.paper('#c92b2b'), { outline: 0.03 }); nose.position.y = 10.5; g.add(nose);
    for (let i = 0; i < 3; i++) { const f = extrude(petalShape(), 0.2, M.paper('#c92b2b'), 0.03); f.scale.set(2, 2.6, 1); const a = (i / 3) * TAU; f.position.set(Math.cos(a) * 1.6, 1.4, Math.sin(a) * 1.6); f.rotation.y = -a + Math.PI / 2; g.add(f); }
    const win = mk(new THREE.TorusGeometry(0.5, 0.12, 8, 18), M.paper('#f3e7cc'), { outline: 0.02 }); win.position.set(0, 7.4, 1.65); g.add(win);
    const glass = new THREE.Mesh(new THREE.CircleGeometry(0.5, 16), new THREE.MeshBasicMaterial({ color: new THREE.Color(0.3, 0.8, 1.6), toneMapped: false })); glass.position.set(0, 7.4, 1.67); g.add(glass);
    const flame = new THREE.Mesh(new THREE.ConeGeometry(1.1, 3, 10), new THREE.MeshBasicMaterial({ color: new THREE.Color(2.5, 1.2, 0.3), toneMapped: false })); flame.rotation.x = Math.PI; flame.position.y = -0.6; g.add(flame);
    for (const s of [-1, 1]) { const post = mk(new THREE.BoxGeometry(0.3, 10, 0.3), M.paper('#8a5a32'), { outline: 0.03 }); post.position.set(s * 2.8, 5, 0); g.add(post); }
    for (let k = 0; k < 4; k++) { const br = mk(new THREE.BoxGeometry(5.6, 0.2, 0.2), M.paper('#8a5a32')); br.position.set(0, 1.5 + k * 2.4, 0); g.add(br); }
    const crane = new THREE.Group(); crane.position.set(7, 0, 0);
    const mast = mk(new THREE.BoxGeometry(0.6, 16, 0.6), M.paper('#c92b2b'), { outline: 0.03 }); mast.position.y = 8; crane.add(mast);
    const jib = mk(new THREE.BoxGeometry(12, 0.6, 0.6), M.paper('#c92b2b'), { outline: 0.03 }); jib.position.set(-3, 16, 0); crane.add(jib);
    g.add(crane);
    g.position.set(0, 0.5, 0); islands[5].g.add(g); g.scale.setScalar(0.9);
    anims.push((_, t) => { flame.scale.set(1 + Math.sin(t * 20) * 0.08, 1 + Math.sin(t * 17) * 0.2, 1); });
  }
  // crowned dome on a far island, with neon ring
  const domeProp = buildDomeModel(1.1);
  domeProp.position.set(0, 0.5, 0); islands[3].g.add(domeProp);
  anims.push((dt, t) => {
    islands.forEach((is) => { is.g.position.y = is.y + Math.sin(t * 0.6 + is.ph) * 0.8; });
    void dt;
  });

  dressNight(root, rng, cols, crates, anims);
  const fog = new THREE.Fog(0x2a1038, 45, 210);
  const spawns = floorSpawns(cols, rng);
  const coins = coinSpots(cols, rng);

  return finish({
    id: 'night', root, colliders: cols, crates, spawns, coinSpots: coins, radius: ARENA_R, start: new THREE.Vector3(0, 0, 20), sun, hemi, fog, bg: 0x1a0c33, domeProp, env: envRT.texture,
    update(dt, t, player) {
      anims.forEach((f) => f(dt, t));
      sun.position.set(player.x + moonDir.x * 70, moonDir.y * 70, player.z + moonDir.z * 70); sun.target.position.set(player.x, 0, player.z);
      stars.rotation.y = t * 0.002;
    },
  });
}

type Filled = 'dispose' | 'name' | 'mood' | 'look' | 'pads' | 'ice' | 'geysers' | 'simTime';
function finish(m: Omit<MapData, Filled>): MapData {
  const data = m as MapData;
  const night = data.id === 'night';
  data.name = night ? 'Neon Night Carnival' : 'Golden-Hour Canyon'; data.mood = night ? 'night' : 'day';
  data.look = night
    ? { bloom: 0.8, thr: 0.85, dust: 0x88ccff, wh: 0xb0a0ff, wg: 0x602040, wk: 0xffc0d0, wr: 0xff3b5c }
    : { bloom: 0.35, thr: 1.0, dust: 0xffe9b0, wh: 0xfff0d0, wg: 0x806040, wk: 0xffe0b0, wr: 0x60a0ff };
  data.pads = []; data.ice = []; data.geysers = []; data.simTime = 0;
  data.dispose = () => {
    data.root.traverse((o) => { const mesh = o as THREE.Mesh; if (mesh.isMesh || (o as THREE.Points).isPoints) mesh.geometry?.dispose(); });
    data.root.removeFromParent();
    data.env?.dispose();
  };
  return data;
}

/** Extra arenas register themselves here (see maps2.ts) so this file does not depend on them. */
export const extraMaps: Partial<Record<MapId, (seed: number) => MapData>> = {};
/** Post-build hooks (maps2.ts uses one to add trampolines to the two original arenas). */
export const mapHooks: ((m: MapData) => void)[] = [];

export function buildMap(id: MapId, scene: THREE.Scene, renderer: THREE.WebGLRenderer, seed: number): MapData {
  const make = extraMaps[id];
  const m = make ? make(seed) : id === 'night' ? buildNight(new Rng(seed), renderer) : buildCanyon(new Rng(seed));
  mapHooks.forEach((f) => f(m));
  scene.add(m.root);
  return m;
}
