/**
 * In-browser self tests (Options -> Diagnostics). They cover the pure-logic systems:
 * RNG, save validation, collision, wave composition, enemy tables, input bindings, plus a perf probe.
 */
import { Rng, groundAt, makeCollider, resolveCircle, segAABB, segSphere } from './core';
import { sanitizeSave, sanitizeSettings, DEFAULT_BINDINGS } from './save';
import { composeWave } from './director';
import { ENEMY_DEFS } from './enemies';
import { WEAPONS } from './weapons';
import { ACTIONS } from './input';
import { CAMPAIGN, MAP_INFO, MAP_ORDER, POWERS } from './progression';
import { AFFINITY, TIPS, WEAPON_ELEM, elemMult, RELOAD_ZONE } from './elements';

export interface TestResult { name: string; ok: boolean; info: string }

export function runSelfTests(): TestResult[] {
  const out: TestResult[] = [];
  const t = (name: string, fn: () => string | void) => {
    try { out.push({ name, ok: true, info: fn() ?? '' }); } catch (e) { out.push({ name, ok: false, info: String((e as Error).message ?? e) }); }
  };
  const assert = (c: boolean, m: string) => { if (!c) throw new Error(m); };

  t('RNG is deterministic and bounded', () => {
    const a = new Rng(42), b = new Rng(42);
    for (let i = 0; i < 100; i++) { const x = a.next(); assert(x === b.next() && x >= 0 && x < 1, 'sequence mismatch'); }
  });
  t('Save sanitizer survives garbage', () => {
    for (const bad of [null, undefined, 'x', 42, [], { coins: 'lots', upgrades: 5, stats: 'no' }, { coins: NaN, scores: { a: Infinity } }]) {
      const s = sanitizeSave(bad);
      assert(Number.isFinite(s.coins) && s.coins >= 0 && s.v === 1 && Object.values(s.scores).every(Number.isFinite), 'bad value leaked');
    }
  });
  t('Save sanitizer clamps and keeps valid data', () => {
    const s = sanitizeSave({ coins: 120.7, charms: ['a', 'b', 'c'], upgrades: { hp: 3, bad: 'x' } });
    assert(s.coins === 120 && s.charms.length === 2 && s.upgrades.hp === 3 && !('bad' in s.upgrades), 'unexpected result');
  });
  t('Settings sanitizer clamps ranges and bindings', () => {
    const s = sanitizeSettings({ fov: 500, master: -3, quality: 'ultra', bindings: { jump: ['KeyJ'], nonsense: ['KeyZ'] } });
    assert(s.fov === 110 && s.master === 0 && s.quality === 'auto' && s.bindings.jump[0] === 'KeyJ' && !('nonsense' in s.bindings), 'not clamped');
  });
  t('Every action has a default binding', () => { for (const a of ACTIONS) assert((DEFAULT_BINDINGS[a] ?? []).length > 0, a + ' unbound'); });
  t('Collision: circle pushed out of box', () => {
    const c = [makeCollider(0, 0, 4, 4, 0, 2, 'wall')], p = { x: 2.1, y: 0, z: 0 };
    resolveCircle(p, 0.5, 1.7, c, 0.45);
    assert(p.x >= 2.5 - 1e-6, 'still inside wall: ' + p.x);
    const q = { x: 0, y: 0, z: 0 }; resolveCircle(q, 0.5, 1.7, c, 0.45);
    assert(Math.hypot(q.x, q.z) >= 2, 'centre-inside not resolved');
  });
  t('Collision: stepping onto low ledge, standing on tall box', () => {
    const c = [makeCollider(0, 0, 4, 4, 0, 0.4, 'wall'), makeCollider(10, 0, 4, 4, 0, 1.2, 'wall')];
    assert(groundAt(0, 0, 0.4, 0, c, 0.45) === 0.4, 'ledge not climbable');
    assert(groundAt(10, 0, 0.4, 0, c, 0.45) === 0, 'tall box should block');
    assert(groundAt(10, 0, 0.4, 1.3, c, 0.45) === 1.2, 'cannot stand on box');
  });
  t('Segment tests (box + sphere)', () => {
    const c = makeCollider(0, 0, 2, 2, 0, 2, 'wall');
    assert(segAABB(-5, 1, 0, 10, 0, 0, c) > 0, 'ray missed box');
    assert(segAABB(-5, 3, 0, 10, 0, 0, c) === -1, 'ray should pass above');
    assert(segSphere(0, 0, 0, 10, 0, 0, 5, 0, 0, 1) > 0, 'sphere missed');
    assert(segSphere(0, 0, 0, 10, 0, 0, 5, 3, 0, 1) === -1, 'sphere false hit');
  });
  t('Wave composition: deterministic, valid, scaling', () => {
    const a = composeWave(new Rng(9), 4, 1), b = composeWave(new Rng(9), 4, 1);
    assert(a.join() === b.join(), 'not deterministic');
    let prev = 0;
    for (let w = 1; w <= 30; w++) {
      const q = composeWave(new Rng(w), w, Math.floor(w / 5));
      assert(q.length > 0 && q.every((id) => ENEMY_DEFS[id] && !ENEMY_DEFS[id].boss), 'invalid wave ' + w);
      if (w === 1) prev = q.length;
    }
    assert(composeWave(new Rng(1), 25, 4).length >= prev, 'waves do not scale');
    return `wave 25 has ${composeWave(new Rng(1), 25, 4).length} creatures`;
  });
  t('Enemy and weapon tables are sane', () => {
    for (const d of Object.values(ENEMY_DEFS)) assert(d.hp > 0 && d.radius > 0 && d.height > 0 && d.dmg > 0, d.id + ' invalid');
    assert(WEAPONS.length >= 18 && new Set(WEAPONS.map((w) => w.id)).size === WEAPONS.length && WEAPONS.every((w) => w.mag > 0 && w.interval > 0 && w.reload > 0), 'weapon table invalid');
  });
  t('Perf probe: 4000 collision resolves', () => {
    const cols = Array.from({ length: 40 }, (_, i) => makeCollider((i % 8) * 6 - 20, Math.floor(i / 8) * 6 - 12, 3, 3, 0, 1.5, 'wall'));
    const p = { x: 0, y: 0, z: 0 };
    const t0 = performance.now();
    for (let i = 0; i < 4000; i++) { p.x = (i % 50) - 25; p.z = (i % 31) - 15; resolveCircle(p, 0.4, 1.7, cols, 0.45); }
    const ms = performance.now() - t0;
    assert(ms < 50, `too slow: ${ms.toFixed(1)}ms`);
    return `${ms.toFixed(2)} ms`;
  });
  t('Arenas, campaign and new roster are consistent', () => {
    assert(MAP_ORDER.length === 5 && MAP_INFO.length === 5 && new Set(MAP_ORDER).size === 5, 'arena tables inconsistent');
    assert(CAMPAIGN.length === 8 && CAMPAIGN.every((s) => MAP_ORDER.includes(s.map)), 'campaign references an unknown arena');
    for (const id of ['globe', 'glue', 'scissors', 'snake', 'crane', 'magnet', 'miniGlobe', 'miniSnake']) assert(!!ENEMY_DEFS[id] && ENEMY_DEFS[id].hp > 0, id + ' missing');
    assert(POWERS.length === 6 && POWERS.every((p) => p.weight > 0), 'power-up table invalid');
    for (let w = 1; w <= 12; w++) for (const m of MAP_ORDER) assert(composeWave(new Rng(w), w, 2, m).every((id) => !!ENEMY_DEFS[id]), `bad wave ${w} on ${m}`);
  });
  t('Weakness table covers every creature and gun', () => {
    for (const id of Object.keys(ENEMY_DEFS)) assert(!!AFFINITY[id] && !!TIPS[id], id + ' is missing an affinity or a tip');
    for (const w of WEAPONS) assert(!!WEAPON_ELEM[w.id], w.id + ' has no damage type');
    assert(elemMult('leaf', 'fire') > 1 && elemMult('leaf', 'impact') === 1 && elemMult('sun', 'fire') < 1, 'multipliers wrong');
    for (const a of Object.values(AFFINITY)) assert(!a.weak || a.weak !== a.resist, 'weak and resist must differ');
    assert(RELOAD_ZONE[0] > 0.3 && RELOAD_ZONE[1] < 0.95 && RELOAD_ZONE[0] < RELOAD_ZONE[1], 'reload zone invalid');
  });
  return out;
}
