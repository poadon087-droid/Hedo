/**
 * Cardboard creatures: procedural models, animation, AI state machines and bosses.
 * Leaf Bots flank and take cover, Sunflowers are petal turrets, Blobs roll and leap.
 */
import * as THREE from 'three';
import { TAU, angleDiff, clamp, damp, easeOutBack, easeOutCubic, resolveCircle, hasLOS, type GameApi, type EProjSpec } from './core';
import { M, T } from './textures';
import { addOutline, disc, extrude, leafShape, mk, petalShape } from './models';
import { CONFETTI } from './fx';
import { buildExtra, updateExtra, syncExtra, isExtra, initialExtraState } from './enemies3';

export interface EnemyDef {
  id: string; name: string; kind: 'leaf' | 'sun' | 'blob' | 'king' | 'dome' | 'ufo' | 'moth' | 'bomb' | 'jack' | 'mimic' | 'tank' | 'ghost' | 'knight' | 'drummer' | 'globe' | 'glue' | 'scissors' | 'snake' | 'crane' | 'magnet';
  hp: number; speed: number; radius: number; height: number; scale: number;
  tint: string; dmg: number; cooldown: number; windup: number; proj: EProjSpec['kind']; projSpeed: number;
  armor?: number; shielded?: boolean; spiked?: boolean; fire?: boolean; ice?: boolean; sniper?: boolean; boss?: boolean; mini?: boolean; crown?: boolean;
  score: number; coins: number; cost: number; minWave: number;
}
const D = (d: Partial<EnemyDef> & Pick<EnemyDef, 'id' | 'name' | 'kind'>): EnemyDef => ({
  hp: 30, speed: 5, radius: 0.55, height: 1.7, scale: 1, tint: '#38b9ad', dmg: 8, cooldown: 2.2, windup: 0.55, proj: 'bolt', projSpeed: 17, score: 100, coins: 1, cost: 1, minWave: 1, ...d,
});
export const ENEMY_DEFS: Record<string, EnemyDef> = {
  leaf: D({ id: 'leaf', name: 'Leaf Bot', kind: 'leaf', cost: 1, minWave: 1 }),
  sun: D({ id: 'sun', name: 'Angry Sunflower', kind: 'sun', hp: 55, speed: 0.9, radius: 0.7, height: 1.9, tint: '#ff9a1e', dmg: 9, cooldown: 2.8, windup: 0.8, proj: 'seed', projSpeed: 14, score: 150, cost: 3, minWave: 1 }),
  blob: D({ id: 'blob', name: 'Blue Smiley Blob', kind: 'blob', hp: 22, speed: 5.6, radius: 0.62, height: 1.25, tint: '#3f8cf0', dmg: 12, cooldown: 1.6, windup: 0.45, score: 80, cost: 1, minWave: 1 }),
  leafArmor: D({ id: 'leafArmor', name: 'Armored Leaf Bot', kind: 'leaf', hp: 95, speed: 4, tint: '#7d98a6', armor: 0.45, score: 220, coins: 2, cost: 4, minWave: 3 }),
  blobSpike: D({ id: 'blobSpike', name: 'Spiked Blob', kind: 'blob', hp: 42, speed: 6.6, radius: 0.7, height: 1.3, tint: '#5a64d8', dmg: 20, spiked: true, score: 180, coins: 2, cost: 3, minWave: 3 }),
  sunFire: D({ id: 'sunFire', name: 'Fire-Petal Sunflower', kind: 'sun', hp: 75, speed: 1.1, radius: 0.7, height: 1.9, tint: '#ff4a1a', dmg: 10, cooldown: 2.4, windup: 0.8, proj: 'fire', projSpeed: 15, fire: true, score: 250, coins: 2, cost: 4, minWave: 4 }),
  leafIce: D({ id: 'leafIce', name: 'Ice Leaf Bot', kind: 'leaf', hp: 42, speed: 5, tint: '#8fd8ff', proj: 'ice', ice: true, dmg: 7, score: 200, coins: 2, cost: 3, minWave: 3 }),
  leafSniper: D({ id: 'leafSniper', name: 'Sniper Leaf Bot', kind: 'leaf', hp: 26, speed: 3.5, tint: '#2f8f99', dmg: 22, cooldown: 3.8, windup: 1.3, projSpeed: 48, sniper: true, score: 260, coins: 2, cost: 4, minWave: 4 }),
  miniLeaf: D({ id: 'miniLeaf', name: 'Captain Leaf', kind: 'leaf', hp: 420, speed: 4.2, radius: 1.1, height: 3.4, scale: 2, tint: '#2a9d8f', dmg: 10, cooldown: 2.6, windup: 0.7, mini: true, crown: true, score: 900, coins: 8, cost: 10, minWave: 6 }),
  miniSun: D({ id: 'miniSun', name: 'Marigold Matron', kind: 'sun', hp: 480, speed: 1.2, radius: 1.3, height: 3.8, scale: 2, tint: '#ffb02e', dmg: 10, cooldown: 3, windup: 0.9, proj: 'seed', projSpeed: 13, mini: true, crown: true, score: 1000, coins: 8, cost: 10, minWave: 7 }),
  miniBlob: D({ id: 'miniBlob', name: 'Mega Blob', kind: 'blob', hp: 380, speed: 6, radius: 1.5, height: 3, scale: 2.4, tint: '#3f8cf0', dmg: 22, cooldown: 2, windup: 0.6, mini: true, crown: true, score: 900, coins: 8, cost: 10, minWave: 8 }),
  kingSun: D({ id: 'kingSun', name: 'Sunflower King', kind: 'king', hp: 1100, speed: 1.6, radius: 2.3, height: 6, scale: 3.2, tint: '#ffa01e', dmg: 12, cooldown: 2, windup: 1, proj: 'seed', projSpeed: 15, boss: true, crown: true, score: 5000, coins: 40, cost: 99, minWave: 99 }),
  domeBoss: D({ id: 'domeBoss', name: 'Crowned Dome', kind: 'dome', hp: 1400, speed: 0, radius: 3, height: 6, scale: 1.7, tint: '#c4935a', dmg: 12, cooldown: 2, windup: 1, proj: 'bolt', projSpeed: 16, boss: true, crown: true, score: 6000, coins: 50, cost: 99, minWave: 99 }),
  ufo: D({ id: 'ufo', name: 'UFO Mothership', kind: 'ufo', hp: 1200, speed: 0, radius: 3.6, height: 2, scale: 1, tint: '#7a8aa8', dmg: 14, cooldown: 2, windup: 1, proj: 'plasma', projSpeed: 20, boss: true, score: 6500, coins: 60, cost: 99, minWave: 99 }),
  moth: D({ id: 'moth', name: 'Paper Moth', kind: 'moth', hp: 24, speed: 6.5, radius: 0.45, height: 0.9, tint: '#e8a04a', dmg: 10, cooldown: 3.2, windup: 0.6, score: 130, coins: 1, cost: 2, minWave: 2 }),
  bomb: D({ id: 'bomb', name: 'Cherry Bomb Bot', kind: 'bomb', hp: 20, speed: 7.8, radius: 0.5, height: 1.2, tint: '#c92b2b', dmg: 26, windup: 0.9, score: 120, coins: 1, cost: 2, minWave: 2 }),
  jack: D({ id: 'jack', name: 'Jack-in-the-Box', kind: 'jack', hp: 70, speed: 3.2, radius: 0.6, height: 1.9, tint: '#3f6fd0', dmg: 9, cooldown: 3.6, windup: 0.8, proj: 'orb', score: 230, coins: 2, cost: 4, minWave: 3 }),
  mimic: D({ id: 'mimic', name: 'Mimic Crate', kind: 'mimic', hp: 85, speed: 5.2, radius: 0.65, height: 1.0, tint: '#c4935a', dmg: 15, cooldown: 2.2, score: 240, coins: 3, cost: 3, minWave: 4 }),
  tank: D({ id: 'tank', name: 'Crayon Tank', kind: 'tank', hp: 170, speed: 2.6, radius: 1.0, height: 1.5, tint: '#b0623a', dmg: 20, cooldown: 3.6, windup: 1.1, score: 380, coins: 4, cost: 6, minWave: 5 }),
  ghost: D({ id: 'ghost', name: 'Tissue Ghost', kind: 'ghost', hp: 48, speed: 4.2, radius: 0.5, height: 1.6, tint: '#f5f0ff', dmg: 9, cooldown: 2.8, windup: 0.6, proj: 'plasma', projSpeed: 12, score: 260, coins: 2, cost: 4, minWave: 4 }),
  knight: D({ id: 'knight', name: 'Corrugate Knight', kind: 'knight', hp: 130, speed: 3.3, radius: 0.7, height: 2.1, tint: '#8e9bb0', dmg: 14, cooldown: 3.2, windup: 0.8, shielded: true, score: 320, coins: 3, cost: 5, minWave: 4 }),
  drummer: D({ id: 'drummer', name: 'Tin-Drum Bot', kind: 'drummer', hp: 60, speed: 3.6, radius: 0.55, height: 1.3, tint: '#c92b2b', dmg: 8, cooldown: 4.6, windup: 0.7, proj: 'seed', projSpeed: 14, score: 280, coins: 3, cost: 4, minWave: 5 }),
  miniKnight: D({ id: 'miniKnight', name: 'Sir Corrugate', kind: 'knight', hp: 520, speed: 3.6, radius: 1.3, height: 3.9, scale: 1.9, tint: '#9aa8c0', dmg: 18, cooldown: 2.8, windup: 0.8, shielded: true, mini: true, crown: true, score: 1100, coins: 9, cost: 10, minWave: 9 }),
  globe: D({ id: 'globe', name: 'Snow Globe Bot', kind: 'globe', hp: 72, speed: 3.4, radius: 0.7, height: 2.0, tint: '#cfeeff', dmg: 7, cooldown: 3.2, windup: 0.9, proj: 'ice', projSpeed: 11, score: 270, coins: 2, cost: 4, minWave: 3 }),
  glue: D({ id: 'glue', name: 'Glue Bottle Goon', kind: 'glue', hp: 48, speed: 3.8, radius: 0.5, height: 1.5, tint: '#f3e7cc', dmg: 10, cooldown: 3.0, windup: 0.7, proj: 'seed', projSpeed: 14, score: 230, coins: 2, cost: 3, minWave: 3 }),
  scissors: D({ id: 'scissors', name: 'Scissor Spinner', kind: 'scissors', hp: 64, speed: 5.4, radius: 0.8, height: 1.1, tint: '#c0c4cc', dmg: 16, cooldown: 3.0, windup: 0.75, score: 260, coins: 2, cost: 4, minWave: 4 }),
  snake: D({ id: 'snake', name: 'Paper Snake', kind: 'snake', hp: 60, speed: 5.8, radius: 0.5, height: 0.9, tint: '#34c3b0', dmg: 11, cooldown: 2.6, windup: 0.5, score: 200, coins: 2, cost: 3, minWave: 3 }),
  crane: D({ id: 'crane', name: 'Origami Crane', kind: 'crane', hp: 36, speed: 6.2, radius: 0.5, height: 1.2, tint: '#f3e7cc', dmg: 7, cooldown: 2.0, windup: 0.5, projSpeed: 24, score: 240, coins: 2, cost: 3, minWave: 4 }),
  magnet: D({ id: 'magnet', name: 'Magnet Bot', kind: 'magnet', hp: 90, speed: 3.6, radius: 0.7, height: 1.5, tint: '#c92b2b', dmg: 14, cooldown: 4.2, windup: 0.9, score: 300, coins: 3, cost: 5, minWave: 5 }),
  miniGlobe: D({ id: 'miniGlobe', name: 'Blizzard Globe', kind: 'globe', hp: 480, speed: 3.0, radius: 1.5, height: 4.4, scale: 2.2, tint: '#cfeeff', dmg: 9, cooldown: 2.6, windup: 0.9, proj: 'ice', projSpeed: 11, mini: true, crown: true, score: 1000, coins: 9, cost: 10, minWave: 8 }),
  miniSnake: D({ id: 'miniSnake', name: 'Paper Wyrm', kind: 'snake', hp: 440, speed: 5.2, radius: 0.9, height: 1.6, scale: 1.8, tint: '#ff9a2e', dmg: 16, cooldown: 2.4, windup: 0.55, mini: true, crown: true, score: 1000, coins: 9, cost: 10, minWave: 9 }),
};

// ------------------------------------------------------------------ models
export interface Parts {
  extra?: Record<string, THREE.Object3D>;
  pivot: THREE.Group; flash: THREE.MeshToonMaterial[];
  brows?: THREE.Mesh[]; arms?: THREE.Object3D[]; petals?: THREE.Object3D; wheels?: THREE.Object3D[]; ring?: THREE.Object3D; beam?: THREE.Mesh; marker: THREE.Sprite; head?: THREE.Object3D;
}
let markerMat: THREE.SpriteMaterial | null = null;
const browMat = () => new THREE.MeshBasicMaterial({ color: 0x141016 });

export function crownMesh(s: number): THREE.Mesh {
  const sh = new THREE.Shape();
  ([[-1, 0], [-1, 1.1], [-0.5, 0.55], [0, 1.45], [0.5, 0.55], [1, 1.1], [1, 0]] as number[][]).forEach(([x, y], i) => (i ? sh.lineTo(x * s * 0.5, y * s * 0.5) : sh.moveTo(x * s * 0.5, y * s * 0.5)));
  sh.closePath();
  return extrude(sh, 0.14 * s, M.paper('#e8b830'), 0.03);
}
export const cloneToon = (m: THREE.MeshToonMaterial, out: THREE.MeshToonMaterial[]) => { const c = m.clone(); out.push(c); return c; };

export function brow(x: number, y: number, z: number, w = 0.3): THREE.Mesh {
  const b = new THREE.Mesh(new THREE.BoxGeometry(w, 0.065, 0.05), browMat());
  b.position.set(x, y, z); return b;
}

function glove(): THREE.Mesh { const g = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), M.paper('#ffffff')); g.castShadow = true; addOutline(g, 0.02); return g; }

function buildLeaf(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [];
  const pivot = new THREE.Group();
  const body = extrude(leafShape(), 0.28, [cloneToon(M.paper(def.tint), flash), M.edge('#256f69')], 0.03);
  body.position.y = 0.98; pivot.add(body);
  const face = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 1.0), M.tex(T.leafFace(), 'leafFace', { transparent: true }));
  face.position.set(0, 1.0, 0.15); pivot.add(face);
  const brows = [brow(-0.2, 1.3, 0.17), brow(0.2, 1.3, 0.17)]; pivot.add(...brows);
  const arms: THREE.Object3D[] = [];
  for (const s of [-1, 1]) {
    const a = new THREE.Group(); a.position.set(s * 0.52, 0.95, 0.02);
    const stub = mk(new THREE.CylinderGeometry(0.05, 0.05, 0.3, 6), M.paper('#33353a')); stub.rotation.z = Math.PI / 2; stub.position.x = s * 0.15; a.add(stub);
    const h = glove(); h.position.x = s * 0.34; a.add(h);
    pivot.add(a); arms.push(a);
  }
  const wheels: THREE.Object3D[] = [];
  for (const s of [-1, 1]) {
    const t = mk(new THREE.BoxGeometry(0.3, 0.16, 0.44), M.paper('#2a2d33'), { outline: 0.02 }); t.position.set(s * 0.24, 0.1, 0); pivot.add(t);
    const w = mk(new THREE.CylinderGeometry(0.1, 0.1, 0.34, 8), M.paper('#9a9aa0')); w.rotation.z = Math.PI / 2; w.position.set(s * 0.24, 0.1, 0.18); pivot.add(w); wheels.push(w);
  }
  if (def.armor) {
    const plate = mk(new THREE.BoxGeometry(0.8, 0.5, 0.1), M.paper('#8a8f96'), { outline: 0.03 }); plate.position.set(0, 0.85, 0.2); pivot.add(plate);
    const helm = mk(new THREE.SphereGeometry(0.4, 10, 6, 0, TAU, 0, Math.PI / 2), M.paper('#8a8f96'), { outline: 0.03 }); helm.position.set(0, 1.45, 0); helm.scale.set(1, 0.7, 0.5); pivot.add(helm);
  }
  if (def.ice) for (let i = 0; i < 4; i++) { const c = mk(new THREE.ConeGeometry(0.1, 0.4, 5), new THREE.MeshToonMaterial({ color: 0xc8f0ff }), { outline: 0.02 }); c.position.set((i - 1.5) * 0.25, 1.75 - Math.abs(i - 1.5) * 0.12, 0); pivot.add(c); }
  if (def.sniper) {
    const barrel = mk(new THREE.BoxGeometry(0.14, 0.14, 1.3), M.paper('#33353a'), { outline: 0.02 }); barrel.position.set(0.3, 0.9, 0.7); pivot.add(barrel);
    const scope = mk(new THREE.CylinderGeometry(0.07, 0.07, 0.35, 8), M.paper('#c92b2b')); scope.rotation.x = Math.PI / 2; scope.position.set(0.3, 1.05, 0.55); pivot.add(scope);
  }
  if (def.crown) { const c = crownMesh(1.2); c.position.set(0, 1.9, 0); pivot.add(c); }
  return { pivot, flash, brows, arms, wheels, marker: makeMarker() };
}

function buildSun(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [];
  const pivot = new THREE.Group();
  const pot = mk(new THREE.BoxGeometry(0.55, 0.36, 0.55), M.paper('#8a5a32'), { outline: 0.03 }); pot.position.y = 0.18; pivot.add(pot);
  const stem = mk(new THREE.CylinderGeometry(0.07, 0.09, 0.6, 6), M.paper('#4f8a3a'), { outline: 0.02 }); stem.position.y = 0.62; pivot.add(stem);
  const arms: THREE.Object3D[] = [];
  for (const s of [-1, 1]) {
    const a = extrude(petalShape(), 0.06, M.paper('#4f8a3a'), 0.03); a.scale.set(0.5, 0.7, 1); a.position.set(s * 0.1, 0.6, 0.02); a.rotation.z = -s * 1.1;
    pivot.add(a); arms.push(a);
  }
  const head = new THREE.Group(); head.position.y = 1.4; pivot.add(head);
  const petals = new THREE.Group(); head.add(petals);
  const pm = cloneToon(M.paper(def.tint), flash), pm2 = cloneToon(M.paper(def.fire ? '#ffb030' : '#ffc24a'), flash);
  for (let i = 0; i < 12; i++) {
    const a = (i / 12) * TAU;
    const p = extrude(petalShape(), 0.07, i % 2 ? pm : pm2, 0.025);
    p.scale.set(0.5, 0.62, 1); p.position.set(Math.cos(a) * 0.3, Math.sin(a) * 0.3, i % 2 ? -0.04 : 0.0); p.rotation.z = a - Math.PI / 2;
    petals.add(p);
  }
  const face = disc(0.44, 0.2, M.tex(T.sunFace(), 'sunFace'), M.edge('#9a6a3a')); face.position.z = 0.06; head.add(face);
  const brows = [brow(-0.15, 0.13, 0.19, 0.22), brow(0.15, 0.13, 0.19, 0.22)]; head.add(...brows);
  if (def.crown) { const c = crownMesh(1.0); c.position.set(0, 0.62, 0); head.add(c); }
  return { pivot, flash, brows, arms, petals, head, marker: makeMarker() };
}

function buildBlob(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [];
  const pivot = new THREE.Group();
  const face = cloneToon(M.tex(T.blobFace(), 'blobFace'), flash);
  const body = disc(0.62, 0.3, face, M.edge(def.spiked ? '#4a4f8a' : '#5a6f9a')); body.position.y = 0.63; pivot.add(body);
  if (def.spiked) for (let i = 0; i < 10; i++) { const a = (i / 10) * TAU; const c = mk(new THREE.ConeGeometry(0.11, 0.34, 5), M.paper('#9a9aa8'), { outline: 0.02 }); c.position.set(Math.cos(a) * 0.68, 0.63 + Math.sin(a) * 0.68, 0); c.rotation.z = a - Math.PI / 2; pivot.add(c); }
  if (def.crown) { const c = crownMesh(0.8); c.position.set(0, 1.28, 0); pivot.add(c); }
  return { pivot, flash, marker: makeMarker(), head: body };
}

/** Crowned Dome: tan cardboard dome, neon ring, gold crown, smiling face. Used by the boss and the night map. */
export function buildDomeModel(scale: number): THREE.Group {
  const g = new THREE.Group();
  const base = mk(new THREE.CylinderGeometry(2.4, 2.6, 1, 24), [M.edge(), M.paper('#a8703c'), M.paper('#a8703c')], { outline: 0.03 }); base.position.y = 0.5; g.add(base);
  const dome = mk(new THREE.SphereGeometry(2.1, 28, 14, 0, TAU, 0, Math.PI / 2), M.paper('#c4935a'), { outline: 0.03 }); dome.position.y = 1; g.add(dome);
  const face = disc(1.05, 0.2, M.tex(T.domeFace(), 'domeFace'), M.edge('#9a6a3a')); face.position.set(0, 2.2, 1.55); face.rotation.x = -0.35; g.add(face);
  const crown = crownMesh(1.8); crown.position.set(0, 3.15, 0); g.add(crown);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(3.4, 0.09, 8, 48), M.glow(0xff3b5c, 3)); ring.rotation.x = Math.PI / 2; ring.position.y = 1.2; g.add(ring);
  g.userData.ring = ring; g.scale.setScalar(scale);
  return g;
}

function buildDome(): Parts {
  const g = buildDomeModel(1);
  return { pivot: g, flash: [], ring: g.userData.ring as THREE.Object3D, marker: makeMarker() };
}

function buildUfo(): Parts {
  const g = new THREE.Group();
  const hull = mk(new THREE.SphereGeometry(4, 22, 10), M.paper('#7a8aa8'), { outline: 0.02 }); hull.scale.y = 0.3; g.add(hull);
  const dome = new THREE.Mesh(new THREE.SphereGeometry(1.9, 16, 8, 0, TAU, 0, Math.PI / 2), new THREE.MeshBasicMaterial({ color: new THREE.Color(0.4, 1.0, 1.9), toneMapped: false })); dome.position.y = 0.5; g.add(dome);
  const pilot = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 1.4), M.tex(T.smiley(), 'smiley', { transparent: true, double: true })); pilot.position.set(0, 1.0, 1.0); g.add(pilot);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(3.7, 0.12, 6, 40), M.glow(0xff3b5c, 3)); ring.rotation.x = Math.PI / 2; ring.position.y = -0.2; g.add(ring);
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(3.2, 3.2, 14, 24, 1, true), new THREE.MeshBasicMaterial({ color: 0x4aa8ff, transparent: true, opacity: 0.28, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
  beam.visible = false; g.add(beam);
  return { pivot: g, flash: [], ring, beam, marker: makeMarker() };
}

export function makeMarker(): THREE.Sprite {
  markerMat ??= new THREE.SpriteMaterial({ map: T.exclaim(), depthTest: false, transparent: true, toneMapped: false });
  const s = new THREE.Sprite(markerMat); s.visible = false; s.renderOrder = 20; return s;
}

// ------------------------------------------------------------------ enemy
let nextId = 1;
type St = 'spawn' | 'taunt' | 'chase' | 'windup' | 'fire' | 'recover' | 'cover' | 'roll' | 'leap' | 'dying' | 'idle' | 'atk';

import { EnemyFx } from './enemyfx';

export class Enemy {
  static bigMarkers = false;
  /** Shadow, health bar and elite-affix presentation (see enemyfx.ts). */
  readonly efx = new EnemyFx(this);
  affix = ''; shieldHp = 0; sinceHit = 99; shieldBroke = false;
  readonly id = nextId++;
  readonly root = new THREE.Group();
  readonly pos = new THREE.Vector3();
  readonly prev = new THREE.Vector3();
  readonly vel = new THREE.Vector3();
  private kb = new THREE.Vector3();
  parts: Parts;
  def: EnemyDef;
  hp = 1; maxHp = 1; active = false; dead = false;
  state: St = 'spawn'; t = 0; age = 0;
  yaw = 0; private visYaw = 0;
  stun = 0; slow = 0; burn = 0; blind = 0; taped = 0; flashT = 0;
  windupAmt = 0;
  dmgMul = 1; cdMul = 1; spdMul = 1;
  /** Incoming damage multiplier (closed Jack-in-the-Box, blinking ghost). */
  takeMul = 1;
  /** Seconds of Tin-Drum haste remaining. */
  haste = 0;
  /** Frontal shield raised (knights). */
  shieldUp = true;
  /** Scratch values for the extra enemy AIs. */
  ex: Record<string, number> = {};
  fireT = 1; shotsLeft = 0; shotT = 0; strafe = 1; strafeT = 0; private flank = 0;
  private cover = new THREE.Vector3();
  vy = 0; contactCd = 0; private hitThisLeap = false;
  private stuckT = 0; private lastX = 0; private lastZ = 0; private checkT = 0; private detour = 0; private detourDir = 1;
  private sq = 0; sqV = 0; visT = Math.random() * 10; private burnAcc = 0;
  // boss
  phase = 1; private atk = 'rest'; private atkT = 0; private spiral = 0; private shock = { t: 0, dur: 1.3, R: 18, hit: false, on: false };
  private beamAng = 0; private beamOn = false; private beamHitCd = 0; private ufoTarget = new THREE.Vector3(); private orbit = 0; private beamDmgT = 0;
  private laser: THREE.Mesh | null = null;
  readonly isBoss: boolean;

  constructor(def: EnemyDef) {
    this.def = def; this.isBoss = !!def.boss;
    this.parts = isExtra(def.kind) ? buildExtra(def) : def.kind === 'leaf' ? buildLeaf(def) : def.kind === 'blob' ? buildBlob(def) : def.kind === 'dome' ? buildDome() : def.kind === 'ufo' ? buildUfo() : buildSun(def);
    this.parts.pivot.scale.setScalar(def.kind === 'king' ? def.scale : def.kind === 'dome' ? def.scale : def.scale);
    this.root.add(this.parts.pivot);
    this.parts.marker.position.y = (def.height + 0.7) / (def.kind === 'ufo' ? 1 : 1);
    this.root.add(this.parts.marker);
    this.root.visible = false;
    if (def.kind === 'dome') {
      this.laser = new THREE.Mesh(new THREE.BoxGeometry(0.5, 0.4, 34), new THREE.MeshBasicMaterial({ color: new THREE.Color(3, 0.4, 0.6), toneMapped: false, transparent: true, opacity: 0.9 }));
      this.laser.visible = false; this.root.add(this.laser);
    }
  }

  get hitCenterY() { return this.def.kind === 'ufo' ? 0 : this.def.height * 0.5; }
  get hitR() { return this.def.kind === 'dome' || this.def.kind === 'king' ? this.def.radius : Math.max(this.def.radius, this.def.height * 0.4); }
  get alive() { return this.active && !this.dead; }

  reset(x: number, z: number, hpMul: number, spdMul: number, cdMul: number, dmgMul: number, fromSky = false) {
    const d = this.def;
    this.hp = this.maxHp = d.hp * hpMul; this.spdMul = spdMul; this.cdMul = cdMul; this.dmgMul = dmgMul;
    this.pos.set(x, d.kind === 'ufo' ? 12 : fromSky ? 16 : 0, z); this.prev.copy(this.pos); this.vel.set(0, 0, 0); this.kb.set(0, 0, 0);
    this.active = true; this.dead = false; this.state = 'spawn'; this.t = 0; this.age = 0; this.vy = 0;
    this.stun = this.slow = this.burn = this.blind = this.taped = this.flashT = 0; this.windupAmt = 0; this.shotsLeft = 0;
    this.haste = 0; this.takeMul = 1; this.shieldUp = true; this.ex = {}; this.efx.reset();
    this.fireT = 1 + Math.random() * 1.5; this.phase = 1; this.atk = 'rest'; this.atkT = 2; this.shock.on = false; this.beamOn = false;
    this.flank = (Math.random() - 0.5) * 1.2; this.strafe = Math.random() < 0.5 ? -1 : 1; this.sq = 0; this.sqV = 0;
    this.parts.pivot.rotation.set(0, 0, 0); this.parts.pivot.position.set(0, 0, 0);
    this.parts.pivot.scale.setScalar(d.scale);
    this.root.visible = true; this.root.position.copy(this.pos);
    if (this.laser) this.laser.visible = false;
    if (this.parts.beam) this.parts.beam.visible = false;
    for (const m of this.parts.flash) m.emissive.setRGB(0, 0, 0);
  }

  // ---- status effects
  addStun(t: number) { this.stun = Math.max(this.stun, this.isBoss ? t * 0.25 : t); }
  addSlow(t: number) { this.slow = Math.max(this.slow, t); }
  addBurn(t: number) { this.burn = Math.max(this.burn, t); }
  addBlind(t: number) { this.blind = Math.max(this.blind, this.isBoss ? t * 0.4 : t); }
  addTape(t: number) { this.taped = Math.max(this.taped, t); }
  knock(dx: number, dz: number, force: number) { const l = Math.hypot(dx, dz) || 1; const f = this.isBoss ? force * 0.05 : force * (this.def.mini ? 0.35 : 1); this.kb.x += (dx / l) * f; this.kb.z += (dz / l) * f; }

  /** Applies damage; returns true if this hit killed the enemy. */
  hurt(dmg: number): boolean {
    if (this.dead) return false;
    const d = (this.def.armor ? dmg * (1 - this.def.armor) : dmg) * this.takeMul;
    this.hp -= this.efx.absorb(d); this.flashT = 0.12; this.sqV -= this.isBoss ? 1 : 5;
    if (!this.isBoss && d > this.maxHp * 0.25 && this.state !== 'spawn') { this.state = 'recover'; this.t = 0; this.windupAmt = 0; this.shotsLeft = 0; }
    if (this.hp <= 0) { this.hp = 0; return true; }
    return false;
  }

  /** Starts the fold-flat death animation; the game awards loot before calling this. */
  die() {
    this.dead = true; this.state = 'dying'; this.t = 0; this.windupAmt = 0; this.parts.marker.visible = false;
    if (this.laser) this.laser.visible = false;
    if (this.parts.beam) this.parts.beam.visible = false;
  }

  private dirToPlayer(g: GameApi, out: { x: number; z: number; d: number }) {
    const dx = g.playerPos.x - this.pos.x, dz = g.playerPos.z - this.pos.z, d = Math.hypot(dx, dz) || 1;
    out.x = dx / d; out.z = dz / d; out.d = d;
  }
  tmp = { x: 0, z: 0, d: 0 };

  speedNow() { return this.def.speed * this.spdMul * (this.haste > 0 ? 1.4 : 1) * (this.slow > 0 ? 0.5 : 1) * (this.taped > 0 ? 0.35 : 1) * (this.stun > 0 ? 0 : 1); }

  /** Steer with smoothing, then integrate + collide + keep inside the arena. */
  steer(_g: GameApi, dx: number, dz: number, speed: number, dt: number) {
    const l = Math.hypot(dx, dz);
    let tx = 0, tz = 0;
    if (l > 1e-4) { tx = (dx / l) * speed; tz = (dz / l) * speed; }
    if (this.detour > 0) { const px = -tz * this.detourDir, pz = tx * this.detourDir; tx = tx * 0.3 + px; tz = tz * 0.3 + pz; this.detour -= dt; }
    this.vel.x = damp(this.vel.x, tx, 9, dt); this.vel.z = damp(this.vel.z, tz, 9, dt);
  }
  integrate(g: GameApi, dt: number, collide = true) {
    this.pos.x += (this.vel.x + this.kb.x) * dt; this.pos.z += (this.vel.z + this.kb.z) * dt;
    this.kb.multiplyScalar(Math.max(0, 1 - 7 * dt));
    if (collide) {
      resolveCircle(this.pos, this.def.radius * 0.8, this.def.height, g.colliders, 0.3);
      const es = g.enemies;
      for (let i = 0; i < es.length; i++) {
        const o = es[i];
        if (o === this || !o.alive || o.def.kind === 'ufo') continue;
        const dx = this.pos.x - o.pos.x, dz = this.pos.z - o.pos.z, min = (this.def.radius + o.def.radius) * 0.8, d2 = dx * dx + dz * dz;
        if (d2 < min * min && d2 > 1e-6) { const d = Math.sqrt(d2), p = (min - d) * 0.5; this.pos.x += (dx / d) * p; this.pos.z += (dz / d) * p; }
      }
    }
    const lim = g.mapRadius - this.def.radius, r = Math.hypot(this.pos.x, this.pos.z);
    if (r > lim) { this.pos.x *= lim / r; this.pos.z *= lim / r; }
  }
  /** If a unit wants to move but barely does, sidestep for a moment (prevents wedged enemies). */
  checkStuck(dt: number, wantsMove: boolean) {
    this.checkT += dt;
    if (this.checkT < 0.6) return;
    const moved = Math.hypot(this.pos.x - this.lastX, this.pos.z - this.lastZ);
    this.stuckT = wantsMove && moved < 0.25 && this.stun <= 0 ? this.stuckT + 1 : 0;
    if (this.stuckT >= 2) { this.detour = 1.2; this.detourDir = Math.random() < 0.5 ? -1 : 1; this.stuckT = 0; }
    this.lastX = this.pos.x; this.lastZ = this.pos.z; this.checkT = 0;
  }

  aimShot(g: GameApi, angleOff: number, kind: EProjSpec['kind'], speed: number, dmg: number, yOff: number) {
    const ox = this.pos.x, oy = this.pos.y + yOff, oz = this.pos.z;
    let tx = g.playerPos.x, ty = g.playerPos.y + 1.1, tz = g.playerPos.z;
    if (this.def.sniper) { const lead = Math.hypot(tx - ox, tz - oz) / speed; tx += g.playerVel.x * lead; tz += g.playerVel.z * lead; }
    let dx = tx - ox, dy = ty - oy, dz = tz - oz; const l = Math.hypot(dx, dy, dz) || 1; dx /= l; dy /= l; dz /= l;
    const err = angleOff + (this.blind > 0 ? (Math.random() - 0.5) * 1.0 : (Math.random() - 0.5) * 0.04);
    const c = Math.cos(err), s = Math.sin(err), rx = dx * c - dz * s, rz = dx * s + dz * c;
    g.fireEnemyProj({ x: ox + rx * 0.7, y: oy, z: oz + rz * 0.7, dx: rx, dy, dz: rz, speed, dmg, kind });
    g.sfx.play('enemyShoot');
  }
  radial(g: GameApi, n: number, offset: number, kind: EProjSpec['kind'], speed: number, dmg: number, y: number, gapAng = 99, gapW = 0) {
    for (let i = 0; i < n; i++) {
      const a = offset + (i / n) * TAU;
      if (Math.abs(angleDiff(a, gapAng)) < gapW) continue;
      g.fireEnemyProj({ x: this.pos.x + Math.cos(a) * 1.2, y: this.pos.y + y, z: this.pos.z + Math.sin(a) * 1.2, dx: Math.cos(a), dy: 0, dz: Math.sin(a), speed, dmg, kind });
    }
    g.sfx.play('enemyShoot', 0.7);
  }

  private findCover(g: GameApi): boolean {
    let best = 1e9; const px = g.playerPos.x, pz = g.playerPos.z;
    for (const c of g.colliders) {
      if (!c.alive || c.top < 1.1 || c.kind === 'prop') continue;
      const cx = (c.minX + c.maxX) / 2, cz = (c.minZ + c.maxZ) / 2, half = Math.max(c.maxX - c.minX, c.maxZ - c.minZ) / 2;
      const dx = cx - px, dz = cz - pz, d = Math.hypot(dx, dz) || 1;
      const bx = cx + (dx / d) * (half + 1.1), bz = cz + (dz / d) * (half + 1.1);
      if (Math.hypot(bx, bz) > g.mapRadius - 1.5) continue;
      const my = Math.hypot(bx - this.pos.x, bz - this.pos.z);
      if (my < best && my < 22 && d > 5) { best = my; this.cover.set(bx, 0, bz); }
    }
    return best < 1e8;
  }

  // ------------------------------------------------------------ update
  update(dt: number, g: GameApi) {
    if (!this.active) return;
    this.prev.copy(this.pos);
    this.t += dt; this.age += dt;
    if (this.state === 'dying') { if (this.pos.y > 0.01 && this.def.kind !== 'ufo') this.pos.y = Math.max(0, this.pos.y - 12 * dt); if (this.t > 0.5) { this.active = false; this.root.visible = false; } return; }
    if (this.contactCd > 0) this.contactCd -= dt;
    if (this.stun > 0) this.stun -= dt;
    if (this.slow > 0) this.slow -= dt;
    if (this.taped > 0) this.taped -= dt;
    if (this.blind > 0) this.blind -= dt;
    if (this.haste > 0) this.haste -= dt;
    this.efx.update(dt, g);
    if (this.burn > 0) { this.burn -= dt; this.burnAcc += dt; if (this.burnAcc >= 0.5) { this.burnAcc = 0; g.damageEnemy(this, 5 + this.maxHp * 0.01, true); g.fx.sparks(this.pos.x, this.pos.y + this.def.height * 0.6, this.pos.z, 3, 0xff7a1a); if (this.dead) return; } }
    this.dirToPlayer(g, this.tmp);
    const want = Math.atan2(this.tmp.x, this.tmp.z);

    if (this.state === 'spawn') {
      if (this.pos.y > 0) { this.vy -= 30 * dt; this.pos.y = Math.max(this.def.kind === 'ufo' ? 12 : 0, this.pos.y + this.vy * dt); if (this.pos.y === 0 && this.vy < 0) { this.sqV -= 8; g.fx.scraps(this.pos.x, 0.1, this.pos.z, 12, 0xb98a52, 3); this.vy = 0; } }
      this.yaw = want;
      if (this.t > 0.6 && this.pos.y <= (this.def.kind === 'ufo' ? 12 : 0)) { this.state = this.def.kind === 'leaf' ? 'taunt' : this.def.kind === 'blob' ? 'roll' : this.def.kind === 'sun' ? 'idle' : isExtra(this.def.kind) ? (initialExtraState(this.def.kind) as St) : 'atk'; this.t = 0; if (this.def.kind === 'leaf' && g.rng.chance(0.2)) g.caption('[' + this.def.name + ' grins]'); }
      this.integrate(g, dt, false);
      return;
    }
    if (this.stun > 0) { this.vel.x = damp(this.vel.x, 0, 12, dt); this.vel.z = damp(this.vel.z, 0, 12, dt); this.integrate(g, dt, !this.isBoss); this.windupAmt = Math.max(0, this.windupAmt - dt * 4); return; }
    switch (this.def.kind) {
      case 'leaf': this.updateLeaf(dt, g, want); break;
      case 'sun': this.updateSun(dt, g, want); break;
      case 'blob': this.updateBlob(dt, g, want); break;
      case 'king': this.updateKing(dt, g, want); break;
      case 'dome': this.updateDome(dt, g, want); break;
      case 'ufo': this.updateUfo(dt, g); break;
      default: updateExtra(this, dt, g, want);
    }
  }

  private updateLeaf(dt: number, g: GameApi, want: number) {
    const d = this.def, p = this.tmp;
    this.strafeT -= dt; if (this.strafeT <= 0) { this.strafe = -this.strafe; this.strafeT = 1.5 + Math.random() * 2; }
    let moving = false;
    switch (this.state) {
      case 'taunt': this.yaw = want; this.vel.multiplyScalar(0.9); if (this.t > 0.7) { this.state = 'chase'; this.t = 0; } break;
      case 'chase': {
        const range = d.sniper ? 22 : d.mini ? 12 : 9 + (this.id % 5);
        this.yaw = damp(this.yaw, this.yaw + angleDiff(this.yaw, want), 10, dt);
        if (p.d > range + 2) { const ca = Math.cos(this.flank), sa = Math.sin(this.flank); this.steer(g, p.x * ca - p.z * sa, p.x * sa + p.z * ca, this.speedNow(), dt); moving = true; }
        else if (p.d < range - 3) { this.steer(g, -p.x, -p.z, this.speedNow() * 0.7, dt); moving = true; }
        else { this.steer(g, -p.z * this.strafe, p.x * this.strafe, this.speedNow() * 0.65, dt); moving = true; }
        this.integrate(g, dt); this.checkStuck(dt, moving);
        this.fireT -= dt;
        if (this.fireT <= 0 && p.d < range + 8 && hasLOS({ x: this.pos.x, y: 1, z: this.pos.z }, { x: g.playerPos.x, y: 1, z: g.playerPos.z }, g.colliders)) { this.state = 'windup'; this.t = 0; g.sfx.play('telegraph'); if (g.rng.chance(0.25)) g.caption('[' + d.name + ' takes aim]'); }
        break;
      }
      case 'windup': {
        this.windupAmt = clamp(this.t / d.windup, 0, 1); this.yaw = want; this.vel.multiplyScalar(0.85); this.integrate(g, dt);
        if (this.t >= d.windup) { this.state = 'fire'; this.t = 0; this.shotsLeft = d.sniper ? 1 : d.mini ? 6 : 3; this.shotT = 0; }
        break;
      }
      case 'fire': {
        this.yaw = want; this.shotT -= dt;
        if (this.shotsLeft > 0 && this.shotT <= 0) {
          this.aimShot(g, 0, d.proj, d.projSpeed, d.dmg * this.dmgMul, 1.0 * d.scale); this.shotsLeft--; this.shotT = 0.11; this.sqV += 3;
          if (d.mini && this.shotsLeft % 2 === 0) { this.aimShot(g, 0.25, d.proj, d.projSpeed, d.dmg * this.dmgMul, 1.0 * d.scale); this.aimShot(g, -0.25, d.proj, d.projSpeed, d.dmg * this.dmgMul, 1.0 * d.scale); }
        }
        if (this.shotsLeft <= 0 && this.shotT <= 0) { this.state = 'recover'; this.t = 0; this.windupAmt = 0; }
        break;
      }
      case 'recover': {
        this.windupAmt = 0; this.vel.multiplyScalar(0.9); this.integrate(g, dt);
        if (this.t > 0.3) {
          this.fireT = (d.cooldown * (0.8 + Math.random() * 0.5)) / this.cdMul;
          if (!d.mini && Math.random() < 0.35 && this.findCover(g)) { this.state = 'cover'; } else { this.state = 'chase'; this.flank = (Math.random() - 0.5) * 1.4; }
          this.t = 0;
        }
        break;
      }
      case 'cover': {
        const dx = this.cover.x - this.pos.x, dz = this.cover.z - this.pos.z;
        if (Math.hypot(dx, dz) > 0.6 && this.t < 3.2) { this.steer(g, dx, dz, this.speedNow() * 1.2, dt); moving = true; this.yaw = Math.atan2(dx, dz); }
        else { this.vel.multiplyScalar(0.8); this.yaw = want; if (this.t > 1.8 || this.fireT < 0) { this.state = 'chase'; this.t = 0; this.fireT = 0.3; } }
        this.integrate(g, dt); this.checkStuck(dt, moving);
        this.fireT -= dt * 0.5;
        break;
      }
      default: this.state = 'chase';
    }
  }

  private updateSun(dt: number, g: GameApi, want: number) {
    const d = this.def, p = this.tmp;
    this.yaw = damp(this.yaw, this.yaw + angleDiff(this.yaw, want), 6, dt);
    if (this.state === 'idle') {
      this.windupAmt = 0;
      if (p.d > 14) this.steer(g, p.x, p.z, this.speedNow(), dt); else this.steer(g, 0, 0, 0, dt);
      this.integrate(g, dt); this.checkStuck(dt, p.d > 14);
      this.fireT -= dt;
      if (this.fireT <= 0 && p.d < 32) { this.state = 'windup'; this.t = 0; g.sfx.play('telegraph', 0.8); if (g.rng.chance(0.25)) g.caption('[' + d.name + ' flares its petals]'); }
    } else if (this.state === 'windup') {
      this.windupAmt = clamp(this.t / d.windup, 0, 1); this.vel.multiplyScalar(0.8); this.integrate(g, dt);
      if (this.t >= d.windup) { this.state = 'fire'; this.t = 0; this.shotsLeft = d.fire ? 4 : d.mini ? 3 : 1; this.shotT = 0; }
    } else if (this.state === 'fire') {
      this.shotT -= dt;
      if (this.shotsLeft > 0 && this.shotT <= 0) {
        const y = d.mini ? 1.0 : 1.5 * d.scale * 0.9;
        if (d.mini) this.radial(g, 14, g.time * 2, d.proj, d.projSpeed, d.dmg * this.dmgMul, y);
        else if (d.fire) this.aimShot(g, 0, 'fire', d.projSpeed, d.dmg * this.dmgMul, y);
        else { this.aimShot(g, 0, 'seed', d.projSpeed, d.dmg * this.dmgMul, y); this.aimShot(g, 0.2, 'seed', d.projSpeed, d.dmg * this.dmgMul, y); this.aimShot(g, -0.2, 'seed', d.projSpeed, d.dmg * this.dmgMul, y); }
        this.shotsLeft--; this.shotT = d.fire ? 0.2 : 0.5; this.sqV += 4;
      }
      if (this.shotsLeft <= 0) { this.state = 'recover'; this.t = 0; }
    } else { // recover
      this.windupAmt = Math.max(0, this.windupAmt - dt * 3); this.integrate(g, dt);
      if (this.t > 0.4) { this.state = 'idle'; this.t = 0; this.fireT = (d.cooldown * (0.8 + Math.random() * 0.5)) / this.cdMul; }
    }
  }

  private updateBlob(dt: number, g: GameApi, want: number) {
    const d = this.def, p = this.tmp, pr = g.playerRadius;
    this.fireT -= dt;
    const touching = p.d < d.radius + pr + 0.15 && g.playerPos.y < this.pos.y + d.height;
    if (this.state === 'roll' || this.state === 'recover') {
      this.yaw = damp(this.yaw, this.yaw + angleDiff(this.yaw, want), 8, dt);
      const zig = Math.sin(this.age * 2.6 + this.id) * 0.6;
      const lx = -p.z * zig, lz = p.x * zig;
      this.steer(g, p.x + lx, p.z + lz, this.speedNow(), dt);
      this.integrate(g, dt); this.checkStuck(dt, true);
      this.windupAmt = 0;
      if (touching && this.contactCd <= 0) { g.hurtPlayer(d.dmg * this.dmgMul, this.pos, 'contact'); this.contactCd = 0.9; this.knock(-p.x, -p.z, 9); g.sfx.play('bounce'); }
      if (this.fireT <= 0 && p.d < 8.5 && p.d > 2) { this.state = 'windup'; this.t = 0; g.sfx.play('telegraph', 1.2); }
    } else if (this.state === 'windup') {
      this.windupAmt = clamp(this.t / d.windup, 0, 1); this.yaw = want; this.vel.multiplyScalar(0.8); this.integrate(g, dt);
      if (this.t >= d.windup) {
        this.state = 'leap'; this.t = 0; this.vy = d.mini ? 11 : 8; this.hitThisLeap = false; this.windupAmt = 0;
        const sp = Math.min(p.d / 0.75, d.mini ? 15 : 12); this.vel.x = p.x * sp; this.vel.z = p.z * sp; this.sqV += 7; g.sfx.play('bounce', 0.7);
      }
    } else if (this.state === 'leap') {
      this.vy -= 24 * dt; this.pos.y += this.vy * dt; this.integrate(g, dt);
      if (!this.hitThisLeap && p.d < d.radius + pr + 0.25 && g.playerPos.y < this.pos.y + d.height * 0.8 && this.pos.y < g.playerPos.y + 1.9) { this.hitThisLeap = true; g.hurtPlayer(d.dmg * 1.3 * this.dmgMul, this.pos, 'contact'); }
      if (this.pos.y <= 0 && this.vy < 0) {
        this.pos.y = 0; this.state = 'roll'; this.sqV -= 6; this.fireT = (d.cooldown * (0.8 + Math.random() * 0.6)) / this.cdMul;
        g.fx.scraps(this.pos.x, 0.1, this.pos.z, 8, 0x3f8cf0, 3.5); g.shake(d.mini ? 0.35 : 0.08); g.sfx.play('bounce');
      }
    }
  }

  // ------------------------------------------------------------ bosses
  private bossPhase(g: GameApi) {
    const f = this.hp / this.maxHp, ph = f > 0.66 ? 1 : f > 0.33 ? 2 : 3;
    if (ph !== this.phase) { this.phase = ph; this.atk = 'rest'; this.atkT = 1.5; this.flashT = 0.4; g.sfx.play('bossRoar'); g.shake(0.6); g.caption('[' + this.def.name + ' roars — phase ' + ph + ']'); g.fx.confetti(this.pos.x, this.def.height * 0.6, this.pos.z, 80, 12); }
  }
  private updateShock(dt: number, g: GameApi) {
    const s = this.shock;
    if (!s.on) return;
    s.t += dt;
    const k = s.t / s.dur;
    if (k >= 1) { s.on = false; return; }
    const r = s.R * easeOutCubic(k), dist = Math.hypot(g.playerPos.x - this.pos.x, g.playerPos.z - this.pos.z);
    if (!s.hit && Math.abs(dist - r) < 1.1 && g.playerPos.y < 0.7) { s.hit = true; g.hurtPlayer(this.def.dmg * 1.4 * this.dmgMul, this.pos, 'shock'); }
  }
  private startShock(g: GameApi, R = 18) {
    this.shock.on = true; this.shock.t = 0; this.shock.hit = false; this.shock.R = R;
    g.fx.ring(this.pos.x, 0.12, this.pos.z, 0xff9a2e, R, this.shock.dur); g.fx.ring(this.pos.x, 0.12, this.pos.z, 0xffffff, R * 0.95, this.shock.dur * 0.95);
    g.shake(0.7); g.sfx.play('boom'); g.fx.scraps(this.pos.x, 0.2, this.pos.z, 40, 0xb98a52, 8);
  }

  private updateKing(dt: number, g: GameApi, want: number) {
    const d = this.def, p = this.tmp;
    this.bossPhase(g); this.updateShock(dt, g);
    this.yaw = damp(this.yaw, this.yaw + angleDiff(this.yaw, want), 4, dt);
    this.atkT -= dt; this.windupAmt = this.atk === 'ring' ? clamp(1 - this.atkT / 1.1, 0, 1) : this.atk === 'slam' ? clamp(1 - this.atkT / 0.9, 0, 1) * 0.7 : 0;
    const ph = this.phase, dmg = d.dmg * this.dmgMul, y = 1.0; // waist height so the player must jump or dash through
    const chaseSp = (ph === 1 ? 1.4 : 2.2) * this.spdMul;
    const walk = () => { if (p.d > 9) this.steer(g, p.x, p.z, chaseSp, dt); else this.steer(g, 0, 0, 0, dt); this.integrate(g, dt); };
    switch (this.atk) {
      case 'rest': walk(); if (this.atkT <= 0) { const seq = ph === 1 ? ['spiral', 'summon', 'spiral'] : ph === 2 ? ['ring', 'slam', 'spiral', 'summon'] : ['ring', 'slam', 'fireSpiral', 'summon', 'slam']; this.atk = seq[Math.floor(this.age / 3) % seq.length]; this.atkT = this.atk === 'ring' ? 1.1 : this.atk === 'slam' ? 0.9 : this.atk === 'summon' ? 1 : 4; this.spiral = 0; this.shotT = 0; if (this.atk === 'slam') { this.vy = 13; } g.sfx.play('telegraph', 0.6); } break;
      case 'spiral': case 'fireSpiral': {
        walk(); this.shotT -= dt;
        if (this.shotT <= 0) { this.spiral += 0.55; const k = this.atk === 'fireSpiral' ? 'fire' : 'seed'; for (let i = 0; i < (ph === 3 ? 3 : 2); i++) { const a = this.spiral + (i * TAU) / (ph === 3 ? 3 : 2); g.fireEnemyProj({ x: this.pos.x + Math.cos(a) * 2.5, y: y, z: this.pos.z + Math.sin(a) * 2.5, dx: Math.cos(a), dy: 0, dz: Math.sin(a), speed: 11, dmg, kind: k }); } this.shotT = ph === 1 ? 0.14 : 0.1; g.sfx.play('enemyShoot', 0.6); }
        if (this.atkT <= 0) { this.atk = 'rest'; this.atkT = ph === 1 ? 1.8 : 1.2; }
        break;
      }
      case 'ring':
        this.vel.multiplyScalar(0.9); this.integrate(g, dt);
        if (this.atkT <= 0) { const gap = Math.atan2(p.z, p.x) + (Math.random() - 0.5) * 1.2; this.radial(g, 28, 0, ph === 3 ? 'fire' : 'seed', 10, dmg, y, gap, 0.28); this.atk = 'rest'; this.atkT = 1.3; this.sqV += 3; }
        break;
      case 'slam': {
        this.pos.y += this.vy * dt; this.vy -= 30 * dt;
        if (this.pos.y > 0) { this.steer(g, p.x, p.z, 7, dt); this.integrate(g, dt); } // drift towards the player so the landing is a threat
        else if (this.vy < 0) { this.pos.y = 0; this.vy = 0; this.startShock(g, ph === 3 ? 22 : 18); this.atk = 'rest'; this.atkT = 1.4; this.sqV -= 3; }
        break;
      }
      case 'summon':
        this.vel.multiplyScalar(0.9); this.integrate(g, dt);
        if (this.atkT <= 0) {
          let alive = 0; for (const e of g.enemies) if (e.alive && !e.isBoss) alive++;
          if (alive < 8) for (let i = 0; i < 2; i++) { const a = Math.random() * TAU; g.spawnEnemy(ph === 3 ? 'blob' : i ? 'leaf' : 'sun', this.pos.x + Math.cos(a) * 6, this.pos.z + Math.sin(a) * 6); }
          g.sfx.play('confetti'); this.atk = 'rest'; this.atkT = 2;
        }
        break;
    }
    if (this.atk !== 'slam' && this.pos.y > 0) this.pos.y = 0;
  }

  private updateDome(dt: number, g: GameApi, want: number) {
    const d = this.def, p = this.tmp, ph = this.phase, dmg = d.dmg * this.dmgMul;
    this.bossPhase(g); this.updateShock(dt, g);
    this.yaw = damp(this.yaw, this.yaw + angleDiff(this.yaw, want), 2.5, dt);
    this.atkT -= dt;
    if (this.parts.ring) this.parts.ring.rotation.z += dt * (this.beamOn ? 6 : 1.5);
    if (this.beamHitCd > 0) this.beamHitCd -= dt;
    this.windupAmt = this.atk === 'fan' ? clamp(1 - this.atkT / 0.8, 0, 1) : 0;
    const y = 2.6;
    if (this.laser) {
      if (this.beamOn) {
        this.beamAng += dt * (ph === 3 ? 1.25 : 0.9);
        this.laser.visible = true;
        const warn = this.atkT > 3.2; // thin flashing telegraph first
        this.laser.scale.set(warn ? 0.25 : 1, 1, 1); (this.laser.material as THREE.MeshBasicMaterial).opacity = warn ? 0.4 + 0.3 * Math.sin(this.age * 30) : 0.95;
        // the root never yaws for the dome (only its pivot does), so the laser is in world orientation
        this.laser.position.set(Math.sin(this.beamAng) * 17, 0.5, Math.cos(this.beamAng) * 17); this.laser.rotation.y = this.beamAng;
        if (!warn && this.beamHitCd <= 0) {
          const dx = g.playerPos.x - this.pos.x, dz = g.playerPos.z - this.pos.z, ang = Math.atan2(dx, dz), dist = Math.hypot(dx, dz);
          if (Math.abs(angleDiff(this.beamAng, ang)) < 0.2 + 0.6 / Math.max(dist, 3) * 0.3 && g.playerPos.y < 0.8 && dist < 34) { this.beamHitCd = 0.6; g.hurtPlayer(dmg * 1.2, this.pos, 'laser'); }
        }
      } else this.laser.visible = false;
    }
    switch (this.atk) {
      case 'rest':
        this.vel.multiplyScalar(0.9); this.integrate(g, dt, false);
        if (this.atkT <= 0) {
          const seq = ph === 1 ? ['fan', 'blobs', 'fan'] : ph === 2 ? ['beam', 'fan', 'blobs', 'beam'] : ['beam', 'orbs', 'pound', 'fan', 'blobs'];
          this.atk = seq[Math.floor(this.age / 2.5) % seq.length]; this.shotT = 0; this.shotsLeft = 3;
          this.atkT = this.atk === 'fan' ? 0.8 : this.atk === 'beam' ? 6 : this.atk === 'pound' ? 1.4 : this.atk === 'orbs' ? 2 : 1;
          if (this.atk === 'beam') { this.beamOn = true; this.beamAng = Math.atan2(p.x, p.z) - 1.5; g.sfx.play('telegraph', 0.5); g.caption('[Neon ring charges — jump the laser!]'); }
          if (this.atk === 'pound') this.vy = 14;
        }
        break;
      case 'fan':
        if (this.atkT <= 0) {
          this.shotT -= dt;
          if (this.shotT <= 0 && this.shotsLeft > 0) { for (let i = -2; i <= 2; i++) this.aimShot(g, i * 0.17, 'bolt', d.projSpeed, dmg, y); this.shotsLeft--; this.shotT = 0.45; this.sqV += 3; }
          if (this.shotsLeft <= 0) { this.atk = 'rest'; this.atkT = 1.6; }
        }
        break;
      case 'blobs':
        if (this.atkT <= 0) { let alive = 0; for (const e of g.enemies) if (e.alive && !e.isBoss) alive++; if (alive < 9) for (let i = 0; i < 3; i++) { const a = (i / 3) * TAU + Math.random(); g.spawnEnemy(i === 0 && ph > 1 ? 'blobSpike' : 'blob', this.pos.x + Math.cos(a) * 5, this.pos.z + Math.sin(a) * 5); } g.sfx.play('confetti'); this.atk = 'rest'; this.atkT = 2; }
        break;
      case 'beam':
        if (this.atkT <= 0) { this.beamOn = false; this.atk = 'rest'; this.atkT = 1.5; }
        break;
      case 'orbs':
        this.shotT -= dt;
        if (this.shotT <= 0) { for (let i = 0; i < 3; i++) { const a = Math.random() * TAU; g.fireEnemyProj({ x: this.pos.x + Math.cos(a) * 2.5, y: y + 1, z: this.pos.z + Math.sin(a) * 2.5, dx: Math.cos(a), dy: 0.4, dz: Math.sin(a), speed: 7, dmg, kind: 'orb', homing: 1.4, life: 6 }); } this.shotT = 0.7; g.sfx.play('enemyShoot', 0.5); }
        if (this.atkT <= 0) { this.atk = 'rest'; this.atkT = 1.4; }
        break;
      case 'pound':
        this.pos.y += this.vy * dt; this.vy -= 30 * dt;
        if (this.pos.y > 0) { this.steer(g, p.x, p.z, 9, dt); this.integrate(g, dt); }
        if (this.pos.y <= 0 && this.vy < 0) { this.pos.y = 0; this.vy = 0; this.startShock(g, 20); this.atk = 'rest'; this.atkT = 1.6; }
        break;
    }
  }

  private updateUfo(dt: number, g: GameApi) {
    const d = this.def, ph = this.phase, dmg = d.dmg * this.dmgMul, p = this.tmp;
    this.bossPhase(g);
    this.atkT -= dt; this.beamDmgT -= dt;
    this.windupAmt = this.atk === 'plasma' ? clamp(1 - this.atkT / 0.9, 0, 1) : 0;
    if (this.parts.ring) this.parts.ring.rotation.z += dt * 3;
    this.yaw += dt * 0.6;
    const hover = 11 + Math.sin(this.age * 1.3) * 0.8;
    this.pos.y = damp(this.pos.y, hover, 3, dt);
    const moveTo = (tx: number, tz: number, k: number) => { this.pos.x = damp(this.pos.x, tx, k, dt); this.pos.z = damp(this.pos.z, tz, k, dt); };
    switch (this.atk) {
      case 'rest': case 'orbit': {
        this.orbit += dt * (0.35 + ph * 0.1);
        moveTo(Math.cos(this.orbit) * 13, Math.sin(this.orbit) * 13, 1.5);
        if (this.atkT <= 0) {
          const seq = ph === 1 ? ['plasma', 'beam', 'plasma'] : ph === 2 ? ['beam', 'plasma', 'beam', 'spin'] : ['beam', 'spin', 'plasma', 'beam', 'spin'];
          this.atk = seq[Math.floor(this.age / 3) % seq.length]; this.shotsLeft = 3; this.shotT = 0;
          this.atkT = this.atk === 'plasma' ? 0.9 : this.atk === 'beam' ? 4.4 : 1.2;
          if (this.atk === 'beam') { this.ufoTarget.set(g.playerPos.x + g.playerVel.x * 0.6, 0, g.playerPos.z + g.playerVel.z * 0.6); const l = Math.hypot(this.ufoTarget.x, this.ufoTarget.z); const lim = g.mapRadius - 4; if (l > lim) { this.ufoTarget.x *= lim / l; this.ufoTarget.z *= lim / l; } g.groundMarker(this.ufoTarget.x, this.ufoTarget.z, 3.4, 1.5, 'warn'); g.caption('[UFO locks on — beam incoming]'); g.sfx.play('telegraph', 0.7); }
          else g.sfx.play('telegraph', 1.2);
        }
        break;
      }
      case 'plasma':
        if (this.atkT <= 0) {
          this.shotT -= dt;
          if (this.shotT <= 0 && this.shotsLeft > 0) { for (let i = -1; i <= 1; i++) this.aimShot(g, i * 0.2, 'plasma', d.projSpeed, dmg, -0.5); this.shotsLeft--; this.shotT = 0.4; }
          if (this.shotsLeft <= 0) { this.atk = 'rest'; this.atkT = 1.4; }
        }
        break;
      case 'beam': {
        const lock = this.atkT > 2.9;
        moveTo(this.ufoTarget.x, this.ufoTarget.z, lock ? 4 : 8);
        const beam = this.parts.beam;
        if (beam) { beam.visible = !lock; beam.position.y = -(this.pos.y) / 2; beam.scale.set(1, this.pos.y / 14, 1); }
        if (!lock && this.atkT < 2.85 && !this.beamOn) { this.beamOn = true; g.spawnCrateDrop(this.pos.x, this.pos.z); g.sfx.play('boom', 0.6); let alive = 0; for (const e of g.enemies) if (e.alive && !e.isBoss) alive++; if (alive < 10) for (let i = 0; i < (ph === 1 ? 2 : 3); i++) { const a = Math.random() * TAU; g.spawnEnemy(g.rng.pick(['leaf', 'blob', 'sun']), this.pos.x + Math.cos(a) * 3.2, this.pos.z + Math.sin(a) * 3.2, { fromSky: true }); } }
        if (!lock && this.beamDmgT <= 0 && Math.hypot(g.playerPos.x - this.pos.x, g.playerPos.z - this.pos.z) < 3.3) { this.beamDmgT = 0.45; g.hurtPlayer(d.dmg * 0.7 * this.dmgMul, this.pos, 'laser'); }
        if (this.atkT <= 0) { this.beamOn = false; if (beam) beam.visible = false; this.atk = 'rest'; this.atkT = 1.2; }
        break;
      }
      case 'spin':
        if (this.atkT <= 0.6) {
          this.shotT -= dt;
          if (this.shotT <= 0 && this.shotsLeft > 0) {
            // ring of plasma that converges on the area around the player (the UFO flies high above)
            for (let k = 0; k < 14; k++) {
              const a = (k / 14) * TAU + this.age * 3, tx = g.playerPos.x + Math.cos(a) * 7 - this.pos.x, tz = g.playerPos.z + Math.sin(a) * 7 - this.pos.z, ty = 0.9 - this.pos.y, l = Math.hypot(tx, ty, tz) || 1;
              g.fireEnemyProj({ x: this.pos.x, y: this.pos.y - 0.6, z: this.pos.z, dx: tx / l, dy: ty / l, dz: tz / l, speed: 13, dmg, kind: 'plasma' });
            }
            g.sfx.play('enemyShoot', 0.6); this.shotsLeft--; this.shotT = 0.55;
          }
          if (this.shotsLeft <= 0) { this.atk = 'rest'; this.atkT = 1.4; }
        }
        break;
    }
    void p;
  }

  // ------------------------------------------------------------ render sync
  /** Interpolated transform + procedural squash/stretch, lean, waddle, telegraph. */
  sync(alpha: number, dt: number, camPos: THREE.Vector3) {
    if (!this.active) return;
    const d = this.def, pv = this.parts.pivot;
    this.visT += dt;
    // spring for squash & stretch
    this.sqV += (-90 * this.sq - 9 * this.sqV) * dt; this.sq = clamp(this.sq + this.sqV * dt, -0.5, 0.5);
    this.root.position.lerpVectors(this.prev, this.pos, alpha);
    this.visYaw += angleDiff(this.visYaw, this.yaw) * Math.min(1, dt * 14);
    const pivotYaw = d.kind === 'ufo' || d.kind === 'dome';
    this.root.rotation.y = pivotYaw ? 0 : this.visYaw;
    if (pivotYaw) pv.rotation.y = d.kind === 'ufo' ? this.yaw : this.visYaw;
    const speed = Math.hypot(this.vel.x, this.vel.z);

    if (this.state === 'dying') {
      const k = clamp(this.t / 0.45, 0, 1), e = k * k;
      pv.rotation.x = -e * (Math.PI / 2) * (d.kind === 'blob' ? 0 : 1);
      pv.scale.set(d.scale * (1 + e * 0.3), d.scale * Math.max(0.05, 1 - e * 0.95), d.scale * (1 + e * 0.3));
      this.parts.marker.visible = false;
      this.efx.sync();
      return;
    }
    let sc = d.scale;
    if (this.state === 'spawn') sc *= easeOutBack(clamp(this.t / 0.5, 0, 1));
    const sy = 1 + this.sq, sxz = 1 - this.sq * 0.5;
    let lean = 0, waddle = 0, hop = 0;
    if (d.kind === 'leaf') {
      waddle = Math.sin(this.visT * 12) * 0.12 * clamp(speed / 4, 0, 1);
      lean = -this.windupAmt * 0.3 + clamp(speed / 14, 0, 0.18);
      hop = Math.abs(Math.sin(this.visT * 12)) * 0.05 * clamp(speed / 4, 0, 1);
      if (this.parts.arms) { const raise = this.state === 'taunt' ? Math.sin(this.visT * 16) * 0.5 + 1.1 : this.windupAmt * 1.2 + (this.state === 'fire' ? 0.9 : 0); this.parts.arms[0].rotation.z = -raise * 0.9 - Math.sin(this.visT * 12) * 0.2 * clamp(speed / 4, 0, 1); this.parts.arms[1].rotation.z = raise * 0.9 + Math.sin(this.visT * 12 + 1) * 0.2 * clamp(speed / 4, 0, 1); }
      if (this.parts.wheels) for (const w of this.parts.wheels) w.rotation.x += speed * dt * 4;
    } else if (d.kind === 'sun' || d.kind === 'king') {
      hop = Math.sin(this.visT * 2) * 0.03;
      if (this.parts.petals) { this.parts.petals.rotation.z += dt * (0.8 + this.windupAmt * 9); const f = 1 + this.windupAmt * 0.35 + Math.sin(this.visT * 3) * 0.02; this.parts.petals.scale.setScalar(f); }
      if (this.parts.head) this.parts.head.rotation.z = Math.sin(this.visT * 1.5) * 0.04;
      if (this.parts.arms) { this.parts.arms[0].rotation.z = -1.1 + Math.sin(this.visT * 2) * 0.12 - this.windupAmt * 0.4; this.parts.arms[1].rotation.z = 1.1 - Math.sin(this.visT * 2 + 1) * 0.12 + this.windupAmt * 0.4; }
    } else if (d.kind === 'blob') {
      const rolling = this.state === 'roll' || this.state === 'recover';
      hop = rolling ? Math.abs(Math.sin(this.visT * 9)) * 0.22 * clamp(speed / 3, 0, 1) : 0;
      pv.rotation.z = rolling ? Math.sin(this.visT * 9) * 0.16 : 0;
      const squashW = this.windupAmt * 0.4;
      pv.scale.set(sc * (sxz + squashW * 0.4), sc * (sy - squashW), sc * sxz);
      pv.rotation.x = this.state === 'leap' ? -0.25 : 0;
    } else if (isExtra(d.kind)) {
      const r = syncExtra(this, dt, speed); lean = r.lean; waddle = r.waddle; hop = r.hop;
    } else if (d.kind === 'dome') {
      pv.position.y = Math.sin(this.visT * 2) * 0.03;
    }
    if (d.kind !== 'blob') {
      pv.scale.set(sc * sxz, sc * sy, sc * sxz);
      pv.rotation.x = lean; pv.rotation.z = waddle;
    }
    if (d.kind === 'ufo') { pv.rotation.z = Math.sin(this.visT * 1.2) * 0.04; pv.rotation.x = Math.cos(this.visT * 0.9) * 0.03; }
    if (d.kind !== 'dome') pv.position.y = hop;

    // telegraph marker: shape (triangle with !) + brows, never colour alone
    const mk = this.parts.marker;
    mk.visible = this.windupAmt > 0.05;
    if (mk.visible) { const s = (Enemy.bigMarkers ? 1.5 : 1) * (0.7 + Math.sin(this.visT * 24) * 0.12 + this.windupAmt * 0.3) * (d.mini || this.isBoss ? 1.8 : 1); mk.scale.set(s * 0.55, s * 0.55, 1); mk.position.y = d.height + 0.6; }
    if (this.parts.brows) { const a = 0.12 + this.windupAmt * 0.55; const sign = d.kind === 'leaf' ? 1 : 1; this.parts.brows[0].rotation.z = -a * sign; this.parts.brows[1].rotation.z = a * sign; }
    // hit flash
    if (this.flashT > 0) { this.flashT -= dt; const f = clamp(this.flashT / 0.12, 0, 1) * 0.8; for (const m of this.parts.flash) m.emissive.setRGB(f, f, f * 0.9); }
    else if (this.windupAmt > 0.05 && d.kind === 'bomb') { const f = (0.4 + 0.6 * Math.sin(this.visT * 34)) * this.windupAmt; for (const m of this.parts.flash) m.emissive.setRGB(f, f * 0.7, f * 0.5); }
    else if (this.burn > 0) { const f = 0.25 + Math.sin(this.visT * 20) * 0.1; for (const m of this.parts.flash) m.emissive.setRGB(f, f * 0.3, 0); }
    else if (this.slow > 0 || this.taped > 0) for (const m of this.parts.flash) m.emissive.setRGB(0, 0.08, 0.2);
    else for (const m of this.parts.flash) m.emissive.setRGB(0, 0, 0);
    this.efx.sync(); // shadow, health bar, elite tint (must run after the emissive state above)
    void camPos;
  }

  /** Confetti colour used when this creature bursts. */
  get burstColors(): number[] { return this.def.kind === 'blob' ? [0x3f8cf0, 0xff8fb8, 0xf3e7cc, 0xffd54a] : this.def.kind === 'leaf' ? [0x38b9ad, 0xf3e7cc, 0xffd54a, 0x141016] : CONFETTI; }
}

// ------------------------------------------------------------------ pool
export class EnemyPool {
  private free = new Map<string, Enemy[]>();
  constructor(private scene: THREE.Scene) {}
  acquire(id: string): Enemy {
    const def = ENEMY_DEFS[id] ?? ENEMY_DEFS.leaf;
    const list = this.free.get(def.id);
    const e = list?.pop() ?? new Enemy(def);
    if (!e.root.parent) this.scene.add(e.root);
    return e;
  }
  release(e: Enemy) {
    e.active = false; e.root.visible = false;
    let list = this.free.get(e.def.id);
    if (!list) { list = []; this.free.set(e.def.id, list); }
    list.push(e);
  }
  dispose() { this.free.forEach((l) => l.forEach((e) => e.root.removeFromParent())); this.free.clear(); }
}
