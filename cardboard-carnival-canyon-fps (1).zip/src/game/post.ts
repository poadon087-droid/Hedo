/**
 * Post-processing: world pass, viewmodel pass (depth-cleared so the blaster never clips walls),
 * bloom for neon, then a lens pass (tilt-shift depth of field, sun shafts, split-tone colour grade,
 * vignette, grain) and tone mapping.
 */
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';

const LensShader = {
  uniforms: {
    tDiffuse: { value: null as THREE.Texture | null },
    res: { value: new THREE.Vector2(1, 1) },
    time: { value: 0 }, focusY: { value: 0.5 }, focusW: { value: 0.16 }, blurAmt: { value: 5 },
    vig: { value: 0.55 }, grain: { value: 0.04 }, hurt: { value: 0 }, dash: { value: 0 },
    gShadow: { value: new THREE.Vector3(1, 1, 1) }, gHigh: { value: new THREE.Vector3(1, 1, 1) }, gSat: { value: 1 }, gCon: { value: 1 },
    sunUV: { value: new THREE.Vector2(0.5, 0.5) }, shaft: { value: 0 }, shaftCol: { value: new THREE.Color(1, 0.9, 0.7) },
  },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
  fragmentShader: `
    uniform sampler2D tDiffuse; uniform vec2 res; uniform float time, focusY, focusW, blurAmt, vig, grain, hurt, dash;
    uniform vec3 gShadow, gHigh; uniform float gSat, gCon; uniform vec2 sunUV; uniform float shaft; uniform vec3 shaftCol;
    varying vec2 vUv;
    float rnd(vec2 co){ return fract(sin(dot(co, vec2(12.9898,78.233))) * 43758.5453); }
    void main(){
      vec2 uv = vUv;
      float d = abs(uv.y - focusY);
      float m = smoothstep(focusW, focusW + 0.38, d);
      float gun = smoothstep(0.42, 0.62, uv.x) * (1.0 - smoothstep(0.28, 0.5, uv.y));
      m *= (1.0 - gun);
      float r = blurAmt * m;
      vec3 col;
      if (r > 0.35) {
        col = vec3(0.0);
        for (int i = 0; i < 12; i++) {
          float a = float(i) * 2.39996;
          float rr = sqrt((float(i) + 0.5) / 12.0) * r;
          col += texture2D(tDiffuse, uv + vec2(cos(a), sin(a)) * rr / res).rgb;
        }
        col /= 12.0;
      } else col = texture2D(tDiffuse, uv).rgb;
      if (dash > 0.01) {
        vec2 dir = (uv - 0.5) * dash * 0.02;
        col.r = texture2D(tDiffuse, uv + dir).r; col.b = texture2D(tDiffuse, uv - dir).b;
      }
      // sun shafts: march towards the light and gather anything brighter than the sky
      if (shaft > 0.001) {
        vec2 stride = (sunUV - uv) * (0.9 / 12.0);
        vec2 p = uv; float w = 1.0; vec3 acc = vec3(0.0);
        for (int i = 0; i < 12; i++) { p += stride; acc += max(texture2D(tDiffuse, p).rgb - vec3(0.85), vec3(0.0)) * w; w *= 0.9; }
        float fall = clamp(1.25 - length(uv - sunUV), 0.0, 1.0);
        col += acc * shaftCol * shaft * 0.11 * fall;
      }
      // split-tone grade: cool shadows, warm highlights (per arena)
      float lum = dot(col, vec3(0.299, 0.587, 0.114));
      col *= mix(gShadow, gHigh, smoothstep(0.02, 0.9, lum));
      col = mix(vec3(lum), col, gSat);
      col = max(vec3(0.0), (col - 0.18) * gCon + 0.18);
      vec2 q = uv - 0.5;
      float v = smoothstep(0.95, 0.25, length(q * vec2(1.15, 1.0)));
      col *= mix(1.0, v, vig);
      col += hurt * vec3(0.9, 0.05, 0.1) * smoothstep(0.25, 0.75, length(q));
      col += (rnd(uv * res + time) - 0.5) * grain;
      gl_FragColor = vec4(col, 1.0);
    }`,
};

export class Post {
  private composer: EffectComposer;
  private bloom: UnrealBloomPass;
  private lens: ShaderPass;
  enabled = true;
  private worldPass: RenderPass;
  private weaponPass: RenderPass;

  constructor(private renderer: THREE.WebGLRenderer, private scene: THREE.Scene, private camera: THREE.Camera, private wScene: THREE.Scene, private wCam: THREE.Camera) {
    const size = renderer.getSize(new THREE.Vector2());
    const target = new THREE.WebGLRenderTarget(size.x, size.y, { type: THREE.HalfFloatType, samples: 4 });
    this.composer = new EffectComposer(renderer, target);
    this.worldPass = new RenderPass(scene, camera);
    this.weaponPass = new RenderPass(wScene, wCam); this.weaponPass.clear = false; this.weaponPass.clearDepth = true;
    this.bloom = new UnrealBloomPass(size, 0.55, 0.65, 0.95);
    this.lens = new ShaderPass(LensShader);
    this.composer.addPass(this.worldPass); this.composer.addPass(this.weaponPass); this.composer.addPass(this.bloom); this.composer.addPass(this.lens); this.composer.addPass(new OutputPass());
  }

  get u() { return this.lens.uniforms; }
  setBloom(strength: number, threshold: number) { this.bloom.strength = strength; this.bloom.threshold = threshold; }
  /** Split-tone colour grade: tint for shadows / highlights, saturation and contrast. */
  setGrade(g: { shadow: readonly number[]; high: readonly number[]; sat: number; con: number }) {
    const u = this.lens.uniforms;
    u.gShadow.value.set(g.shadow[0], g.shadow[1], g.shadow[2]); u.gHigh.value.set(g.high[0], g.high[1], g.high[2]);
    u.gSat.value = g.sat; u.gCon.value = g.con;
  }
  /** Sun-shaft strength and the light's screen position (0..1). Strength 0 switches the effect off. */
  setShafts(k: number, sx: number, sy: number, color: number) {
    const u = this.lens.uniforms;
    u.shaft.value = k; u.sunUV.value.set(sx, sy); u.shaftCol.value.setHex(color);
  }
  setSize(w: number, h: number, pr: number) {
    this.composer.setPixelRatio(pr); this.composer.setSize(w, h);
    this.lens.uniforms.res.value.set(w * pr, h * pr);
  }
  /** Quality switches: bloom and lens can be skipped entirely (low preset renders directly). */
  setEffects(bloom: boolean, lens: boolean) { this.bloom.enabled = bloom; this.lens.enabled = lens; }
  setScenes(scene: THREE.Scene) { this.worldPass.scene = scene; }

  render(dt: number, time: number) {
    this.lens.uniforms.time.value = time % 100;
    if (this.enabled) this.composer.render(dt);
    else {
      const r = this.renderer;
      r.autoClear = true; r.render(this.scene, this.camera);
      r.autoClear = false; r.clearDepth(); r.render(this.wScene, this.wCam);
      r.autoClear = true;
    }
  }
  dispose() { this.composer.dispose(); }
}
