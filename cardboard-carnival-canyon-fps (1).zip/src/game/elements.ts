/**
 * Damage types and enemy affinities. Every weapon deals one element; every creature is weak to one
 * element (x1.6, "WEAK!") and shrugs off another (x0.55, "resist"). Switching guns to exploit that is a core loop.
 */
export type Elem = 'impact' | 'blast' | 'pierce' | 'fire' | 'ice' | 'shock';

export const ELEM_INFO: Record<Elem, { name: string; icon: string; tag: string; hex: number; css: string }> = {
  impact: { name: 'Impact', icon: '👊', tag: 'H', hex: 0xf3e7cc, css: '#f3e7cc' },
  blast: { name: 'Blast', icon: '💥', tag: 'B', hex: 0xff5ab4, css: '#ff5ab4' },
  pierce: { name: 'Pierce', icon: '🎯', tag: 'P', hex: 0xc0c4cc, css: '#c0c4cc' },
  fire: { name: 'Fire', icon: '🔥', tag: 'F', hex: 0xff7a1a, css: '#ff7a1a' },
  ice: { name: 'Ice', icon: '❄️', tag: 'I', hex: 0x66e0ff, css: '#66e0ff' },
  shock: { name: 'Shock', icon: '⚡', tag: 'Z', hex: 0xffe14a, css: '#ffe14a' },
};

export const WEAPON_ELEM: Record<string, Elem> = {
  gatling: 'fire', slinger: 'blast', bazooka: 'blast', crossbow: 'pierce', grappler: 'impact', shotgun: 'impact', yoyo: 'pierce', horn: 'shock',
  pinwheel: 'fire', spring: 'impact', planes: 'pierce', marker: 'pierce', balloon: 'ice', stamp: 'impact', fireworks: 'fire', zapper: 'shock',
  pencil: 'pierce', bubble: 'blast',
};

export const WEAK_MULT = 1.6;
export const RESIST_MULT = 0.55;
/** Reload mini-game: tapping reload while the bar is inside this window finishes instantly and grants a damage buff. */
export const RELOAD_ZONE: [number, number] = [0.58, 0.76];

interface Affinity { weak?: Elem; resist?: Elem }
export const AFFINITY: Record<string, Affinity> = {
  leaf: { weak: 'fire' }, sun: { weak: 'ice', resist: 'fire' }, blob: { weak: 'pierce', resist: 'impact' },
  leafArmor: { weak: 'shock', resist: 'pierce' }, blobSpike: { weak: 'blast', resist: 'pierce' }, sunFire: { weak: 'ice', resist: 'fire' },
  leafIce: { weak: 'fire', resist: 'ice' }, leafSniper: { weak: 'impact' },
  miniLeaf: { weak: 'fire', resist: 'pierce' }, miniSun: { weak: 'ice', resist: 'fire' }, miniBlob: { weak: 'pierce', resist: 'impact' },
  kingSun: { weak: 'ice', resist: 'fire' }, domeBoss: { weak: 'blast', resist: 'pierce' }, ufo: { weak: 'shock', resist: 'impact' },
  moth: { weak: 'fire' }, bomb: { weak: 'ice', resist: 'fire' }, jack: { weak: 'blast' }, mimic: { weak: 'fire', resist: 'pierce' },
  tank: { weak: 'shock', resist: 'impact' }, ghost: { weak: 'fire', resist: 'impact' }, knight: { weak: 'blast', resist: 'pierce' },
  drummer: { weak: 'shock' }, miniKnight: { weak: 'blast', resist: 'pierce' },
  globe: { weak: 'fire', resist: 'ice' }, glue: { weak: 'fire' }, scissors: { weak: 'shock', resist: 'pierce' }, snake: { weak: 'blast' },
  crane: { weak: 'fire' }, magnet: { weak: 'shock', resist: 'pierce' }, miniGlobe: { weak: 'fire', resist: 'ice' }, miniSnake: { weak: 'blast' },
};

export function elemMult(enemyId: string, elem: string): number {
  const a = AFFINITY[enemyId];
  if (!a) return 1;
  return a.weak === elem ? WEAK_MULT : a.resist === elem ? RESIST_MULT : 1;
}

/** One-line field notes shown in the Bestiary. */
export const TIPS: Record<string, string> = {
  leaf: 'Flanks in groups and fires three-shot bursts. Burn it, and dash through the volleys.',
  sun: 'Slow petal turret that fires a seed fan. Frost wilts it; fire is wasted on it.',
  blob: 'Rolls, squashes, then leaps. Pop it with piercing shots; blunt hits just bounce off.',
  leafArmor: 'Plated bot that halves most damage. Electricity ignores the plating.',
  blobSpike: 'Fast spiked roller. Explosions pop it; thin shots barely scratch it.',
  sunFire: 'Spits fire that sets you alight. Ice it down.',
  leafIce: 'Frost bolts slow you. Fire melts it quickly.',
  leafSniper: 'Long wind-up, leads its target. Strafe, then punish the reload.',
  miniLeaf: 'Captain with six-round bursts. Keep moving, keep burning.',
  miniSun: 'Rings of seeds in every direction. Stay inside the gaps and freeze it.',
  miniBlob: 'Giant bouncer that splits into blobs. Pierce it, then clean up.',
  kingSun: 'Three phases: spirals, rings, shockwave slams. Ice hurts most; jump the slam.',
  domeBoss: 'Sweeping neon laser: jump it. Explosives crack the dome.',
  ufo: 'Tractor beam drops crates and creatures. Shock short-circuits it.',
  moth: 'Orbits, rears up, then dive-bombs where you stood. Paper wings burn easily.',
  bomb: 'Sprints at you and lights its fuse. Freeze it before it arrives; its blast hurts other foes too.',
  jack: 'Nearly immune while shut. Wait for it to pop, then hit it with something explosive.',
  mimic: 'Looks like a crate until you get close. Burn the wood; thin shots resist.',
  tank: 'Marks the ground and lobs mortar shells. Shock overloads it; blunt hits do little.',
  ghost: 'Fires a triple wail, then blinks away, intangible while fading. Fire; impact passes through.',
  knight: 'Frontal shield blocks all shots. Explosions go around it; hit it while it recovers from a charge.',
  drummer: 'Hastes and heals nearby allies. Zap it first.',
  miniKnight: 'Armoured champion with a shield and a charge. Explosives and patience.',
  globe: 'Shakes up a ring of ice shards, leaves a frost puddle. Fire; ice just refreezes it.',
  glue: 'Lobs sticky glue that slows you, then follows up with seeds. Burn it.',
  scissors: 'Spins up then homing-dashes; afterwards it is dizzy and takes extra damage. Shock it.',
  snake: 'The whole body hurts, only the head is the target. Blasts shred it.',
  crane: 'Circles and fires dart volleys, every third one is a wide crescent. Origami burns.',
  magnet: 'Drags you in unless you break line of sight, then slams. Shock it; break LOS.',
  miniGlobe: 'Blizzard nova with aimed shards. Bring fire.',
  miniSnake: 'Huge wyrm that lunges and spits seeds. Explosions.',
};
