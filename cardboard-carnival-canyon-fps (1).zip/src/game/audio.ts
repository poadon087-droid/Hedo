/**
 * Procedural WebAudio: every sound effect is synthesised, plus a small carnival-western
 * step-sequencer score whose intensity follows the combat.
 */
export type SfxName =
  | 'gatling' | 'slinger' | 'bazooka' | 'crossbow' | 'grappler' | 'shotgun' | 'yoyo' | 'horn' | 'pinwheel' | 'spring'
  | 'click' | 'reelTick' | 'pop' | 'crunch' | 'confetti' | 'coin' | 'hurt' | 'dash' | 'parry' | 'jackpot' | 'ui' | 'boom'
  | 'reload' | 'reloadDone' | 'enemyShoot' | 'telegraph' | 'bossRoar' | 'super' | 'heal' | 'waveStart' | 'empty' | 'bounce'
  | 'planes' | 'marker' | 'balloon' | 'stamp' | 'fireworks' | 'zapper' | 'pencil' | 'bubble';

export class Sfx {
  private ctx: AudioContext | null = null;
  private master!: GainNode; private sfxBus!: GainNode; private musicBus!: GainNode;
  private noiseBuf: AudioBuffer | null = null;
  private voices = 0;
  private last = new Map<string, number>();
  vol = { master: 0.8, music: 0.6, sfx: 0.9, muted: false };
  private intensity = 0; private targetIntensity = 0;
  private step = 0; private nextTime = 0; private timer = 0; private musicOn = false;
  private mood: 'day' | 'night' = 'day';

  /** Must be called from a user gesture the first time. */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AC) return;
      this.ctx = new AC();
      const comp = this.ctx.createDynamicsCompressor();
      comp.threshold.value = -14; comp.ratio.value = 6;
      this.master = this.ctx.createGain(); this.sfxBus = this.ctx.createGain(); this.musicBus = this.ctx.createGain();
      this.sfxBus.connect(this.master); this.musicBus.connect(this.master); this.master.connect(comp); comp.connect(this.ctx.destination);
      const len = this.ctx.sampleRate;
      this.noiseBuf = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this.applyVolumes();
    }
    if (this.ctx.state === 'suspended') void this.ctx.resume();
  }
  suspend() { if (this.ctx && this.ctx.state === 'running') void this.ctx.suspend(); }
  resume() { if (this.ctx && this.ctx.state === 'suspended') void this.ctx.resume(); }

  setVolumes(v: Partial<typeof this.vol>) { Object.assign(this.vol, v); this.applyVolumes(); }
  private applyVolumes() {
    if (!this.ctx) return;
    const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.vol.muted ? 0 : this.vol.master, t, 0.03);
    this.sfxBus.gain.setTargetAtTime(this.vol.sfx, t, 0.03);
    this.musicBus.gain.setTargetAtTime(this.vol.music * 0.5, t, 0.03);
  }

  private tone(f: number, type: OscillatorType, dur: number, vol: number, slide = 0, delay = 0) {
    const c = this.ctx!;
    const t = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(20, f + slide), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.sfxBus); o.start(t); o.stop(t + dur + 0.02);
    this.voices++; o.onended = () => { this.voices--; };
  }
  private noise(dur: number, vol: number, type: BiquadFilterType, f0: number, f1: number, delay = 0) {
    const c = this.ctx!;
    const t = c.currentTime + delay;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const fl = c.createBiquadFilter(); fl.type = type; fl.frequency.setValueAtTime(f0, t); fl.frequency.exponentialRampToValueAtTime(Math.max(30, f1), t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(fl); fl.connect(g); g.connect(this.sfxBus); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.02);
    this.voices++; s.onended = () => { this.voices--; };
  }

  play(name: SfxName, pitch = 1) {
    const c = this.ctx;
    if (!c || c.state !== 'running' || this.vol.muted) return;
    const now = c.currentTime;
    // per-sound throttle + global polyphony cap prevents audio pile-ups
    const gap = name === 'gatling' ? 0.035 : name === 'coin' || name === 'reelTick' || name === 'crunch' ? 0.04 : 0.015;
    if (now - (this.last.get(name) ?? -1) < gap || this.voices > 36) return;
    this.last.set(name, now);
    const p = pitch * (0.94 + Math.random() * 0.12);
    switch (name) {
      case 'gatling': this.tone(520 * p, 'square', 0.07, 0.12, -300); this.noise(0.05, 0.14, 'bandpass', 2400, 900); break;
      case 'slinger': this.tone(340 * p, 'triangle', 0.14, 0.25, -200); this.noise(0.09, 0.2, 'highpass', 1800, 6000); break;
      case 'bazooka': this.tone(110 * p, 'sawtooth', 0.35, 0.3, -70); this.noise(0.3, 0.3, 'lowpass', 1800, 200); break;
      case 'crossbow': this.tone(200 * p, 'triangle', 0.2, 0.3, 500); this.tone(900 * p, 'sine', 0.15, 0.12, -600, 0.02); break;
      case 'grappler': this.noise(0.28, 0.3, 'bandpass', 600, 3800); this.tone(260 * p, 'square', 0.1, 0.12, 200); break;
      case 'shotgun': this.noise(0.22, 0.45, 'lowpass', 4500, 300); this.tone(90 * p, 'sine', 0.2, 0.4, -40); break;
      case 'yoyo': this.tone(300 * p, 'sawtooth', 0.4, 0.18, 400); this.noise(0.4, 0.1, 'bandpass', 1500, 3500); break;
      case 'horn': this.tone(233 * p, 'sawtooth', 0.4, 0.25); this.tone(349 * p, 'sawtooth', 0.4, 0.2); this.noise(0.25, 0.25, 'lowpass', 1500, 200); break;
      case 'pinwheel': this.tone(600 * p, 'sine', 0.25, 0.2, 700); this.noise(0.2, 0.1, 'highpass', 3000, 7000); break;
      case 'spring': this.tone(70 * p, 'sine', 0.6, 0.55, -30); this.tone(140 * p, 'sawtooth', 0.5, 0.2, 800); this.noise(0.4, 0.4, 'lowpass', 3000, 100); this.tone(900, 'triangle', 0.5, 0.1, -500, 0.05); break;
      case 'click': this.tone(1300 * p, 'square', 0.025, 0.12); this.noise(0.02, 0.1, 'highpass', 4000, 6000); break;
      case 'reelTick': this.tone(1800 * p, 'triangle', 0.02, 0.06); break;
      case 'pop': this.tone(500 * p, 'sine', 0.09, 0.3, -380); this.noise(0.05, 0.2, 'bandpass', 1800, 700); break;
      case 'crunch': this.noise(0.14, 0.4, 'bandpass', 1200, 400); this.noise(0.08, 0.3, 'highpass', 3000, 1500, 0.04); break;
      case 'confetti': this.noise(0.4, 0.28, 'highpass', 2500, 8000); this.tone(700 * p, 'triangle', 0.15, 0.1, 500); break;
      case 'coin': this.tone(988 * p, 'square', 0.07, 0.1); this.tone(1319 * p, 'square', 0.18, 0.1, 0, 0.06); break;
      case 'hurt': this.tone(160 * p, 'sawtooth', 0.28, 0.4, -90); this.noise(0.2, 0.3, 'lowpass', 1500, 200); break;
      case 'dash': this.noise(0.25, 0.3, 'bandpass', 800, 3000); break;
      case 'parry': this.tone(1568 * p, 'triangle', 0.3, 0.25); this.tone(2093 * p, 'sine', 0.35, 0.18, 0, 0.04); this.noise(0.1, 0.25, 'highpass', 4000, 8000); break;
      case 'jackpot': [523, 659, 784, 1047, 1319].forEach((f, i) => this.tone(f, 'square', 0.18, 0.14, 0, i * 0.07)); break;
      case 'ui': this.tone(660 * p, 'triangle', 0.08, 0.14); break;
      case 'boom': this.tone(70 * p, 'sine', 0.5, 0.6, -40); this.noise(0.5, 0.5, 'lowpass', 2500, 100); break;
      case 'reload': this.tone(420 * p, 'triangle', 0.06, 0.12); this.noise(0.05, 0.12, 'highpass', 3000, 5000); break;
      case 'reloadDone': this.tone(880 * p, 'square', 0.04, 0.12); this.tone(1320 * p, 'square', 0.07, 0.12, 0, 0.05); break;
      case 'enemyShoot': this.tone(280 * p, 'triangle', 0.12, 0.16, -120); this.noise(0.06, 0.1, 'bandpass', 2000, 800); break;
      case 'telegraph': this.tone(740 * p, 'square', 0.07, 0.09); this.tone(740 * p, 'square', 0.07, 0.09, 0, 0.1); break;
      case 'bossRoar': this.tone(80 * p, 'sawtooth', 0.9, 0.4, -30); this.tone(120 * p, 'square', 0.7, 0.18, 30); this.noise(0.8, 0.25, 'lowpass', 900, 120); break;
      case 'super': this.tone(120, 'sawtooth', 0.8, 0.4, 900); this.noise(0.8, 0.4, 'highpass', 500, 9000); [523, 784, 1047].forEach((f, i) => this.tone(f, 'square', 0.3, 0.14, 0, 0.35 + i * 0.09)); break;
      case 'heal': this.tone(660, 'sine', 0.2, 0.18, 400); this.tone(990, 'sine', 0.3, 0.14, 0, 0.1); break;
      case 'waveStart': [392, 523, 659].forEach((f, i) => this.tone(f, 'triangle', 0.2, 0.2, 0, i * 0.1)); break;
      case 'empty': this.tone(220, 'square', 0.05, 0.1); break;
      case 'bounce': this.tone(300 * p, 'sine', 0.1, 0.15, 200); break;
      case 'planes': this.noise(0.25, 0.18, 'bandpass', 2500, 6000); this.tone(900 * p, 'triangle', 0.18, 0.12, -500); break;
      case 'marker': this.noise(0.05, 0.1, 'highpass', 4000, 7000); this.tone(1700 * p, 'sine', 0.04, 0.05, -700); break;
      case 'balloon': this.tone(200 * p, 'sine', 0.12, 0.25, 300); this.noise(0.12, 0.18, 'lowpass', 900, 300); break;
      case 'stamp': this.tone(90 * p, 'square', 0.1, 0.4, -50); this.noise(0.12, 0.4, 'lowpass', 800, 100); this.tone(180 * p, 'triangle', 0.2, 0.2, -100, 0.02); break;
      case 'fireworks': this.noise(0.45, 0.22, 'bandpass', 1500, 5500); this.tone(500 * p, 'sawtooth', 0.4, 0.1, 1200); break;
      case 'zapper': this.tone(1200 * p, 'sawtooth', 0.12, 0.14, -900); this.noise(0.12, 0.22, 'highpass', 3000, 9000); this.tone(60, 'square', 0.1, 0.15); break;
      case 'pencil': this.tone(1400 * p, 'triangle', 0.06, 0.22, -1200); this.noise(0.1, 0.3, 'highpass', 2000, 8000); this.tone(150 * p, 'sine', 0.25, 0.3, -80); break;
      case 'bubble': this.tone(400 * p, 'sine', 0.1, 0.18, 500); this.tone(700 * p, 'sine', 0.08, 0.1, 400, 0.05); break;
    }
  }

  // ------------------------------------------------------------ music
  startMusic(mood: 'day' | 'night') { this.mood = mood; this.musicOn = true; this.step = 0; if (this.ctx) { this.nextTime = this.ctx.currentTime + 0.1; } if (!this.timer) this.timer = window.setInterval(() => this.schedule(), 60); }
  stopMusic() { this.musicOn = false; }
  setIntensity(v: number) { this.targetIntensity = Math.max(0, Math.min(1, v)); }

  private note(f: number, t: number, dur: number, type: OscillatorType, vol: number) {
    const c = this.ctx!;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.musicBus); o.start(t); o.stop(t + dur + 0.02);
  }
  private drum(t: number, kind: 'kick' | 'snare' | 'hat') {
    const c = this.ctx!;
    if (kind === 'kick') {
      const o = c.createOscillator(), g = c.createGain();
      o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(40, t + 0.14);
      g.gain.setValueAtTime(0.9, t); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.18);
      o.connect(g); g.connect(this.musicBus); o.start(t); o.stop(t + 0.2);
    } else {
      const s = c.createBufferSource(); s.buffer = this.noiseBuf;
      const f = c.createBiquadFilter(); f.type = kind === 'snare' ? 'bandpass' : 'highpass'; f.frequency.value = kind === 'snare' ? 1800 : 7000;
      const g = c.createGain(); g.gain.setValueAtTime(kind === 'snare' ? 0.45 : 0.18, t); g.gain.exponentialRampToValueAtTime(0.0001, t + (kind === 'snare' ? 0.14 : 0.04));
      s.connect(f); f.connect(g); g.connect(this.musicBus); s.start(t, Math.random() * 0.5); s.stop(t + 0.2);
    }
  }
  private schedule() {
    const c = this.ctx;
    if (!c || !this.musicOn || c.state !== 'running') return;
    const bpm = this.mood === 'day' ? 132 : 120, sp = 60 / bpm / 2; // eighth notes
    this.intensity += (this.targetIntensity - this.intensity) * 0.08;
    if (this.nextTime < c.currentTime - 0.5) this.nextTime = c.currentTime + 0.05;
    while (this.nextTime < c.currentTime + 0.25) {
      const t = this.nextTime, s = this.step % 32, bar = Math.floor(s / 8), b = s % 8;
      // progression: i - VII - VI - V (western minor) or I - V - vi - IV (day)
      const roots = this.mood === 'day' ? [196, 146.8, 164.8, 130.8] : [110, 98, 87.3, 82.4];
      const root = roots[bar];
      const minor = this.mood === 'night';
      if (b % 2 === 0) { this.note(root, t, sp * 1.6, 'triangle', 0.5); this.drum(t, 'kick'); } else this.note(root * 1.5, t, sp * 0.9, 'triangle', 0.35);
      if (b % 2 === 1) { this.note(root * 4, t, sp * 0.8, 'square', 0.07); this.note(root * (minor ? 4.757 : 5.04), t, sp * 0.8, 'square', 0.06); }
      if (this.intensity > 0.25 && b % 4 === 2) this.drum(t, 'snare');
      if (this.intensity > 0.45) this.drum(t, 'hat');
      const scale = minor ? [0, 3, 5, 7, 10, 12, 15] : [0, 2, 4, 7, 9, 12, 14];
      const m = (s * 7 + bar * 3) % 7;
      if (this.intensity > 0.15 && (b === 0 || b === 3 || b === 5 || (this.intensity > 0.6 && b % 2 === 1))) this.note(root * 4 * Math.pow(2, scale[(m + b) % 7] / 12), t, sp * 1.4, this.mood === 'day' ? 'square' : 'sawtooth', 0.045 + this.intensity * 0.04);
      this.nextTime += sp; this.step++;
    }
  }
}
