/**
 * Three extra arenas built on the same cardboard-cover layout as the originals, each with its own look, boundary and hazard:
 *  Frostbite Fold (aurora dusk, slippery ice), Toybox Takeover (giant blocks and trampolines), Ember Foundry (lava moat and erupting vents).
 * They register themselves with `extraMaps`; `mapHooks` also drops jump pads into the two original arenas.
 */
import * as THREE from 'three';
import { Rng, TAU, makeCollider, resolveCircle, type Collider, type Crate } from './core';
import { M, T, boxGeo, gradientMap } from './textures';
import { makeCrate, mk } from './models';
import { extraMaps, mapHooks, type Geyser, type MapData, type MapId } from './maps';

type Anim = (dt: number, t: number) => void;
type Spot = [number, number];
const ARENA_R = 30.5;
const LAYER_H = 1.2;
const STACKS = [
  { x: -13, z: -6, w: 6, d: 4.5, layers: 2 }, { x: -13, z: -1.4, w: 3, d: 3, layers: 1 },
  { x: 12, z: -9, w: 5, d: 6, layers: 2 }, { x: 7, z: -9, w: 3, d: 3, layers: 1 },
  { x: -3, z: -17, w: 9, d: 3.5, layers: 1 }, { x: 20, z: 7, w: 4, d: 4, layers: 1 },
  { x: -21, z: 9, w: 4, d: 6, layers: 1 }, { x: 3, z: -4, w: 3, d: 3, layers: 1 },
  { x: -7, z: 10, w: 5, d: 3, layers: 1 }, { x: 14, z: 16, w: 3.5, d: 3.5, layers: 2 }, { x: 10.5, z: 16, w: 3, d: 3, layers: 1 },
];
const PILLARS: Spot[] = [[-7, -10], [8, 2], [-18, -14], [22, -2]];
const inkMat = new THREE.MeshBasicMaterial({ color: 0x141016 });
const hexStr = (c: number) => '#' + c.toString(16).padStart(6, '0');

interface Theme {
  id: MapId; name: string; mood: 'day' | 'night';
  skyTop: number; skyHor: number; sunDir: THREE.Vector3; sunCol: number; sunGlow: number;
  hemiSky: number; hemiGnd: number; hemiI: number; sunLight: number; sunI: number;
  fogColor: number; fogNear: number; fogFar: number;
  floorMat: THREE.Material; floorDisc: boolean;
  stack: string[]; tape: string; strip: number | null; cap: string;
  pads: Spot[]; padColor: number; avoid: Spot[];
  look: MapData['look'];
}

// ------------------------------------------------------------------ shared helpers
function skyDome(top: number, hor: number, sunDir: THREE.Vector3, sunCol: number, glow: number) {
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: { top: { value: new THREE.Color(top) }, hor: { value: new THREE.Color(hor) }, sunDir: { value: sunDir.clone().normalize() }, sunCol: { value: new THREE.Color(sunCol) }, glow: { value: glow } },
    vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
    fragmentShader: 'uniform vec3 top; uniform vec3 hor; uniform vec3 sunDir; uniform vec3 sunCol; uniform float glow; varying vec3 vP; void main(){ float h = clamp(vP.y,0.0,1.0); vec3 c = mix(hor, top, pow(h,0.55)); float s = max(dot(normalize(vP), sunDir),0.0); c += sunCol * (pow(s,6.0)*0.45*glow + pow(s,160.0)*glow); gl_FragColor = vec4(c,1.0); }',
  });
  const m = new THREE.Mesh(new THREE.SphereGeometry(400, 24, 16), mat); m.renderOrder = -10;
  return m;
}

function glowSprite(color: number, size: number, opacity = 1): THREE.Sprite {
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, opacity, fog: false, toneMapped: false }));
  s.scale.setScalar(size); return s;
}

const rod = (a: THREE.Vector3, b: THREE.Vector3, r: number, mat: THREE.Material) => {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, a.distanceTo(b), 5), mat);
  m.position.copy(a).lerp(b, 0.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.clone().sub(a).normalize());
  return m;
};

/** Particles that wrap around the player: falling snow or rising embers. */
class Drift {
  private pts: THREE.Points;
  private pos: Float32Array;
  private ph: Float32Array;
  constructor(root: THREE.Group, private n: number, color: number, size: number, additive: boolean, private fall: number, private sway: number) {
    this.pos = new Float32Array(n * 3); this.ph = new Float32Array(n);
    const r = new Rng(99);
    for (let i = 0; i < n; i++) { this.pos[i * 3] = r.range(-24, 24); this.pos[i * 3 + 1] = r.range(0, 18); this.pos[i * 3 + 2] = r.range(-24, 24); this.ph[i] = r.range(0, TAU); }
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    this.pts = new THREE.Points(geo, new THREE.PointsMaterial({ color, size, sizeAttenuation: false, transparent: true, opacity: 0.9, depthWrite: false, fog: false, toneMapped: !additive, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending }));
    this.pts.frustumCulled = false; root.add(this.pts);
  }
  update(dt: number, t: number, cam: THREE.Vector3) {
    const p = this.pos;
    for (let i = 0; i < this.n; i++) {
      const k = i * 3;
      p[k + 1] -= this.fall * dt;
      p[k] += Math.sin(t * 0.6 + this.ph[i]) * this.sway * dt;
      p[k + 2] += Math.cos(t * 0.5 + this.ph[i]) * this.sway * dt;
      if (p[k + 1] < 0) p[k + 1] += 18; else if (p[k + 1] > 18) p[k + 1] -= 18;
      let rel = p[k] - cam.x; if (rel > 24) p[k] -= 48; else if (rel < -24) p[k] += 48;
      rel = p[k + 2] - cam.z; if (rel > 24) p[k + 2] -= 48; else if (rel < -24) p[k + 2] += 48;
    }
    (this.pts.geometry.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  }
}

/** Glowing trampoline: stepping on it launches the player (logic lives in gameplay.ts). */
function padMesh(root: THREE.Group, anims: Anim[], x: number, z: number, r: number, color: number) {
  const g = new THREE.Group(); g.position.set(x, 0, z);
  const base = mk(new THREE.CylinderGeometry(r, r * 1.08, 0.2, 24), [M.edge(), M.paper('#2a2d33'), M.paper('#2a2d33')], { outline: 0.03 }); base.position.y = 0.1; g.add(base);
  const top = new THREE.Mesh(new THREE.CylinderGeometry(r * 0.78, r * 0.78, 0.08, 24), M.glow(color, 1.8)); top.position.y = 0.24; g.add(top);
  const ring = new THREE.Mesh(new THREE.TorusGeometry(r * 0.9, 0.05, 6, 32), M.glow(0xffffff, 2.2)); ring.rotation.x = Math.PI / 2; ring.position.y = 0.23; g.add(ring);
  const arrow = new THREE.Mesh(new THREE.PlaneGeometry(r * 1.3, r * 1.3), new THREE.MeshBasicMaterial({ map: T.chevron(hexStr(color)), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, color: new THREE.Color(1.6, 1.6, 1.6) }));
  arrow.rotation.x = -Math.PI / 2; arrow.rotation.z = Math.PI / 2; arrow.position.y = 0.3; g.add(arrow);
  root.add(g);
  anims.push((_, t) => {
    top.scale.setScalar(1 + Math.sin(t * 6 + x) * 0.04);
    arrow.position.y = 0.3 + (Math.sin(t * 4 + x) * 0.5 + 0.5) * 0.18; (arrow.material as THREE.MeshBasicMaterial).opacity = 0.45 + 0.4 * Math.sin(t * 4 + x);
  });
}

function makeTnt(size: number): THREE.Group {
  const g = new THREE.Group();
  const body = mk(boxGeo(size, size, size, size), M.paper('#c92b2b'), { outline: 0.035 }); body.position.y = size / 2; g.add(body);
  const tapeM = M.tex(T.tape('#f3e7cc'), 'tapeCream');
  for (const rot of [0, Math.PI / 2]) { const t = mk(new THREE.BoxGeometry(size * 1.02, size * 0.012, size * 0.16), tapeM, { cast: false }); t.position.y = size * 1.003; t.rotation.y = rot; g.add(t); }
  const signMat = M.tex(T.sign('TNT'), 'signTNT');
  for (let k = 0; k < 4; k++) {
    const s = new THREE.Mesh(new THREE.PlaneGeometry(size * 0.82, size * 0.41), signMat), a = (k / 4) * TAU;
    s.position.set(Math.sin(a) * (size / 2 + 0.012), size * 0.55, Math.cos(a) * (size / 2 + 0.012)); s.rotation.y = a; g.add(s);
  }
  const fuse = new THREE.Mesh(new THREE.SphereGeometry(size * 0.07, 6, 4), M.glow(0xffaa33, 2.6)); fuse.position.set(0, size * 1.06, 0); g.add(fuse);
  return g;
}

function ringFence(root: THREE.Group, radius: number, postMat: THREE.Material, railMat: THREE.Material, count = 60) {
  const im = new THREE.InstancedMesh(new THREE.BoxGeometry(0.22, 1.2, 0.22), postMat, count), d = new THREE.Object3D();
  for (let i = 0; i < count; i++) { const a = (i / count) * TAU; d.position.set(Math.cos(a) * radius, 0.6, Math.sin(a) * radius); d.rotation.y = -a; d.updateMatrix(); im.setMatrixAt(i, d.matrix); }
  im.castShadow = true; im.receiveShadow = true; root.add(im);
  for (const h of [0.45, 0.95]) { const t = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.05, 5, 120), railMat); t.rotation.x = Math.PI / 2; t.position.y = h; root.add(t); }
}

function forest(pts: { x: number; z: number; s: number }[], mats: THREE.Material[], y = 0): THREE.Group {
  const geos = [new THREE.CylinderGeometry(0.18, 0.24, 1.2, 5).translate(0, 0.6, 0), new THREE.ConeGeometry(1.5, 2.4, 6).translate(0, 2.2, 0), new THREE.ConeGeometry(1.15, 2.1, 6).translate(0, 3.4, 0), new THREE.ConeGeometry(0.8, 1.8, 6).translate(0, 4.5, 0)];
  const grp = new THREE.Group(), m4 = new THREE.Matrix4();
  geos.forEach((geo, k) => {
    const im = new THREE.InstancedMesh(geo, mats[k], pts.length);
    pts.forEach((p, i) => { m4.makeScale(p.s, p.s, p.s).setPosition(p.x, y, p.z); im.setMatrixAt(i, m4); });
    im.castShadow = true; im.receiveShadow = true; grp.add(im);
  });
  return grp;
}

function cliffRing(root: THREE.Group, rng: Rng, n: number, r: number, colors: string[], cap: string | null) {
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU, rr = r + rng.range(-0.6, 0.6), g = new THREE.Group(), layers = rng.int(3, 5);
    let y = 0, topW = 0, topD = 0, tx = 0, tz = 0;
    for (let l = 0; l < layers; l++) {
      const h = rng.range(2.5, 4), w = 10.5 - l * 0.8 + rng.range(-0.6, 0.6), d = 8 - l * 0.9;
      const b = mk(boxGeo(w, h, d, 3), M.paper(colors[(i + l * 2) % colors.length]), { cast: false });
      tx = rng.range(-0.3, 0.3); tz = rng.range(-0.3, 0.3); b.position.set(tx, y + h / 2, tz); y += h; topW = w; topD = d; g.add(b);
    }
    if (cap) { const c = mk(boxGeo(topW + 0.5, 0.6, topD + 0.5, 3), M.paper(cap), { cast: false }); c.position.set(tx, y + 0.3, tz); g.add(c); }
    g.position.set(Math.cos(a) * rr, 0, Math.sin(a) * rr); g.rotation.y = -a + Math.PI / 2; root.add(g);
  }
}

/** Remove random crates that ended up inside scenery added after the base layout. */
function cull(cols: Collider[], crates: Crate[], from: number) {
  const scenery = cols.slice(from);
  for (let i = crates.length - 1; i >= 0; i--) {
    const c = crates[i].collider;
    for (const o of scenery) {
      if (c.minX < o.maxX + 0.7 && c.maxX > o.minX - 0.7 && c.minZ < o.maxZ + 0.7 && c.maxZ > o.minZ - 0.7) {
        c.alive = false; crates[i].mesh.visible = false;
        const k = cols.indexOf(c); if (k >= 0) cols.splice(k, 1);
        crates.splice(i, 1); break;
      }
    }
  }
}

function floorSpawns(cols: Collider[], rng: Rng): THREE.Vector3[] {
  const out: THREE.Vector3[] = [];
  for (let i = 0; i < 48 && out.length < 22; i++) {
    const a = (i / 48) * TAU + rng.range(-0.1, 0.1), r = rng.range(15, 28), p = { x: Math.cos(a) * r, y: 0, z: Math.sin(a) * r }, q = { ...p };
    resolveCircle(q, 1.0, 1.5, cols, 0.1);
    if (Math.hypot(q.x - p.x, q.z - p.z) < 0.01) out.push(new THREE.Vector3(p.x, 0, p.z));
  }
  return out;
}
function coinSpots(cols: Collider[], rng: Rng): THREE.Vector3[] {
  const out: THREE.Vector3[] = [];
  for (let i = 0; i < 60 && out.length < 14; i++) {
    const a = rng.range(0, TAU), r = rng.range(4, 26), p = { x: Math.cos(a) * r, y: 0, z: Math.sin(a) * r }, q = { ...p };
    resolveCircle(q, 0.8, 1.5, cols, 0.1);
    if (Math.hypot(q.x - p.x, q.z - p.z) < 0.01) out.push(new THREE.Vector3(p.x, 1.1, p.z));
  }
  return out;
}

// ------------------------------------------------------------------ base layout
function base(th: Theme, seed: number) {
  const rng = new Rng(seed);
  const root = new THREE.Group(), cols: Collider[] = [], crates: Crate[] = [], anims: Anim[] = [];
  const hemi = new THREE.HemisphereLight(th.hemiSky, th.hemiGnd, th.hemiI);
  const sun = new THREE.DirectionalLight(th.sunLight, th.sunI);
  sun.castShadow = true;
  sun.shadow.camera.left = -32; sun.shadow.camera.right = 32; sun.shadow.camera.top = 32; sun.shadow.camera.bottom = -32;
  sun.shadow.camera.near = 1; sun.shadow.camera.far = 160; sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.05; sun.shadow.mapSize.set(2048, 2048);
  root.add(hemi, sun, sun.target, skyDome(th.skyTop, th.skyHor, th.sunDir, th.sunCol, th.sunGlow));
  const floor = new THREE.Mesh(th.floorDisc ? new THREE.CircleGeometry(31.2, 72) : new THREE.PlaneGeometry(210, 210), th.floorMat);
  floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; root.add(floor);

  STACKS.forEach((s, si) => {
    const g = new THREE.Group();
    for (let l = 0; l < s.layers; l++) {
      const inset = l * 0.18;
      const b = mk(boxGeo(s.w - inset, LAYER_H, s.d - inset, 2.4), M.paper(th.stack[(si + l) % th.stack.length]), { outline: 0.03 });
      b.position.y = LAYER_H * (l + 0.5); g.add(b);
      const tape = mk(new THREE.BoxGeometry(s.w - inset + 0.05, 0.03, 0.4), M.tex(T.tape(th.tape), 'tape' + th.tape), { cast: false });
      tape.position.set(0, LAYER_H * (l + 1) + 0.005, 0); g.add(tape);
    }
    if (th.strip !== null) { const strip = new THREE.Mesh(new THREE.BoxGeometry(s.w + 0.05, 0.08, 0.08), M.glow(th.strip, 2.4)); strip.position.set(0, s.layers * LAYER_H + 0.02, s.d / 2 + 0.02); g.add(strip); }
    g.position.set(s.x, 0, s.z); root.add(g);
    cols.push(makeCollider(s.x, s.z, s.w, s.d, 0, s.layers * LAYER_H, 'wall'));
  });
  PILLARS.forEach(([x, z]) => {
    const p = mk(new THREE.CylinderGeometry(0.8, 0.8, 4, 14), [M.edge(), M.paper(th.stack[0]), M.paper(th.stack[0])], { outline: 0.03 });
    p.position.set(x, 2, z);
    const cap = mk(new THREE.CylinderGeometry(0.95, 0.95, 0.2, 14), M.paper(th.cap), { outline: 0.03 }); cap.position.y = 2.1; p.add(cap);
    root.add(p); cols.push(makeCollider(x, z, 1.6, 1.6, 0, 4, 'pillar'));
  });

  let tries = 0, n = 0;
  const keepClear = th.pads.concat(th.avoid);
  while (crates.length < 16 && tries++ < 500) {
    const a = rng.range(0, TAU), r = rng.range(5, 25), size = rng.range(1.0, 1.5), x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (Math.abs(x) < 3 && z > 12) continue;
    if (keepClear.some(([px, pz]) => Math.hypot(px - x, pz - z) < 3.4)) continue;
    const probe = { x, y: 0, z };
    resolveCircle(probe, size * 0.75 + 0.4, 1, cols, 0);
    if (Math.abs(probe.x - x) > 1e-3 || Math.abs(probe.z - z) > 1e-3) continue;
    const boom = n++ % 5 === 2, mesh = boom ? makeTnt(size) : makeCrate(size);
    mesh.position.set(x, 0, z); mesh.rotation.y = rng.range(-0.3, 0.3); root.add(mesh);
    const collider = makeCollider(x, z, size, size, 0, size, 'crate');
    const crate: Crate = { collider, mesh, hp: 20 + size * 10, maxHp: 20 + size * 10, shake: 0, loot: !boom && rng.chance(0.45), explosive: boom };
    collider.crate = crate; cols.push(collider); crates.push(crate);
  }
  return { rng, root, cols, crates, anims, hemi, sun };
}
type Base = ReturnType<typeof base>;

function pack(th: Theme, b: Base, extra: { ice?: MapData['ice']; geysers?: Geyser[] }, tick: (dt: number, t: number, p: THREE.Vector3) => void): MapData {
  const spawns = floorSpawns(b.cols, b.rng), coins = coinSpots(b.cols, b.rng);
  th.pads.forEach(([x, z]) => padMesh(b.root, b.anims, x, z, 1.5, th.padColor));
  const dir = th.sunDir;
  const m: MapData = {
    id: th.id, name: th.name, mood: th.mood, look: th.look, pads: th.pads.map(([x, z]) => ({ x, z, r: 1.5 })), ice: extra.ice ?? [], geysers: extra.geysers ?? [], simTime: 0,
    root: b.root, colliders: b.cols, crates: b.crates, spawns, coinSpots: coins, radius: ARENA_R, start: new THREE.Vector3(0, 0, 20), sun: b.sun, hemi: b.hemi,
    fog: new THREE.Fog(th.fogColor, th.fogNear, th.fogFar), bg: th.fogColor, domeProp: null, env: null,
    update(dt, t, player) {
      b.anims.forEach((f) => f(dt, t)); tick(dt, t, player);
      b.sun.position.set(player.x + dir.x * 70, dir.y * 70, player.z + dir.z * 70); b.sun.target.position.set(player.x, 0, player.z);
    },
    dispose() {
      m.root.traverse((o) => { const mesh = o as THREE.Mesh; if (mesh.isMesh || (o as THREE.Points).isPoints) mesh.geometry?.dispose(); });
      m.root.removeFromParent();
    },
  };
  return m;
}

// ====================================================================== FROSTBITE FOLD
function penguin(): THREE.Group {
  const g = new THREE.Group();
  const body = mk(new THREE.SphereGeometry(0.42, 12, 10), M.paper('#2a2d33'), { outline: 0.02 }); body.scale.set(1, 1.35, 0.9); body.position.y = 0.6; g.add(body);
  const belly = new THREE.Mesh(new THREE.SphereGeometry(0.36, 10, 8), M.paper('#f3e7cc')); belly.scale.set(0.9, 1.25, 0.6); belly.position.set(0, 0.58, 0.2); g.add(belly);
  const beak = mk(new THREE.ConeGeometry(0.07, 0.2, 5), M.paper('#ff9a1e'), { cast: false }); beak.rotation.x = Math.PI / 2; beak.position.set(0, 0.95, 0.4); g.add(beak);
  for (const s of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 4), new THREE.MeshBasicMaterial({ color: 0xffffff })); eye.position.set(s * 0.14, 1.02, 0.34); g.add(eye);
    const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.025, 6, 4), inkMat); pupil.position.set(s * 0.14, 1.02, 0.38); g.add(pupil);
    const foot = mk(new THREE.BoxGeometry(0.22, 0.05, 0.3), M.paper('#ff9a1e'), { cast: false }); foot.position.set(s * 0.16, 0.03, 0.1); g.add(foot);
    const wing = mk(new THREE.BoxGeometry(0.07, 0.4, 0.2), M.paper('#2a2d33'), { cast: false }); wing.position.set(s * 0.43, 0.65, 0); wing.rotation.z = s * 0.4; g.add(wing);
  }
  return g;
}

function buildSnow(seed: number): MapData {
  const ft = T.floorSnow(); ft.repeat.set(26, 26);
  const dir = new THREE.Vector3(0.5, 0.32, 0.55).normalize();
  const th: Theme = {
    id: 'snow', name: 'Frostbite Fold', mood: 'day',
    skyTop: 0x1a2a6a, skyHor: 0xf2c8e8, sunDir: dir, sunCol: 0xffc8a0, sunGlow: 0.9,
    hemiSky: 0xbcd0ff, hemiGnd: 0xdde6f6, hemiI: 1.9, sunLight: 0xffe2c8, sunI: 2.3,
    fogColor: 0xb9c3e6, fogNear: 45, fogFar: 175,
    floorMat: new THREE.MeshToonMaterial({ map: ft, bumpMap: T.corrBump(), bumpScale: 0.4, gradientMap: gradientMap() }), floorDisc: false,
    stack: ['#aebfd6', '#bccde2', '#9fb2cc'], tape: '#e0384a', strip: null, cap: '#e0384a',
    pads: [[10, 10], [-10, -14]], padColor: 0x33d6ff, avoid: [],
    look: { bloom: 0.45, thr: 0.95, dust: 0xffffff, wh: 0xdbe6ff, wg: 0x8090b0, wk: 0xffe2c8, wr: 0x7ab0ff },
  };
  const b = base(th, seed), { root, cols, crates, anims, rng } = b, from = cols.length;

  // slippery ice patches
  const ice = [{ x: -6, z: -2, r: 3.6 }, { x: 8, z: 5, r: 3.4 }, { x: -15, z: 8, r: 3.2 }, { x: 14, z: -3, r: 3 }, { x: 0, z: 12, r: 3 }];
  const iceMat = new THREE.MeshToonMaterial({ color: 0xbfeaff, transparent: true, opacity: 0.88, gradientMap: gradientMap() });
  const iceRim = new THREE.MeshBasicMaterial({ color: 0xffffff });
  ice.forEach((z) => {
    const d = new THREE.Mesh(new THREE.CircleGeometry(z.r, 36), iceMat); d.rotation.x = -Math.PI / 2; d.position.set(z.x, 0.025, z.z); d.receiveShadow = true; root.add(d);
    const rim = new THREE.Mesh(new THREE.RingGeometry(z.r - 0.12, z.r, 40), iceRim); rim.rotation.x = -Math.PI / 2; rim.position.set(z.x, 0.03, z.z); root.add(rim);
    const sp = glowSprite(0xffffff, 1.3, 0.7); sp.position.set(z.x + z.r * 0.3, 0.4, z.z - z.r * 0.2); root.add(sp);
    anims.push((_, t) => { sp.material.opacity = 0.35 + 0.35 * Math.sin(t * 3 + z.x); });
  });

  // igloo
  {
    const x = -23, z = -12, g = new THREE.Group();
    g.add(mk(new THREE.SphereGeometry(2.6, 20, 12, 0, TAU, 0, Math.PI / 2), M.paper('#f2f8ff'), { outline: 0.03 }));
    for (const y of [0.9, 1.7]) { const ring = new THREE.Mesh(new THREE.TorusGeometry(Math.sqrt(2.6 * 2.6 - y * y), 0.03, 4, 36), M.paper('#9ab4d8')); ring.rotation.x = Math.PI / 2; ring.position.y = y; g.add(ring); }
    const tunnel = mk(boxGeo(1.7, 1.5, 1.6, 1.4), M.paper('#e6f0fa'), { outline: 0.03 }); tunnel.position.set(0, 0.75, 2.6); g.add(tunnel);
    const door = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 1.1), inkMat); door.position.set(0, 0.55, 3.42); g.add(door);
    const glow = glowSprite(0xffb060, 3, 0.6); glow.position.set(0, 0.8, 3.6); g.add(glow);
    g.position.set(x, 0, z); g.rotation.y = Math.atan2(-x, -z); root.add(g);
    cols.push(makeCollider(x, z, 6, 6, 0, 3.2, 'wall'));
  }
  // snowmen
  ([[-10, 18], [12, -18], [22, -8], [-25, 6], [3, -23]] as Spot[]).forEach(([x, z]) => {
    const g = new THREE.Group(), white = M.paper('#f4f9ff');
    for (const [r, y] of [[0.9, 0.85], [0.65, 2.0], [0.46, 2.9]]) { const s = mk(new THREE.SphereGeometry(r, 14, 10), white, { outline: 0.03 }); s.position.y = y; g.add(s); }
    const cg = new THREE.ConeGeometry(0.07, 0.5, 6); cg.rotateX(Math.PI / 2); const nose = mk(cg, M.paper('#ff9a1e'), { cast: false }); nose.position.set(0, 2.9, 0.55); g.add(nose);
    for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.05, 6, 4), inkMat); e.position.set(s * 0.15, 3.0, 0.42); g.add(e); }
    const scarf = mk(new THREE.TorusGeometry(0.42, 0.09, 6, 14), M.paper('#e0384a'), { cast: false }); scarf.rotation.x = Math.PI / 2; scarf.position.y = 2.5; g.add(scarf);
    const hat = mk(new THREE.CylinderGeometry(0.3, 0.3, 0.5, 12), M.paper('#2a2d33'), { outline: 0.02 }); hat.position.y = 3.5; g.add(hat);
    const brim = mk(new THREE.CylinderGeometry(0.46, 0.46, 0.05, 12), M.paper('#2a2d33'), { cast: false }); brim.position.y = 3.25; g.add(brim);
    for (const s of [-1, 1]) { const arm = mk(new THREE.CylinderGeometry(0.03, 0.03, 0.9, 5), M.paper('#6b4a2b'), { cast: false }); arm.position.set(s * 0.8, 2.2, 0); arm.rotation.z = s * 1.0; g.add(arm); }
    g.position.set(x, 0, z); g.rotation.y = Math.atan2(-x, -z); root.add(g);
    cols.push(makeCollider(x, z, 1.7, 1.7, 0, 3.4, 'pillar'));
  });
  // drifts, pines, mountains, fence, cliffs
  for (let i = 0; i < 12; i++) {
    const a = rng.range(0, TAU), r = rng.range(22, 29), m = new THREE.Mesh(new THREE.SphereGeometry(1.6, 12, 8), M.paper('#f4f9ff'));
    m.scale.set(rng.range(1.2, 2), 0.4, rng.range(1, 1.6)); m.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); m.receiveShadow = true; root.add(m);
  }
  const pines = Array.from({ length: 28 }, () => { const a = rng.range(0, TAU), r = rng.range(31.8, 35.5); return { x: Math.cos(a) * r, z: Math.sin(a) * r, s: rng.range(1.1, 2.0) }; });
  root.add(forest(pines, [M.paper('#6b4a2b'), M.paper('#2f6a58'), M.paper('#e8f2ff'), M.paper('#f4f9ff')]));
  cliffRing(root, rng, 24, 36, ['#8fa6c4', '#a3b8d2', '#7d94b4'], '#f4f9ff');
  for (let i = 0; i < 14; i++) {
    const a = (i / 14) * TAU + 0.2, r = rng.range(70, 100), h = rng.range(30, 52), w = rng.range(14, 22);
    const peak = mk(new THREE.ConeGeometry(w, h, 5), M.paper(['#7d94b4', '#6a82a6', '#8fa6c4'][i % 3]), { cast: false, receive: false }); peak.position.set(Math.cos(a) * r, h / 2, Math.sin(a) * r); root.add(peak);
    const capM = mk(new THREE.ConeGeometry(w * 0.45, h * 0.36, 5), M.paper('#f4f9ff'), { cast: false, receive: false }); capM.position.set(Math.cos(a) * r, h * 0.82, Math.sin(a) * r); root.add(capM);
  }
  ringFence(root, 30.3, M.tex(T.stripesRW(), 'rwPost'), M.paper('#e0384a'));
  // penguins patrol the rim
  for (let i = 0; i < 4; i++) {
    const p = penguin(); root.add(p);
    const a0 = (i / 4) * TAU + 0.5, dirn = i % 2 ? 1 : -1, sp = 0.05 + i * 0.012;
    anims.push((_, t) => { const a = a0 + t * sp * dirn; p.position.set(Math.cos(a) * 28.2, 0, Math.sin(a) * 28.2); p.rotation.y = dirn > 0 ? -a : -a + Math.PI; p.rotation.z = Math.sin(t * 8 + i) * 0.14; });
  }
  // aurora curtains
  const auroraCols = [0x44ffaa, 0x33d6ff, 0xaa66ff];
  for (let i = 0; i < 7; i++) {
    const mat = new THREE.MeshBasicMaterial({ map: T.ray(), color: auroraCols[i % 3], transparent: true, opacity: 0.4, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false, toneMapped: false });
    const m = new THREE.Mesh(new THREE.PlaneGeometry(30, 80), mat), ang = -1.3 + i * 0.43;
    m.position.set(Math.sin(ang) * 150, 62, -Math.cos(ang) * 150); m.lookAt(0, 50, 0); root.add(m);
    anims.push((_, t) => { m.position.y = 62 + Math.sin(t * 0.4 + i) * 4; mat.opacity = 0.3 + 0.15 * Math.sin(t * 0.6 + i * 1.7); });
  }
  // ski lift beyond the cliffs
  {
    const cable = rod(new THREE.Vector3(-54, 17, -60), new THREE.Vector3(54, 17, -60), 0.06, M.paper('#33353a')); root.add(cable);
    for (const x of [-54, 0, 54]) { const py = mk(new THREE.BoxGeometry(0.5, 18, 0.5), M.paper('#7a4e2a'), { cast: false }); py.position.set(x, 9, -60); root.add(py); }
    for (let i = 0; i < 3; i++) {
      const g = new THREE.Group();
      const cab = mk(boxGeo(1.6, 1.2, 1.2, 1.2), M.paper(['#e0384a', '#3f8cf0', '#ffd54a'][i]), { outline: 0.03, cast: false }); cab.position.y = -2.4; g.add(cab);
      const roof = mk(new THREE.ConeGeometry(1.2, 0.6, 4), M.paper('#f3e7cc'), { cast: false }); roof.position.y = -1.5; roof.rotation.y = Math.PI / 4; g.add(roof);
      g.add(rod(new THREE.Vector3(0, 0, 0), new THREE.Vector3(0, -1.6, 0), 0.04, M.paper('#33353a')));
      root.add(g);
      anims.push((_, t) => { const u = (t * 0.02 + i / 3) % 1; g.position.set(-54 + u * 108, 17, -60); });
    }
  }
  cull(cols, crates, from);
  const snow = new Drift(root, 260, 0xffffff, 3, false, 1.8, 0.8);
  return pack(th, b, { ice }, (dt, t, p) => snow.update(dt, t, p));
}

// ====================================================================== TOYBOX TAKEOVER
function buildToy(seed: number): MapData {
  const ft = T.floorToy(); ft.repeat.set(26, 26);
  const dir = new THREE.Vector3(0.35, 0.7, 0.4).normalize();
  const th: Theme = {
    id: 'toy', name: 'Toybox Takeover', mood: 'day',
    skyTop: 0x8fc8ff, skyHor: 0xffd9ec, sunDir: dir, sunCol: 0xfff0d0, sunGlow: 0.6,
    hemiSky: 0xfff0f8, hemiGnd: 0xcfa8c0, hemiI: 2.0, sunLight: 0xfff4e6, sunI: 2.8,
    fogColor: 0xffe3f0, fogNear: 55, fogFar: 190,
    floorMat: new THREE.MeshToonMaterial({ map: ft, bumpMap: T.corrBump(), bumpScale: 0.35, gradientMap: gradientMap() }), floorDisc: false,
    stack: ['#e0384a', '#3f8cf0', '#ffd54a', '#34c3b0'], tape: '#f3e7cc', strip: null, cap: '#ff8fb8',
    pads: [[-16, 16], [16, 12], [-14, -14], [12, -2]], padColor: 0xff5ab4, avoid: [],
    look: { bloom: 0.35, thr: 1.0, dust: 0xfff0f8, wh: 0xfff0f8, wg: 0xa08090, wk: 0xfff0d8, wr: 0xff8fb8 },
  };
  const b = base(th, seed), { root, cols, crates, anims, rng } = b, from = cols.length;
  const BC = ['#e0384a', '#3f8cf0', '#ffd54a', '#34c3b0', '#ff8fb8', '#ff9a2e'];
  const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';

  // wall of giant alphabet blocks
  const blockRing = (count: number, r: number, size: number, off: number) => {
    for (let i = 0; i < count; i++) {
      const a = (i / count) * TAU + off, g = new THREE.Group(), n = rng.int(2, 4);
      let y = 0;
      for (let l = 0; l < n; l++) {
        const cube = mk(boxGeo(size, size, size, 3), M.paper(BC[(i + l * 2) % BC.length]), { cast: false, outline: 0.03 });
        const jx = rng.range(-0.5, 0.5), jz = rng.range(-0.4, 0.4); cube.position.set(jx, y + size / 2, jz);
        const ch = letters[(i * 3 + l * 7) % 26];
        const face = new THREE.Mesh(new THREE.PlaneGeometry(size * 0.72, size * 0.72), M.tex(T.block(ch), 'block' + ch, { transparent: true }));
        face.position.set(jx, y + size / 2, jz - size / 2 - 0.03); face.rotation.y = Math.PI;
        g.add(cube, face); y += size;
      }
      g.position.set(Math.cos(a) * r, 0, Math.sin(a) * r); g.rotation.y = -a + Math.PI / 2; root.add(g);
    }
  };
  blockRing(26, 39, 7.2, 0); blockRing(22, 47, 8.5, 0.12);

  // toy-block fence
  const fenceN = 90, fim = new THREE.InstancedMesh(new THREE.BoxGeometry(0.75, 0.75, 0.75), M.paper('#ffffff'), fenceN * 2), fd = new THREE.Object3D(), fc = new THREE.Color();
  for (let k = 0; k < fenceN * 2; k++) {
    const i = k % fenceN, row = k < fenceN ? 0 : 1, a = ((i + row * 0.5) / fenceN) * TAU;
    fd.position.set(Math.cos(a) * 30.4, 0.38 + row * 0.75, Math.sin(a) * 30.4); fd.rotation.y = -a; fd.updateMatrix(); fim.setMatrixAt(k, fd.matrix); fim.setColorAt(k, fc.set(BC[(i + row) % BC.length]));
  }
  fim.castShadow = true; fim.receiveShadow = true; root.add(fim);

  // toy train circling outside the fence
  const trackR = 34;
  for (const rr of [trackR - 0.55, trackR + 0.55]) { const t = new THREE.Mesh(new THREE.TorusGeometry(rr, 0.07, 5, 180), M.paper('#9a9aa0')); t.rotation.x = Math.PI / 2; t.position.y = 0.16; root.add(t); }
  const sl = new THREE.InstancedMesh(new THREE.BoxGeometry(1.8, 0.08, 0.25), M.paper('#9c6a3a'), 150), sd = new THREE.Object3D();
  for (let i = 0; i < 150; i++) { const a = (i / 150) * TAU; sd.position.set(Math.cos(a) * trackR, 0.08, Math.sin(a) * trackR); sd.rotation.y = -a; sd.updateMatrix(); sl.setMatrixAt(i, sd.matrix); }
  root.add(sl);
  const train: THREE.Group[] = [], puffs: THREE.Sprite[] = [];
  const car = (color: string, loco: boolean) => {
    const g = new THREE.Group();
    const body = mk(boxGeo(1.7, 1.3, loco ? 2.4 : 2.0, 1.4), M.paper(color), { outline: 0.03 }); body.position.y = 1.0; g.add(body);
    const roof = mk(boxGeo(1.9, 0.18, loco ? 2.6 : 2.2, 1.4), M.paper('#f3e7cc'), { outline: 0.02 }); roof.position.y = 1.72; g.add(roof);
    for (const sx of [-1, 1]) for (const sz of [-0.7, 0.7]) { const w = mk(new THREE.CylinderGeometry(0.34, 0.34, 0.14, 12), M.paper('#2a2d33'), { outline: 0.02 }); w.rotation.z = Math.PI / 2; w.position.set(sx * 0.85, 0.36, sz); g.add(w); }
    if (loco) {
      const boiler = mk(new THREE.CylinderGeometry(0.55, 0.55, 1.4, 14), M.paper('#e0384a'), { outline: 0.03 }); boiler.rotation.x = Math.PI / 2; boiler.position.set(0, 2.1, 0.3); g.add(boiler);
      const chim = mk(new THREE.CylinderGeometry(0.2, 0.3, 0.7, 10), M.paper('#2a2d33'), { outline: 0.02 }); chim.position.set(0, 2.9, 0.7); g.add(chim);
      const lamp = new THREE.Mesh(new THREE.SphereGeometry(0.16, 8, 6), M.glow(0xffe9a0, 2.4)); lamp.position.set(0, 2.1, 1.05); g.add(lamp);
      for (let k = 0; k < 4; k++) { const pf = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color: 0xffffff, transparent: true, opacity: 0.5, depthWrite: false })); pf.position.set(0, 3.3, 0.7); g.add(pf); puffs.push(pf); }
    }
    root.add(g); train.push(g);
  };
  car('#c92b2b', true); ['#3f8cf0', '#ffd54a', '#34c3b0', '#ff8fb8'].forEach((c) => car(c, false));
  anims.push((_, t) => {
    train.forEach((g, i) => { const a = t * 0.085 - i * 0.082 + 1; g.position.set(Math.cos(a) * trackR, 0, Math.sin(a) * trackR); g.rotation.y = -a; });
    puffs.forEach((p, k) => { const u = (t * 0.7 + k / 4) % 1; p.position.y = 3.3 + u * 3; p.scale.setScalar(0.5 + u * 1.8); p.material.opacity = 0.55 * (1 - u); });
  });

  // rainbow arch
  {
    const RC = ['#e0384a', '#ff9a2e', '#ffd54a', '#34c3b0', '#3f8cf0', '#9a5ad8'], g = new THREE.Group();
    RC.forEach((c, i) => { const arc = mk(new THREE.TorusGeometry(7.4 - i * 0.62, 0.32, 8, 40, Math.PI), M.paper(c), { outline: 0.02, cast: false }); g.add(arc); });
    for (const s of [-1, 1]) for (let k = 0; k < 3; k++) { const cl = mk(new THREE.IcosahedronGeometry(1.1 + (k % 2) * 0.4, 1), M.paper('#ffffff'), { cast: false }); cl.position.set(s * (6.1 + k * 0.5), 0.5, (k - 1) * 0.6); cl.scale.y = 0.7; g.add(cl); }
    g.position.set(0, 0, -27); root.add(g);
    for (const s of [-1, 1]) cols.push(makeCollider(s * 6.4, -27, 3, 1.6, 0, 6, 'wall'));
  }
  // giant crayons
  ([[-20, 20, '#e0384a'], [24, 12, '#3f8cf0'], [-24, -5, '#ffd54a'], [4, -22, '#34c3b0']] as [number, number, string][]).forEach(([x, z, color]) => {
    const g = new THREE.Group();
    const bodyM = mk(new THREE.CylinderGeometry(0.7, 0.7, 4.2, 14), [M.paper(color), M.edge(), M.edge()], { outline: 0.03 }); bodyM.position.y = 2.1; g.add(bodyM);
    const band = mk(new THREE.CylinderGeometry(0.73, 0.73, 1.8, 14), M.paper('#f3e7cc'), { outline: 0.02 }); band.position.y = 2.4; g.add(band);
    const label = new THREE.Mesh(new THREE.PlaneGeometry(0.9, 0.6), M.tex(T.smiley(), 'smiley', { transparent: true })); label.position.set(0, 2.4, 0.75); g.add(label);
    const tip = mk(new THREE.ConeGeometry(0.7, 1.2, 14), M.paper(color), { outline: 0.03 }); tip.position.y = 4.8; g.add(tip);
    const nib = mk(new THREE.ConeGeometry(0.16, 0.35, 8), M.paper('#2a2d33'), { cast: false }); nib.position.y = 5.55; g.add(nib);
    g.position.set(x, 0, z); g.rotation.y = Math.atan2(-x, -z); root.add(g);
    cols.push(makeCollider(x, z, 1.5, 1.5, 0, 5.6, 'pillar'));
  });
  // teddy bears
  ([[22, -16, '#c4935a'], [-8, -24, '#ff8fb8'], [24, 16, '#9c703a']] as [number, number, string][]).forEach(([x, z, color]) => {
    const g = new THREE.Group(), fur = M.paper(color);
    const body = mk(new THREE.SphereGeometry(1.2, 14, 10), fur, { outline: 0.03 }); body.scale.set(1, 1.05, 0.9); body.position.y = 1.2; g.add(body);
    const belly = new THREE.Mesh(new THREE.SphereGeometry(0.8, 12, 8), M.paper('#f3e7cc')); belly.scale.set(1, 1.05, 0.5); belly.position.set(0, 1.1, 0.8); g.add(belly);
    const head = mk(new THREE.SphereGeometry(0.85, 14, 10), fur, { outline: 0.03 }); head.position.y = 2.9; g.add(head);
    for (const s of [-1, 1]) {
      const ear = mk(new THREE.SphereGeometry(0.3, 10, 8), fur, { outline: 0.02 }); ear.position.set(s * 0.62, 3.6, 0); g.add(ear);
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), inkMat); eye.position.set(s * 0.3, 3.05, 0.76); g.add(eye);
      const arm = mk(new THREE.SphereGeometry(0.42, 10, 8), fur, { outline: 0.02 }); arm.position.set(s * 1.25, 1.5, 0.3); g.add(arm);
      const leg = mk(new THREE.SphereGeometry(0.5, 10, 8), fur, { outline: 0.02 }); leg.position.set(s * 0.7, 0.4, 0.8); g.add(leg);
    }
    const snout = mk(new THREE.SphereGeometry(0.34, 10, 8), M.paper('#f3e7cc'), { cast: false }); snout.position.set(0, 2.78, 0.75); g.add(snout);
    const nose = new THREE.Mesh(new THREE.SphereGeometry(0.1, 8, 6), inkMat); nose.position.set(0, 2.9, 1.06); g.add(nose);
    const bow = mk(new THREE.BoxGeometry(0.7, 0.3, 0.12), M.paper('#e0384a'), { cast: false }); bow.position.set(0, 2.1, 0.7); g.add(bow);
    g.position.set(x, 0, z); g.rotation.y = Math.atan2(-x, -z); root.add(g);
    cols.push(makeCollider(x, z, 2.8, 2.4, 0, 2.6, 'wall'));
  });
  // alphabet block cover
  ([[-3, 6, 'A', '#e0384a'], [16, 5, 'B', '#3f8cf0'], [-20, -7, 'C', '#ffd54a'], [1, -12, 'D', '#34c3b0']] as [number, number, string, string][]).forEach(([x, z, ch, color]) => {
    const g = new THREE.Group(), s = 1.7;
    const cube = mk(boxGeo(s, s, s, 1.7), M.paper(color), { outline: 0.03 }); cube.position.y = s / 2; g.add(cube);
    for (let k = 0; k < 4; k++) { const f = new THREE.Mesh(new THREE.PlaneGeometry(s * 0.7, s * 0.7), M.tex(T.block(ch), 'block' + ch, { transparent: true })), a = (k / 4) * TAU; f.position.set(Math.sin(a) * (s / 2 + 0.02), s / 2, Math.cos(a) * (s / 2 + 0.02)); f.rotation.y = a; g.add(f); }
    g.position.set(x, 0, z); g.rotation.y = rng.range(-0.5, 0.5); root.add(g);
    cols.push(makeCollider(x, z, s * 1.2, s * 1.2, 0, s, 'wall'));
  });
  // floating balloons and cotton clouds
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * TAU, r = rng.range(31.5, 36), y0 = rng.range(7, 14), g = new THREE.Group();
    const ball = mk(new THREE.SphereGeometry(1.1, 14, 10), M.paper(BC[i % BC.length]), { outline: 0.03, cast: false }); ball.scale.y = 1.2; g.add(ball);
    g.add(rod(new THREE.Vector3(0, -1.3, 0), new THREE.Vector3(0, -5, 0), 0.02, M.paper('#f3e7cc')));
    g.position.set(Math.cos(a) * r, y0, Math.sin(a) * r); root.add(g);
    anims.push((_, t) => { g.position.y = y0 + Math.sin(t * 0.8 + i) * 0.7; g.rotation.z = Math.sin(t * 0.5 + i) * 0.08; });
  }
  for (let i = 0; i < 8; i++) {
    const g = new THREE.Group();
    for (let k = 0; k < 4; k++) { const c = mk(new THREE.IcosahedronGeometry(rng.range(3, 4.6), 1), M.paper('#ffffff'), { cast: false, receive: false }); c.position.set(k * 3.6 - 5.4, rng.range(-0.4, 0.8), rng.range(-1, 1)); c.scale.y = 0.6; g.add(c); }
    g.position.set(rng.range(-150, 150), rng.range(60, 95), rng.range(-190, -50)); root.add(g);
    anims.push((dt) => { g.position.x += dt * 1.0; if (g.position.x > 180) g.position.x = -180; });
  }
  cull(cols, crates, from);
  return pack(th, b, {}, () => undefined);
}

// ====================================================================== EMBER FOUNDRY
function gear(root: THREE.Group, anims: Anim[], x: number, y: number, z: number, r: number, speed: number) {
  const g = new THREE.Group(); g.position.set(x, y, z);
  const disc = mk(new THREE.CylinderGeometry(r, r, 1.2, 28), M.paper('#6a4a3a'), { outline: 0.03, cast: false }); disc.rotation.x = Math.PI / 2; g.add(disc);
  const teeth = 14;
  for (let i = 0; i < teeth; i++) { const a = (i / teeth) * TAU, t = mk(new THREE.BoxGeometry(r * 0.28, r * 0.32, 1.1), M.paper('#7a5a48'), { cast: false }); t.position.set(Math.cos(a) * (r + r * 0.1), Math.sin(a) * (r + r * 0.1), 0); t.rotation.z = a; g.add(t); }
  const hub = mk(new THREE.CylinderGeometry(r * 0.3, r * 0.3, 1.6, 14), M.paper('#c0c4cc'), { outline: 0.02, cast: false }); hub.rotation.x = Math.PI / 2; g.add(hub);
  const glowRing = new THREE.Mesh(new THREE.TorusGeometry(r * 0.62, 0.12, 6, 32), M.glow(0xff6a1a, 2.2)); glowRing.position.z = 0.62; g.add(glowRing);
  root.add(g); anims.push((_, t) => { g.rotation.z = t * speed; });
}

function buildEmber(seed: number): MapData {
  const tf = T.floorEmber(false), gf = T.floorEmber(true); tf.repeat.set(7, 7); gf.repeat.set(7, 7);
  const dir = new THREE.Vector3(-0.25, 0.3, -0.8).normalize();
  const geoSpots: Spot[] = [[-10, 3], [10, -3], [0, -11], [6, 8]];
  const anvilSpots: Spot[] = [[-22, -4], [19, -17], [-3, 7]];
  const th: Theme = {
    id: 'ember', name: 'Ember Foundry', mood: 'night',
    skyTop: 0x1a0a22, skyHor: 0xff6a2a, sunDir: dir, sunCol: 0xff7a30, sunGlow: 1.2,
    hemiSky: 0xff9a70, hemiGnd: 0x3a1010, hemiI: 1.7, sunLight: 0xff9a60, sunI: 2.2,
    fogColor: 0x4a1a14, fogNear: 38, fogFar: 170,
    floorMat: new THREE.MeshToonMaterial({ map: tf, emissiveMap: gf, emissive: 0xffffff, emissiveIntensity: 1.5, bumpMap: T.corrBump(), bumpScale: 0.4, gradientMap: gradientMap() }), floorDisc: true,
    stack: ['#4a3a40', '#5a4448', '#3e3036'], tape: '#ff6a1a', strip: 0xff6a1a, cap: '#ff6a1a',
    pads: [], padColor: 0xff6a1a, avoid: geoSpots.concat(anvilSpots),
    look: { bloom: 0.75, thr: 0.8, dust: 0xff9a40, wh: 0xff9a70, wg: 0x401810, wk: 0xffb080, wr: 0xff5a1a },
  };
  const b = base(th, seed), { root, cols, crates, anims, rng } = b, from = cols.length;

  // lava moat
  const lavaTex = T.lava(); lavaTex.repeat.set(14, 14);
  const lava = new THREE.Mesh(new THREE.RingGeometry(31.4, 150, 72, 1), new THREE.MeshBasicMaterial({ map: lavaTex, color: new THREE.Color(1.5, 1.2, 1.0), toneMapped: false }));
  lava.rotation.x = -Math.PI / 2; lava.position.y = -0.7; root.add(lava);
  anims.push((_, t) => { lavaTex.offset.set(t * 0.01, t * 0.006); });
  const rimWall = mk(new THREE.CylinderGeometry(31.6, 31.2, 0.9, 64, 1, true), M.edge('#6a3a2a'), { cast: false });
  (rimWall.material as THREE.Material).side = THREE.DoubleSide; rimWall.position.y = -0.35; root.add(rimWall);
  const edgeGlow = new THREE.Mesh(new THREE.TorusGeometry(31.3, 0.12, 6, 128), M.glow(0xff6a1a, 2.4)); edgeGlow.rotation.x = Math.PI / 2; edgeGlow.position.y = 0.03; root.add(edgeGlow);
  ringFence(root, 30.4, M.paper('#2a2d33'), M.glow(0xff7a1a, 2.4), 56);

  // jagged rock spires, volcano, chimneys, hall, gears
  for (let i = 0; i < 20; i++) {
    const a = rng.range(0, TAU), r = rng.range(42, 62), h = rng.range(8, 22), w = rng.range(3, 6);
    const spire = mk(new THREE.ConeGeometry(w, h, 5), M.paper(['#3a2a30', '#4a343a', '#2e2228'][i % 3]), { cast: false, receive: false }); spire.position.set(Math.cos(a) * r, h / 2, Math.sin(a) * r); root.add(spire);
    const gl = glowSprite(0xff5a1a, 16, 0.5); gl.position.set(Math.cos(a) * r, 2, Math.sin(a) * r); root.add(gl);
  }
  const volcano = mk(new THREE.CylinderGeometry(10, 75, 80, 16, 1, true), M.paper('#3a2228'), { cast: false, receive: false }); (volcano.material as THREE.Material).side = THREE.DoubleSide; volcano.position.set(0, 40, -135); root.add(volcano);
  const crater = new THREE.Mesh(new THREE.CircleGeometry(10, 24), M.glow(0xff6a1a, 2)); crater.rotation.x = -Math.PI / 2; crater.position.set(0, 79, -135); root.add(crater);
  const craterGlow = glowSprite(0xff5a1a, 90, 0.8); craterGlow.position.set(0, 90, -135); root.add(craterGlow);
  const smoke: { m: THREE.Mesh; x: number; y0: number; z: number; k: number }[] = [];
  const puff = (x: number, y0: number, z: number, k: number, size: number) => {
    const m = new THREE.Mesh(new THREE.SphereGeometry(size, 8, 6), new THREE.MeshBasicMaterial({ color: 0x3a3030, transparent: true, opacity: 0.6, depthWrite: false })); root.add(m); smoke.push({ m, x, y0, z, k });
  };
  ([[-30, -42], [30, -42], [-46, -20], [46, -20]] as Spot[]).forEach(([x, z], i) => {
    const ch = mk(new THREE.CylinderGeometry(2, 2.4, 20, 12), M.paper('#6a3a2a'), { cast: false, outline: 0.03 }); ch.position.set(x, 10, z); root.add(ch);
    const top = new THREE.Mesh(new THREE.TorusGeometry(2.0, 0.25, 6, 20), M.glow(0xff6a1a, 2.4)); top.rotation.x = Math.PI / 2; top.position.set(x, 20, z); root.add(top);
    for (let k = 0; k < 4; k++) puff(x, 21, z, (k / 4 + i * 0.13) % 1, 1.6);
  });
  for (let k = 0; k < 6; k++) puff(0, 82, -135, k / 6, 9);
  anims.push((_, t) => smoke.forEach((s) => { const u = (t * 0.12 + s.k) % 1; s.m.position.set(s.x + u * 4, s.y0 + u * 22, s.z); s.m.scale.setScalar(1 + u * 2.4); (s.m.material as THREE.MeshBasicMaterial).opacity = 0.6 * (1 - u); }));
  {
    const hall = new THREE.Group(); hall.position.set(0, 0, -62);
    const hb = mk(boxGeo(36, 16, 14, 4), M.paper('#4a343a'), { cast: false, outline: 0.03 }); hb.position.y = 8; hall.add(hb);
    const frame = mk(boxGeo(10.6, 10.2, 0.6, 3), M.paper('#2a2024'), { cast: false }); frame.position.set(0, 5.1, 7.1); hall.add(frame);
    const door = new THREE.Mesh(new THREE.PlaneGeometry(9, 9.4), M.glow(0xff6a1a, 1.8)); door.position.set(0, 4.7, 7.45); hall.add(door);
    for (let k = 0; k < 4; k++) { const t = mk(new THREE.ConeGeometry(4.6, 3, 4), M.paper('#3a2a30'), { cast: false }); t.position.set(-13.5 + k * 9, 17.5, 0); t.rotation.y = Math.PI / 4; hall.add(t); }
    const wins = new THREE.InstancedMesh(new THREE.PlaneGeometry(1.4, 1.8), M.glow(0xffa040, 1.8), 12), wd = new THREE.Object3D();
    for (let i = 0; i < 12; i++) { wd.position.set(-15 + (i % 6) * 6 + (i >= 6 ? 0 : 0), i < 6 ? 12.5 : 8.8, 7.1); wd.updateMatrix(); wins.setMatrixAt(i, wd.matrix); }
    hall.add(wins); root.add(hall);
    anims.push((_, t) => { (door.material as THREE.MeshBasicMaterial).color.setRGB(2.4 + Math.sin(t * 9) * 0.3, 0.9 + Math.sin(t * 7) * 0.15, 0.25); });
  }
  gear(root, anims, -20, 13, -53, 5.5, 0.35); gear(root, anims, -8, 17, -53, 4, -0.5); gear(root, anims, 22, 12, -53, 6, -0.3);
  for (const x of [-20, 20]) { const l = new THREE.PointLight(0xff6a1a, 140, 45, 2); l.position.set(x, 6, -12); root.add(l); }

  // anvils as cover
  anvilSpots.forEach(([x, z]) => {
    const g = new THREE.Group(), iron = M.paper('#4a4e58');
    const foot = mk(boxGeo(1.6, 0.4, 0.9, 1), iron, { outline: 0.03 }); foot.position.y = 0.2; g.add(foot);
    const waist = mk(boxGeo(0.8, 0.5, 0.6, 1), iron, { outline: 0.03 }); waist.position.y = 0.65; g.add(waist);
    const topB = mk(boxGeo(2.2, 0.5, 0.95, 1), M.paper('#5a5e68'), { outline: 0.03 }); topB.position.y = 1.15; g.add(topB);
    const horn = mk(new THREE.ConeGeometry(0.46, 0.9, 8), M.paper('#5a5e68'), { outline: 0.03 }); horn.rotation.z = -Math.PI / 2; horn.position.set(1.5, 1.15, 0); g.add(horn);
    const hot = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.04, 0.5), M.glow(0xff7a1a, 2)); hot.position.set(-0.2, 1.41, 0); g.add(hot);
    g.position.set(x, 0, z); g.rotation.y = Math.atan2(-x, -z) + Math.PI / 2; root.add(g);
    cols.push(makeCollider(x, z, 2.8, 2.4, 0, 1.5, 'wall'));
  });

  // lava vents (the hazard logic is in gameplay.ts; visuals follow `state`)
  const geysers: Geyser[] = geoSpots.map(([x, z], i) => ({ x, z, r: 2.2, period: 6 + i * 0.7, offset: i * 1.7, state: 0, hit: false }));
  const vis = geysers.map((gz) => {
    const g = new THREE.Group(); g.position.set(gz.x, 0, gz.z);
    const ring = mk(new THREE.CylinderGeometry(2.4, 2.6, 0.25, 20), M.paper('#2a2024'), { outline: 0.03 }); ring.position.y = 0.12; g.add(ring);
    const disc = new THREE.Mesh(new THREE.CircleGeometry(1.8, 24), new THREE.MeshBasicMaterial({ color: new THREE.Color(1, 0.3, 0.08), toneMapped: false })); disc.rotation.x = -Math.PI / 2; disc.position.y = 0.27; g.add(disc);
    const warn = new THREE.Mesh(new THREE.RingGeometry(gz.r * 0.9, gz.r * 1.15, 32), new THREE.MeshBasicMaterial({ color: new THREE.Color(2.4, 0.9, 0.2), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, side: THREE.DoubleSide })); warn.rotation.x = -Math.PI / 2; warn.position.y = 0.3; g.add(warn);
    const cg = new THREE.CylinderGeometry(1.5, 2.0, 1, 16, 1, true); cg.translate(0, 0.5, 0);
    const col = new THREE.Mesh(cg, new THREE.MeshBasicMaterial({ color: new THREE.Color(2.2, 1.0, 0.3), transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false })); col.visible = false; g.add(col);
    root.add(g);
    return { disc, warn, col };
  });
  cull(cols, crates, from);
  const embers = new Drift(root, 200, 0xff9a40, 2.6, true, -2.2, 1.2);
  return pack(th, b, { geysers }, (dt, t, p) => {
    embers.update(dt, t, p);
    geysers.forEach((gz, i) => {
      const v = vis[i], s = gz.state;
      (v.disc.material as THREE.MeshBasicMaterial).color.setRGB(s === 0 ? 0.9 : 2.2 + Math.sin(t * 30) * 0.4, s === 0 ? 0.25 : 0.7, 0.08);
      v.warn.visible = s >= 1; v.warn.scale.setScalar(1 + 0.12 * Math.sin(t * 20));
      v.col.visible = s >= 1; v.col.scale.set(1, s === 2 ? 9 * (0.8 + 0.2 * Math.sin(t * 40)) : 0.5 + 0.4 * Math.sin(t * 18), 1);
    });
  });
}

// ------------------------------------------------------------------ registration
extraMaps.snow = buildSnow;
extraMaps.toy = buildToy;
extraMaps.ember = buildEmber;

/** The two original arenas get trampolines too (cull any crates standing on them). */
mapHooks.push((m) => {
  if (m.id !== 'canyon' && m.id !== 'night') return;
  const spots: Spot[] = [[9, 6], [-15, 16]];
  for (let i = m.crates.length - 1; i >= 0; i--) {
    const c = m.crates[i];
    if (spots.some(([x, z]) => Math.hypot(c.mesh.position.x - x, c.mesh.position.z - z) < 3.2)) {
      c.collider.alive = false; c.mesh.visible = false;
      const k = m.colliders.indexOf(c.collider); if (k >= 0) m.colliders.splice(k, 1);
      m.crates.splice(i, 1);
    }
  }
  const anims: Anim[] = [];
  spots.forEach(([x, z]) => { padMesh(m.root, anims, x, z, 1.5, m.id === 'night' ? 0xff35c8 : 0xffd54a); m.pads.push({ x, z, r: 1.5 }); });
  const old = m.update;
  m.update = (dt, t, p) => { old(dt, t, p); anims.forEach((f) => f(dt, t)); };
});
