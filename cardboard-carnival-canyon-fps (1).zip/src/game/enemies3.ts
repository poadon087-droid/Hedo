/**
 * Third creature batch, each with its own mechanic:
 *  Snow Globe Bot (shakes up an ice-shard nova, frost puddle on death), Glue Bottle Goon (lobs sticky glue that slows you),
 *  Scissor Spinner (homing spin-dash, then dizzy and extra vulnerable), Paper Snake (slithering body that bites along its whole length),
 *  Origami Crane (flying orbiter with dart volleys), Magnet Bot (pulls you in unless you break line of sight).
 * Also exposes the combined dispatchers (this batch + enemies2) used by enemies.ts.
 */
import * as THREE from 'three';
import { TAU, angleDiff, clamp, damp, hasLOS, type GameApi } from './core';
import { M, T, boxGeo, gradientMap } from './textures';
import { extrude, mk, petalShape } from './models';
import { brow, cloneToon, crownMesh, makeMarker, type Enemy, type EnemyDef, type Parts } from './enemies';
import { buildExtra as build2, initialExtraState as init2, isExtra as isExtra2, syncExtra as sync2, updateExtra as update2 } from './enemies2';

const KINDS = ['globe', 'glue', 'scissors', 'snake', 'crane', 'magnet'];
export const isExtra = (k: string) => KINDS.includes(k) || isExtra2(k);
export const initialExtraState = (k: string) => (KINDS.includes(k) ? 'chase' : init2(k));

// ------------------------------------------------------------------ helpers
const inkMat = new THREE.MeshBasicMaterial({ color: 0x141016 });
const eye = (x: number, y: number, z: number, r = 0.07) => {
  const g = new THREE.Group();
  const w = new THREE.Mesh(new THREE.SphereGeometry(r, 10, 8), new THREE.MeshToonMaterial({ color: 0xffffff, gradientMap: gradientMap() }));
  const p = new THREE.Mesh(new THREE.SphereGeometry(r * 0.5, 8, 6), inkMat); p.position.z = r * 0.7;
  g.add(w, p); g.position.set(x, y, z); return g;
};
const cooldown = (e: Enemy) => (e.def.cooldown * (0.8 + Math.random() * 0.5)) / e.cdMul;
const faceSmooth = (e: Enemy, want: number, rate: number, dt: number) => { e.yaw = damp(e.yaw, e.yaw + angleDiff(e.yaw, want), rate, dt); };
const eyeLos = (e: Enemy, g: GameApi) => hasLOS({ x: e.pos.x, y: 1, z: e.pos.z }, { x: g.playerPos.x, y: 1, z: g.playerPos.z }, g.colliders);

/** Arcing shell that lands on (tx, tz) after ~1-2 s. */
function lobShell(e: Enemy, g: GameApi, tx: number, tz: number, dmg: number, kind: 'seed' | 'fire', explode: number, yOff: number) {
  const ox = e.pos.x, oy = e.pos.y + yOff, oz = e.pos.z, dx = tx - ox, dz = tz - oz, D = Math.hypot(dx, dz), G = 13;
  const T2 = clamp(D / 12, 0.8, 2.0), vx = dx / T2, vz = dz / T2, vy = (0.15 - oy) / T2 + 0.5 * G * T2, sp = Math.hypot(vx, vy, vz);
  g.fireEnemyProj({ x: ox, y: oy, z: oz, dx: vx / sp, dy: vy / sp, dz: vz / sp, speed: sp, dmg, kind, gravity: G, explode, life: T2 + 2.5 });
  g.sfx.play('enemyShoot', 0.5);
}

// ------------------------------------------------------------------ builders
function buildGlobe(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group();
  const base = mk(new THREE.CylinderGeometry(0.62, 0.78, 0.5, 14), cloneToon(M.paper('#9c6a3a'), flash), { outline: 0.03 }); base.position.y = 0.25; pivot.add(base);
  const trim = mk(new THREE.TorusGeometry(0.66, 0.05, 6, 20), M.paper('#e8b830'), { outline: 0.01 }); trim.rotation.x = Math.PI / 2; trim.position.y = 0.52; pivot.add(trim);
  const glass = new THREE.Mesh(new THREE.SphereGeometry(0.78, 18, 14), new THREE.MeshBasicMaterial({ color: 0xcfeeff, transparent: true, opacity: 0.26, depthWrite: false })); glass.position.y = 1.3; pivot.add(glass);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(0.78, 0.015, 4, 28), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6 })); rim.position.y = 1.3; rim.rotation.x = Math.PI / 2; pivot.add(rim);
  const inner = new THREE.Group(); inner.position.y = 1.0; pivot.add(inner);
  inner.add(mk(new THREE.SphereGeometry(0.28, 10, 8), cloneToon(M.paper('#38b9ad'), flash), { outline: 0.02 }));
  const face = new THREE.Mesh(new THREE.PlaneGeometry(0.42, 0.42), M.tex(T.leafFace(), 'leafFace', { transparent: true })); face.position.set(0, 0.02, 0.28); inner.add(face);
  const brows = [brow(-0.1, 0.2, 0.3, 0.14), brow(0.1, 0.2, 0.3, 0.14)]; inner.add(...brows);
  const n = 42, pos = new Float32Array(n * 3);
  for (let i = 0; i < n; i++) {
    const a = Math.random() * TAU, el = Math.acos(2 * Math.random() - 1), r = 0.15 + Math.random() * 0.5;
    pos[i * 3] = Math.sin(el) * Math.cos(a) * r; pos[i * 3 + 1] = Math.cos(el) * r; pos[i * 3 + 2] = Math.sin(el) * Math.sin(a) * r;
  }
  const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xffffff, size: 3, sizeAttenuation: false })); pts.position.y = 1.3; pts.frustumCulled = false; pivot.add(pts);
  if (def.crown) { const c = crownMesh(1.3); c.position.set(0, 2.2, 0); pivot.add(c); }
  return { pivot, flash, brows, marker: makeMarker(), extra: { inner, pts } };
}

function buildGlue(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group();
  const bottle = mk(new THREE.CylinderGeometry(0.4, 0.44, 0.95, 14), cloneToon(M.paper(def.tint), flash), { outline: 0.03 }); bottle.position.y = 0.75; pivot.add(bottle);
  const shoulder = mk(new THREE.CylinderGeometry(0.16, 0.4, 0.3, 14), cloneToon(M.paper(def.tint), flash), { outline: 0.03 }); shoulder.position.y = 1.37; pivot.add(shoulder);
  const nozzle = mk(new THREE.CylinderGeometry(0.1, 0.16, 0.28, 10), M.paper('#ff9a1e'), { outline: 0.02 }); nozzle.position.y = 1.68; pivot.add(nozzle);
  const tip = mk(new THREE.ConeGeometry(0.1, 0.18, 10), M.paper('#ff9a1e'), { outline: 0.02 }); tip.position.y = 1.9; pivot.add(tip);
  const label = new THREE.Mesh(new THREE.PlaneGeometry(0.8, 0.4), M.tex(T.sign('GLUE'), 'signGLUE')); label.position.set(0, 0.62, 0.45); pivot.add(label);
  pivot.add(eye(-0.15, 1.2, 0.27, 0.09), eye(0.15, 1.2, 0.27, 0.09));
  const brows = [brow(-0.15, 1.33, 0.3, 0.15), brow(0.15, 1.33, 0.3, 0.15)]; pivot.add(...brows);
  for (const s of [-1, 1]) { const l = mk(new THREE.CylinderGeometry(0.1, 0.12, 0.28, 8), M.paper('#2a2d33'), { outline: 0.02 }); l.position.set(s * 0.2, 0.14, 0.04); pivot.add(l); }
  const drip = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), new THREE.MeshBasicMaterial({ color: 0xd8e04a })); drip.position.set(0, 1.78, 0.12); pivot.add(drip);
  return { pivot, flash, brows, marker: makeMarker(), extra: { drip } };
}

function buildScissors(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group();
  const spin = new THREE.Group(); spin.position.y = 0.7; pivot.add(spin);
  const shape = new THREE.Shape(); shape.moveTo(0.25, -0.14); shape.lineTo(1.55, 0); shape.lineTo(0.25, 0.14); shape.closePath();
  for (let k = 0; k < 4; k++) {
    const arm = new THREE.Group(); arm.rotation.y = (k / 4) * TAU; arm.position.y = (k % 2 ? 0.04 : -0.04);
    const blade = extrude(shape, 0.05, cloneToon(M.paper(k % 2 ? '#c0c4cc' : '#9aa0aa'), flash), 0.02); blade.rotation.x = Math.PI / 2; arm.add(blade);
    const handle = mk(new THREE.TorusGeometry(0.12, 0.035, 6, 12), M.paper('#c92b2b'), { outline: 0.01 }); handle.rotation.x = Math.PI / 2; handle.position.x = 0.08; arm.add(handle);
    spin.add(arm);
  }
  const hub = mk(new THREE.CylinderGeometry(0.34, 0.34, 0.3, 14), M.paper('#c92b2b'), { outline: 0.03 }); hub.position.y = 0.7; pivot.add(hub);
  pivot.add(eye(-0.13, 0.78, 0.29, 0.08), eye(0.13, 0.78, 0.29, 0.08));
  const brows = [brow(-0.13, 0.9, 0.31, 0.14), brow(0.13, 0.9, 0.31, 0.14)]; pivot.add(...brows);
  for (const s of [-1, 1]) { const l = mk(new THREE.BoxGeometry(0.18, 0.4, 0.22), M.paper('#2a2d33'), { outline: 0.02 }); l.position.set(s * 0.2, 0.2, 0); pivot.add(l); }
  void def;
  return { pivot, flash, brows, marker: makeMarker(), extra: { spin } };
}

const segCount = (d: EnemyDef) => (d.mini ? 12 : 7);
function buildSnake(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group(), n = segCount(def);
  const head = new THREE.Group(); pivot.add(head);
  const skull = mk(new THREE.SphereGeometry(0.4, 14, 10), cloneToon(M.paper(def.tint), flash), { outline: 0.03 }); skull.scale.set(1, 0.85, 1.15); skull.position.y = 0.42; head.add(skull);
  const snout = mk(new THREE.SphereGeometry(0.22, 10, 8), cloneToon(M.paper(def.tint), flash), { outline: 0.02 }); snout.position.set(0, 0.34, 0.38); head.add(snout);
  head.add(eye(-0.2, 0.6, 0.26, 0.1), eye(0.2, 0.6, 0.26, 0.1));
  const brows = [brow(-0.2, 0.74, 0.3, 0.18), brow(0.2, 0.74, 0.3, 0.18)]; head.add(...brows);
  const tongue = mk(new THREE.BoxGeometry(0.06, 0.02, 0.4), M.paper('#e0384a'), { cast: false }); tongue.position.set(0, 0.28, 0.7); head.add(tongue);
  if (def.crown) { const c = crownMesh(1.0); c.position.set(0, 0.95, 0); head.add(c); }
  const body = new THREE.Group(); pivot.add(body);
  for (let i = 0; i < n; i++) {
    const r = Math.max(0.14, 0.36 - i * (def.mini ? 0.014 : 0.026));
    const s = mk(new THREE.SphereGeometry(r, 12, 9), cloneToon(M.paper(i % 2 ? '#f3e7cc' : def.tint), flash), { outline: 0.025 }); s.userData.r = r; body.add(s);
  }
  return { pivot, flash, brows, head, marker: makeMarker(), extra: { head, body, tongue } };
}

function buildCrane(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group();
  const paper = cloneToon(M.paper(def.tint), flash), red = cloneToon(M.paper('#c92b2b'), flash);
  const body = new THREE.Group(); body.position.y = 0.6; pivot.add(body);
  const cg = new THREE.ConeGeometry(0.22, 0.9, 4); cg.rotateX(Math.PI / 2); const torso = mk(cg, paper, { outline: 0.02 }); torso.position.z = 0.05; body.add(torso);
  const tg = new THREE.ConeGeometry(0.13, 0.7, 4); tg.rotateX(-Math.PI / 2); const tail = mk(tg, red, { outline: 0.02 }); tail.position.z = -0.62; body.add(tail);
  const neck = mk(new THREE.ConeGeometry(0.08, 0.6, 4), paper, { outline: 0.015 }); neck.position.set(0, 0.28, 0.5); neck.rotation.x = 0.9; body.add(neck);
  const head = mk(new THREE.SphereGeometry(0.1, 8, 6), paper, { outline: 0.015 }); head.position.set(0, 0.5, 0.76); body.add(head);
  const bg = new THREE.ConeGeometry(0.04, 0.22, 4); bg.rotateX(Math.PI / 2); const beak = mk(bg, M.paper('#ff9a1e'), { outline: 0.01 }); beak.position.set(0, 0.47, 0.92); body.add(beak);
  for (const s of [-1, 1]) { const e = new THREE.Mesh(new THREE.SphereGeometry(0.03, 6, 4), inkMat); e.position.set(s * 0.07, 0.55, 0.82); body.add(e); }
  const brows = [brow(-0.06, 0.62, 0.84, 0.08), brow(0.06, 0.62, 0.84, 0.08)]; body.add(...brows);
  const extra: Record<string, THREE.Object3D> = { body };
  for (const s of [-1, 1]) {
    const hinge = new THREE.Group(); hinge.position.set(s * 0.12, 0.08, 0);
    const big = extrude(petalShape(), 0.02, red, 0.015); big.scale.set(0.8, 1.15, 1); big.rotation.z = -s * Math.PI / 2; hinge.add(big);
    const small = extrude(petalShape(), 0.02, paper, 0.015); small.scale.set(0.5, 0.7, 1); small.rotation.z = -s * (Math.PI / 2 + 0.6); small.position.z = 0.02; hinge.add(small);
    body.add(hinge); extra[s < 0 ? 'wl' : 'wr'] = hinge;
  }
  return { pivot, flash, brows, marker: makeMarker(), extra };
}

function buildMagnet(def: EnemyDef): Parts {
  const flash: THREE.MeshToonMaterial[] = [], pivot = new THREE.Group();
  const redMat = cloneToon(M.paper(def.tint), flash);
  const arch = mk(new THREE.TorusGeometry(0.5, 0.2, 10, 20, Math.PI), redMat, { outline: 0.03 }); arch.position.y = 0.7; pivot.add(arch);
  for (const s of [-1, 1]) {
    const leg = mk(new THREE.CylinderGeometry(0.2, 0.2, 0.55, 12), redMat, { outline: 0.03 }); leg.position.set(s * 0.5, 0.43, 0); pivot.add(leg);
    const tip = mk(new THREE.CylinderGeometry(0.21, 0.21, 0.22, 12), M.paper('#c0c4cc'), { outline: 0.02 }); tip.position.set(s * 0.5, 0.12, 0); pivot.add(tip);
  }
  const plate = mk(boxGeo(0.84, 0.72, 0.12, 0.6), M.paper('#c4935a'), { outline: 0.02 }); plate.position.set(0, 0.6, -0.04); pivot.add(plate);
  const face = new THREE.Mesh(new THREE.PlaneGeometry(0.62, 0.62), M.tex(T.domeFace(), 'domeFace', { transparent: true })); face.position.set(0, 0.6, 0.03); pivot.add(face);
  const brows = [brow(-0.14, 0.82, 0.05, 0.16), brow(0.14, 0.82, 0.05, 0.16)]; pivot.add(...brows);
  const rings = new THREE.Group(); rings.position.y = 0.7; pivot.add(rings);
  for (let i = 0; i < 3; i++) {
    const r = new THREE.Mesh(new THREE.TorusGeometry(1, 0.03, 4, 36), new THREE.MeshBasicMaterial({ color: 0x7fc8ff, transparent: true, opacity: 0.6, depthWrite: false, toneMapped: false }));
    r.rotation.x = Math.PI / 2; r.visible = false; rings.add(r);
  }
  return { pivot, flash, brows, marker: makeMarker(), extra: { rings } };
}

export function buildExtra(def: EnemyDef): Parts {
  switch (def.kind) {
    case 'globe': return buildGlobe(def);
    case 'glue': return buildGlue(def);
    case 'scissors': return buildScissors(def);
    case 'snake': return buildSnake(def);
    case 'crane': return buildCrane(def);
    case 'magnet': return buildMagnet(def);
    default: return build2(def);
  }
}

// ------------------------------------------------------------------ snake trail
const SNAKE_N = 48;
const trails = new WeakMap<Enemy, Float32Array>();
const trailOf = (e: Enemy) => { let t = trails.get(e); if (!t) { t = new Float32Array(SNAKE_N * 2); trails.set(e, t); } return t; };
function recordTrail(e: Enemy, step: number) {
  const t = trailOf(e), dx = e.pos.x - t[0], dz = e.pos.z - t[1];
  if (dx * dx + dz * dz > step * step) { t.copyWithin(2, 0, (SNAKE_N - 1) * 2); t[0] = e.pos.x; t[1] = e.pos.z; }
}
/** World position of body segment `i`, interpolated along the recorded trail (~0.5 m apart). */
function snakeAt(e: Enemy, i: number, out: { x: number; z: number }) {
  const t = trailOf(e), f = (i + 1) * 2.3, j = Math.floor(f), u = f - j;
  const ax = t[(j - 1) * 2], az = t[(j - 1) * 2 + 1], bx = t[j * 2], bz = t[j * 2 + 1];
  out.x = ax + (bx - ax) * u; out.z = az + (bz - az) * u;
}
const _o = { x: 0, z: 0 };

// ------------------------------------------------------------------ AI
/** Snow Globe: keeps range, shakes up (windup), then bursts a ring of ice shards plus aimed shards. */
function globe(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex;
  faceSmooth(e, want, 5, dt);
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / d.windup, 0, 1); ex.shake = e.windupAmt; e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t >= d.windup) { e.state = 'fire'; e.t = 0; e.windupAmt = 0; ex.shake = 0; }
      break;
    case 'fire': {
      const dmg = d.dmg * e.dmgMul;
      e.radial(g, d.mini ? 20 : 12, g.time * 3, 'ice', 9, dmg, 1.0);
      for (const o of d.mini ? [-0.3, 0, 0.3] : [0]) e.aimShot(g, o, 'ice', 14, dmg, 1.3);
      g.sfx.play('enemyShoot', 0.8); e.sqV += 5; e.state = 'recover'; e.t = 0;
      break;
    }
    case 'recover':
      e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t > 0.7) { e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); }
      break;
    default: {
      if (p.d > 15) e.steer(g, p.x, p.z, e.speedNow(), dt); else if (p.d < 9) e.steer(g, -p.x, -p.z, e.speedNow(), dt); else e.steer(g, -p.z * e.strafe, p.x * e.strafe, e.speedNow() * 0.6, dt);
      e.integrate(g, dt); e.checkStuck(dt, true);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 30 && eyeLos(e, g)) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 0.9); g.caption('[Snow globe shakes]'); }
    }
  }
}

/** Glue Bottle: lobs a glue blob at your feet (sticky puddle), then follows up with seeds while you struggle. */
function glue(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex, pp = g.playerPos;
  faceSmooth(e, want, 6, dt);
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / d.windup, 0, 1); e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t >= d.windup) { e.state = 'fire'; e.t = 0; e.windupAmt = 0; ex.shots = 3; e.shotT = 0; }
      break;
    case 'fire':
      e.shotT -= dt;
      if (ex.shots > 0 && e.shotT <= 0) {
        if (ex.shots === 3) lobShell(e, g, pp.x + g.playerVel.x * 0.5, pp.z + g.playerVel.z * 0.5, d.dmg * e.dmgMul, 'seed', 2.8, 1.8);
        else e.aimShot(g, 0, 'seed', d.projSpeed, d.dmg * e.dmgMul, 1.2);
        ex.shots--; e.shotT = ex.shots === 2 ? 0.6 : 0.35; e.sqV += 4;
      }
      e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (ex.shots <= 0 && e.shotT <= 0) { e.state = 'recover'; e.t = 0; }
      break;
    case 'recover':
      e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t > 0.6) { e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); }
      break;
    default: {
      if (p.d > 14) e.steer(g, p.x, p.z, e.speedNow(), dt); else if (p.d < 8) e.steer(g, -p.x, -p.z, e.speedNow(), dt); else e.steer(g, -p.z * e.strafe, p.x * e.strafe, e.speedNow() * 0.6, dt);
      e.integrate(g, dt); e.checkStuck(dt, true);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 26 && eyeLos(e, g)) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 0.8); g.caption('[Glue bottle gurgles]'); }
    }
  }
}

/** Scissor Spinner: spins up, then dashes on a homing curve. Afterwards it is dizzy and takes extra damage. */
function scissors(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex;
  ex.spin = damp(ex.spin ?? 3, e.state === 'atk' ? 32 : e.state === 'windup' ? 14 : e.state === 'recover' ? 1 : 4, 6, dt);
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / d.windup, 0, 1); faceSmooth(e, want, 10, dt); e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t >= d.windup) { e.state = 'atk'; e.t = 0; e.windupAmt = 0; ex.hit = 0; ex.h = want; g.sfx.play('dash', 1.3); }
      break;
    case 'atk': {
      e.takeMul = 0.35;
      ex.h += clamp(angleDiff(ex.h, want), -2.2 * dt, 2.2 * dt);
      const sp = e.speedNow() * 2.8;
      e.vel.set(Math.sin(ex.h) * sp, 0, Math.cos(ex.h) * sp); e.integrate(g, dt); e.yaw = ex.h;
      if (!ex.hit && p.d < d.radius + g.playerRadius + 0.5 && g.playerPos.y < 1.7) {
        ex.hit = 1; g.hurtPlayer(d.dmg * e.dmgMul, e.pos, 'contact'); g.playerVel.x += Math.sin(ex.h) * 9; g.playerVel.z += Math.cos(ex.h) * 9; g.shake(0.15);
      }
      if (e.t > 1.3 || (ex.hit && e.t > 0.5)) { e.state = 'recover'; e.t = 0; g.caption('[Scissors are dizzy]'); }
      break;
    }
    case 'recover':
      e.takeMul = 1.6; e.vel.multiplyScalar(0.9); e.integrate(g, dt);
      if (e.t > 1.6) { e.state = 'chase'; e.t = 0; e.takeMul = 1; e.fireT = cooldown(e); }
      break;
    default: {
      e.takeMul = 1; faceSmooth(e, want, 8, dt);
      const zig = Math.sin(e.age * 3 + e.id) * 0.5;
      e.steer(g, p.x - p.z * zig, p.z + p.x * zig, e.speedNow(), dt); e.integrate(g, dt); e.checkStuck(dt, true);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 13 && p.d > 3) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 1.3); }
    }
  }
}

/** Paper Snake: slithers in a sine weave, rears up, then lunges. The whole body hurts on contact (aim for the head). */
function snake(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex, pp = g.playerPos, sc = d.scale;
  if (!ex.init) { ex.init = 1; const t = trailOf(e); for (let k = 0; k < SNAKE_N; k++) { t[k * 2] = e.pos.x; t[k * 2 + 1] = e.pos.z; } }
  faceSmooth(e, want, e.state === 'atk' ? 3 : 9, dt);
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / d.windup, 0, 1); e.vel.multiplyScalar(0.8); e.integrate(g, dt);
      if (e.t >= d.windup) {
        e.state = 'atk'; e.t = 0; e.windupAmt = 0; ex.hx = p.x; ex.hz = p.z; g.sfx.play('dash', 1.2);
        if (d.mini) for (const o of [-0.3, 0, 0.3]) e.aimShot(g, o, 'seed', 12, d.dmg * 0.6 * e.dmgMul, 0.8 * sc);
      }
      break;
    case 'atk': {
      const sp = e.speedNow() * 2.7;
      e.vel.set(ex.hx * sp, 0, ex.hz * sp); e.integrate(g, dt);
      if (e.t > 0.55) { e.state = 'recover'; e.t = 0; }
      break;
    }
    case 'recover':
      e.vel.multiplyScalar(0.88); e.integrate(g, dt);
      if (e.t > 0.6) { e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); }
      break;
    default: {
      const sl = Math.sin(e.age * 3.2 + e.id) * 0.9;
      e.steer(g, p.x - p.z * sl, p.z + p.x * sl, e.speedNow(), dt); e.integrate(g, dt); e.checkStuck(dt, true);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 8.5 && p.d > 1.6) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 1.6); }
    }
  }
  recordTrail(e, 0.22 * sc);
  if (e.contactCd <= 0 && pp.y < 1.4 * sc) {
    let hit = p.d < d.radius + g.playerRadius + 0.15;
    for (let i = 0; i < segCount(d) && !hit; i += 2) { snakeAt(e, i, _o); hit = Math.hypot(pp.x - _o.x, pp.z - _o.z) < 0.3 * sc + g.playerRadius; }
    if (hit) { g.hurtPlayer(d.dmg * e.dmgMul, e.pos, 'contact'); e.contactCd = 0.7; }
  }
}

/** Origami Crane: circles at head height and fires fast three-dart volleys; every third volley is a wide crescent. */
function crane(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex, pp = g.playerPos;
  faceSmooth(e, want, 9, dt);
  e.pos.y = damp(e.pos.y, 3.4 + Math.sin(e.age * 1.8 + e.id) * 0.5, 3, dt);
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / d.windup, 0, 1); e.vel.multiplyScalar(0.9); e.integrate(g, dt, false);
      if (e.t >= d.windup) { e.state = 'fire'; e.t = 0; e.windupAmt = 0; ex.volley = (ex.volley ?? 0) + 1; }
      break;
    case 'fire': {
      const dmg = d.dmg * e.dmgMul;
      if (ex.volley % 3 === 0) for (let i = -3; i <= 3; i++) e.aimShot(g, i * 0.16, 'bolt', d.projSpeed * 0.85, dmg, 0.5);
      else for (const o of [-0.14, 0, 0.14]) e.aimShot(g, o, 'bolt', d.projSpeed, dmg, 0.5);
      g.sfx.play('enemyShoot', 1.4); e.sqV += 3; e.state = 'recover'; e.t = 0;
      break;
    }
    case 'recover':
      e.vel.multiplyScalar(0.92); e.integrate(g, dt, false);
      if (e.t > 0.5) { e.state = 'chase'; e.t = 0; e.fireT = cooldown(e); }
      break;
    default: {
      ex.ang = (ex.ang ?? e.id) + dt * (e.id % 2 ? 1 : -1) * (e.speedNow() / 13);
      const R = 12 + Math.sin(e.age * 0.5 + e.id) * 2.5;
      e.steer(g, pp.x + Math.cos(ex.ang) * R - e.pos.x, pp.z + Math.sin(ex.ang) * R - e.pos.z, e.speedNow(), dt); e.integrate(g, dt, false);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 30) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 1.5); }
    }
  }
}

/** Magnet Bot: hums up, then drags you towards it for two seconds. Break line of sight (or dash away) to resist; it slams if it catches you. */
function magnet(e: Enemy, dt: number, g: GameApi, want: number) {
  const d = e.def, p = e.tmp, ex = e.ex, pp = g.playerPos;
  faceSmooth(e, want, 7, dt);
  ex.pulling = 0;
  switch (e.state) {
    case 'windup':
      e.windupAmt = clamp(e.t / d.windup, 0, 1); e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t >= d.windup) { e.state = 'fire'; e.t = 0; e.windupAmt = 0; ex.slam = 0; g.sfx.play('dash', 0.6); g.caption('[Magnet hums: take cover!]'); }
      break;
    case 'fire': {
      if (p.d < 24 && eyeLos(e, g)) {
        const k = clamp(1.15 - p.d / 24, 0, 1) * 6.5 * dt;
        pp.x -= p.x * k; pp.z -= p.z * k; ex.pulling = 1;
        if (!ex.slam && p.d < d.radius + g.playerRadius + 0.9) {
          ex.slam = 1; g.hurtPlayer(d.dmg * e.dmgMul, e.pos, 'contact'); g.playerVel.x += p.x * 11; g.playerVel.z += p.z * 11; g.shake(0.3); g.sfx.play('boom', 0.7);
          e.state = 'recover'; e.t = 0; break;
        }
      }
      e.vel.multiplyScalar(0.85); e.integrate(g, dt);
      if (e.t > 2.3) { e.state = 'recover'; e.t = 0; }
      break;
    }
    case 'recover':
      e.takeMul = 1.3; e.vel.multiplyScalar(0.88); e.integrate(g, dt);
      if (e.t > 1.0) { e.state = 'chase'; e.t = 0; e.takeMul = 1; e.fireT = cooldown(e); }
      break;
    default:
      e.takeMul = 1;
      if (p.d < 10) e.steer(g, -p.x, -p.z, e.speedNow(), dt); else if (p.d > 15) e.steer(g, p.x, p.z, e.speedNow(), dt); else e.steer(g, -p.z * e.strafe, p.x * e.strafe, e.speedNow() * 0.5, dt);
      e.integrate(g, dt); e.checkStuck(dt, true);
      e.fireT -= dt;
      if (e.fireT <= 0 && p.d < 24 && eyeLos(e, g)) { e.state = 'windup'; e.t = 0; g.sfx.play('telegraph', 0.7); }
  }
}

export function updateExtra(e: Enemy, dt: number, g: GameApi, want: number) {
  switch (e.def.kind) {
    case 'globe': globe(e, dt, g, want); break;
    case 'glue': glue(e, dt, g, want); break;
    case 'scissors': scissors(e, dt, g, want); break;
    case 'snake': snake(e, dt, g, want); break;
    case 'crane': crane(e, dt, g, want); break;
    case 'magnet': magnet(e, dt, g, want); break;
    default: update2(e, dt, g, want);
  }
}

// ------------------------------------------------------------------ animation
const R3 = { lean: 0, waddle: 0, hop: 0 };

/** Per-frame procedural animation; returns lean / waddle / hop for the shared transform code. */
export function syncExtra(e: Enemy, dt: number, speed: number) {
  const k = e.def.kind;
  if (!KINDS.includes(k)) return sync2(e, dt, speed);
  const ex = e.ex, t = e.visT, w = e.windupAmt, x = e.parts.extra ?? {};
  let lean = 0, waddle = 0, hop = 0;
  switch (k) {
    case 'globe': {
      const sh = ex.shake ?? 0;
      x.pts.rotation.y += dt * (0.6 + sh * 9); x.inner.rotation.y = Math.sin(t * 1.5) * 0.3;
      waddle = Math.sin(t * 42) * 0.09 * sh; hop = Math.sin(t * 2) * 0.04 + sh * 0.06 * Math.abs(Math.sin(t * 30)); lean = -w * 0.1; break;
    }
    case 'glue': {
      const run = clamp(speed / 3, 0, 1);
      waddle = Math.sin(t * 10) * 0.08 * run; hop = Math.abs(Math.sin(t * 10)) * 0.05 * run; lean = -w * 0.25;
      x.drip.position.y = 1.78 - ((t * 0.8) % 1) * 0.25; break;
    }
    case 'scissors': {
      x.spin.rotation.y += dt * (ex.spin ?? 3);
      waddle = e.state === 'recover' ? Math.sin(t * 18) * 0.16 : Math.sin(t * 9) * 0.04 * clamp(speed / 4, 0, 1); lean = e.state === 'atk' ? 0.22 : -w * 0.2; break;
    }
    case 'snake': {
      const body = x.body, root = e.root, th = root.rotation.y, c = Math.cos(th), s = Math.sin(th), sc = e.def.scale;
      for (let i = 0; i < body.children.length; i++) {
        const seg = body.children[i], r = seg.userData.r as number;
        if (!ex.init) { seg.position.set(0, r, -0.1 * (i + 1)); continue; }
        snakeAt(e, i, _o);
        const dx = _o.x - root.position.x, dz = _o.z - root.position.z;
        seg.position.set((dx * c - dz * s) / sc, r + Math.sin(t * 6 - i * 0.7) * 0.04, (dx * s + dz * c) / sc);
      }
      x.head.position.y = w * 0.35; x.head.rotation.x = -w * 0.5; x.tongue.scale.z = 0.6 + 0.4 * Math.abs(Math.sin(t * 14));
      waddle = Math.sin(t * 5) * 0.03; break;
    }
    case 'crane': {
      const f = Math.sin(t * (10 + w * 10)) * 0.75;
      x.wr.rotation.z = f + 0.15; x.wl.rotation.z = -f - 0.15; x.body.rotation.x = clamp(speed / 20, 0, 0.3) - w * 0.25; hop = Math.sin(t * 3) * 0.1; break;
    }
    case 'magnet': {
      const rings = x.rings.children, on = (ex.pulling ?? 0) > 0;
      for (let i = 0; i < rings.length; i++) {
        const r = rings[i] as THREE.Mesh, u = on ? ((t * 1.6 + i / 3) % 1) : 0;
        r.visible = on; r.scale.setScalar(5.5 * (1 - u) + 0.6); (r.material as THREE.MeshBasicMaterial).opacity = 0.6 * u;
      }
      waddle = Math.sin(t * 8) * 0.03 * clamp(speed / 3, 0, 1) + (w > 0 ? Math.sin(t * 40) * 0.05 * w : 0); lean = -w * 0.12; break;
    }
  }
  R3.lean = lean; R3.waddle = waddle; R3.hop = hop;
  return R3;
}
