/**
 * Scenery pass applied to every arena after it is built:
 *  - colour grade, exposure, rim-light colour and sun-shaft settings per arena
 *  - layered cut-paper horizon ridges (day arenas) and a sea of clouds below the floating carnival
 *  - wind-swept ground cover, rocks, flowers, studs, toy blocks, ice crystals, embers
 *  - floor decals (ink blots, neon spills, scorch marks), contact shadows under every prop
 *  - flickering point lights, lava-vent glow and shooting stars
 */
import * as THREE from 'three';
import { Rng, TAU, clamp, hashString, type Collider } from './core';
import { T, gradientMap, rimPatch, rimU } from './textures';
import { aoTexture, windTime } from './models';
import { mapHooks, type MapData, type MapId } from './maps';
import { CONFETTI } from './fx';

type Anim = (dt: number, t: number) => void;
type Pt = { x: number; z: number };

interface Look { grade: NonNullable<MapData['grade']>; exposure: number; light: [number, number, number]; shaft: number; shaftColor: number; rim: number; rimK: number }
const LOOKS: Record<MapId, Look> = {
  canyon: { grade: { shadow: [0.9, 0.97, 1.12], high: [1.1, 1.02, 0.88], sat: 1.12, con: 1.06 }, exposure: 1.05, light: [0.55, 0.5, -0.65], shaft: 0.9, shaftColor: 0xffd9a0, rim: 0xffb070, rimK: 0.32 },
  night: { grade: { shadow: [0.9, 0.85, 1.2], high: [1.1, 0.95, 1.1], sat: 1.2, con: 1.1 }, exposure: 1.1, light: [-0.4, 0.8, -0.5], shaft: 0.35, shaftColor: 0x9ab8ff, rim: 0xff5aa0, rimK: 0.5 },
  snow: { grade: { shadow: [0.92, 0.97, 1.15], high: [1.05, 1.0, 0.95], sat: 1.05, con: 1.04 }, exposure: 1.05, light: [0.5, 0.32, 0.55], shaft: 0.5, shaftColor: 0xffc8a0, rim: 0xb8d8ff, rimK: 0.4 },
  toy: { grade: { shadow: [1.0, 0.95, 1.08], high: [1.06, 1.02, 0.96], sat: 1.15, con: 1.02 }, exposure: 1.05, light: [0.35, 0.7, 0.4], shaft: 0.5, shaftColor: 0xfff0d0, rim: 0xffa0d0, rimK: 0.3 },
  ember: { grade: { shadow: [1.1, 0.9, 0.9], high: [1.12, 0.98, 0.85], sat: 1.15, con: 1.12 }, exposure: 1.15, light: [0, 0.55, -0.83], shaft: 0.8, shaftColor: 0xff7a30, rim: 0xff6a20, rimK: 0.6 },
};

const inside = (cols: Collider[], x: number, z: number, pad: number) => cols.some((c) => c.alive && c.top > 0.2 && x > c.minX - pad && x < c.maxX + pad && z > c.minZ - pad && z < c.maxZ + pad);

/** Random floor points that avoid solid props. */
function scatter(m: MapData, rng: Rng, n: number, r0: number, r1: number, pad = 0.6): Pt[] {
  const out: Pt[] = [];
  for (let i = 0; i < n * 4 && out.length < n; i++) {
    const a = rng.range(0, TAU), r = Math.sqrt(rng.range(r0 * r0, r1 * r1)), x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (!inside(m.colliders, x, z, pad)) out.push({ x, z });
  }
  return out;
}
function ringPoints(m: MapData, radii: number[], spacing: number): Pt[] {
  const out: Pt[] = [];
  for (const r of radii) { const n = Math.floor((TAU * r) / spacing); for (let i = 0; i < n; i++) { const a = (i / n) * TAU, x = Math.cos(a) * r, z = Math.sin(a) * r; if (!inside(m.colliders, x, z, 0.8)) out.push({ x, z }); } }
  return out;
}

interface InstOpt { y?: number; s0: number; s1: number; sy?: number; colors?: number[]; flat?: boolean }
function inst(parent: THREE.Object3D, geo: THREE.BufferGeometry, mat: THREE.Material, pts: Pt[], rng: Rng, o: InstOpt): THREE.InstancedMesh {
  const im = new THREE.InstancedMesh(geo, mat, pts.length), d = new THREE.Object3D(), c = new THREE.Color();
  pts.forEach((p, i) => {
    const s = rng.range(o.s0, o.s1);
    d.position.set(p.x, o.y ?? 0, p.z); d.rotation.set(0, rng.range(0, TAU), 0); d.scale.set(s, s * (o.sy ?? 1), s);
    d.updateMatrix(); im.setMatrixAt(i, d.matrix);
    if (o.colors) im.setColorAt(i, c.setHex(o.colors[i % o.colors.length]));
  });
  im.receiveShadow = !o.flat; im.frustumCulled = false; parent.add(im);
  return im;
}

// ------------------------------------------------------------------ swaying grass
let tuftGeo: THREE.BufferGeometry | null = null;
function tuft(): THREE.BufferGeometry {
  if (tuftGeo) return tuftGeo;
  const pos: number[] = [], nor: number[] = [];
  const blades: [number, number, number, number][] = [[0, 0.55, 0.09, 0.05], [0.1, 0.4, 0.07, -0.06], [-0.1, 0.46, 0.07, 0.04]];
  for (let k = 0; k < 3; k++) {
    const a = (k / 3) * Math.PI, c = Math.cos(a), s = Math.sin(a);
    for (const [bx, h, w, lean] of blades) for (const [lx, y] of [[bx - w, 0], [bx + w, 0], [bx + lean, h]]) { pos.push(lx * c, y, lx * s); nor.push(0, 1, 0); }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(nor, 3));
  tuftGeo = g;
  return g;
}
/** Toon material whose tips sway in the shared wind. */
function windMat(): THREE.MeshToonMaterial {
  const m = new THREE.MeshToonMaterial({ side: THREE.DoubleSide, gradientMap: gradientMap() });
  m.onBeforeCompile = (sh) => {
    rimPatch(sh);
    sh.uniforms.uWind = windTime;
    sh.vertexShader = 'uniform float uWind;\n' + sh.vertexShader.replace('#include <begin_vertex>', `#include <begin_vertex>
      vec3 ip = vec3(0.0);
      #ifdef USE_INSTANCING
        ip = vec3(instanceMatrix[3][0], instanceMatrix[3][1], instanceMatrix[3][2]);
      #endif
      float sw = position.y * position.y;
      transformed.x += sin(uWind * 1.6 + ip.x * 0.7 + ip.z * 0.4) * 0.45 * sw;
      transformed.z += cos(uWind * 1.2 + ip.z * 0.6) * 0.3 * sw;`);
  };
  return m;
}
const toon = () => new THREE.MeshToonMaterial({ gradientMap: gradientMap() });
const glowBasic = () => new THREE.MeshBasicMaterial({ toneMapped: false });

function cover(m: MapData, rng: Rng) {
  const root = m.root;
  const BC = [0xe0384a, 0x3f8cf0, 0xffd54a, 0x34c3b0, 0xff8fb8, 0xff9a2e];
  switch (m.id) {
    case 'canyon': {
      inst(root, tuft(), windMat(), scatter(m, rng, 650, 3, 30), rng, { s0: 0.8, s1: 1.7, colors: [0xc9a85a, 0xb8943f, 0xa08a3a, 0xd4b46a, 0x8fa04a] });
      inst(root, new THREE.IcosahedronGeometry(1, 0), toon(), scatter(m, rng, 90, 3, 30, 0.9), rng, { y: 0.06, s0: 0.14, s1: 0.5, sy: 0.6, colors: [0xb98a52, 0x9c703a, 0xc4935a, 0x8a5f2e] });
      const fl = scatter(m, rng, 70, 4, 29, 0.8);
      inst(root, new THREE.CylinderGeometry(0.012, 0.016, 0.4, 4).translate(0, 0.2, 0), toon(), fl, rng, { s0: 0.8, s1: 1.4, colors: [0x4f8a3a] });
      inst(root, new THREE.IcosahedronGeometry(0.08, 0).translate(0, 0.42, 0), toon(), fl, rng, { s0: 0.8, s1: 1.4, colors: [0xe0384a, 0xffd54a, 0xff8fb8, 0xffffff] });
      break;
    }
    case 'night': {
      const pts = ringPoints(m, [10, 19, 27], 3.2), cols = [0x33d6ff, 0xff35c8, 0xffd54a], c = new THREE.Color();
      const geo = new THREE.CircleGeometry(0.13, 12).rotateX(-Math.PI / 2);
      const studs = inst(root, geo, glowBasic(), pts, rng, { y: 0.04, s0: 0.9, s1: 1.1, flat: true });
      pts.forEach((_, i) => studs.setColorAt(i, c.setHex(cols[i % 3]).multiplyScalar(2.2)));
      inst(root, new THREE.PlaneGeometry(0.16, 0.1).rotateX(-Math.PI / 2), new THREE.MeshToonMaterial({ gradientMap: gradientMap(), side: THREE.DoubleSide }), scatter(m, rng, 260, 3, 30, 0.2), rng, { y: 0.035, s0: 0.8, s1: 1.4, colors: CONFETTI, flat: true });
      break;
    }
    case 'snow': {
      inst(root, tuft(), windMat(), scatter(m, rng, 380, 3, 30), rng, { s0: 0.5, s1: 1.0, colors: [0xe8f2ff, 0xcfe0f5, 0xffffff, 0xb8d0f0] });
      inst(root, new THREE.SphereGeometry(1, 10, 6, 0, TAU, 0, Math.PI / 2), toon(), scatter(m, rng, 60, 3, 30, 1.2), rng, { s0: 0.5, s1: 1.1, sy: 0.3, colors: [0xffffff, 0xf0f6ff] });
      const ice = new THREE.MeshToonMaterial({ gradientMap: gradientMap(), transparent: true, opacity: 0.82, emissive: 0x2a7a98, color: 0xbfeaff });
      inst(root, new THREE.ConeGeometry(0.13, 0.7, 5).translate(0, 0.35, 0), ice, scatter(m, rng, 70, 4, 29, 1), rng, { s0: 0.6, s1: 1.5 });
      break;
    }
    case 'toy': {
      inst(root, new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0), toon(), scatter(m, rng, 110, 3, 30, 1), rng, { s0: 0.22, s1: 0.5, colors: BC });
      inst(root, new THREE.SphereGeometry(1, 10, 8).translate(0, 1, 0), toon(), scatter(m, rng, 50, 3, 30, 0.5), rng, { s0: 0.12, s1: 0.2, colors: [0x3f8cf0, 0xe0384a, 0x34c3b0, 0xffd54a] });
      inst(root, new THREE.PlaneGeometry(0.16, 0.1).rotateX(-Math.PI / 2), new THREE.MeshToonMaterial({ gradientMap: gradientMap(), side: THREE.DoubleSide }), scatter(m, rng, 200, 3, 30, 0.2), rng, { y: 0.035, s0: 0.8, s1: 1.4, colors: CONFETTI, flat: true });
      break;
    }
    case 'ember': {
      inst(root, new THREE.IcosahedronGeometry(1, 0), toon(), scatter(m, rng, 100, 3, 30, 0.9), rng, { y: 0.1, s0: 0.2, s1: 0.8, sy: 0.7, colors: [0x2e2228, 0x3a2a30, 0x4a343a] });
      const hot = scatter(m, rng, 80, 3, 30, 0.4), c = new THREE.Color();
      const pebbles = inst(root, new THREE.IcosahedronGeometry(1, 0), glowBasic(), hot, rng, { y: 0.05, s0: 0.06, s1: 0.12, flat: true });
      hot.forEach((_, i) => pebbles.setColorAt(i, c.setRGB(2.4, 0.5 + (i % 5) * 0.12, 0.12)));
      inst(root, tuft(), windMat(), scatter(m, rng, 260, 3, 30), rng, { s0: 0.5, s1: 1.0, colors: [0x3a3030, 0x2a2024, 0x4a3a3a] });
      break;
    }
    default: break;
  }
}

// ------------------------------------------------------------------ floor decals and contact shadows
function decals(m: MapData, rng: Rng) {
  const cfg: Record<MapId, { n: number; s0: number; s1: number; colors: number[]; opacity: number; additive: boolean }> = {
    canyon: { n: 55, s0: 0.8, s1: 2.4, colors: [0x141016], opacity: 0.28, additive: false },
    night: { n: 40, s0: 1.5, s1: 4, colors: [0xff3b5c, 0x33d6ff, 0xff35c8], opacity: 0.3, additive: true },
    snow: { n: 50, s0: 1.5, s1: 4, colors: [0x6a86b8], opacity: 0.18, additive: false },
    toy: { n: 60, s0: 0.7, s1: 2, colors: [0xe0384a, 0x3f8cf0, 0xffd54a, 0x34c3b0], opacity: 0.35, additive: false },
    ember: { n: 60, s0: 1, s1: 3.5, colors: [0x0a0405], opacity: 0.5, additive: false },
  };
  const c = cfg[m.id], pts = scatter(m, rng, c.n, 2, 29, 0.2), col = new THREE.Color();
  const mat = new THREE.MeshBasicMaterial({ map: T.blot(), transparent: true, opacity: c.opacity, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, blending: c.additive ? THREE.AdditiveBlending : THREE.NormalBlending, toneMapped: !c.additive });
  const im = inst(m.root, new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), mat, pts, rng, { y: 0.026, s0: c.s0, s1: c.s1, flat: true });
  pts.forEach((_, i) => im.setColorAt(i, col.setHex(c.colors[i % c.colors.length]).multiplyScalar(c.additive ? 1.6 : 1)));
}

function propShadows(m: MapData) {
  const cs = m.colliders.filter((c) => c.alive && c.kind !== 'crate' && c.top > 0.6);
  if (!cs.length) return;
  const mat = new THREE.MeshBasicMaterial({ map: aoTexture(), transparent: true, opacity: 0.55, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
  const im = new THREE.InstancedMesh(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), mat, cs.length), d = new THREE.Object3D();
  cs.forEach((c, i) => { d.position.set((c.minX + c.maxX) / 2, 0.022, (c.minZ + c.maxZ) / 2); d.scale.set(c.maxX - c.minX + 2.2, 1, c.maxZ - c.minZ + 2.2); d.updateMatrix(); im.setMatrixAt(i, d.matrix); });
  im.renderOrder = 1; im.frustumCulled = false; m.root.add(im);
}

// ------------------------------------------------------------------ horizon
/** Layered cut-paper ridges: far layers are lighter, which (with the fog) gives real atmospheric depth. */
function ridges(root: THREE.Group, rng: Rng, layers: [number, number, number][]) {
  for (const [R, H, color] of layers) {
    const geo = new THREE.CylinderGeometry(R, R, H, 160, 1, true), pos = geo.attributes.position as THREE.BufferAttribute;
    const p1 = rng.range(0, TAU), p2 = rng.range(0, TAU), p3 = rng.range(0, TAU);
    for (let i = 0; i < pos.count; i++) {
      if (pos.getY(i) <= 0) continue;
      const a = Math.atan2(pos.getZ(i), pos.getX(i));
      const n = Math.round(clamp(0.5 + 0.28 * Math.sin(3 * a + p1) + 0.16 * Math.sin(7 * a + p2) + 0.1 * Math.sin(13 * a + p3), 0, 1) * 6) / 6; // terraced like stacked paper
      pos.setY(i, -H / 2 + H * (0.18 + 0.82 * n));
    }
    const mesh = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color, side: THREE.BackSide }));
    mesh.position.y = H / 2 - 4; mesh.frustumCulled = false; root.add(mesh);
  }
}

/** The night arena floats in the void; give it a rolling sea of clouds far below. */
function cloudSea(m: MapData, rng: Rng, anims: Anim[]) {
  const g = new THREE.Group(); m.root.add(g);
  const im = new THREE.InstancedMesh(new THREE.IcosahedronGeometry(1, 1), new THREE.MeshBasicMaterial({ color: 0xffffff }), 110), d = new THREE.Object3D(), c = new THREE.Color();
  const cols = [0x7a2a6a, 0x5a2468, 0x9a3a7a, 0x4a2060];
  for (let i = 0; i < 110; i++) {
    const a = rng.range(0, TAU), r = rng.range(48, 170), s = rng.range(9, 26);
    d.position.set(Math.cos(a) * r, rng.range(-34, -20), Math.sin(a) * r); d.scale.set(s, s * 0.38, s * 0.8); d.rotation.y = rng.range(0, TAU); d.updateMatrix();
    im.setMatrixAt(i, d.matrix); im.setColorAt(i, c.setHex(cols[i % cols.length]));
  }
  im.frustumCulled = false; g.add(im);
  anims.push((_, t) => { g.rotation.y = t * 0.004; });
}

function shootingStars(m: MapData, anims: Anim[]) {
  const mat = new THREE.MeshBasicMaterial({ map: T.ray(), color: new THREE.Color(1.8, 1.8, 2.2), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false, toneMapped: false });
  const geo = new THREE.PlaneGeometry(0.8, 24), up = new THREE.Vector3(0, 1, 0);
  for (let i = 0; i < 3; i++) {
    const mesh = new THREE.Mesh(geo, mat), vel = new THREE.Vector3(); let life = 0;
    mesh.visible = false; mesh.frustumCulled = false; m.root.add(mesh);
    anims.push((dt) => {
      if (life <= 0) {
        if (Math.random() < dt * 0.22) {
          life = 1.2; mesh.position.set((Math.random() - 0.5) * 320, 110 + Math.random() * 60, -(130 + Math.random() * 120));
          vel.set((Math.random() - 0.5) * 140, -45 - Math.random() * 30, 0); mesh.quaternion.setFromUnitVectors(up, vel.clone().normalize()); mesh.visible = true;
        }
        return;
      }
      life -= dt; mesh.position.addScaledVector(vel, dt); mesh.scale.x = Math.sin(clamp(life / 1.2, 0, 1) * Math.PI);
      if (life <= 0) mesh.visible = false;
    });
  }
}

// ------------------------------------------------------------------ entry point
mapHooks.push((m) => {
  const L = LOOKS[m.id], rng = new Rng(hashString(m.id) ^ 0x51ed);
  m.grade = L.grade; m.exposure = L.exposure; m.lightDir = new THREE.Vector3(...L.light).normalize();
  m.shaft = { k: L.shaft, color: L.shaftColor }; m.rim = { color: L.rim, k: L.rimK };
  rimU.color.value.setHex(L.rim); rimU.strength.value = L.rimK; // the rim light takes this arena's edge colour
  const anims: Anim[] = [];

  // every existing point light gets a gentle flicker
  const lights: THREE.PointLight[] = [];
  m.root.traverse((o) => { if ((o as THREE.PointLight).isPointLight) lights.push(o as THREE.PointLight); });
  const base = lights.map((l) => l.intensity);
  anims.push((_, t) => { lights.forEach((l, i) => { l.intensity = base[i] * (0.9 + 0.1 * Math.sin(t * (5 + i * 1.7) + i * 2.1) + 0.05 * Math.sin(t * 23 + i)); }); });

  cover(m, rng); decals(m, rng); propShadows(m);
  switch (m.id) {
    case 'canyon': ridges(m.root, rng, [[118, 24, 0xb5603a], [150, 32, 0xc9785a], [182, 40, 0xe0a07a]]); break;
    case 'snow': ridges(m.root, rng, [[125, 30, 0x8fa6c4], [158, 40, 0xb0c4de]]); break;
    case 'night': cloudSea(m, rng, anims); shootingStars(m, anims); break;
    case 'ember': {
      // the lava vents light up the arena while they erupt
      const gl = m.geysers.map((g) => { const l = new THREE.PointLight(0xff6a1a, 0, 22, 2); l.position.set(g.x, 2, g.z); m.root.add(l); return l; });
      anims.push(() => { gl.forEach((l, i) => { const s = m.geysers[i].state; l.intensity = s === 2 ? 220 : s === 1 ? 40 : 0; }); });
      break;
    }
    default: break;
  }
  const old = m.update;
  m.update = (dt, t, p) => { old(dt, t, p); for (const f of anims) f(dt, t); };
});
