/**
 * Core math helpers, seeded RNG, collision primitives and shared type contracts.
 * Everything here is allocation-free on hot paths.
 */
import * as THREE from 'three';
import type { Enemy } from './enemies';
import type { Fx } from './fx';
import type { Sfx } from './audio';

export const TAU = Math.PI * 2;
export const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
/** Frame-rate independent exponential smoothing. */
export const damp = (a: number, b: number, lambda: number, dt: number) => lerp(a, b, 1 - Math.exp(-lambda * dt));
export const easeOutCubic = (t: number) => 1 - Math.pow(1 - t, 3);
export const easeInOut = (t: number) => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
export const easeOutBack = (t: number) => {
  const c1 = 1.70158, c3 = c1 + 1;
  return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
};
export const angleDiff = (a: number, b: number) => {
  let d = (b - a) % TAU;
  if (d > Math.PI) d -= TAU;
  if (d < -Math.PI) d += TAU;
  return d;
};

/** Small deterministic PRNG (mulberry32). */
export class Rng {
  private s: number;
  constructor(seed = 1) { this.s = seed >>> 0; }
  next(): number {
    this.s = (this.s + 0x6d2b79f5) >>> 0;
    let t = this.s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  }
  range(a: number, b: number) { return a + (b - a) * this.next(); }
  int(a: number, b: number) { return Math.floor(this.range(a, b + 1)); }
  chance(p: number) { return this.next() < p; }
  pick<T>(arr: readonly T[]): T { return arr[Math.floor(this.next() * arr.length) % arr.length]; }
}

export function hashString(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

// ---------------------------------------------------------------- colliders
export interface Collider {
  minX: number; maxX: number; minZ: number; maxZ: number;
  bottom: number; top: number;
  kind: 'wall' | 'crate' | 'pillar' | 'prop';
  alive: boolean;
  crate?: Crate;
}
export interface Crate {
  collider: Collider;
  mesh: THREE.Object3D;
  hp: number; maxHp: number;
  shake: number;
  loot: boolean;
  /** TNT crates blow up when destroyed; `spent` stops them going off twice. */
  explosive?: boolean;
  spent?: boolean;
}
export function makeCollider(cx: number, cz: number, w: number, d: number, bottom: number, top: number, kind: Collider['kind']): Collider {
  return { minX: cx - w / 2, maxX: cx + w / 2, minZ: cz - d / 2, maxZ: cz + d / 2, bottom, top, kind, alive: true };
}

interface XYZ { x: number; y: number; z: number }

/** Pushes a vertical cylinder (circle in XZ) out of every solid collider it overlaps. */
export function resolveCircle(pos: XYZ, r: number, h: number, cols: Collider[], step: number): void {
  for (let i = 0; i < cols.length; i++) {
    const c = cols[i];
    if (!c.alive) continue;
    if (pos.y >= c.top - step) continue; // standing on / stepping over
    if (pos.y + h <= c.bottom) continue; // passing underneath
    const cx = clamp(pos.x, c.minX, c.maxX);
    const cz = clamp(pos.z, c.minZ, c.maxZ);
    let dx = pos.x - cx, dz = pos.z - cz;
    const d2 = dx * dx + dz * dz;
    if (d2 >= r * r) continue;
    if (d2 > 1e-8) {
      const d = Math.sqrt(d2);
      const push = (r - d) / d;
      pos.x += dx * push; pos.z += dz * push;
    } else {
      // centre inside box: leave via the shallowest axis
      const l = pos.x - c.minX, rr = c.maxX - pos.x, t = pos.z - c.minZ, b = c.maxZ - pos.z;
      const m = Math.min(l, rr, t, b);
      if (m === l) pos.x = c.minX - r; else if (m === rr) pos.x = c.maxX + r;
      else if (m === t) pos.z = c.minZ - r; else pos.z = c.maxZ + r;
      dx = 0; dz = 0;
    }
  }
}

/** Highest walkable surface below `feet` (+ step tolerance) at x,z. */
export function groundAt(x: number, z: number, r: number, feet: number, cols: Collider[], step: number): number {
  let g = 0;
  const rr = r * 0.6;
  for (let i = 0; i < cols.length; i++) {
    const c = cols[i];
    if (!c.alive) continue;
    if (c.top > g && c.top <= feet + step && x > c.minX - rr && x < c.maxX + rr && z > c.minZ - rr && z < c.maxZ + rr) g = c.top;
  }
  return g;
}

let _t0 = 0, _t1 = 1;
function slab(o: number, d: number, lo: number, hi: number): boolean {
  if (Math.abs(d) < 1e-9) return o >= lo && o <= hi;
  let a = (lo - o) / d, b = (hi - o) / d;
  if (a > b) { const t = a; a = b; b = t; }
  if (a > _t0) _t0 = a;
  if (b < _t1) _t1 = b;
  return _t0 <= _t1;
}
/** Segment (origin + d*t, t in 0..1) vs collider. Returns entry t or -1. */
export function segAABB(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, c: Collider): number {
  _t0 = 0; _t1 = 1;
  if (!slab(ox, dx, c.minX, c.maxX) || !slab(oy, dy, c.bottom, c.top) || !slab(oz, dz, c.minZ, c.maxZ)) return -1;
  return _t0;
}
/** Face normal of the collider face closest to a surface point. */
export function aabbNormal(c: Collider, x: number, y: number, z: number, out: THREE.Vector3): THREE.Vector3 {
  const dl = Math.abs(x - c.minX), dr = Math.abs(x - c.maxX), df = Math.abs(z - c.minZ), db = Math.abs(z - c.maxZ), dt = Math.abs(y - c.top);
  const m = Math.min(dl, dr, df, db, dt);
  out.set(0, 0, 0);
  if (m === dt) out.y = 1; else if (m === dl) out.x = -1; else if (m === dr) out.x = 1; else if (m === df) out.z = -1; else out.z = 1;
  return out;
}
export function segSphere(ox: number, oy: number, oz: number, dx: number, dy: number, dz: number, cx: number, cy: number, cz: number, r: number): number {
  const fx = ox - cx, fy = oy - cy, fz = oz - cz;
  const a = dx * dx + dy * dy + dz * dz;
  if (a < 1e-12) return -1;
  const b = 2 * (fx * dx + fy * dy + fz * dz);
  const c = fx * fx + fy * fy + fz * fz - r * r;
  if (c <= 0) return 0;
  const disc = b * b - 4 * a * c;
  if (disc < 0) return -1;
  const t = (-b - Math.sqrt(disc)) / (2 * a);
  return t >= 0 && t <= 1 ? t : -1;
}
/** Line of sight between two points against solid colliders. */
export function hasLOS(a: XYZ, b: XYZ, cols: Collider[]): boolean {
  const dx = b.x - a.x, dy = b.y - a.y, dz = b.z - a.z;
  for (let i = 0; i < cols.length; i++) {
    const c = cols[i];
    if (!c.alive || c.top < 0.8) continue;
    if (segAABB(a.x, a.y, a.z, dx, dy, dz, c) >= 0) return false;
  }
  return true;
}

// ---------------------------------------------------------------- contracts
export type HurtKind = 'hit' | 'fire' | 'ice' | 'laser' | 'shock' | 'contact';

export interface EProjSpec {
  x: number; y: number; z: number;
  dx: number; dy: number; dz: number;
  speed: number; dmg: number;
  kind: 'seed' | 'fire' | 'ice' | 'bolt' | 'plasma' | 'orb';
  life?: number; radius?: number; gravity?: number; homing?: number; explode?: number;
}

/** What enemies are allowed to know about the running game. */
export interface GameApi {
  playerPos: THREE.Vector3;
  playerVel: THREE.Vector3;
  playerRadius: number;
  playerHeight: number;
  colliders: Collider[];
  rng: Rng;
  fx: Fx;
  sfx: Sfx;
  enemies: Enemy[];
  mapRadius: number;
  time: number;
  difficulty: number;
  captionsOn: boolean;
  fireEnemyProj(spec: EProjSpec): void;
  hurtPlayer(dmg: number, from: THREE.Vector3, kind: HurtKind): void;
  spawnEnemy(id: string, x: number, z: number, opts?: { fromSky?: boolean }): Enemy | null;
  caption(text: string): void;
  shake(amount: number): void;
  spawnCrateDrop(x: number, z: number): void;
  damageEnemy(e: Enemy, dmg: number, silent?: boolean): void;
  /** Area blast: always hurts the player in range, optionally friendly fire on other enemies. */
  blast(x: number, y: number, z: number, radius: number, dmg: number, hurtEnemies?: boolean, color?: number): void;
  /** Sticky glue / frost puddle that slows the player standing in it. */
  stickyZone(x: number, z: number, r: number, life: number, ice?: boolean): void;
  groundMarker(x: number, z: number, r: number, life: number, kind: 'warn' | 'beam'): void;
}
