/**
 * Visual effects: pooled paper-scrap/confetti particles (one instanced draw call),
 * ink-blot decals, expanding rings, ink-ribbon trails and ambient dust/paper moths.
 */
import * as THREE from 'three';
import { Rng, TAU } from './core';
import { T } from './textures';

export const CONFETTI = [0xc92b2b, 0xffd54a, 0x3f8cf0, 0x34c3b0, 0xff8fb8, 0xf3e7cc, 0xff9a2e];
export const KRAFT = [0xb98a52, 0xc4935a, 0x9c703a, 0xd9aa70, 0x8a5f2e];
const UP = new THREE.Vector3(0, 1, 0);
const FWD = new THREE.Vector3(0, 0, 1);

export class Fx {
  readonly mesh: THREE.InstancedMesh;
  private n = 0;
  private cap: number;
  private readonly max: number;
  private pos: Float32Array; private vel: Float32Array; private rot: Float32Array; private spin: Float32Array;
  private life: Float32Array; private maxLife: Float32Array; private size: Float32Array; private grav: Float32Array; private drag: Float32Array; private col: Float32Array;
  private d = new THREE.Object3D();
  private rng = new Rng(1234);
  private rings: RingPool;
  private decals: DecalPool;
  private ambient: Ambient;

  constructor(scene: THREE.Scene, max = 2200) {
    this.max = max; this.cap = max;
    const geo = new THREE.PlaneGeometry(1, 0.6);
    const mat = new THREE.MeshBasicMaterial({ side: THREE.DoubleSide });
    this.mesh = new THREE.InstancedMesh(geo, mat, max);
    this.mesh.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(max * 3), 3);
    this.mesh.frustumCulled = false;
    this.mesh.count = 0;
    scene.add(this.mesh);
    this.pos = new Float32Array(max * 3); this.vel = new Float32Array(max * 3); this.rot = new Float32Array(max * 3); this.spin = new Float32Array(max * 3);
    this.life = new Float32Array(max); this.maxLife = new Float32Array(max); this.size = new Float32Array(max); this.grav = new Float32Array(max); this.drag = new Float32Array(max);
    this.col = new Float32Array(max * 3);
    this.rings = new RingPool(scene, 14);
    this.decals = new DecalPool(scene, 40);
    this.ambient = new Ambient(scene, 80);
  }

  setCap(frac: number) { this.cap = Math.max(100, Math.floor(this.max * frac)); }
  setAmbient(color: number, moths: boolean, visible: boolean) { this.ambient.configure(color, moths, visible); }
  get count() { return this.n; }

  emit(x: number, y: number, z: number, vx: number, vy: number, vz: number, size: number, life: number, grav: number, drag: number, hex: number) {
    let i = this.n;
    if (i >= this.cap) i = Math.floor(this.rng.next() * this.cap); else this.n++;
    const r = this.rng, i3 = i * 3;
    this.pos[i3] = x; this.pos[i3 + 1] = y; this.pos[i3 + 2] = z;
    this.vel[i3] = vx; this.vel[i3 + 1] = vy; this.vel[i3 + 2] = vz;
    this.rot[i3] = r.range(0, TAU); this.rot[i3 + 1] = r.range(0, TAU); this.rot[i3 + 2] = r.range(0, TAU);
    this.spin[i3] = r.range(-12, 12); this.spin[i3 + 1] = r.range(-12, 12); this.spin[i3 + 2] = r.range(-12, 12);
    this.life[i] = life; this.maxLife[i] = life; this.size[i] = size; this.grav[i] = grav; this.drag[i] = drag;
    this.col[i3] = ((hex >> 16) & 255) / 255; this.col[i3 + 1] = ((hex >> 8) & 255) / 255; this.col[i3 + 2] = (hex & 255) / 255;
  }

  burst(x: number, y: number, z: number, n: number, colors: readonly number[], power: number, up = 0.5, size = 0.12, life = 1.2, grav = 9) {
    const r = this.rng;
    for (let i = 0; i < n; i++) {
      const a = r.range(0, TAU), e = r.range(-0.2, 1) , s = power * r.range(0.35, 1);
      this.emit(x, y, z, Math.cos(a) * s * (1 - e * 0.4), (e + up) * s, Math.sin(a) * s * (1 - e * 0.4), size * r.range(0.6, 1.4), life * r.range(0.6, 1.2), grav, 1.2, colors[(r.next() * colors.length) | 0]);
    }
  }
  confetti(x: number, y: number, z: number, n: number, power = 7) { this.burst(x, y, z, n, CONFETTI, power, 0.8, 0.14, 1.8, 7); }
  scraps(x: number, y: number, z: number, n: number, hex = 0xb98a52, power = 4) { this.burst(x, y, z, n, [hex, ...KRAFT], power, 0.5, 0.11, 1.0, 11); }
  sparks(x: number, y: number, z: number, n: number, hex = 0xffd54a) { this.burst(x, y, z, n, [hex, 0xffffff], 6, 0.2, 0.06, 0.35, 4); }

  ring(x: number, y: number, z: number, color: number, maxR: number, dur: number, dir?: THREE.Vector3, hold = false) { this.rings.spawn(x, y, z, color, maxR, dur, dir, hold); }
  blot(x: number, y: number, z: number, nx: number, ny: number, nz: number, color: number, size: number) { this.decals.spawn(x, y, z, nx, ny, nz, color, size); }

  update(dt: number, camPos: THREE.Vector3) {
    const d = this.d;
    let i = 0;
    while (i < this.n) {
      const i3 = i * 3;
      this.life[i] -= dt;
      if (this.life[i] <= 0) {
        // swap-remove keeps the active range contiguous
        const l = --this.n, l3 = l * 3;
        if (i !== l) {
          for (let k = 0; k < 3; k++) { this.pos[i3 + k] = this.pos[l3 + k]; this.vel[i3 + k] = this.vel[l3 + k]; this.rot[i3 + k] = this.rot[l3 + k]; this.spin[i3 + k] = this.spin[l3 + k]; this.col[i3 + k] = this.col[l3 + k]; }
          this.life[i] = this.life[l]; this.maxLife[i] = this.maxLife[l]; this.size[i] = this.size[l]; this.grav[i] = this.grav[l]; this.drag[i] = this.drag[l];
        }
        continue;
      }
      this.vel[i3 + 1] -= this.grav[i] * dt;
      const dr = Math.max(0, 1 - this.drag[i] * dt);
      this.vel[i3] *= dr; this.vel[i3 + 2] *= dr;
      this.pos[i3] += this.vel[i3] * dt; this.pos[i3 + 1] += this.vel[i3 + 1] * dt; this.pos[i3 + 2] += this.vel[i3 + 2] * dt;
      if (this.pos[i3 + 1] < 0.03) {
        this.pos[i3 + 1] = 0.03; this.vel[i3 + 1] *= -0.25; this.vel[i3] *= 0.6; this.vel[i3 + 2] *= 0.6;
        this.spin[i3] *= 0.4; this.spin[i3 + 1] *= 0.4; this.spin[i3 + 2] *= 0.4;
      }
      this.rot[i3] += this.spin[i3] * dt; this.rot[i3 + 1] += this.spin[i3 + 1] * dt; this.rot[i3 + 2] += this.spin[i3 + 2] * dt;
      const fade = Math.min(1, this.life[i] / 0.35);
      d.position.set(this.pos[i3], this.pos[i3 + 1], this.pos[i3 + 2]);
      d.rotation.set(this.rot[i3], this.rot[i3 + 1], this.rot[i3 + 2]);
      d.scale.setScalar(this.size[i] * fade);
      d.updateMatrix();
      this.mesh.setMatrixAt(i, d.matrix);
      i++;
    }
    const ca = this.mesh.instanceColor!.array as Float32Array;
    ca.set(this.col.subarray(0, this.n * 3));
    this.mesh.count = this.n;
    this.mesh.instanceMatrix.needsUpdate = true;
    this.mesh.instanceColor!.needsUpdate = true;
    this.rings.update(dt);
    this.decals.update(dt);
    this.ambient.update(dt, camPos);
  }

  clear() { this.n = 0; this.mesh.count = 0; this.rings.clear(); this.decals.clear(); }
}

// ---------------------------------------------------------------- rings
class RingPool {
  private meshes: THREE.Mesh[] = [];
  private t: Float32Array; private dur: Float32Array; private r: Float32Array; private hold: Uint8Array;
  private next = 0;
  constructor(scene: THREE.Scene, n: number) {
    const geo = new THREE.RingGeometry(0.88, 1, 40); geo.rotateX(-Math.PI / 2);
    for (let i = 0; i < n; i++) {
      const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
      m.visible = false; m.frustumCulled = false; scene.add(m); this.meshes.push(m);
    }
    this.t = new Float32Array(n); this.dur = new Float32Array(n).fill(1); this.r = new Float32Array(n); this.hold = new Uint8Array(n);
  }
  spawn(x: number, y: number, z: number, color: number, maxR: number, dur: number, dir?: THREE.Vector3, hold = false) {
    const i = this.next; this.next = (this.next + 1) % this.meshes.length;
    const m = this.meshes[i];
    m.position.set(x, y, z);
    if (dir) m.quaternion.setFromUnitVectors(UP, dir); else m.quaternion.identity();
    (m.material as THREE.MeshBasicMaterial).color.setHex(color).multiplyScalar(1.6);
    this.t[i] = 0; this.dur[i] = dur; this.r[i] = maxR; this.hold[i] = hold ? 1 : 0;
    m.visible = true;
  }
  update(dt: number) {
    for (let i = 0; i < this.meshes.length; i++) {
      const m = this.meshes[i];
      if (!m.visible) continue;
      this.t[i] += dt;
      const k = this.t[i] / this.dur[i];
      if (k >= 1) { m.visible = false; continue; }
      const mat = m.material as THREE.MeshBasicMaterial;
      if (this.hold[i]) {
        m.scale.setScalar(this.r[i]);
        mat.opacity = 0.35 + 0.35 * Math.sin(this.t[i] * 14);
      } else {
        m.scale.setScalar(Math.max(0.01, this.r[i] * (1 - Math.pow(1 - k, 3))));
        mat.opacity = 1 - k;
      }
    }
  }
  clear() { this.meshes.forEach((m) => (m.visible = false)); }
}

// ---------------------------------------------------------------- ink blots
class DecalPool {
  private meshes: THREE.Mesh[] = [];
  private t: Float32Array; private base: Float32Array;
  private next = 0;
  constructor(scene: THREE.Scene, n: number) {
    const geo = new THREE.PlaneGeometry(1, 1);
    const tex = T.blot();
    for (let i = 0; i < n; i++) {
      const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -4 }));
      m.visible = false; scene.add(m); this.meshes.push(m);
    }
    this.t = new Float32Array(n).fill(99); this.base = new Float32Array(n);
  }
  private nrm = new THREE.Vector3();
  spawn(x: number, y: number, z: number, nx: number, ny: number, nz: number, color: number, size: number) {
    const i = this.next; this.next = (this.next + 1) % this.meshes.length;
    const m = this.meshes[i];
    this.nrm.set(nx, ny, nz).normalize();
    m.position.set(x + this.nrm.x * 0.02, y + this.nrm.y * 0.02, z + this.nrm.z * 0.02);
    m.quaternion.setFromUnitVectors(FWD, this.nrm);
    m.rotateZ(Math.random() * TAU);
    (m.material as THREE.MeshBasicMaterial).color.setHex(color);
    this.t[i] = 0; this.base[i] = size; m.visible = true;
  }
  update(dt: number) {
    for (let i = 0; i < this.meshes.length; i++) {
      const m = this.meshes[i];
      if (!m.visible) continue;
      this.t[i] += dt;
      const t = this.t[i];
      if (t > 9) { m.visible = false; continue; }
      const pop = Math.min(1, t / 0.08), fade = t > 7 ? 1 - (t - 7) / 2 : 1;
      m.scale.setScalar(this.base[i] * pop * (0.85 + 0.15 * fade));
      (m.material as THREE.MeshBasicMaterial).opacity = 0.9 * fade;
    }
  }
  clear() { this.meshes.forEach((m) => (m.visible = false)); }
}

// ---------------------------------------------------------------- ribbons
const RN = 12;
let ribbonMat: THREE.MeshBasicMaterial | null = null;
export class Ribbon {
  readonly mesh: THREE.Mesh;
  private pts = new Float32Array(RN * 3);
  private count = 0;
  private geo = new THREE.BufferGeometry();
  private posA = new Float32Array(RN * 2 * 3);
  private colA = new Float32Array(RN * 2 * 4);
  r = 1; g = 1; b = 1; width = 0.14;
  constructor() {
    this.geo.setAttribute('position', new THREE.BufferAttribute(this.posA, 3));
    this.geo.setAttribute('color', new THREE.BufferAttribute(this.colA, 4));
    const idx: number[] = [];
    for (let i = 0; i < RN - 1; i++) { const a = i * 2; idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2); }
    this.geo.setIndex(idx);
    ribbonMat ??= new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
    this.mesh = new THREE.Mesh(this.geo, ribbonMat);
    this.mesh.frustumCulled = false; this.mesh.visible = false;
  }
  start(x: number, y: number, z: number, hex: number, width: number) {
    this.count = 0; this.width = width;
    this.r = ((hex >> 16) & 255) / 255 * 1.4; this.g = ((hex >> 8) & 255) / 255 * 1.4; this.b = (hex & 255) / 255 * 1.4;
    this.push(x, y, z); this.mesh.visible = true;
  }
  push(x: number, y: number, z: number) {
    if (this.count < RN) this.count++;
    this.pts.copyWithin(3, 0, (RN - 1) * 3);
    this.pts[0] = x; this.pts[1] = y; this.pts[2] = z;
  }
  rebuild(cam: THREE.Vector3) {
    const p = this.pts, n = this.count;
    for (let i = 0; i < RN; i++) {
      const k = Math.min(i, n - 1), pv = Math.max(k - 1, 0), nx = Math.min(k + 1, n - 1);
      const tx = p[nx * 3] - p[pv * 3], ty = p[nx * 3 + 1] - p[pv * 3 + 1], tz = p[nx * 3 + 2] - p[pv * 3 + 2];
      const vx = p[k * 3] - cam.x, vy = p[k * 3 + 1] - cam.y, vz = p[k * 3 + 2] - cam.z;
      let wx = ty * vz - tz * vy, wy = tz * vx - tx * vz, wz = tx * vy - ty * vx;
      const l = Math.hypot(wx, wy, wz) || 1;
      const taper = (1 - i / RN) * (i < n ? 1 : 0);
      const w = (this.width * taper) / l;
      wx *= w; wy *= w; wz *= w;
      const o = i * 6;
      this.posA[o] = p[k * 3] + wx; this.posA[o + 1] = p[k * 3 + 1] + wy; this.posA[o + 2] = p[k * 3 + 2] + wz;
      this.posA[o + 3] = p[k * 3] - wx; this.posA[o + 4] = p[k * 3 + 1] - wy; this.posA[o + 5] = p[k * 3 + 2] - wz;
      const c = i * 8, a = taper * 0.9;
      for (let s = 0; s < 2; s++) { this.colA[c + s * 4] = this.r; this.colA[c + s * 4 + 1] = this.g; this.colA[c + s * 4 + 2] = this.b; this.colA[c + s * 4 + 3] = a; }
    }
    (this.geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
    (this.geo.attributes.color as THREE.BufferAttribute).needsUpdate = true;
  }
  stop() { this.mesh.visible = false; }
}

// ---------------------------------------------------------------- ambient
/** Dust motes (and optionally paper moths) drifting in the light around the camera. */
class Ambient {
  private mesh: THREE.InstancedMesh;
  private p: Float32Array; private ph: Float32Array;
  private d = new THREE.Object3D();
  private moths = true; private time = 0;
  private readonly n: number;
  constructor(scene: THREE.Scene, n: number) {
    this.n = n;
    this.mesh = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.07, 0.05), new THREE.MeshBasicMaterial({ color: 0xffe9b0, transparent: true, opacity: 0.8, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }), n);
    this.mesh.frustumCulled = false;
    scene.add(this.mesh);
    this.p = new Float32Array(n * 3); this.ph = new Float32Array(n);
    const r = new Rng(8);
    for (let i = 0; i < n; i++) { this.p[i * 3] = r.range(-14, 14); this.p[i * 3 + 1] = r.range(0.2, 7); this.p[i * 3 + 2] = r.range(-14, 14); this.ph[i] = r.range(0, TAU); }
  }
  configure(color: number, moths: boolean, visible: boolean) {
    (this.mesh.material as THREE.MeshBasicMaterial).color.setHex(color);
    this.moths = moths; this.mesh.visible = visible;
  }
  update(dt: number, cam: THREE.Vector3) {
    if (!this.mesh.visible) return;
    this.time += dt;
    const d = this.d;
    for (let i = 0; i < this.n; i++) {
      const i3 = i * 3, moth = this.moths && i % 8 === 0;
      this.p[i3] += Math.sin(this.time * 0.4 + this.ph[i]) * dt * (moth ? 1.2 : 0.2);
      this.p[i3 + 1] += Math.cos(this.time * 0.5 + this.ph[i]) * dt * (moth ? 0.8 : 0.1);
      this.p[i3 + 2] += Math.sin(this.time * 0.3 + this.ph[i] * 2) * dt * (moth ? 1.2 : 0.2);
      // wrap around the camera so the cloud follows the player
      for (const k of [0, 2]) { const rel = this.p[i3 + k] - (k === 0 ? cam.x : cam.z); if (rel > 14) this.p[i3 + k] -= 28; else if (rel < -14) this.p[i3 + k] += 28; }
      d.position.set(this.p[i3], this.p[i3 + 1], this.p[i3 + 2]);
      d.rotation.set(0, this.ph[i] + this.time * 0.3, 0);
      const flap = moth ? 2.2 + Math.abs(Math.sin(this.time * 18 + this.ph[i])) * 2.4 : 1;
      d.scale.set(flap, moth ? 1.6 : 1, 1);
      d.updateMatrix();
      this.mesh.setMatrixAt(i, d.matrix);
    }
    this.mesh.instanceMatrix.needsUpdate = true;
  }
}
