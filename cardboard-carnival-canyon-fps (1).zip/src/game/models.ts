/**
 * Shared cardboard model helpers: inked outline hulls, cut-paper shapes, crates, trees, pickups.
 */
import * as THREE from 'three';
import { TAU } from './core';
import { M, T, boxGeo } from './textures';

// ---------------------------------------------------------------- outline
/** Shared time uniform; the outline vertex wobble snaps at 8 fps for a hand-drawn feel. */
export const outlineTime = { value: 0 };
const outlineMat = new THREE.MeshBasicMaterial({ color: 0x141016, side: THREE.BackSide });
outlineMat.onBeforeCompile = (sh) => {
  sh.uniforms.uTime = outlineTime;
  sh.vertexShader = 'uniform float uTime;\n' + sh.vertexShader.replace('#include <begin_vertex>', 'vec3 transformed = position + normal * 0.007 * sin(dot(position, vec3(41.0, 57.0, 33.0)) + floor(uTime * 8.0) * 2.3);');
};
export function setOutlineEnabled(on: boolean) { outlineMat.visible = on; }

/** Shared wind clock (seconds) driving swaying grass. */
export const windTime = outlineTime;

let aoTex: THREE.CanvasTexture | null = null;
/** Soft black radial falloff used for contact shadows under props and creatures. */
export function aoTexture(): THREE.CanvasTexture {
  if (!aoTex) {
    const c = document.createElement('canvas'); c.width = c.height = 128;
    const g = c.getContext('2d')!, gr = g.createRadialGradient(64, 64, 6, 64, 64, 62);
    gr.addColorStop(0, 'rgba(0,0,0,0.9)'); gr.addColorStop(0.5, 'rgba(0,0,0,0.45)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
    aoTex = new THREE.CanvasTexture(c); aoTex.colorSpace = THREE.SRGBColorSpace;
  }
  return aoTex;
}
let aoGeo: THREE.PlaneGeometry | null = null;
const aoMats = new Map<number, THREE.MeshBasicMaterial>();
/** Flat contact-shadow quad lying on the floor. */
export function aoQuad(w: number, d: number, opacity = 0.5): THREE.Mesh {
  aoGeo ??= new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2);
  let m = aoMats.get(opacity);
  if (!m) { m = new THREE.MeshBasicMaterial({ map: aoTexture(), transparent: true, opacity, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 }); aoMats.set(opacity, m); }
  const q = new THREE.Mesh(aoGeo, m); q.scale.set(w, 1, d); q.renderOrder = 1;
  return q;
}

/** Inverted-hull ink outline: a slightly enlarged back-face copy. */
export function addOutline(mesh: THREE.Mesh, t = 0.03): THREE.Mesh {
  const geo = mesh.geometry;
  if (!geo.boundingBox) geo.computeBoundingBox();
  const bb = geo.boundingBox!;
  const sx = 1 + (2 * t) / Math.max(bb.max.x - bb.min.x, 0.05), sy = 1 + (2 * t) / Math.max(bb.max.y - bb.min.y, 0.05), sz = 1 + (2 * t) / Math.max(bb.max.z - bb.min.z, 0.05);
  const cx = (bb.max.x + bb.min.x) / 2, cy = (bb.max.y + bb.min.y) / 2, cz = (bb.max.z + bb.min.z) / 2;
  const hull = new THREE.Mesh(geo, outlineMat);
  hull.scale.set(sx, sy, sz);
  hull.position.set(cx * (1 - sx), cy * (1 - sy), cz * (1 - sz));
  hull.userData.outline = true;
  mesh.add(hull);
  return hull;
}

/** Convenience: mesh + shadow flags (+ optional outline). */
export function mk(geo: THREE.BufferGeometry, mat: THREE.Material | THREE.Material[], opts: { outline?: number; cast?: boolean; receive?: boolean } = {}): THREE.Mesh {
  const m = new THREE.Mesh(geo, mat);
  m.castShadow = opts.cast ?? true; m.receiveShadow = opts.receive ?? true;
  if (opts.outline) addOutline(m, opts.outline);
  return m;
}

// ---------------------------------------------------------------- shapes
export function extrude(shape: THREE.Shape, depth: number, mat: THREE.Material | THREE.Material[], outline = 0.03): THREE.Mesh {
  const g = new THREE.ExtrudeGeometry(shape, { depth, bevelEnabled: false, curveSegments: 14 });
  g.translate(0, 0, -depth / 2);
  return mk(g, mat, { outline });
}
export function leafShape(): THREE.Shape {
  const s = new THREE.Shape();
  s.moveTo(0, 0.85); s.bezierCurveTo(0.62, 0.5, 0.66, -0.1, 0.46, -0.46); s.quadraticCurveTo(0, -0.78, -0.46, -0.46); s.bezierCurveTo(-0.66, -0.1, -0.62, 0.5, 0, 0.85);
  return s;
}
export function petalShape(): THREE.Shape {
  const s = new THREE.Shape();
  s.moveTo(0, 0); s.bezierCurveTo(0.34, 0.15, 0.3, 0.7, 0, 1); s.bezierCurveTo(-0.3, 0.7, -0.34, 0.15, 0, 0);
  return s;
}
export function starShape(r: number, inner = 0.45): THREE.Shape {
  const s = new THREE.Shape();
  for (let i = 0; i < 10; i++) { const a = Math.PI / 2 + (i / 10) * TAU, rr = i % 2 ? r * inner : r; if (i) s.lineTo(Math.cos(a) * rr, Math.sin(a) * rr); else s.moveTo(Math.cos(a) * rr, Math.sin(a) * rr); }
  s.closePath(); return s;
}
export function crescentShape(R: number): THREE.Shape {
  const s = new THREE.Shape();
  s.absarc(0, 0, R, 0.896, TAU - 0.896, false);
  s.absarc(0.45 * R, 0, 0.8 * R, -1.35, 1.35 - TAU, true);
  return s;
}
export function heartShape(): THREE.Shape {
  const s = new THREE.Shape();
  s.moveTo(0, -0.5); s.bezierCurveTo(-0.8, 0, -0.6, 0.6, 0, 0.25); s.bezierCurveTo(0.6, 0.6, 0.8, 0, 0, -0.5);
  return s;
}

/** Flat decal plane (stickers, faces). */
export function decal(tex: THREE.Texture, w: number, h: number, key: string, double = false): THREE.Mesh {
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), M.tex(tex, key, { transparent: true, double }));
  m.receiveShadow = true;
  return m;
}

/** Corrugated disc: edge flutes on the rim, face texture on both flat sides. */
export function disc(radius: number, thick: number, face: THREE.Material, edge = M.edge()): THREE.Mesh {
  const g = new THREE.CylinderGeometry(radius, radius, thick, 32);
  g.rotateX(Math.PI / 2);
  const uv = g.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < 66; i++) uv.setX(i, uv.getX(i) * 6); // torso only: more flutes around the rim
  return mk(g, [edge, face, face], { outline: 0.03 });
}

// ---------------------------------------------------------------- props
export function makeCrate(size: number): THREE.Group {
  const g = new THREE.Group();
  const body = mk(boxGeo(size, size, size, size), M.tex(T.crate(), 'crate', { bump: true }), { outline: 0.035 });
  body.position.y = size / 2;
  g.add(body);
  const ao = aoQuad(size * 2.2, size * 2.2, 0.55); ao.position.y = 0.02; g.add(ao);
  const tapeMat = M.tex(T.tape('#d9b45a'), 'tapeTan');
  const t1 = mk(new THREE.BoxGeometry(size * 1.02, size * 0.012, size * 0.16), tapeMat, { cast: false });
  t1.position.y = size * 1.001;
  const t2 = mk(new THREE.BoxGeometry(size * 0.16, size * 0.012, size * 1.02), tapeMat, { cast: false });
  t2.position.y = size * 1.003;
  g.add(t1, t2);
  return g;
}

let pineGeos: { trunk: THREE.BufferGeometry; c1: THREE.BufferGeometry; c2: THREE.BufferGeometry; c3: THREE.BufferGeometry } | null = null;
/** Low-poly paper pine: instanced trunk + three cone tiers. */
export function pineForest(points: { x: number; z: number; s: number }[]): THREE.Group {
  pineGeos ??= {
    trunk: new THREE.CylinderGeometry(0.18, 0.24, 1.2, 5).translate(0, 0.6, 0),
    c1: new THREE.ConeGeometry(1.5, 2.4, 6).translate(0, 2.2, 0),
    c2: new THREE.ConeGeometry(1.15, 2.1, 6).translate(0, 3.4, 0),
    c3: new THREE.ConeGeometry(0.8, 1.8, 6).translate(0, 4.5, 0),
  };
  const grp = new THREE.Group();
  const mats = [M.paper('#6b4a2b'), M.paper('#2e6b3c'), M.paper('#357a45'), M.paper('#3f8a50')];
  const parts = [pineGeos.trunk, pineGeos.c1, pineGeos.c2, pineGeos.c3];
  const m4 = new THREE.Matrix4();
  parts.forEach((geo, k) => {
    const im = new THREE.InstancedMesh(geo, mats[k], points.length);
    points.forEach((p, i) => { m4.makeScale(p.s, p.s, p.s).setPosition(p.x, 0, p.z); im.setMatrixAt(i, m4); });
    im.castShadow = true; im.receiveShadow = true;
    grp.add(im);
  });
  return grp;
}

export function cactus(h = 1.2): THREE.Group {
  const g = new THREE.Group();
  const mat = M.paper('#4f9a5a');
  const body = mk(new THREE.CapsuleGeometry(0.22, h, 4, 8), mat, { outline: 0.025 }); body.position.y = h / 2 + 0.22;
  const arm = mk(new THREE.CapsuleGeometry(0.1, 0.35, 4, 6), mat, { outline: 0.02 }); arm.position.set(0.32, h * 0.65, 0); arm.rotation.z = -0.5;
  const arm2 = arm.clone(); arm2.position.set(-0.3, h * 0.5, 0); arm2.rotation.z = 0.5;
  const flower = mk(new THREE.SphereGeometry(0.09, 6, 4), M.paper('#ff6fa0'), { cast: false }); flower.position.y = h + 0.5;
  g.add(body, arm, arm2, flower);
  return g;
}

export function palmTree(): THREE.Group {
  const g = new THREE.Group();
  const trunk = mk(new THREE.CylinderGeometry(0.12, 0.2, 2.4, 6), M.paper('#9c703a'), { outline: 0.02 });
  trunk.position.y = 1.2; trunk.rotation.z = 0.15;
  g.add(trunk);
  for (let i = 0; i < 6; i++) {
    const leaf = extrude(petalShape(), 0.03, M.paper('#2f9a58'), 0.02);
    leaf.scale.set(1.2, 1.9, 1);
    leaf.position.set(0.3, 2.4, 0);
    leaf.rotation.set(-1.1, (i / 6) * TAU, 0, 'YXZ');
    g.add(leaf);
  }
  return g;
}

let coinGeo: THREE.BufferGeometry | null = null;
export function coinMesh(): THREE.Mesh {
  coinGeo ??= (() => { const gg = new THREE.CylinderGeometry(0.34, 0.34, 0.07, 20); gg.rotateX(Math.PI / 2); return gg; })();
  const face = M.tex(T.coin(), 'coin');
  const m = new THREE.Mesh(coinGeo, [M.paper('#c99a20'), face, face]);
  m.castShadow = true;
  return m;
}
export function heartMesh(): THREE.Mesh {
  const m = extrude(heartShape(), 0.14, M.paper('#e0384a'), 0.04);
  m.scale.setScalar(0.7);
  return m;
}

/** Instanced helper for static repeated props. */
export function instanced(geo: THREE.BufferGeometry, mat: THREE.Material, xf: { x: number; y: number; z: number; ry?: number; s?: number; sy?: number }[]): THREE.InstancedMesh {
  const im = new THREE.InstancedMesh(geo, mat, xf.length);
  const d = new THREE.Object3D();
  xf.forEach((p, i) => { d.position.set(p.x, p.y, p.z); d.rotation.set(0, p.ry ?? 0, 0); d.scale.set(p.s ?? 1, p.sy ?? p.s ?? 1, p.s ?? 1); d.updateMatrix(); im.setMatrixAt(i, d.matrix); });
  im.castShadow = true; im.receiveShadow = true;
  return im;
}
