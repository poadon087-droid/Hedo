/**
 * Map dressing: the set pieces that turn the two arenas into full carnival-canyon scenes.
 * Everything is built from cardboard primitives; animated pieces register callbacks in `anims`.
 */
import * as THREE from 'three';
import { Rng, TAU, makeCollider, type Collider, type Crate } from './core';
import { M, T, boxGeo } from './textures';
import { disc, extrude, instanced, makeCrate, mk, petalShape, starShape } from './models';

export type Anim = (dt: number, t: number) => void;

const plane = (tex: THREE.Texture, key: string, w: number, h: number) => new THREE.Mesh(new THREE.PlaneGeometry(w, h), M.tex(tex, key, { transparent: true, double: true }));
const rodBetween = (a: THREE.Vector3, b: THREE.Vector3, r: number, mat: THREE.Material) => {
  const len = a.distanceTo(b), m = new THREE.Mesh(new THREE.CylinderGeometry(r, r, len, 5), mat);
  m.position.copy(a).lerp(b, 0.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.clone().sub(a).normalize());
  return m;
};

/** Remove random crates that ended up inside freshly added scenery. */
function cullCrates(cols: Collider[], crates: Crate[], start: number) {
  for (let i = crates.length - 1; i >= 0; i--) {
    const c = crates[i].collider;
    for (let j = start; j < cols.length; j++) {
      const o = cols[j];
      if (c.minX < o.maxX + 0.7 && c.maxX > o.minX - 0.7 && c.minZ < o.maxZ + 0.7 && c.maxZ > o.minZ - 0.7) {
        c.alive = false; crates[i].mesh.visible = false;
        const k = cols.indexOf(c); if (k >= 0) { cols.splice(k, 1); start--; }
        crates.splice(i, 1); break;
      }
    }
  }
}

// ------------------------------------------------------------------ shared set pieces
/** A raised lookout platform reached by a climbable three-step stair (steps are 0.4 m, step-up is 0.45 m). */
function stairPlatform(root: THREE.Group, cols: Collider[], cx: number, cz: number, dir: number, night: boolean) {
  const base = night ? '#8a4a3e' : '#c4935a', step = night ? '#96593f' : '#d09f66';
  const box = (x: number, w: number, d: number, h: number, color: string) => {
    const b = mk(boxGeo(w, h, d, 2.2), M.paper(color), { outline: 0.03 });
    b.position.set(x, h / 2, cz); root.add(b); cols.push(makeCollider(x, cz, w, d, 0, h, 'wall'));
  };
  box(cx, 4.6, 6, 1.6, base);
  const fx = cx + dir * 2.3;
  box(fx + dir * 0.5, 1, 2.4, 1.2, step); box(fx + dir * 1.5, 1, 2.4, 0.8, step); box(fx + dir * 2.5, 1, 2.4, 0.4, step);
  const tape = mk(new THREE.BoxGeometry(4.7, 0.03, 0.5), M.tex(T.tape(night ? '#33d6ff' : '#e0b84a'), night ? 'tapeC' : 'tapeY'), { cast: false });
  tape.position.set(cx, 1.61, cz); root.add(tape);
  const wood = M.paper('#7a4e2a');
  ([[-dir * 2.2, -2.8], [-dir * 2.2, 0], [-dir * 2.2, 2.8], [0, -2.9], [0, 2.9], [dir * 2.2, -2.8], [dir * 2.2, 2.8]] as [number, number][]).forEach(([ox, oz]) => {
    const p = mk(new THREE.BoxGeometry(0.16, 0.9, 0.16), wood, { outline: 0.02 }); p.position.set(cx + ox, 2.05, cz + oz); root.add(p);
  });
  const back = mk(new THREE.BoxGeometry(0.1, 0.1, 5.6), wood); back.position.set(cx - dir * 2.2, 2.35, cz); root.add(back);
  for (const s of [-1, 1]) { const r = mk(new THREE.BoxGeometry(4.4, 0.1, 0.1), wood); r.position.set(cx, 2.35, cz + s * 2.9); root.add(r); }
  const pole = mk(new THREE.CylinderGeometry(0.06, 0.06, 4.2, 6), wood); pole.position.set(cx - dir * 1.8, 3.7, cz - 2.4); root.add(pole);
  const ban = plane(T.banner(), 'banner', 1.3, 2.6); ban.position.set(cx - dir * 1.8 + 0.7, 4.4, cz - 2.4); root.add(ban);
  if (night) { const n = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.08, 5.8), M.glow(0x33d6ff, 2.6)); n.position.set(cx + dir * 2.31, 1.55, cz); root.add(n); }
}

/** Market stall with a striped awning, sign, goods and (at night) bulbs. */
function stall(root: THREE.Group, cols: Collider[], x: number, z: number, night: boolean, label: string) {
  const g = new THREE.Group();
  const counter = mk(boxGeo(2.2, 0.95, 0.9, 1), M.paper('#a8703c'), { outline: 0.03 }); counter.position.set(0, 0.475, 0.2); g.add(counter);
  const top = mk(new THREE.BoxGeometry(2.4, 0.1, 1.1), M.paper('#d8b27a'), { outline: 0.03 }); top.position.set(0, 1.0, 0.2); g.add(top);
  for (const s of [-1, 1]) { const p = mk(new THREE.BoxGeometry(0.12, 2.6, 0.12), M.paper('#7a4e2a')); p.position.set(s * 1.1, 1.3, -0.3); g.add(p); }
  const awn = mk(boxGeo(2.7, 0.08, 1.8, 1), M.tex(T.stripesRW(), 'rwAwn'), { outline: 0.03 }); awn.position.set(0, 2.55, 0.1); awn.rotation.x = 0.28; g.add(awn);
  const sign = plane(T.sign(label), 'sign' + label, 1.8, 0.9); sign.position.set(0, 3.15, -0.3); g.add(sign);
  for (let i = 0; i < 3; i++) { const c = mk(new THREE.CylinderGeometry(0.13, 0.09, 0.26, 10), M.tex(T.stripesRW(), 'rwAwn'), { outline: 0.015 }); c.position.set(0.2 + i * 0.3, 1.18, 0.2); g.add(c); }
  const cr = makeCrate(0.45); cr.position.set(-0.8, 1.05, 0.2); g.add(cr);
  if (night) for (let i = 0; i < 7; i++) { const b = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 4), M.glow([0xff3b5c, 0xffd54a, 0x33d6ff][i % 3], 2.6)); b.position.set(-1.2 + i * 0.4, 2.42 - 0.03, 0.95); g.add(b); }
  g.position.set(x, 0, z); root.add(g);
  cols.push(makeCollider(x, z + 0.2, 2.5, 1.2, 0, 1.05, 'prop'));
}

/** Triangle flags on a sagging rope between two points. */
function bunting(root: THREE.Group, a: THREE.Vector3, b: THREE.Vector3, count: number, sag: number, colors: number[]) {
  const tri = new THREE.BufferGeometry(); tri.setAttribute('position', new THREE.Float32BufferAttribute([-0.2, 0, 0, 0.2, 0, 0, 0, -0.44, 0], 3)); tri.computeVertexNormals();
  const mat = new THREE.MeshToonMaterial({ side: THREE.DoubleSide }); const im = new THREE.InstancedMesh(tri, mat, count);
  const d = new THREE.Object3D(), col = new THREE.Color(), phi = Math.atan2(b.x - a.x, b.z - a.z), pts: THREE.Vector3[] = [];
  for (let i = 0; i < count; i++) {
    const u = (i + 0.5) / count, p = a.clone().lerp(b, u); p.y -= Math.sin(u * Math.PI) * sag;
    d.position.copy(p); d.rotation.set(0, phi - Math.PI / 2, 0); d.updateMatrix(); im.setMatrixAt(i, d.matrix); im.setColorAt(i, col.setHex(colors[i % colors.length]));
  }
  for (let i = 0; i <= 14; i++) { const u = i / 14, p = a.clone().lerp(b, u); p.y -= Math.sin(u * Math.PI) * sag; pts.push(p); }
  root.add(im, new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), 24, 0.025, 4), M.paper('#5a3a1e')));
}

/** Bouncing, rolling balls on a ring (tumbleweeds by day, beach balls at night). */
function rollers(root: THREE.Group, anims: Anim[], rng: Rng, n: number, ringR: number, size: number, night: boolean) {
  for (let i = 0; i < n; i++) {
    const geo = night ? new THREE.SphereGeometry(size, 16, 12) : new THREE.IcosahedronGeometry(size, 1);
    const m = mk(geo, night ? M.tex(T.stripesRW(), 'rwBall') : M.paper(i % 2 ? '#b08a5a' : '#9c703a'), { outline: 0.03 });
    const a0 = rng.range(0, TAU), sp = rng.range(0.7, 1.3) * (i % 2 ? 1 : -1), r = ringR + rng.range(-1.2, 0.5), ph = rng.range(0, TAU);
    root.add(m);
    anims.push((_, t) => {
      const a = a0 + sp * t * 0.12;
      m.position.set(Math.cos(a) * r, size + Math.abs(Math.sin(t * 2.2 + ph)) * size * 0.9, Math.sin(a) * r);
      m.rotation.x = -t * sp * 3; m.rotation.z = t * 1.3;
    });
  }
}

function hotAirBalloons(root: THREE.Group, anims: Anim[], rng: Rng, spots: [number, number, number][]) {
  spots.forEach(([x, y, z], i) => {
    const g = new THREE.Group();
    const env = mk(new THREE.SphereGeometry(3, 18, 14), i % 2 ? M.tex(T.stripesRW(), 'rwBall') : M.paper('#ff9a1e'), { outline: 0.02, cast: false, receive: false }); env.scale.y = 1.2; env.position.y = 4.4; g.add(env);
    const basket = mk(boxGeo(1.1, 0.8, 1.1, 0.8), M.paper('#a8703c'), { outline: 0.03, cast: false }); basket.position.y = 0.4; g.add(basket);
    for (const sx of [-1, 1]) for (const sz of [-1, 1]) g.add(rodBetween(new THREE.Vector3(sx * 0.5, 0.8, sz * 0.5), new THREE.Vector3(sx * 1.5, 2.6, sz * 1.5), 0.02, M.paper('#5a3a1e')));
    const flame = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.6, 8), M.glow(0xff9a2e, 2.6)); flame.position.y = 1.7; g.add(flame);
    g.position.set(x, y, z); root.add(g);
    const ph = rng.range(0, TAU);
    anims.push((_, t) => { g.position.set(x + Math.sin(t * 0.07 + ph) * 8, y + Math.sin(t * 0.3 + ph) * 1.6, z + Math.cos(t * 0.05 + ph) * 5); g.rotation.y = t * 0.05; flame.scale.y = 1 + Math.sin(t * 17 + ph) * 0.25; });
  });
}

function paperBirds(root: THREE.Group, anims: Anim[], rng: Rng, n: number, color: string) {
  const wing = (s: number) => { const sh = new THREE.Shape(); sh.moveTo(0, 0); sh.lineTo(1.1 * s, -0.25); sh.lineTo(0.2 * s, 0.45); sh.closePath(); const g = new THREE.ExtrudeGeometry(sh, { depth: 0.02, bevelEnabled: false }); g.rotateX(-Math.PI / 2); return g; };
  const mat = M.paper(color).clone(); mat.side = THREE.DoubleSide;
  const gl = wing(-1), gr = wing(1);
  for (let i = 0; i < n; i++) {
    const grp = new THREE.Group(), wl = new THREE.Mesh(gl, mat), wr = new THREE.Mesh(gr, mat);
    const body = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.6, 4), mat); body.rotation.x = -Math.PI / 2; grp.add(wl, wr, body); root.add(grp);
    const a0 = rng.range(0, TAU), sp = rng.range(0.05, 0.09), r = rng.range(38, 54), y = rng.range(20, 34), ph = rng.range(0, TAU);
    anims.push((_, t) => {
      const a = a0 + t * sp; grp.position.set(Math.cos(a) * r, y + Math.sin(t * 0.6 + ph) * 1.5, Math.sin(a) * r); grp.rotation.y = Math.PI - a;
      const f = Math.sin(t * 7 + ph) * 0.6; wl.rotation.z = -f; wr.rotation.z = f;
    });
  }
}

function floorEmblem(root: THREE.Group, night: boolean) {
  const m = new THREE.Mesh(new THREE.CircleGeometry(9.5, 48), new THREE.MeshBasicMaterial({ map: T.emblem(night), transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2, toneMapped: !night, color: night ? new THREE.Color(1.7, 1.7, 1.7) : 0xffffff }));
  m.rotation.x = -Math.PI / 2; m.position.y = 0.03; root.add(m);
}

// ------------------------------------------------------------------ canyon
function sunflowerRim(root: THREE.Group, rng: Rng, n: number) {
  const petalGeo = new THREE.ExtrudeGeometry(petalShape(), { depth: 0.05, bevelEnabled: false });
  const per = 14, im = new THREE.InstancedMesh(petalGeo, M.paper('#ff9a1e'), n * per);
  im.castShadow = true;
  const flowerM = new THREE.Matrix4(), petalM = new THREE.Matrix4(), m = new THREE.Matrix4(), q = new THREE.Quaternion(), e = new THREE.Euler(), s = new THREE.Vector3(), p = new THREE.Vector3(), col = new THREE.Color();
  let idx = 0;
  for (let f = 0; f < n; f++) {
    const a = (f / n) * TAU + rng.range(-0.1, 0.1), r = rng.range(31.2, 32), h = rng.range(3.6, 6), R = rng.range(1.0, 1.5);
    const x = Math.cos(a) * r, z = Math.sin(a) * r, yaw = Math.atan2(-x, -z);
    const stem = mk(new THREE.CylinderGeometry(0.1, 0.14, h, 6), M.paper('#4f8a3a'), { outline: 0.02 }); stem.position.set(x, h / 2, z); root.add(stem);
    for (const sd of [-1, 1]) { const leaf = extrude(petalShape(), 0.04, M.paper('#4f8a3a'), 0.02); leaf.scale.set(0.5, 1.0, 1); leaf.position.set(x, h * 0.4, z); leaf.rotation.set(0, yaw + sd * 1.4, -sd * 0.9, 'YXZ'); root.add(leaf); }
    const hp = new THREE.Vector3(x, h, z), qh = new THREE.Quaternion().setFromEuler(e.set(-0.25, yaw, 0, 'YXZ'));
    flowerM.compose(hp, qh, s.set(R, R, R));
    for (let k = 0; k < per; k++) {
      const pa = (k / per) * TAU;
      petalM.compose(p.set(Math.cos(pa) * 0.5, Math.sin(pa) * 0.5, k % 2 ? -0.05 : 0), q.setFromEuler(e.set(0, 0, pa - Math.PI / 2)), s.set(0.55, 0.7, 1));
      m.multiplyMatrices(flowerM, petalM); im.setMatrixAt(idx, m); im.setColorAt(idx, col.setHex(k % 2 ? 0xffffff : 0xffe0a0)); idx++;
    }
    const face = disc(0.5 * R, 0.25 * R, M.tex(T.sunFace(), 'sunFace'), M.edge('#9a6a3a')); face.position.copy(hp); face.quaternion.copy(qh); face.translateZ(0.05); root.add(face);
  }
  root.add(im);
}

function windmill(root: THREE.Group, cols: Collider[], anims: Anim[], x: number, z: number) {
  const g = new THREE.Group();
  const tower = mk(new THREE.CylinderGeometry(0.9, 1.35, 5, 8), [M.paper('#d8b27a'), M.edge(), M.edge()], { outline: 0.03 }); tower.position.y = 2.5; g.add(tower);
  const cap = mk(new THREE.ConeGeometry(1.1, 1.2, 8), M.paper('#c92b2b'), { outline: 0.03 }); cap.position.y = 5.6; g.add(cap);
  const hubG = new THREE.Group(); hubG.position.set(0, 4.7, 1.15); g.add(hubG);
  hubG.add(mk(new THREE.CylinderGeometry(0.22, 0.22, 0.3, 10), M.paper('#e8b830'), { outline: 0.02 }).rotateX(Math.PI / 2));
  for (let i = 0; i < 4; i++) {
    const arm = new THREE.Group(); arm.rotation.z = (i / 4) * TAU;
    const blade = mk(boxGeo(0.7, 2.6, 0.06, 1), M.tex(T.stripesRW(), 'rwBall'), { outline: 0.02 }); blade.position.y = 1.7; arm.add(blade);
    const spar = mk(new THREE.BoxGeometry(0.1, 3.0, 0.1), M.paper('#7a4e2a')); spar.position.y = 1.5; arm.add(spar);
    hubG.add(arm);
  }
  const dr = mk(new THREE.BoxGeometry(0.8, 1.3, 0.1), M.paper('#7a4e2a'), { outline: 0.02 }); dr.position.set(0, 0.65, 1.2); g.add(dr);
  g.position.set(x, 0, z); g.rotation.y = Math.atan2(-x, -z); root.add(g);
  cols.push(makeCollider(x, z, 2.6, 2.6, 0, 5, 'pillar'));
  anims.push((_, t) => { hubG.rotation.z = -t * 0.9; });
}

function godRays(root: THREE.Group, anims: Anim[], rng: Rng, sunDir: THREE.Vector3) {
  const mat = new THREE.MeshBasicMaterial({ map: T.ray(), color: 0xffd9a0, transparent: true, opacity: 0.16, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false, toneMapped: false });
  const geo = new THREE.PlaneGeometry(5, 90), rays: THREE.Group[] = [];
  const up = new THREE.Vector3(0, 1, 0);
  for (let i = 0; i < 7; i++) {
    const g = new THREE.Group();
    for (let k = 0; k < 2; k++) { const m = new THREE.Mesh(geo, mat); m.rotation.y = k * Math.PI / 2; g.add(m); }
    g.quaternion.setFromUnitVectors(up, sunDir);
    g.position.set(rng.range(-30, 30), 38, rng.range(-30, 20)).addScaledVector(sunDir, 0);
    g.scale.x = rng.range(0.7, 1.8); root.add(g); rays.push(g);
  }
  anims.push((_, t) => { mat.opacity = 0.13 + Math.sin(t * 0.4) * 0.04; rays.forEach((g, i) => { g.rotateY(0.0008 * (i % 2 ? 1 : -1)); }); });
}

function barrels(root: THREE.Group, cols: Collider[], pts: [number, number][]) {
  const geo = new THREE.CylinderGeometry(0.45, 0.45, 1, 14), tapeM = M.tex(T.tape('#e0b84a'), 'tapeY');
  pts.forEach(([x, z], i) => {
    const b = mk(geo, [M.paper('#b98550'), M.edge(), M.edge()], { outline: 0.03 }); b.position.set(x, 0.5, z); b.rotation.y = i; root.add(b);
    for (const y of [0.28, 0.72]) { const r = new THREE.Mesh(new THREE.TorusGeometry(0.46, 0.03, 5, 16), tapeM); r.rotation.x = Math.PI / 2; r.position.set(x, y, z); root.add(r); }
    cols.push(makeCollider(x, z, 0.9, 0.9, 0, 1, 'prop'));
  });
}

function campfire(root: THREE.Group, cols: Collider[], anims: Anim[], x: number, z: number) {
  const g = new THREE.Group();
  for (let i = 0; i < 5; i++) { const l = mk(new THREE.CylinderGeometry(0.08, 0.08, 0.9, 5), M.paper('#6b4a2b'), { outline: 0.02 }); l.rotation.z = Math.PI / 2; l.rotation.y = (i / 5) * Math.PI; l.position.y = 0.12; g.add(l); }
  const flames: THREE.Mesh[] = [];
  for (let i = 0; i < 3; i++) { const f = new THREE.Mesh(new THREE.ConeGeometry(0.22 - i * 0.04, 0.8 + i * 0.2, 6), M.glow(i ? 0xffd54a : 0xff6a1a, 2.4)); f.position.set((i - 1) * 0.12, 0.5, (i % 2) * 0.1); g.add(f); flames.push(f); }
  const light = new THREE.PointLight(0xff9a40, 30, 14, 2); light.position.y = 1; g.add(light);
  g.position.set(x, 0, z); root.add(g); cols.push(makeCollider(x, z, 1.1, 1.1, 0, 0.3, 'prop'));
  anims.push((_, t) => { flames.forEach((f, i) => { f.scale.set(1, 0.8 + Math.sin(t * 13 + i * 2) * 0.25, 1); }); light.intensity = 26 + Math.sin(t * 17) * 5 + Math.sin(t * 9) * 3; });
}

function fenceRing(root: THREE.Group, radius: number, color: string, glow: boolean) {
  const posts: { x: number; y: number; z: number; sy: number }[] = [];
  for (let i = 0; i < 60; i++) { const a = (i / 60) * TAU; posts.push({ x: Math.cos(a) * radius, y: 0.6, z: Math.sin(a) * radius, sy: 1.2 }); }
  root.add(instanced(new THREE.BoxGeometry(0.22, 1, 0.22), M.paper(color), posts));
  for (const h of [0.45, 0.95]) { const t = new THREE.Mesh(new THREE.TorusGeometry(radius, 0.05, 5, 120), glow ? M.glow(h < 0.6 ? 0x33d6ff : 0xff3b5c, 2.6) : M.paper(color)); t.rotation.x = Math.PI / 2; t.position.y = h; root.add(t); }
}

export function dressCanyon(root: THREE.Group, rng: Rng, cols: Collider[], crates: Crate[], anims: Anim[], sunDir: THREE.Vector3) {
  const start = cols.length;
  floorEmblem(root, false);
  stairPlatform(root, cols, -26, 2, 1, false);
  stall(root, cols, -11.5, 15, false, 'SALOON'); stall(root, cols, 5.5, 15, false, 'COINS');
  windmill(root, cols, anims, -8, -27);
  campfire(root, cols, anims, -23, -12.5);
  barrels(root, cols, [[-20.5, -15], [-21.4, -16.2], [-19.8, -16.4], [-27, -14.5], [15, -17.5], [15.9, -18.4], [21.5, -17.2], [-4, 21.5]]);
  fenceRing(root, 30.3, '#c4935a', false);
  sunflowerRim(root, rng, 14);
  // painted signposts
  ([[-6, 8, 'COINS', 0.5], [16, 2, 'DANGER', -0.6], [-16, -10, 'WEST', 0.9]] as [number, number, string, number][]).forEach(([x, z, label, ry]) => {
    const g = new THREE.Group(), post = mk(new THREE.CylinderGeometry(0.07, 0.09, 2.2, 6), M.paper('#7a4e2a'), { outline: 0.02 }); post.position.y = 1.1; g.add(post);
    const board = plane(T.sign(label), 'sign' + label, 1.5, 0.75); board.position.set(0, 1.9, 0.1); g.add(board);
    const back = mk(new THREE.BoxGeometry(1.5, 0.75, 0.06), M.paper('#9c6a3a'), { outline: 0.02 }); back.position.set(0, 1.9, 0.04); g.add(back);
    g.position.set(x, 0, z); g.rotation.y = ry; root.add(g);
  });
  bunting(root, new THREE.Vector3(-27.5, 4.1, -20.5), new THREE.Vector3(18, 7.5, -20), 36, 4.5, [0xc92b2b, 0xffd54a, 0x3f8cf0, 0x34c3b0, 0xff8fb8]);
  bunting(root, new THREE.Vector3(-26, 4.2, -2), new THREE.Vector3(-18, 4, -14), 14, 2, [0xc92b2b, 0xffd54a, 0xf3e7cc]);
  rollers(root, anims, rng, 6, 26.8, 0.55, false);
  hotAirBalloons(root, anims, rng, [[-60, 34, -70], [55, 40, -85], [70, 30, 20]]);
  paperBirds(root, anims, rng, 9, '#f3e7cc');
  godRays(root, anims, rng, sunDir);
  cullCrates(cols, crates, start);
}

// ------------------------------------------------------------------ night carnival
interface Win { x: number; y: number; z: number; ry: number }

function tower(root: THREE.Group, wins: Win[], rng: Rng, x: number, z: number, w: number, d: number, floors: number, color: string): number {
  let y = 0; const fh = 3.2;
  for (let f = 0; f < floors; f++) {
    const ww = w - f * 0.4, dd = d - f * 0.4;
    const b = mk(boxGeo(ww, fh, dd, 2.4), M.paper(color), { outline: 0.03, cast: false }); b.position.set(x, y + fh / 2, z); root.add(b);
    const nx = Math.max(1, Math.floor(ww / 1.8)), nz = Math.max(1, Math.floor(dd / 1.8)), wy = y + fh * 0.55;
    for (let i = 0; i < nx; i++) { const ox = ((i + 0.5) / nx) * ww - ww / 2; if (rng.chance(0.75)) wins.push({ x: x + ox, y: wy, z: z + dd / 2 + 0.02, ry: 0 }); if (rng.chance(0.75)) wins.push({ x: x + ox, y: wy, z: z - dd / 2 - 0.02, ry: Math.PI }); }
    for (let i = 0; i < nz; i++) { const oz = ((i + 0.5) / nz) * dd - dd / 2; if (rng.chance(0.75)) wins.push({ x: x + ww / 2 + 0.02, y: wy, z: z + oz, ry: Math.PI / 2 }); if (rng.chance(0.75)) wins.push({ x: x - ww / 2 - 0.02, y: wy, z: z + oz, ry: -Math.PI / 2 }); }
    y += fh;
  }
  return y;
}

/** A floating cardboard city block with lit windows, a neon sign facing the arena, a banner and a blinking mast. */
function chunk(root: THREE.Group, wins: Win[], anims: Anim[], rng: Rng, x: number, z: number, w: number, d: number, floors: number, color: string, neon: number) {
  const base = mk(boxGeo(w + 1.2, 1.6, d + 1.2, 2.4), M.paper('#6a4a3a'), { outline: 0.03, cast: false }); base.position.set(x, -0.8, z); root.add(base);
  const under = mk(new THREE.ConeGeometry(Math.max(w, d) * 0.62, 9, 7), M.paper('#5a3f32'), { cast: false, receive: false }); under.rotation.x = Math.PI; under.position.set(x, -6.1, z); root.add(under);
  const top = tower(root, wins, rng, x, z, w, d, floors, color);
  const star = extrude(starShape(0.9), 0.2, [M.glow(0xffe08a, 1.8), M.paper('#e8b25a')], 0.02); star.position.set(x, top + 1.2, z); root.add(star);
  const mast = mk(new THREE.CylinderGeometry(0.05, 0.05, 2.2, 5), M.paper('#33353a')); mast.position.set(x + w * 0.25, top + 1.1, z); root.add(mast);
  const blink = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 6), M.glow(0xff2a4a, 3)); blink.position.set(x + w * 0.25, top + 2.3, z); root.add(blink);
  const hex = '#' + neon.toString(16).padStart(6, '0');
  const sign = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 2.4), new THREE.MeshBasicMaterial({ map: T.neonArrow(hex), toneMapped: false, color: new THREE.Color(1.7, 1.7, 1.7) }));
  const ban = plane(T.banner(), 'banner', 1.4, 2.8);
  if (Math.abs(x) > Math.abs(z)) { const sx = Math.sign(x), off = w / 2 + 0.05; sign.position.set(x - sx * off, 4.8, z - d * 0.2); sign.rotation.y = -sx * Math.PI / 2; ban.position.set(x - sx * off, 3.4, z + d * 0.28); ban.rotation.y = -sx * Math.PI / 2; }
  else { const sz = Math.sign(z), off = d / 2 + 0.05; sign.position.set(x - w * 0.2, 4.8, z - sz * off); sign.rotation.y = sz > 0 ? Math.PI : 0; ban.position.set(x + w * 0.28, 3.4, z - sz * off); ban.rotation.y = sz > 0 ? Math.PI : 0; }
  root.add(sign, ban);
  const ph = rng.range(0, TAU);
  anims.push((_, t) => { star.rotation.y = t * 1.2 + ph; blink.visible = Math.sin(t * 5 + ph) > 0; sign.scale.setScalar(1 + Math.sin(t * 4 + ph) * 0.04); });
  return top;
}

function ferrisWheel(root: THREE.Group, anims: Anim[], x: number, z: number) {
  const R = 8.5, hubY = R + 2.4, outer = new THREE.Group(); outer.position.set(x, hubY, z); outer.rotation.y = Math.PI / 2;
  const wheel = new THREE.Group(); outer.add(wheel);
  const redM = M.paper('#c92b2b');
  for (const rr of [R, R * 0.55]) wheel.add(mk(new THREE.TorusGeometry(rr, 0.12, 6, 44), redM, { outline: 0.02, cast: false }));
  for (let i = 0; i < 6; i++) { const sp = mk(new THREE.BoxGeometry(0.12, R * 2, 0.12), M.paper('#f3e7cc'), { cast: false }); sp.rotation.z = (i / 6) * Math.PI; wheel.add(sp); }
  wheel.add(mk(new THREE.CylinderGeometry(0.5, 0.5, 0.9, 12), M.paper('#e8b830'), { outline: 0.03, cast: false }).rotateX(Math.PI / 2));
  const bulbs = new THREE.InstancedMesh(new THREE.SphereGeometry(0.12, 6, 4), M.glow(0xffffff, 2.4), 40), col = new THREE.Color(), d = new THREE.Object3D();
  for (let i = 0; i < 40; i++) { const a = (i / 40) * TAU; d.position.set(Math.cos(a) * R, Math.sin(a) * R, 0.15); d.updateMatrix(); bulbs.setMatrixAt(i, d.matrix); bulbs.setColorAt(i, col.setHex([0xff3b5c, 0xffd54a, 0x33d6ff, 0xff35c8][i % 4])); }
  wheel.add(bulbs);
  const gondolas: THREE.Group[] = [];
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * TAU, gd = new THREE.Group();
    const cab = mk(boxGeo(1.2, 0.9, 0.9, 0.9), M.paper(['#c92b2b', '#3f8cf0', '#e8b830', '#34c3b0'][i % 4]), { outline: 0.03, cast: false }); cab.position.y = -0.8; gd.add(cab);
    const roof = mk(new THREE.ConeGeometry(0.85, 0.5, 4), M.paper('#f3e7cc'), { outline: 0.02, cast: false }); roof.position.y = -0.1; roof.rotation.y = Math.PI / 4; gd.add(roof);
    const win = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.4), M.glow(0xffe9a0, 2)); win.position.set(0, -0.75, 0.46); gd.add(win);
    gd.position.set(Math.cos(a) * R, Math.sin(a) * R, 0.1); wheel.add(gd); gondolas.push(gd);
  }
  const L = Math.hypot(3.4, hubY);
  for (const s of [-1, 1]) for (const zz of [-0.9, 0.9]) { const leg = mk(new THREE.BoxGeometry(0.26, L, 0.26), M.paper('#8a5a32'), { outline: 0.03, cast: false }); leg.position.set(s * 1.7, -hubY / 2, zz); leg.rotation.z = s * Math.atan2(3.4, hubY); outer.add(leg); }
  root.add(outer);
  anims.push((_, t) => { wheel.rotation.z = -t * 0.12; gondolas.forEach((g) => { g.rotation.z = t * 0.12; }); });
}

function crane(root: THREE.Group, anims: Anim[], x: number, z: number, baseY: number) {
  const g = new THREE.Group(); g.position.set(x, baseY, z);
  const mast = mk(new THREE.BoxGeometry(0.6, 16, 0.6), M.paper('#c92b2b'), { outline: 0.03, cast: false }); mast.position.y = 8; g.add(mast);
  const jibG = new THREE.Group(); jibG.position.y = 16; g.add(jibG);
  const jib = mk(new THREE.BoxGeometry(12, 0.5, 0.5), M.paper('#c92b2b'), { outline: 0.03, cast: false }); jib.position.x = -3; jibG.add(jib);
  const lamps = new THREE.InstancedMesh(new THREE.SphereGeometry(0.14, 6, 4), M.glow(0xffffff, 2.4), 14), col = new THREE.Color(), d = new THREE.Object3D();
  for (let i = 0; i < 14; i++) { d.position.set(-9 + i * 0.85, -0.45 - Math.sin((i / 13) * Math.PI) * 0.3, 0); d.updateMatrix(); lamps.setMatrixAt(i, d.matrix); lamps.setColorAt(i, col.setHex([0xff3b5c, 0xffd54a, 0x33d6ff][i % 3])); }
  jibG.add(lamps);
  const cable = mk(new THREE.CylinderGeometry(0.03, 0.03, 5, 4), M.paper('#33353a')); cable.position.set(-7, -2.5, 0); jibG.add(cable);
  const hook = makeCrate(1.0); hook.position.set(-7, -6, 0); jibG.add(hook);
  root.add(g);
  anims.push((_, t) => { jibG.rotation.y = Math.sin(t * 0.15) * 0.5; hook.position.y = -6 + Math.sin(t * 0.8) * 0.5; });
}

function spotlights(root: THREE.Group, anims: Anim[], pts: THREE.Vector3[]) {
  const geo = new THREE.CylinderGeometry(3.4, 0.1, 70, 14, 1, true); geo.translate(0, 35, 0);
  pts.forEach((p, i) => {
    const g = new THREE.Group(); g.position.copy(p);
    g.add(new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ color: [0xffe9a0, 0x6ac8ff, 0xff7ac8][i % 3], transparent: true, opacity: 0.13, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false, toneMapped: false })));
    root.add(g); anims.push((_, t) => { g.rotation.x = Math.sin(t * 0.5 + i * 2) * 0.55; g.rotation.z = Math.cos(t * 0.4 + i) * 0.55; });
  });
}

function bannerPoles(root: THREE.Group, anims: Anim[]) {
  [0.8, 2.4, 3.9, 5.5].forEach((a, i) => {
    const x = Math.cos(a) * 29.2, z = Math.sin(a) * 29.2, g = new THREE.Group();
    const pole = mk(new THREE.CylinderGeometry(0.1, 0.12, 9, 6), M.paper('#8a5a32'), { outline: 0.03 }); pole.position.y = 4.5; g.add(pole);
    const ban = plane(T.banner(), 'banner', 2.2, 4.4); ban.position.set(1.2, 6.4, 0); g.add(ban);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 6), M.glow(0xffd54a, 2.6)); cap.position.y = 9.1; g.add(cap);
    g.position.set(x, 0, z); g.rotation.y = Math.atan2(-x, -z) + Math.PI / 2; root.add(g);
    anims.push((_, t) => { ban.rotation.y = Math.sin(t * 1.8 + i) * 0.25; ban.scale.x = 1 + Math.sin(t * 3 + i) * 0.03; });
  });
}

function floorChevrons(root: THREE.Group, n: number, radius: number) {
  for (let i = 0; i < n; i++) {
    const a = (i / n) * TAU, x = Math.cos(a) * radius, z = Math.sin(a) * radius, hex = i % 2 ? '#33d6ff' : '#ff3b5c';
    const wrap = new THREE.Group(); wrap.position.set(x, 0.035, z); wrap.rotation.y = Math.atan2(z, -x);
    const m = new THREE.Mesh(new THREE.PlaneGeometry(2.2, 2.2), new THREE.MeshBasicMaterial({ map: T.chevron(hex), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, color: new THREE.Color(1.6, 1.6, 1.6) }));
    m.rotation.x = -Math.PI / 2; wrap.add(m); root.add(wrap);
  }
}

export function dressNight(root: THREE.Group, rng: Rng, cols: Collider[], crates: Crate[], anims: Anim[]) {
  const start = cols.length;
  floorEmblem(root, true);
  floorChevrons(root, 8, 14);
  stairPlatform(root, cols, 24.5, -10, -1, true);
  stall(root, cols, -11.5, 15, true, 'POPCORN'); stall(root, cols, 5.5, 15, true, 'CANDY');
  fenceRing(root, 30.3, '#d8b27a', false);
  bannerPoles(root, anims);
  rollers(root, anims, rng, 5, 26.8, 0.7, true);
  // floating carnival fortress ring
  const wins: Win[] = [];
  const tops = [
    chunk(root, wins, anims, rng, -38, -10, 8, 8, 3, '#8a4a3e', 0xff3b5c),
    chunk(root, wins, anims, rng, -22, -46, 10, 7, 5, '#7d3f52', 0x33d6ff),
    chunk(root, wins, anims, rng, 0, -50, 16, 8, 4, '#96593f', 0xff35c8),
    chunk(root, wins, anims, rng, 22, -46, 9, 7, 6, '#8a4a3e', 0x33d6ff),
    chunk(root, wins, anims, rng, 40, -22, 8, 8, 3, '#7d3f52', 0xff3b5c),
    chunk(root, wins, anims, rng, 38, 30, 9, 8, 4, '#96593f', 0x33d6ff),
    chunk(root, wins, anims, rng, -34, 32, 8, 8, 4, '#8a4a3e', 0xff35c8),
  ];
  const wm = new THREE.InstancedMesh(new THREE.PlaneGeometry(0.55, 0.75), new THREE.MeshBasicMaterial({ toneMapped: false }), wins.length), d = new THREE.Object3D(), col = new THREE.Color();
  wins.forEach((w, i) => { d.position.set(w.x, w.y, w.z); d.rotation.set(0, w.ry, 0); d.updateMatrix(); wm.setMatrixAt(i, d.matrix); wm.setColorAt(i, col.setRGB(...(rng.chance(0.18) ? [0.3, 1.2, 1.9] : [2.0, 1.4, 0.5]) as [number, number, number])); });
  root.add(wm);
  // ferris wheel on its own block
  const fb = mk(boxGeo(8, 1.6, 15, 2.4), M.paper('#6a4a3a'), { outline: 0.03, cast: false }); fb.position.set(-47, -0.8, 6); root.add(fb);
  const fu = mk(new THREE.ConeGeometry(8, 9, 7), M.paper('#5a3f32'), { cast: false, receive: false }); fu.rotation.x = Math.PI; fu.position.set(-47, -6.1, 6); root.add(fu);
  ferrisWheel(root, anims, -47, 6);
  crane(root, anims, 40, -22, tops[4] + 0.1);
  // string lights between the fortress masts and the arena poles
  bunting(root, new THREE.Vector3(-28, 10.5, 0), new THREE.Vector3(0, 10.5, -28), 40, 3, [0xff3b5c, 0xffd54a, 0x33d6ff, 0xff35c8]);
  bunting(root, new THREE.Vector3(28, 10.5, 0), new THREE.Vector3(0, 10.5, 28), 40, 3, [0xff3b5c, 0xffd54a, 0x33d6ff, 0xff35c8]);
  spotlights(root, anims, [new THREE.Vector3(-22, tops[1], -46), new THREE.Vector3(0, tops[2], -50), new THREE.Vector3(22, tops[3], -46)]);
  hotAirBalloons(root, anims, rng, [[-60, 38, -50], [62, 34, -30]]);
  cullCrates(cols, crates, start);
}
