/** Static progression data: upgrades, charms, achievements, modes, arenas, power-ups and campaign stages. */
import type { MapId } from './maps';

export interface Upgrade { id: string; name: string; desc: string; max: number; cost: (lv: number) => number }
export const UPGRADES: Upgrade[] = [
  { id: 'hp', name: 'Paper Heart', desc: '+10 max health per level', max: 5, cost: (l) => 40 + l * 35 },
  { id: 'dash', name: 'Quick-Step Soles', desc: '-8% dash cooldown per level', max: 5, cost: (l) => 35 + l * 30 },
  { id: 'magnet', name: 'Coin Magnet', desc: '+1.5m coin pickup range per level', max: 4, cost: (l) => 30 + l * 30 },
  { id: 'luck', name: 'Capsule Luck', desc: '+1.5% reel jackpot odds per level', max: 5, cost: (l) => 50 + l * 40 },
  { id: 'reload', name: 'Speedy Capsules', desc: '-8% reload time per level', max: 5, cost: (l) => 35 + l * 30 },
  { id: 'dmg', name: 'Sharper Scissors', desc: '+6% damage with every weapon per level', max: 5, cost: (l) => 60 + l * 45 },
];
export const WEAPON_MAX_LV = 5;
export const weaponUpgradeCost = (lv: number) => 30 + lv * 30;

export interface Charm { id: string; name: string; desc: string; cost: number }
export const CHARMS: Charm[] = [
  { id: 'penny', name: 'Lucky Penny', desc: '+40% coin drops', cost: 80 },
  { id: 'heart', name: 'Paper Heart Charm', desc: 'Heal 2 health on every kill', cost: 120 },
  { id: 'glitter', name: 'Glitter Charm', desc: '+10% reel special odds', cost: 100 },
  { id: 'soles', name: 'Rubber Soles', desc: '+12% movement speed', cost: 90 },
  { id: 'popper', name: 'Confetti Popper', desc: 'Defeated enemies burst for small area damage', cost: 150 },
  { id: 'shield', name: 'Cardboard Shield', desc: 'Start every wave with a 20-point shield', cost: 130 },
];

export interface Achievement { id: string; name: string; desc: string }
export const ACHIEVEMENTS: Achievement[] = [
  { id: 'first', name: 'First Pop', desc: 'Defeat your first creature.' },
  { id: 'kills100', name: 'Paper Cutter', desc: 'Defeat 100 creatures.' },
  { id: 'kills1000', name: 'Scissor Legend', desc: 'Defeat 1000 creatures.' },
  { id: 'jackpot', name: 'Triple Star', desc: 'Land a 3-star jackpot on the capsule reel.' },
  { id: 'boss', name: 'Crown Snatcher', desc: 'Defeat a boss.' },
  { id: 'flawless', name: 'Untouched', desc: 'Clear a wave without taking damage.' },
  { id: 'parry10', name: 'Page Turner', desc: 'Deflect 10 projectiles.' },
  { id: 'dash50', name: 'Ink Ghost', desc: 'Dash 50 times.' },
  { id: 'rich', name: 'Pocket Full of Gold', desc: 'Collect 300 coins in total.' },
  { id: 'campaign', name: 'Carnival Closer', desc: 'Finish the campaign.' },
];

export type ModeId = 'campaign' | 'endless' | 'bossrush' | 'daily' | 'timeattack';
export const MODES: { id: ModeId; name: string; desc: string }[] = [
  { id: 'campaign', name: 'Story Campaign', desc: 'Eight stages across five arenas, with three boss fights along the way.' },
  { id: 'endless', name: 'Endless Survival', desc: 'Waves never stop. Pick one arena or cycle through all five; a boss crashes every third stage.' },
  { id: 'bossrush', name: 'Boss Rush', desc: 'Sunflower King, Crowned Dome and the UFO Mothership back to back.' },
  { id: 'daily', name: 'Daily Challenge', desc: 'Same arena and seed for everyone today, with a twist modifier. One score per day.' },
  { id: 'timeattack', name: 'Time Attack', desc: 'Clear six waves in the arena of your choice as fast as you can. Every hit costs 2 seconds.' },
];

export interface StageCfg { name: string; map: MapId; waves: number; boss?: string; blurb: string }
export const CAMPAIGN: StageCfg[] = [
  { name: 'Canyon Kickoff', map: 'canyon', waves: 3, blurb: 'Golden hour. Leaf Bots, Sunflowers and Blobs wander into the arena.' },
  { name: 'Neon Night Carnival', map: 'night', waves: 3, blurb: 'The lights come on. Moths, bombs and ghosts join in.' },
  { name: 'Frostbite Fold', map: 'snow', waves: 3, blurb: 'Slippery ice, snow globes and swooping origami cranes.' },
  { name: "The Sunflower King's Court", map: 'canyon', waves: 2, boss: 'kingSun', blurb: 'A crowned sunflower demands your attention.' },
  { name: 'Toybox Takeover', map: 'toy', waves: 3, blurb: 'Bounce on the trampolines. Mimics and magnets are loose.' },
  { name: 'Ember Foundry', map: 'ember', waves: 3, blurb: 'Lava vents erupt on a rhythm. Watch the glow.' },
  { name: 'The Crowned Dome', map: 'night', waves: 2, boss: 'domeBoss', blurb: 'Jump the neon laser. Break the smile.' },
  { name: 'UFO Showdown', map: 'night', waves: 2, boss: 'ufo', blurb: 'Crates and creatures rain from the beam.' },
];

export const MAP_ORDER: MapId[] = ['canyon', 'night', 'snow', 'toy', 'ember'];
export interface MapInfo { id: MapId; name: string; tag: string; hazard: string; grad: [string, string] }
export const MAP_INFO: MapInfo[] = [
  { id: 'canyon', name: 'Golden-Hour Canyon', tag: 'Windmill, saloon stalls and a sunflower rim', hazard: 'Jump pads · TNT crates', grad: ['#ffd9a0', '#c4753c'] },
  { id: 'night', name: 'Neon Night Carnival', tag: 'Ferris wheel, floating city and a wet neon floor', hazard: 'Jump pads · TNT crates', grad: ['#c83a6c', '#0b0626'] },
  { id: 'snow', name: 'Frostbite Fold', tag: 'Aurora sky, igloos, snowmen and penguins', hazard: 'Slippery ice · jump pads', grad: ['#f2c8e8', '#1a2a6a'] },
  { id: 'toy', name: 'Toybox Takeover', tag: 'Giant blocks, crayons and a toy train', hazard: 'Four trampolines', grad: ['#ffd9ec', '#8fc8ff'] },
  { id: 'ember', name: 'Ember Foundry', tag: 'Lava moat, spinning gears and chimneys', hazard: 'Erupting lava vents', grad: ['#ff6a2a', '#1a0a22'] },
];

export interface PowerDef { id: 'rapid' | 'damage' | 'shield' | 'slow' | 'vacuum' | 'bomb'; name: string; desc: string; color: number; dur: number; weight: number }
export const POWERS: PowerDef[] = [
  { id: 'rapid', name: 'Rapid Reels', desc: 'Fire twice as fast', color: 0xff9a2e, dur: 12, weight: 3 },
  { id: 'damage', name: 'Double Dip', desc: '+80% damage', color: 0xe0384a, dur: 12, weight: 3 },
  { id: 'shield', name: 'Paper Shield', desc: '+35 shield', color: 0x3f8cf0, dur: 0, weight: 2 },
  { id: 'slow', name: 'Slow-Mo Syrup', desc: 'Enemies move at half speed', color: 0x33d6ff, dur: 8, weight: 2 },
  { id: 'vacuum', name: 'Coin Vacuum', desc: 'Sucks up every coin on the map', color: 0xffd54a, dur: 0, weight: 2 },
  { id: 'bomb', name: 'Confetti Bomb', desc: 'Big blast around you', color: 0xff5ab4, dur: 0, weight: 2 },
];

export const DAILY_MODS = [
  { id: 'lowgrav', name: 'Feather Fall', desc: 'Low gravity' },
  { id: 'fastfoes', name: 'Caffeinated Cardboard', desc: 'Enemies are 25% faster' },
  { id: 'richcoins', name: 'Gold Rush', desc: 'Double coin drops' },
  { id: 'glass', name: 'Glass Cannon', desc: '+50% damage, 60% health' },
];

export const todayKey = () => { const d = new Date(); return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`; };
