/**
 * The 18-weapon armory: stats plus a distinct first-person cardboard prop for each gun, every one with moving parts
 * that react to firing, charging, reloading and ammo (spinning barrel cluster, sliding pump, flexing bow limbs,
 * squeezing horn bulb, compressing spring...). Models are built lazily and never share silhouettes.
 */
import * as THREE from 'three';
import { TAU, clamp } from './core';
import { M, T, boxGeo, gradientMap } from './textures';
import { extrude, mk, petalShape } from './models';
import type { SfxName } from './audio';

export interface WeaponDef {
  id: string; name: string; desc: string;
  auto: boolean; interval: number; mag: number; reload: number; dmg: number;
  color: number; sfx: SfxName; kick: number; shake: number; charge?: number;
}

export const WEAPONS: WeaponDef[] = [
  { id: 'gatling', name: 'Popcorn Gatling', desc: 'Rapid-fire popcorn kernels that pop, bounce and splash.', auto: true, interval: 0.075, mag: 90, reload: 1.8, dmg: 8, color: 0xffe9a0, sfx: 'gatling', kick: 0.25, shake: 0.03 },
  { id: 'slinger', name: 'Sticker Slinger', desc: 'Sticker bombs stick to enemies and detonate after a beat.', auto: false, interval: 0.42, mag: 6, reload: 1.5, dmg: 20, color: 0xff5a8a, sfx: 'slinger', kick: 0.9, shake: 0.1 },
  { id: 'bazooka', name: 'Confetti Bazooka', desc: 'Slow rocket, huge confetti blast with area damage and stun.', auto: false, interval: 1.0, mag: 3, reload: 2.2, dmg: 40, color: 0xffd54a, sfx: 'bazooka', kick: 2.2, shake: 0.3 },
  { id: 'crossbow', name: 'Rubber-Band Crossbow', desc: 'Hold to charge a piercing bolt that ricochets off crates.', auto: false, interval: 0.35, mag: 5, reload: 1.6, dmg: 30, color: 0xff8fb8, sfx: 'crossbow', kick: 1.2, shake: 0.12, charge: 0.9 },
  { id: 'grappler', name: 'Tape-Gun Grappler', desc: 'Pull enemies in, or yank yourself to a spot. Tape traps slow foes.', auto: false, interval: 0.9, mag: 8, reload: 1.4, dmg: 8, color: 0xe0b84a, sfx: 'grappler', kick: 0.6, shake: 0.05 },
  { id: 'shotgun', name: 'Glitter Shotgun', desc: 'Wide spread of glitter that blinds enemies briefly.', auto: false, interval: 0.75, mag: 6, reload: 2.0, dmg: 7, color: 0xff9cf0, sfx: 'shotgun', kick: 2.0, shake: 0.25 },
  { id: 'yoyo', name: 'Yo-Yo Buzzsaw', desc: 'A boomerang disc that returns and slices through lines of enemies.', auto: false, interval: 0.55, mag: 6, reload: 1.5, dmg: 24, color: 0x33d6ff, sfx: 'yoyo', kick: 0.5, shake: 0.05 },
  { id: 'horn', name: 'Party-Horn Blaster', desc: 'Shockwave cone that shoves crowds back and breaks crates.', auto: false, interval: 0.9, mag: 8, reload: 1.6, dmg: 14, color: 0xff3b5c, sfx: 'horn', kick: 1.4, shake: 0.2 },
  { id: 'pinwheel', name: 'Pinwheel Launcher', desc: 'Homing spinners, alternating fire and ice.', auto: false, interval: 0.38, mag: 10, reload: 1.7, dmg: 16, color: 0xff9a2e, sfx: 'pinwheel', kick: 0.6, shake: 0.06 },
  { id: 'spring', name: 'Gold Spring Cannon', desc: 'Coil-powered mega shot with huge recoil and screen shake.', auto: false, interval: 1.5, mag: 2, reload: 2.4, dmg: 110, color: 0xffd54a, sfx: 'spring', kick: 4.5, shake: 0.8 },
  { id: 'planes', name: 'Paper-Plane Volley', desc: 'Three folded planes that glide, curve and home in on targets.', auto: false, interval: 0.55, mag: 8, reload: 1.6, dmg: 14, color: 0xdfe8ff, sfx: 'planes', kick: 0.5, shake: 0.05 },
  { id: 'marker', name: 'Giant Marker', desc: 'Rapid ink beam that draws on everything. Weak per hit, never misses.', auto: true, interval: 0.07, mag: 120, reload: 2.0, dmg: 4.5, color: 0x5a3aff, sfx: 'marker', kick: 0.15, shake: 0.02 },
  { id: 'balloon', name: 'Balloon Pump', desc: 'Lobs a pink balloon that bursts into a sticky, damaging puddle.', auto: false, interval: 0.7, mag: 6, reload: 1.8, dmg: 12, color: 0xff6fa8, sfx: 'balloon', kick: 0.8, shake: 0.08 },
  { id: 'stamp', name: 'Rubber Stamp Slammer', desc: 'Hurls a huge stamp that thumps for heavy area damage and leaves a red mark.', auto: false, interval: 0.8, mag: 5, reload: 1.7, dmg: 55, color: 0xc92b2b, sfx: 'stamp', kick: 2.4, shake: 0.35 },
  { id: 'fireworks', name: 'Firework Rack', desc: 'Four rockets in a salvo that burst into spherical starbursts.', auto: false, interval: 1.0, mag: 4, reload: 2.2, dmg: 18, color: 0xffd54a, sfx: 'fireworks', kick: 1.6, shake: 0.2 },
  { id: 'zapper', name: 'Paperclip Zapper', desc: 'Chain lightning that jumps between up to five nearby enemies.', auto: true, interval: 0.3, mag: 18, reload: 1.8, dmg: 18, color: 0x33d6ff, sfx: 'zapper', kick: 0.4, shake: 0.06 },
  { id: 'pencil', name: 'Pencil Sniper', desc: 'Long-range graphite beam that pierces three targets; hits harder from afar.', auto: false, interval: 1.1, mag: 5, reload: 2.0, dmg: 85, color: 0x9a9aaa, sfx: 'pencil', kick: 1.8, shake: 0.2 },
  { id: 'bubble', name: 'Bubble-Wrap Mines', desc: 'Slow bubbles that drift, hover and pop when an enemy comes near.', auto: false, interval: 0.5, mag: 8, reload: 1.7, dmg: 28, color: 0xaee6ff, sfx: 'bubble', kick: 0.5, shake: 0.06 },
];

/** Everything a weapon model needs to animate itself for one frame. */
export interface TickState {
  dt: number; t: number;
  /** Recoil impulse, decays quickly after every shot (0..1.6). */
  kick: number;
  /** Charge fraction for charge weapons, otherwise 0. */
  charge: number;
  /** Ammo remaining as a 0..1 fraction. */
  ratio: number;
  /** Reload progress 0..1, or 0 when not reloading. */
  reload: number;
  /** Seconds since the last shot. */
  since: number;
}
type Tick = (s: TickState) => void;

export interface WeaponView {
  root: THREE.Group;
  muzzle: THREE.Object3D;
  drums: THREE.Mesh[];
  capsules: THREE.Mesh[];
  flash: THREE.Sprite;
  tick: Tick;
}

/** Drum angle that shows symbol `i` (0 flower, 1 bullseye, 2 star, 3 smiley) to the viewer on the left side. */
export const symbolAngle = (i: number) => 1.5 * Math.PI - (Math.PI * (i + 0.5)) / 2;

// ------------------------------------------------------------------ geometry helpers
const cyl = (r0: number, r1: number, len: number, seg = 16) => { const g = new THREE.CylinderGeometry(r0, r1, len, seg); g.rotateX(Math.PI / 2); return g; };
/** Cone with its tip pointing forward (-z). */
const cone = (r: number, len: number, seg = 16) => { const g = new THREE.ConeGeometry(r, len, seg); g.rotateX(-Math.PI / 2); return g; };
/** Open megaphone: wide end forward (-z). */
const funnel = (rFront: number, rBack: number, len: number) => { const g = new THREE.CylinderGeometry(rBack, rFront, len, 22, 1, true); g.rotateX(Math.PI / 2); return g; };
const dbl = (m: THREE.Material) => { const c = m.clone(); c.side = THREE.DoubleSide; return c; };
const axisX = (g: THREE.BufferGeometry) => g.rotateZ(Math.PI / 2);
const part = { cast: false, receive: false };

function helix(radius: number, length: number, turns: number, tube: number, mat: THREE.Material): THREE.Mesh {
  const pts: THREE.Vector3[] = [], n = turns * 14;
  for (let i = 0; i <= n; i++) { const a = (i / 14) * TAU; pts.push(new THREE.Vector3(Math.cos(a) * radius, Math.sin(a) * radius, -(i / n) * length)); }
  return new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts), n * 2, tube, 6, false), mat);
}

const _z = new THREE.Vector3(0, 0, 1), _d = new THREE.Vector3();
/** Stretch a unit-length strand mesh between two points. */
function strandBetween(m: THREE.Object3D, a: THREE.Vector3, b: THREE.Vector3) {
  _d.subVectors(b, a);
  const L = _d.length();
  m.position.copy(a).addScaledVector(_d, 0.5);
  if (L > 1e-5) m.quaternion.setFromUnitVectors(_z, _d.multiplyScalar(1 / L));
  m.scale.set(1, 1, Math.max(L, 1e-4));
}
function strand(r: number, mat: THREE.Material): THREE.Mesh {
  const g = new THREE.CylinderGeometry(r, r, 1, 5); g.rotateX(Math.PI / 2);
  return new THREE.Mesh(g, mat);
}

// ------------------------------------------------------------------ shared rig
type Add = (geo: THREE.BufferGeometry, mat: THREE.Material | THREE.Material[], x: number, y: number, z: number, ol?: number) => THREE.Mesh;
interface Rig {
  root: THREE.Group; add: Add;
  sticker: (tex: THREE.Texture, key: string, size: number, x: number, y: number, z: number) => void;
  grip: (color?: string) => void;
  sight: (y: number, z: number) => void;
  tape: (w: number, h: number, d: number, x: number, y: number, z: number, color?: string) => THREE.Mesh;
}
type Build = (r: Rig) => { muzzleZ: number; tick: Tick };

/** Capsule reel drums + ammo capsule tube bolted to the left side of every weapon. */
function addReel(root: THREE.Group, zc = -0.06) {
  const gold = M.paper('#e8b830'), x = -0.19;
  const tubeMat = new THREE.MeshBasicMaterial({ color: 0xffd54a, transparent: true, opacity: 0.32, depthWrite: false, toneMapped: false });
  for (const y of [0.0, -0.12]) {
    const tg = new THREE.CylinderGeometry(0.052, 0.052, 0.34, 14, 1, true); tg.rotateX(Math.PI / 2);
    const tube = new THREE.Mesh(tg, tubeMat); tube.position.set(x, y - 0.04, zc); root.add(tube);
    for (const z of [zc - 0.17, zc + 0.17]) { const cg = new THREE.CylinderGeometry(0.058, 0.058, 0.025, 14); cg.rotateX(Math.PI / 2); const cap = mk(cg, gold, { ...part, outline: 0.003 }); cap.position.set(x, y - 0.04, z); root.add(cap); }
  }
  const drums: THREE.Mesh[] = [];
  for (let i = 0; i < 3; i++) {
    const dg = new THREE.CylinderGeometry(0.044, 0.044, 0.09, 20); dg.rotateX(Math.PI / 2);
    const d = new THREE.Mesh(dg, M.tex(T.reelDrum(), 'reel')); d.position.set(x, -0.04, zc - 0.09 + i * 0.1); root.add(d); drums.push(d);
  }
  const capsules: THREE.Mesh[] = [];
  const capGeo = new THREE.SphereGeometry(0.036, 10, 8), capMat = new THREE.MeshToonMaterial({ color: 0xffd54a, emissive: 0x805a00 });
  for (let i = 0; i < 8; i++) { const m = new THREE.Mesh(capGeo, capMat); m.position.set(x, -0.16, zc - 0.13 + i * 0.043); root.add(m); capsules.push(m); }
  return { drums, capsules };
}

// ------------------------------------------------------------------ the original ten, rebuilt
const gatling: Build = (r) => {
  const { root, add } = r;
  const red = M.paper('#c92b2b'), gold = M.paper('#e8b830'), cream = M.paper('#f3e7cc'), kraft = M.edge();
  const stripe = M.tex(T.stripesRW(), 'rwBarrel', { bump: true });
  add(boxGeo(0.26, 0.24, 0.5, 0.3), red, 0, -0.08, 0.02); r.grip(); r.sight(0.2, -0.12);
  r.tape(0.29, 0.03, 0.1, 0, 0.05, -0.08, '#e0b84a');
  const cluster = new THREE.Group(); cluster.position.y = 0.02; root.add(cluster);
  for (let i = 0; i < 6; i++) { const a = (i / 6) * TAU, rod = mk(cyl(0.024, 0.024, 0.64, 8), i % 2 ? stripe : gold, { ...part, outline: 0.003 }); rod.position.set(Math.cos(a) * 0.066, Math.sin(a) * 0.066, -0.5); cluster.add(rod); }
  for (const z of [-0.2, -0.82]) { const d = mk(cyl(0.108, 0.108, 0.035, 20), [kraft, red, red], { ...part, outline: 0.004 }); d.position.z = z; cluster.add(d); }
  const axle = mk(cyl(0.032, 0.032, 0.7, 10), cream, { ...part, outline: 0.003 }); axle.position.z = -0.5; cluster.add(axle);
  const crank = new THREE.Group(); crank.position.set(0.15, -0.06, 0.06); root.add(crank);
  const arm = mk(new THREE.BoxGeometry(0.03, 0.13, 0.03), gold, { ...part, outline: 0.003 }); arm.position.y = 0.065;
  const knob = mk(new THREE.SphereGeometry(0.04, 8, 6), red, { ...part, outline: 0.003 }); knob.position.y = 0.13; crank.add(arm, knob);
  const cup = add(new THREE.CylinderGeometry(0.1, 0.075, 0.18, 12), [M.tex(T.stripesRW(), 'rwCup'), cream, cream], 0.05, 0.22, -0.04, 0.005);
  const face = new THREE.Mesh(new THREE.PlaneGeometry(0.09, 0.09), M.tex(T.smiley(), 'smiley', { transparent: true })); face.position.z = 0.1; face.rotation.x = -0.1; cup.add(face);
  for (let i = 0; i < 12; i++) { const k = new THREE.Mesh(new THREE.IcosahedronGeometry(0.034, 0), new THREE.MeshToonMaterial({ color: i % 3 ? 0xfff3c0 : 0xffd54a })); k.position.set((Math.random() - 0.5) * 0.12, 0.1 + Math.random() * 0.04, (Math.random() - 0.5) * 0.12); cup.add(k); }
  r.sticker(T.popcornSticker(), 'popcorn', 0.12, -0.134, -0.08, 0.05);
  return { muzzleZ: -0.98, tick: (s) => { cluster.rotation.z += s.dt * (1.2 + s.kick * 22); crank.rotation.x = cluster.rotation.z; cup.position.y = 0.22 + Math.abs(Math.sin(s.t * 45)) * 0.014 * s.kick; } };
};

const slinger: Build = (r) => {
  const { root, add } = r;
  const orange = M.paper('#e0a030'), pink = M.paper('#ff5a8a'), cream = M.paper('#f3e7cc'), kraft = M.edge();
  add(boxGeo(0.3, 0.28, 0.55, 0.3), orange, 0, -0.06, 0.0); r.grip('#9c703a'); r.sight(0.14, -0.2);
  add(cyl(0.07, 0.07, 0.34, 16), [pink, kraft, kraft], 0, 0.02, -0.42);
  add(funnel(0.17, 0.08, 0.26), dbl(M.paper('#ff9ab8')), 0, 0.02, -0.7);
  const roll = new THREE.Group(); roll.position.set(0, 0.22, -0.02); root.add(roll);
  const ring = mk(new THREE.TorusGeometry(0.1, 0.05, 8, 20), pink, { ...part, outline: 0.004 }); ring.rotation.y = Math.PI / 2; roll.add(ring);
  roll.add(mk(axisX(new THREE.CylinderGeometry(0.06, 0.06, 0.12, 14)), cream, { ...part, outline: 0.003 }));
  const strip = mk(new THREE.PlaneGeometry(0.09, 0.42), dbl(M.paper('#ffd0e0')), { ...part, outline: 0 }); strip.rotation.x = Math.PI / 2 - 0.2; strip.position.set(0, 0.17, -0.3); root.add(strip);
  const lever = mk(new THREE.BoxGeometry(0.05, 0.14, 0.04), M.paper('#c92b2b'), { ...part, outline: 0.003 }); lever.position.set(0, 0.12, 0.3); root.add(lever);
  r.sticker(T.flowerSticker(), 'flower', 0.15, -0.154, -0.04, -0.05); r.sticker(T.smiley(), 'smiley', 0.1, -0.154, 0.0, 0.14);
  r.tape(0.33, 0.03, 0.1, 0, 0.09, -0.1, '#3f8cf0');
  return { muzzleZ: -0.84, tick: (s) => { roll.rotation.x += s.dt * (0.5 + s.kick * 10); strip.rotation.x = Math.PI / 2 - 0.2 + Math.sin(s.t * 18) * 0.09 * (0.3 + s.kick); lever.rotation.x = -s.kick * 0.7; } };
};

const bazooka: Build = (r) => {
  const { root, add } = r;
  const yellow = M.paper('#e8b830'), blue = M.paper('#3f6fd0'), red = M.paper('#c92b2b'), kraft = M.edge();
  add(cyl(0.13, 0.13, 0.7, 20), [yellow, kraft, kraft], 0, 0.02, -0.4);
  add(boxGeo(0.22, 0.2, 0.3, 0.3), blue, 0, -0.12, 0.1); r.grip('#c92b2b'); r.sight(0.2, -0.45);
  add(boxGeo(0.3, 0.3, 0.12, 0.3), red, 0, 0.0, 0.42);
  const sleeve = mk(cyl(0.15, 0.15, 0.24, 20), [blue, kraft, kraft], { ...part, outline: 0.004 }); sleeve.position.set(0, 0.02, -0.3); root.add(sleeve);
  add(funnel(0.23, 0.13, 0.28), dbl(blue), 0, 0.02, -0.88);
  add(cone(0.09, 0.18), red, 0, 0.02, -0.76, 0.004);
  const streamers = new THREE.Group(); streamers.position.set(0, 0.02, -1.02); root.add(streamers);
  const cols = [0xff3b5c, 0xffd54a, 0x33d6ff, 0xff35c8, 0x34c3b0, 0xf3e7cc], sw: THREE.Mesh[] = [];
  cols.forEach((c, i) => { const a = (i / cols.length) * TAU, m = new THREE.Mesh(new THREE.PlaneGeometry(0.035, 0.24), new THREE.MeshBasicMaterial({ color: c, side: THREE.DoubleSide })); m.position.set(Math.cos(a) * 0.2, Math.sin(a) * 0.2 - 0.1, 0); streamers.add(m); sw.push(m); });
  const gauge = new THREE.Group(); gauge.position.set(0, 0.2, -0.18); root.add(gauge);
  gauge.add(mk(new THREE.CylinderGeometry(0.065, 0.065, 0.02, 18), M.paper('#f3e7cc'), { ...part, outline: 0.003 }));
  const needle = new THREE.Group(); needle.position.y = 0.014; needle.add(mk(new THREE.BoxGeometry(0.008, 0.006, 0.06), M.paper('#c92b2b'), { ...part, outline: 0 })); needle.children[0].position.z = -0.025; gauge.add(needle);
  r.sticker(T.crownDoodle(), 'crownD', 0.16, -0.134, 0.0, -0.4); r.tape(0.32, 0.12, 0.03, 0, 0.0, 0.34, '#e0b84a');
  return { muzzleZ: -1.08, tick: (s) => { sleeve.position.z = -0.3 + s.kick * 0.09; needle.rotation.y = 1.2 - s.ratio * 2.4; sw.forEach((m, i) => { m.rotation.x = Math.sin(s.t * 9 + i) * 0.35 + s.kick * 0.5; }); } };
};

const crossbow: Build = (r) => {
  const { root, add } = r;
  const wood = M.paper('#9c703a'), red = M.paper('#c92b2b'), dark = M.paper('#2a2d33'), gold = M.paper('#e8b830');
  const pinkMat = new THREE.MeshToonMaterial({ color: 0xff8fb8, gradientMap: gradientMap() });
  add(boxGeo(0.1, 0.12, 0.95, 0.3), wood, 0, -0.02, -0.3); add(boxGeo(0.18, 0.16, 0.3, 0.3), red, 0, -0.08, 0.14); r.grip('#9c703a'); r.sight(0.14, -0.2);
  add(new THREE.BoxGeometry(0.035, 0.02, 0.72), dark, 0, 0.045, -0.4, 0.003);
  const limbs: THREE.Group[] = [];
  for (const s of [-1, 1]) {
    const g = new THREE.Group(); g.position.set(s * 0.04, 0.02, -0.78); root.add(g);
    const limb = mk(new THREE.BoxGeometry(0.32, 0.035, 0.045), wood, { ...part, outline: 0.004 }); limb.position.x = s * 0.16; g.add(limb);
    const tip = mk(new THREE.SphereGeometry(0.03, 8, 6), gold, { ...part, outline: 0.003 }); tip.position.x = s * 0.32; g.add(tip);
    limbs.push(g);
  }
  const bandL = strand(0.007, pinkMat), bandR = strand(0.007, pinkMat); root.add(bandL, bandR);
  const bolt = new THREE.Group(); root.add(bolt);
  const shaft = mk(cyl(0.015, 0.015, 0.56, 6), wood, { ...part, outline: 0.002 }); bolt.add(shaft);
  const head = mk(cone(0.04, 0.12, 6), gold, { ...part, outline: 0.002 }); head.position.z = -0.34; bolt.add(head);
  const fletch = mk(new THREE.BoxGeometry(0.1, 0.01, 0.1), pinkMat, { ...part, outline: 0 }); fletch.position.z = 0.24; bolt.add(fletch);
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color: 0xff8fb8, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })); glow.position.set(0, 0.04, -0.52); root.add(glow);
  r.sticker(T.smiley(), 'smiley', 0.1, -0.134, -0.07, 0.14);
  const tipA = new THREE.Vector3(), tipB = new THREE.Vector3(), nock = new THREE.Vector3();
  return {
    muzzleZ: -1.12,
    tick: (s) => {
      const c = clamp(s.charge, 0, 1), th = 0.62 - c * 0.38 - s.kick * 0.05;
      limbs[0].rotation.y = -th; limbs[1].rotation.y = th;
      const nz = -0.52 + c * 0.3 + s.kick * 0.04;
      tipA.set(-(0.04 + 0.32 * Math.cos(th)), 0.02, -0.78 - 0.32 * Math.sin(th)); tipB.set(0.04 + 0.32 * Math.cos(th), 0.02, -0.78 - 0.32 * Math.sin(th)); nock.set(0, 0.04, nz);
      strandBetween(bandL, tipA, nock); strandBetween(bandR, tipB, nock);
      bolt.position.set(0, 0.07, nz - 0.28);
      glow.scale.setScalar(0.04 + c * 0.32 + Math.sin(s.t * 40) * 0.03 * c); glow.position.z = nz - 0.1;
    },
  };
};

const grappler: Build = (r) => {
  const { root, add } = r;
  const blue = M.paper('#3f6fd0'), gold = M.paper('#e0a030'), silver = M.paper('#c0c4cc'), cream = M.paper('#f3e7cc');
  const tapeMat = M.tex(T.tape('#e0b84a'), 'tapeY');
  add(boxGeo(0.2, 0.24, 0.5, 0.3), blue, 0, -0.06, 0.02); r.grip(); r.sight(0.2, 0.08);
  add(cyl(0.06, 0.06, 0.4, 14), gold, 0, 0.0, -0.44);
  const roll = new THREE.Group(); roll.position.set(0, 0.17, -0.08); root.add(roll);
  const ring = mk(new THREE.TorusGeometry(0.14, 0.07, 8, 22), tapeMat, { ...part, outline: 0.005 }); ring.rotation.y = Math.PI / 2; roll.add(ring);
  roll.add(mk(axisX(new THREE.CylinderGeometry(0.075, 0.075, 0.2, 16)), cream, { ...part, outline: 0.004 }));
  const strip = mk(new THREE.PlaneGeometry(0.1, 0.5), dbl(M.paper('#f0cc60')), { ...part, outline: 0 }); strip.position.set(0, 0.0, -0.4); strip.rotation.x = Math.PI / 2 - 0.1; root.add(strip);
  for (let i = 0; i < 7; i++) { const t = mk(new THREE.ConeGeometry(0.018, 0.06, 4), silver, { ...part, outline: 0 }); t.rotation.x = Math.PI; t.position.set((i - 3) * 0.028, -0.07, -0.66); root.add(t); }
  add(cone(0.06, 0.16, 8), gold, 0, 0.0, -0.7, 0.003);
  const hookRing = add(new THREE.TorusGeometry(0.07, 0.02, 6, 14), silver, 0, 0.0, -0.66, 0.003); hookRing.rotation.y = 0;
  r.sticker(T.smiley(), 'smiley', 0.1, -0.104, -0.06, 0.06); r.sticker(T.crownDoodle(), 'crownD', 0.12, -0.104, -0.08, -0.2);
  return { muzzleZ: -0.88, tick: (s) => { roll.rotation.x += s.dt * (0.3 + s.kick * 8 + (s.reload > 0 ? 5 : 0)); strip.rotation.x = Math.PI / 2 - 0.1 + Math.sin(s.t * 15) * 0.06 * (0.3 + s.kick); } };
};

const shotgun: Build = (r) => {
  const { root, add } = r;
  const blue = M.paper('#3f6fd0'), red = M.paper('#c92b2b'), gold = M.paper('#e8b830'), wood = M.paper('#9c703a'), kraft = M.edge();
  const stripe = M.tex(T.stripesRW(), 'rwBarrel', { bump: true });
  for (const x of [-0.065, 0.065]) { add(cyl(0.05, 0.05, 0.74, 16), [x < 0 ? blue : stripe, kraft, kraft], x, 0.03, -0.52); add(cyl(0.062, 0.062, 0.05, 16), gold, x, 0.03, -0.9, 0.003); }
  add(new THREE.BoxGeometry(0.04, 0.02, 0.72), gold, 0, 0.085, -0.52, 0.003);
  add(boxGeo(0.26, 0.22, 0.42, 0.3), red, 0, -0.06, 0.06); r.grip('#c92b2b'); r.sight(0.19, -0.1);
  const pump = new THREE.Group(); pump.position.set(0, -0.08, -0.46); root.add(pump);
  pump.add(mk(boxGeo(0.2, 0.1, 0.24, 0.3), wood, { ...part, outline: 0.004 }));
  for (let i = 0; i < 4; i++) { const g = mk(new THREE.BoxGeometry(0.21, 0.012, 0.012), M.paper('#5a3a1e'), { ...part, outline: 0 }); g.position.set(0, 0.053, -0.08 + i * 0.055); pump.add(g); }
  const can = new THREE.Group(); can.position.set(0, -0.19, -0.4); root.add(can);
  can.add(mk(cyl(0.062, 0.062, 0.32, 14), new THREE.MeshBasicMaterial({ color: 0xffe0ff, transparent: true, opacity: 0.28, depthWrite: false }), { ...part, outline: 0 }));
  for (const z of [-0.17, 0.17]) { const cap = mk(cyl(0.066, 0.066, 0.03, 14), gold, { ...part, outline: 0.003 }); cap.position.z = z; can.add(cap); }
  const glitter = new THREE.Group(); can.add(glitter);
  const gm = new THREE.MeshBasicMaterial({ color: new THREE.Color(2, 1.1, 2), toneMapped: false });
  for (let i = 0; i < 18; i++) { const o = new THREE.Mesh(new THREE.OctahedronGeometry(0.01 + Math.random() * 0.008, 0), gm); o.position.set((Math.random() - 0.5) * 0.08, (Math.random() - 0.5) * 0.08, (Math.random() - 0.5) * 0.26); glitter.add(o); }
  r.sticker(T.flowerSticker(), 'flower', 0.13, -0.134, -0.06, 0.06);
  return { muzzleZ: -0.98, tick: (s) => { pump.position.z = -0.46 + s.kick * 0.1 + Math.sin(clamp(s.reload * 3, 0, 1) * Math.PI) * 0.1 * (s.reload > 0 ? 1 : 0); glitter.rotation.z += s.dt * (0.8 + s.kick * 10); glitter.rotation.x = Math.sin(s.t * 3) * 0.3; } };
};

const yoyo: Build = (r) => {
  const { root, add } = r;
  const blue = M.paper('#3f6fd0'), red = M.paper('#c92b2b'), kraft = M.edge(), gold = M.paper('#e8b830');
  const star = M.tex(T.star(), 'starD');
  add(boxGeo(0.24, 0.22, 0.5, 0.3), blue, 0, -0.06, 0.04); r.grip('#c92b2b'); r.sight(0.17, -0.02);
  add(cyl(0.07, 0.07, 0.3, 16), [red, kraft, kraft], 0, 0.02, -0.34);
  for (const s of [-1, 1]) { const p = mk(new THREE.BoxGeometry(0.03, 0.2, 0.05), gold, { ...part, outline: 0.003 }); p.position.set(s * 0.13, 0.02, -0.62); root.add(p); const arm = mk(new THREE.BoxGeometry(0.03, 0.03, 0.3), gold, { ...part, outline: 0.003 }); arm.position.set(s * 0.13, -0.08, -0.46); root.add(arm); }
  const disc = mk(axisX(new THREE.CylinderGeometry(0.19, 0.19, 0.06, 28)), [kraft, star, star], { ...part, outline: 0.005 }); disc.position.set(0, 0.02, -0.62); root.add(disc);
  const spool = new THREE.Group(); spool.position.set(0, 0.2, -0.02); root.add(spool);
  const sring = mk(new THREE.TorusGeometry(0.07, 0.035, 6, 14), gold, { ...part, outline: 0.003 }); sring.rotation.y = Math.PI / 2; spool.add(sring);
  const cord = strand(0.006, M.paper('#f3e7cc')); root.add(cord);
  strandBetween(cord, new THREE.Vector3(0, 0.2, -0.02), new THREE.Vector3(0, 0.02, -0.62));
  r.sticker(T.smiley(), 'smiley', 0.1, -0.124, -0.06, 0.04);
  return { muzzleZ: -0.84, tick: (s) => { const away = s.since < 0.7; disc.visible = true; disc.scale.setScalar(clamp(0.12 + s.since * 1.8, 0.12, 1)); disc.rotation.x += s.dt * (away ? 24 : 9); spool.rotation.x += s.dt * (away ? 14 : 1.5); } };
};

const horn: Build = (r) => {
  const { root, add } = r;
  const red = M.paper('#c92b2b'), gold = M.paper('#e8b830'), blue = M.paper('#3f6fd0');
  const stripe = M.tex(T.stripesRW(), 'rwHorn');
  const bulb = mk(new THREE.SphereGeometry(0.11, 14, 10), red, { ...part, outline: 0.005 }); bulb.position.set(0, -0.02, 0.22); root.add(bulb);
  add(cyl(0.045, 0.045, 0.2, 12), gold, 0, 0.0, 0.06, 0.003);
  const acc: THREE.Mesh[] = [];
  for (let i = 0; i < 6; i++) { const ring = add(new THREE.TorusGeometry(0.065, 0.02, 6, 16), i % 2 ? gold : red, 0, 0.0, -0.06 - i * 0.065, 0.003); acc.push(ring); }
  const bell = mk(funnel(0.28, 0.07, 0.46), dbl(stripe), { ...part, outline: 0.005 }); bell.position.set(0, 0.0, -0.66); root.add(bell);
  const rim = mk(new THREE.TorusGeometry(0.28, 0.022, 6, 28), gold, { ...part, outline: 0.003 }); rim.position.set(0, 0, -0.89); root.add(rim);
  add(boxGeo(0.16, 0.14, 0.3, 0.3), blue, 0, -0.14, 0.0); r.grip();
  const fl = new THREE.Group(); fl.position.set(0, 0, -0.9); root.add(fl);
  const sw: THREE.Mesh[] = [], cols = [0xff3b5c, 0xffd54a, 0x33d6ff, 0xff35c8, 0x34c3b0, 0xf3e7cc, 0xff9a2e, 0xffffff];
  cols.forEach((c, i) => { const a = (i / cols.length) * TAU, m = new THREE.Mesh(new THREE.PlaneGeometry(0.03, 0.26), new THREE.MeshBasicMaterial({ color: c, side: THREE.DoubleSide })); m.position.set(Math.cos(a) * 0.28, Math.sin(a) * 0.28 - 0.12, 0); fl.add(m); sw.push(m); });
  r.sticker(T.star(), 'starD', 0.1, -0.084, -0.14, 0.0);
  return { muzzleZ: -1.0, tick: (s) => { bulb.scale.set(1 + s.kick * 0.22, 1 - s.kick * 0.32, 1 + s.kick * 0.22); bell.rotation.z = Math.sin(s.t * 32) * 0.03 * s.kick; acc.forEach((a, i) => { a.scale.setScalar(1 + Math.sin(s.t * 20 - i) * 0.08 * s.kick); }); sw.forEach((m, i) => { m.rotation.x = Math.sin(s.t * 14 + i) * (0.3 + s.kick * 0.9); }); } };
};

const pinwheel: Build = (r) => {
  const { root, add } = r;
  const blue = M.paper('#3f6fd0'), orange = M.paper('#e0a030'), gold = M.paper('#e8b830'), kraft = M.edge();
  add(cyl(0.045, 0.045, 0.72, 14), [blue, kraft, kraft], 0, 0.02, -0.5);
  for (const z of [-0.2, -0.55]) add(cyl(0.065, 0.065, 0.04, 14), gold, 0, 0.02, z, 0.003);
  add(boxGeo(0.24, 0.22, 0.46, 0.3), orange, 0, -0.07, 0.04); r.grip(); r.sight(0.16, -0.08);
  const stick = add(cyl(0.012, 0.012, 0.14, 6), M.paper('#9c703a'), 0, 0.02, -0.92, 0.002);
  const wheel = new THREE.Group(); wheel.position.set(0, 0.02, -1.0); root.add(wheel);
  for (let i = 0; i < 6; i++) { const b = extrude(petalShape(), 0.012, new THREE.MeshToonMaterial({ color: i % 2 ? 0x33d6ff : 0xff9a2e, side: THREE.DoubleSide, gradientMap: gradientMap() }), 0.004); b.scale.set(0.15, 0.24, 1); b.rotation.z = (i / 6) * TAU; wheel.add(b); }
  wheel.add(mk(new THREE.SphereGeometry(0.03, 8, 6), gold, { ...part, outline: 0.002 }));
  stick.visible = true;
  r.sticker(T.flowerSticker(), 'flower', 0.13, -0.124, -0.07, 0.04);
  return { muzzleZ: -1.12, tick: (s) => { wheel.rotation.z += s.dt * (2.5 + s.kick * 22); } };
};

const spring: Build = (r) => {
  const { root, add } = r;
  const red = M.paper('#c92b2b'), gold = M.paper('#e8b830'), kraft = M.edge();
  add(boxGeo(0.3, 0.26, 0.5, 0.3), red, 0, -0.06, 0.06); r.grip(); r.sight(0.2, -0.06);
  add(cyl(0.1, 0.1, 0.56, 18), [gold, kraft, kraft], 0, 0.02, -0.42);
  const coil = helix(0.17, 0.5, 5, 0.024, gold); coil.position.set(0, 0.02, -0.17); root.add(coil);
  const plate = mk(cyl(0.14, 0.17, 0.1, 18), gold, { ...part, outline: 0.004 }); plate.position.set(0, 0.02, -0.84); root.add(plate);
  const dial = new THREE.Group(); dial.position.set(0, 0.2, 0.12); root.add(dial);
  dial.add(mk(new THREE.CylinderGeometry(0.06, 0.06, 0.02, 16), M.paper('#f3e7cc'), { ...part, outline: 0.003 }));
  const needle = new THREE.Group(); needle.position.y = 0.014; const nb = mk(new THREE.BoxGeometry(0.008, 0.006, 0.055), M.paper('#c92b2b'), { ...part, outline: 0 }); nb.position.z = -0.024; needle.add(nb); dial.add(needle);
  const glow = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color: 0xffd54a, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })); glow.position.set(0, 0.02, -0.9); root.add(glow);
  r.sticker(T.crownDoodle(), 'crownD', 0.16, -0.154, -0.06, 0.1); r.tape(0.33, 0.03, 0.1, 0, 0.075, 0.1, '#e0b84a');
  return { muzzleZ: -1.0, tick: (s) => { coil.scale.z = 1 - s.kick * 0.35; plate.position.z = -0.84 + s.kick * 0.08; needle.rotation.y = 1.3 - s.ratio * 2.6; glow.scale.setScalar(0.1 + s.kick * 0.7); } };
};

// ------------------------------------------------------------------ the prop-style eight
const planes: Build = (r) => {
  const { add } = r;
  const cream = M.paper('#f3e7cc'), wm = dbl(cream);
  const wings: THREE.Mesh[] = [];
  for (const sg of [-1, 1]) {
    const sh = new THREE.Shape(); sh.moveTo(0, 0.75); sh.lineTo(0.4 * sg, -0.1); sh.lineTo(0, -0.1); sh.closePath();
    const g = new THREE.ExtrudeGeometry(sh, { depth: 0.012, bevelEnabled: false }); g.rotateX(-Math.PI / 2);
    const w = add(g, wm, 0, 0.03, -0.12, 0.004); w.rotation.z = sg * 0.45; wings.push(w);
  }
  add(new THREE.BoxGeometry(0.04, 0.12, 0.85), cream, 0, -0.02, -0.4);
  add(boxGeo(0.2, 0.18, 0.45, 0.3), M.paper('#3f6fd0'), 0, -0.1, 0.0);
  const band = add(new THREE.TorusGeometry(0.09, 0.012, 6, 14), M.paper('#c92b2b'), 0, 0.03, -0.45, 0.003); band.rotation.y = Math.PI / 2;
  r.tape(0.2, 0.025, 0.04, 0, 0.05, -0.1, '#e0b84a');
  r.sticker(T.smiley(), 'smiley', 0.1, -0.025, -0.02, -0.4); r.sticker(T.flowerSticker(), 'flower', 0.12, -0.103, -0.1, 0.0); r.grip();
  return { muzzleZ: -0.98, tick: (s) => { wings.forEach((w, i) => { const sg = i ? 1 : -1; w.rotation.z = sg * (0.45 + Math.sin(s.t * 16 + i) * 0.05 * (0.4 + s.kick) - s.kick * 0.12); }); band.rotation.z += s.dt * s.kick * 12; } };
};

const marker: Build = (r) => {
  const { root, add } = r;
  const kraft = M.edge(), cream = M.paper('#f3e7cc');
  add(cyl(0.065, 0.065, 0.62, 20), [M.paper('#c92b2b'), kraft, kraft], 0, 0.02, -0.45);
  add(cyl(0.07, 0.07, 0.2, 20), [M.tex(T.stripesRW(), 'rwBand'), cream, cream], 0, 0.02, -0.3);
  add(cone(0.065, 0.14), M.paper('#2a2060'), 0, 0.02, -0.83);
  const nib = add(new THREE.SphereGeometry(0.03, 8, 6), M.glow(0x6a4aff, 1.8), 0, 0.02, -0.91, 0.003);
  add(cyl(0.08, 0.08, 0.22, 16), M.paper('#2a2d33'), 0, 0.02, -0.02);
  add(new THREE.BoxGeometry(0.03, 0.04, 0.2), M.paper('#c0c4cc'), 0, 0.11, -0.04, 0.003);
  const drip = new THREE.Group(); drip.position.set(0, -0.06, -0.9); root.add(drip);
  drip.add(mk(new THREE.SphereGeometry(0.04, 8, 6), M.glow(0x6a4aff, 1.4), { ...part, outline: 0.004 }));
  r.sticker(T.flowerSticker(), 'flower', 0.12, -0.071, 0.02, -0.5); r.grip('#2a2d33');
  return { muzzleZ: -0.98, tick: (s) => { drip.scale.setScalar((0.7 + 0.4 * s.ratio) * (1 - s.kick * 0.12) + Math.sin(s.t * 3) * 0.02); nib.scale.setScalar(1 + s.kick * 0.9); } };
};

const balloon: Build = (r) => {
  const { root, add } = r;
  const silver = M.paper('#c0c4cc');
  add(cyl(0.045, 0.045, 0.55, 14), M.paper('#e8b830'), 0, 0.02, -0.35);
  for (const z of [-0.18, -0.5]) add(cyl(0.06, 0.06, 0.04, 14), M.paper('#c92b2b'), 0, 0.02, z, 0.003);
  add(boxGeo(0.2, 0.2, 0.3, 0.3), M.paper('#c92b2b'), 0, -0.08, 0.05);
  const handle = new THREE.Group(); handle.position.set(0, 0.02, 0.28); root.add(handle);
  handle.add(mk(cyl(0.02, 0.02, 0.3, 8), silver, { ...part, outline: 0.003 }));
  const bar = mk(new THREE.CylinderGeometry(0.025, 0.025, 0.3, 8), M.paper('#c92b2b'), { ...part, outline: 0.004 }); bar.rotation.z = Math.PI / 2; bar.position.z = 0.15; handle.add(bar);
  const bal = new THREE.Group(); bal.position.set(0, 0.04, -0.82); root.add(bal);
  const bm = new THREE.MeshToonMaterial({ color: 0xff6fa8, transparent: true, opacity: 0.9, gradientMap: gradientMap() });
  bal.add(mk(new THREE.SphereGeometry(0.17, 16, 12), bm, { ...part, outline: 0.006 }));
  const knot = mk(new THREE.ConeGeometry(0.035, 0.07, 8), bm, { ...part, outline: 0 }); knot.rotation.x = -Math.PI / 2; knot.position.z = 0.19; bal.add(knot);
  const hl = new THREE.Mesh(new THREE.SphereGeometry(0.035, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff })); hl.position.set(-0.07, 0.08, -0.12); hl.scale.set(1, 1.5, 0.4); bal.add(hl);
  r.sticker(T.smiley(), 'smiley', 0.1, -0.103, -0.08, 0.05); r.grip();
  return { muzzleZ: -1.05, tick: (s) => { const pump = s.reload > 0 ? Math.abs(Math.sin(s.reload * Math.PI * 4)) * 0.1 : 0; handle.position.z = 0.28 + s.kick * 0.06 + pump; bal.scale.setScalar((0.7 + 0.4 * s.ratio) * (1 - s.kick * 0.12) + Math.sin(s.t * 3) * 0.02 + pump * 0.4); } };
};

const stamp: Build = (r) => {
  const { root, add } = r;
  const plate = new THREE.Group(); plate.position.set(0, 0.02, -0.62); root.add(plate);
  plate.add(mk(boxGeo(0.34, 0.34, 0.1, 0.34), M.paper('#c4935a'), { ...part, outline: 0.008 }));
  const pad = mk(new THREE.BoxGeometry(0.3, 0.3, 0.03), M.paper('#c92b2b'), { ...part, outline: 0.004 }); pad.position.z = -0.065; plate.add(pad);
  const st = new THREE.Mesh(new THREE.PlaneGeometry(0.2, 0.2), M.tex(T.star(), 'starD', { transparent: true })); st.position.z = -0.082; st.rotation.y = Math.PI; plate.add(st);
  const stem = mk(cyl(0.05, 0.05, 0.55, 12), M.paper('#9c6a3a'), { ...part, outline: 0.006 }); stem.position.z = 0.32; plate.add(stem);
  const knob = mk(new THREE.SphereGeometry(0.1, 12, 10), M.paper('#c92b2b'), { ...part, outline: 0.006 }); knob.position.z = 0.64; plate.add(knob);
  add(boxGeo(0.16, 0.14, 0.4, 0.3), M.paper('#3f6fd0'), 0, -0.1, 0.0); r.tape(0.2, 0.025, 0.05, 0, 0.0, 0.0, '#e0b84a'); r.grip('#c92b2b');
  return { muzzleZ: -0.98, tick: (s) => { plate.position.z = -0.62 - s.kick * 0.14; plate.rotation.z = Math.sin(s.t * 2) * 0.01; } };
};

const fireworks: Build = (r) => {
  const { root, add } = r;
  const cols = ['#c92b2b', '#e8b830', '#3f6fd0', '#f3e7cc'], kraft = M.edge();
  ([[-0.065, 0.065], [0.065, 0.065], [-0.065, -0.065], [0.065, -0.065]] as [number, number][]).forEach(([x, y], i) => {
    add(cyl(0.05, 0.05, 0.7, 14), [M.paper(cols[i]), kraft, kraft], x, y + 0.02, -0.45);
    add(cone(0.05, 0.1, 10), M.paper(cols[(i + 1) % 4]), x, y + 0.02, -0.85, 0.004);
  });
  for (const z of [-0.3, -0.62]) { r.tape(0.27, 0.025, 0.05, 0, 0.145, z, '#e0b84a'); r.tape(0.27, 0.025, 0.05, 0, -0.105, z, '#e0b84a'); r.tape(0.025, 0.27, 0.05, 0.135, 0.02, z, '#e0b84a'); r.tape(0.025, 0.27, 0.05, -0.135, 0.02, z, '#e0b84a'); }
  const fuse = add(new THREE.CylinderGeometry(0.01, 0.01, 0.3, 5), M.paper('#33353a'), 0, 0.22, -0.02, 0.002); fuse.rotation.x = 0.6;
  const spark = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color: 0xffaa33, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })); spark.scale.setScalar(0.16); spark.position.set(0, 0.34, 0.1); root.add(spark);
  add(boxGeo(0.16, 0.14, 0.4, 0.3), M.paper('#3f6fd0'), 0, -0.1, 0.05); r.sticker(T.star(), 'starD', 0.12, -0.14, 0.02, -0.46); r.grip();
  return { muzzleZ: -0.95, tick: (s) => { spark.scale.setScalar(0.12 + Math.random() * 0.08 + s.kick * 0.2); } };
};

const zapper: Build = (r) => {
  const { root, add } = r;
  const silver = M.paper('#c0c4cc');
  const mag = new THREE.TorusGeometry(0.15, 0.045, 10, 20, Math.PI); mag.rotateX(Math.PI / 2); add(mag, M.paper('#c92b2b'), 0, 0.02, -0.3, 0.005);
  for (const s of [-1, 1]) {
    add(cyl(0.045, 0.045, 0.34, 12), M.paper('#c92b2b'), s * 0.15, 0.02, -0.47, 0.004);
    add(cyl(0.05, 0.05, 0.1, 12), silver, s * 0.15, 0.02, -0.69, 0.004);
    const coil = helix(0.07, 0.26, 6, 0.011, M.paper('#d98a3a')); coil.position.set(s * 0.15, 0.02, -0.33); root.add(coil);
  }
  for (let i = 0; i < 3; i++) { const clip = add(new THREE.TorusGeometry(0.04, 0.007, 6, 12), silver, (i - 1) * 0.09, 0.02, -0.12 - Math.abs(i - 1) * 0.02, 0.002); clip.scale.set(1, 1.7, 1); clip.rotation.y = 0.6 * (i - 1); }
  const orb = new THREE.Mesh(new THREE.IcosahedronGeometry(0.05, 0), M.glow(0x66e6ff, 2.8)); orb.position.set(0, 0.02, -0.72); root.add(orb);
  add(boxGeo(0.14, 0.14, 0.3, 0.3), M.paper('#3f6fd0'), 0, -0.1, 0.0); r.grip();
  return { muzzleZ: -0.84, tick: (s) => { orb.rotation.x += s.dt * 3; orb.rotation.y += s.dt * 4; orb.scale.setScalar(1 + s.kick * 0.6 + Math.sin(s.t * 25) * 0.08); } };
};

const pencil: Build = (r) => {
  const { root, add } = r;
  const silver = M.paper('#c0c4cc'), kraft = M.edge();
  add(cyl(0.06, 0.06, 0.9, 6), M.paper('#f2c230'), 0, 0.02, -0.5);
  add(cone(0.06, 0.22, 6), M.paper('#d9aa70'), 0, 0.02, -1.06, 0.005); add(cone(0.022, 0.07, 8), M.paper('#3a3a44'), 0, 0.02, -1.2, 0.003);
  add(cyl(0.063, 0.063, 0.1, 12), silver, 0, 0.02, -0.03, 0.004); add(cyl(0.055, 0.055, 0.09, 12), M.paper('#ff9cb0'), 0, 0.02, 0.06, 0.004);
  const sg = new THREE.CylinderGeometry(0.05, 0.05, 0.3, 14, 1, true); sg.rotateX(Math.PI / 2); add(sg, dbl(kraft), 0, 0.15, -0.5, 0.004);
  for (const z of [-0.4, -0.6]) add(new THREE.BoxGeometry(0.02, 0.06, 0.02), M.paper('#2a2d33'), 0, 0.09, z, 0.002);
  const lens = new THREE.Mesh(new THREE.CircleGeometry(0.04, 14), new THREE.MeshBasicMaterial({ color: new THREE.Color(0.3, 1.2, 1.9), toneMapped: false })); lens.position.set(0, 0.15, -0.655); lens.rotation.y = Math.PI; root.add(lens);
  for (const z of [-0.25, -0.75]) add(new THREE.TorusGeometry(0.066, 0.012, 6, 14), M.paper('#c92b2b'), 0, 0.02, z, 0.002);
  r.sticker(T.smiley(), 'smiley', 0.1, -0.065, 0.02, -0.5); r.grip();
  return { muzzleZ: -1.32, tick: (s) => { lens.scale.setScalar(1 + Math.sin(s.t * 3) * 0.1 + s.kick * 0.3); } };
};

const bubble: Build = (r) => {
  const { root, add } = r;
  add(cyl(0.075, 0.075, 0.5, 16), M.paper('#3f8cf0'), 0, 0.02, -0.4);
  const nz = new THREE.ConeGeometry(0.14, 0.18, 16, 1, true); nz.rotateX(Math.PI / 2); add(nz, dbl(M.paper('#e8b830')), 0, 0.02, -0.74, 0.004);
  const wrap = new THREE.InstancedMesh(new THREE.SphereGeometry(0.03, 8, 6), new THREE.MeshBasicMaterial({ color: 0xcfeeff, transparent: true, opacity: 0.55, depthWrite: false }), 42), d = new THREE.Object3D();
  let k = 0; for (let row = 0; row < 7; row++) for (let a = 0; a < 6; a++) { const an = (a / 6) * TAU + (row % 2) * 0.5; d.position.set(Math.cos(an) * 0.092, 0.02 + Math.sin(an) * 0.092, -0.2 - row * 0.065); d.updateMatrix(); wrap.setMatrixAt(k++, d.matrix); }
  wrap.frustumCulled = false; root.add(wrap);
  const tank = new THREE.Mesh(new THREE.SphereGeometry(0.12, 14, 10), new THREE.MeshBasicMaterial({ color: 0xaee6ff, transparent: true, opacity: 0.28, depthWrite: false })); tank.position.set(0, 0.22, -0.3); root.add(tank);
  const inner = new THREE.Group(); inner.position.copy(tank.position); root.add(inner);
  for (let i = 0; i < 7; i++) { const a = (i / 7) * TAU, b = new THREE.Mesh(new THREE.SphereGeometry(0.022 + (i % 3) * 0.006, 8, 6), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.8 })); b.position.set(Math.cos(a) * 0.06, Math.sin(a) * 0.06, ((i % 3) - 1) * 0.03); inner.add(b); }
  add(cyl(0.09, 0.09, 0.04, 16), M.paper('#e8b830'), 0, 0.02, -0.18, 0.003);
  add(boxGeo(0.16, 0.14, 0.34, 0.3), M.paper('#c92b2b'), 0, -0.1, 0.0); r.grip();
  return { muzzleZ: -0.9, tick: (s) => { inner.rotation.y += s.dt * (1.6 + s.kick * 8); inner.rotation.x = Math.sin(s.t * 2) * 0.4; tank.scale.setScalar(1 + s.kick * 0.25); } };
};

const BUILDERS: Record<string, Build> = { gatling, slinger, bazooka, crossbow, grappler, shotgun, yoyo, horn, pinwheel, spring, planes, marker, balloon, stamp, fireworks, zapper, pencil, bubble };

export function buildWeaponView(def: WeaponDef): WeaponView {
  const root = new THREE.Group();
  const add: Add = (geo, mat, x, y, z, ol = 0.006) => { const m = mk(geo, mat, { ...part, outline: ol }); m.position.set(x, y, z); root.add(m); return m; };
  const rig: Rig = {
    root, add,
    sticker: (tex, key, size, x, y, z) => { const s = new THREE.Mesh(new THREE.PlaneGeometry(size, size), M.tex(tex, key, { transparent: true })); s.position.set(x, y, z); s.rotation.y = -Math.PI / 2; root.add(s); },
    grip: (color = '#9c703a') => { const g = add(boxGeo(0.14, 0.3, 0.16, 0.3), M.paper(color), 0, -0.3, 0.14); g.rotation.x = -0.25; },
    sight: (y, z) => { const s = add(boxGeo(0.15, 0.15, 0.15, 0.3), M.paper('#c4935a'), 0, y, z); const sm = new THREE.Mesh(new THREE.PlaneGeometry(0.11, 0.11), M.tex(T.smiley(), 'smiley', { transparent: true })); sm.position.z = 0.078; s.add(sm); },
    tape: (w, h, d, x, y, z, color = '#e0b84a') => add(new THREE.BoxGeometry(w, h, d), M.tex(T.tape(color), 'tape' + color), x, y, z, 0.003),
  };
  const built = BUILDERS[def.id](rig);
  const reel = addReel(root, def.id === 'pencil' || def.id === 'marker' ? -0.1 : -0.06);
  const muzzle = new THREE.Object3D(); muzzle.position.set(0, 0.02, built.muzzleZ); root.add(muzzle);
  const flash = new THREE.Sprite(new THREE.SpriteMaterial({ map: T.glow(), color: def.color, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
  flash.scale.setScalar(0.5); flash.visible = false; muzzle.add(flash);
  return { root, muzzle, drums: reel.drums, capsules: reel.capsules, flash, tick: built.tick };
}
