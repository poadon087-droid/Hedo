/**
 * A tiny fixed pool of point lights for muzzle flashes, explosions and kills.
 * The pool always exists (intensity 0 when idle) so the shader programs never need to recompile.
 */
import * as THREE from 'three';

export class DynLights {
  private slots: { l: THREE.PointLight; t: number; dur: number; peak: number }[] = [];

  constructor(scene: THREE.Scene, n = 3) {
    for (let i = 0; i < n; i++) {
      const l = new THREE.PointLight(0xffffff, 0, 20, 2);
      l.position.set(0, -100, 0); scene.add(l);
      this.slots.push({ l, t: 1, dur: 1, peak: 0 });
    }
  }

  /** Cheap quality switch: lights stay in the scene but contribute nothing. */
  setEnabled(on: boolean) { for (const s of this.slots) { s.l.visible = on; if (!on) s.l.intensity = 0; } }

  flash(x: number, y: number, z: number, color: number, intensity: number, dur: number, range = 18) {
    let best = this.slots[0], bestK = -1;
    for (const s of this.slots) { const k = s.t / s.dur; if (k > bestK) { bestK = k; best = s; } }
    best.l.position.set(x, y, z); best.l.color.setHex(color); best.l.distance = range;
    best.t = 0; best.dur = dur; best.peak = intensity;
  }

  update(dt: number) {
    for (const s of this.slots) {
      if (s.t >= s.dur) { s.l.intensity = 0; continue; }
      s.t += dt;
      const k = Math.max(0, 1 - s.t / s.dur);
      s.l.intensity = s.peak * k * k;
    }
  }

  clear() { for (const s of this.slots) { s.t = s.dur; s.l.intensity = 0; } }
}
