/**
 * Per-weapon visual signatures. Every weapon has its own muzzle effect (shape, colour, motion)
 * and every projectile type its own impact effect, so no two weapons feel alike.
 */
import * as THREE from 'three';
import { TAU } from './core';
import { CONFETTI, type Fx } from './fx';

const _r = new THREE.Vector3(), _u = new THREE.Vector3(), _n = new THREE.Vector3(), _ax = new THREE.Vector3(), _ring = new THREE.Vector3();
const PAPER = [0xf3e7cc, 0xb98a52, 0xc4935a];

function basis(d: THREE.Vector3) {
  _r.crossVectors(d, Math.abs(d.y) > 0.95 ? _ax.set(1, 0, 0) : _ax.set(0, 1, 0)).normalize();
  _u.crossVectors(_r, d).normalize();
}

/** Emit `n` particles inside a cone around `d`. */
function cone(fx: Fx, m: THREE.Vector3, d: THREE.Vector3, n: number, spread: number, s0: number, s1: number, size: number, life: number, grav: number, drag: number, cols: readonly number[]) {
  basis(d);
  const rx = _r.x, ry = _r.y, rz = _r.z, ux = _u.x, uy = _u.y, uz = _u.z;
  for (let i = 0; i < n; i++) {
    const a = Math.random() * TAU, k = Math.sqrt(Math.random()) * spread, sp = s0 + Math.random() * (s1 - s0), ca = Math.cos(a) * k, sa = Math.sin(a) * k;
    fx.emit(m.x, m.y, m.z, (d.x + rx * ca + ux * sa) * sp, (d.y + ry * ca + uy * sa) * sp, (d.z + rz * ca + uz * sa) * sp, size * (0.6 + Math.random() * 0.8), life * (0.7 + Math.random() * 0.6), grav, drag, cols[(Math.random() * cols.length) | 0]);
  }
}
const at = (m: THREE.Vector3, d: THREE.Vector3, k: number) => _ring.set(m.x + d.x * k, m.y + d.y * k, m.z + d.z * k);

/** Muzzle effect when `id` fires. `power` is 0..1 (crossbow charge). */
export function muzzleFx(id: string, fx: Fx, m: THREE.Vector3, d: THREE.Vector3, power: number) {
  switch (id) {
    case 'gatling': {
      cone(fx, m, d, 3, 0.25, 6, 11, 0.06, 0.3, 0, 2, [0xffd54a, 0xffffff]);
      basis(d);
      for (let i = 0; i < 2; i++) fx.emit(m.x - d.x * 0.5, m.y + 0.1, m.z - d.z * 0.5, _r.x * (2.5 + Math.random() * 2) + 0, 2.5 + Math.random() * 2, _r.z * (2.5 + Math.random() * 2), 0.09, 0.9, 13, 0.4, i ? 0xfff3c0 : 0xffd54a); // ejected kernels
      break;
    }
    case 'slinger': cone(fx, m, d, 7, 0.55, 2, 5, 0.12, 1.3, -0.8, 1.6, [0xff5a8a, 0xf3e7cc, 0xffffff]); fx.ring(m.x, m.y, m.z, 0xff5a8a, 0.9, 0.25, d.clone()); break; // peeled sticker backing floats up
    case 'bazooka':
      cone(fx, m, d, 32, 0.45, 6, 17, 0.17, 1.5, 5, 1.4, CONFETTI);
      fx.ring(at(m, d, 0.8).x, _ring.y, _ring.z, 0xf3e7cc, 2.6, 0.55, d.clone()); // smoke ring
      cone(fx, m, _n.copy(d).negate(), 12, 0.55, 3, 8, 0.13, 0.8, 8, 2, PAPER); // back-blast scraps
      break;
    case 'crossbow': {
      const r = 1.6 + power * 1.8;
      fx.ring(at(m, d, 0.5).x, _ring.y, _ring.z, 0xff8fb8, r, 0.22, d.clone());
      cone(fx, m, d, 8 + Math.floor(power * 16), 0.1, 10, 24, 0.05, 0.3, 0, 1, [0xff8fb8, 0xffffff]); break; // band-snap whip
    }
    case 'grappler': cone(fx, m, d, 12, 0.35, 5, 13, 0.1, 0.9, 2, 1, [0xe0b84a, 0xf3e7cc]); fx.ring(m.x, m.y, m.z, 0xe0b84a, 1.2, 0.25, d.clone()); break;
    case 'shotgun':
      cone(fx, m, d, 48, 0.58, 3, 15, 0.05, 1.1, -0.5, 3, [0xff9cf0, 0xffffff, 0x33d6ff, 0xffd54a]); // glitter cloud
      fx.ring(m.x, m.y, m.z, 0xff9cf0, 2.3, 0.3, d.clone()); break;
    case 'yoyo': fx.ring(at(m, d, 0.4).x, _ring.y, _ring.z, 0x33d6ff, 1.4, 0.2, d.clone()); fx.ring(at(m, d, 1.0).x, _ring.y, _ring.z, 0xffffff, 2.2, 0.28, d.clone()); cone(fx, m, d, 8, 0.2, 8, 16, 0.07, 0.4, 0, 2, [0x33d6ff, 0xffffff]); break;
    case 'horn': cone(fx, m, d, 26, 0.7, 8, 19, 0.13, 1.3, 3, 2, CONFETTI); break;
    case 'pinwheel': {
      basis(d);
      for (let i = 0; i < 16; i++) { const a = (i / 16) * TAU, sp = 5; fx.emit(m.x, m.y, m.z, d.x * 4 + (_r.x * Math.cos(a) + _u.x * Math.sin(a)) * sp, d.y * 4 + (_r.y * Math.cos(a) + _u.y * Math.sin(a)) * sp, d.z * 4 + (_r.z * Math.cos(a) + _u.z * Math.sin(a)) * sp, 0.08, 0.5, 0, 2.5, i % 2 ? 0xff9a2e : 0x33d6ff); }
      break;
    }
    case 'spring':
      fx.ring(at(m, d, 0.6).x, _ring.y, _ring.z, 0xffd54a, 5.2, 0.45, d.clone()); fx.ring(at(m, d, 1.2).x, _ring.y, _ring.z, 0xff3b5c, 3.4, 0.35, d.clone());
      cone(fx, m, d, 28, 0.3, 10, 28, 0.13, 0.8, 1, 1, [0xffd54a, 0xffffff]);
      cone(fx, m, _n.copy(d).negate(), 24, 0.7, 4, 12, 0.14, 0.9, 10, 1.5, PAPER); // coil kicks scraps backward
      break;
    case 'planes': cone(fx, m, d, 11, 0.5, 2, 6, 0.1, 1.4, 1.2, 2, [0xffffff, 0xdfe8ff, 0x9ab8ff]); fx.ring(m.x, m.y, m.z, 0x9ab8ff, 1.0, 0.25, d.clone()); break; // flutter of folded paper
    case 'marker': cone(fx, m, d, 3, 0.25, 3, 8, 0.06, 0.55, 8, 1, [0x141016, 0x3a2a9a, 0x5a3aff]); break; // ink flecks
    case 'balloon': cone(fx, m, d, 14, 0.5, 3, 8, 0.07, 0.9, 9, 1, [0x9fe0ff, 0xffffff, 0xff9cf0]); fx.ring(m.x, m.y, m.z, 0xff6fa8, 0.9, 0.22, d.clone()); break;
    case 'stamp': fx.ring(at(m, d, 0.5).x, _ring.y, _ring.z, 0xc92b2b, 3.4, 0.35, d.clone()); cone(fx, m, d, 24, 0.5, 6, 15, 0.13, 1.0, 5, 1.5, [0xc92b2b, 0xf3e7cc, 0x141016]); break;
    case 'fireworks': cone(fx, m, d, 34, 0.55, 8, 22, 0.05, 0.7, 6, 1, [0xffd54a, 0xff3b5c, 0xffffff, 0x33d6ff]); break; // sparkler shower
    case 'zapper': cone(fx, m, d, 12, 0.5, 6, 16, 0.05, 0.3, 0, 2, [0x33d6ff, 0xffffff]); fx.ring(m.x, m.y, m.z, 0x33d6ff, 1.1, 0.18, d.clone()); break;
    case 'pencil':
      cone(fx, m, d, 12, 0.12, 12, 28, 0.04, 0.3, 0, 1, [0x9a9aaa, 0xffffff]); // graphite spark
      cone(fx, m, _n.copy(d).negate(), 12, 0.9, 2, 6, 0.1, 0.8, 8, 2, [0xf2c230, 0xd9aa70]); // wood shavings
      fx.ring(at(m, d, 0.5).x, _ring.y, _ring.z, 0x9a9aaa, 3.4, 0.3, d.clone()); break;
    case 'bubble': cone(fx, m, d, 18, 0.5, 2, 7, 0.1, 1.5, -2, 1.5, [0xaee6ff, 0xffffff, 0xe0f4ff]); break; // bubbles drift upward
  }
}

/** Impact effect, keyed by projectile kind (or `burst_<kind>` for detonations, `hitscan` / `zap` for beams). */
export function impactFx(kind: string, fx: Fx, p: THREE.Vector3, n: THREE.Vector3, color: number) {
  const x = p.x, y = p.y, z = p.z;
  switch (kind) {
    case 'kernel': fx.burst(x, y, z, 7, [0xfff3c0, 0xffd54a, 0xffffff], 4.5, 0.6, 0.1, 0.7, 10); break; // pop!
    case 'sticker': fx.burst(x, y, z, 6, [0xff5a8a, 0xf3e7cc], 3, 0.5, 0.1, 1.0, 5); break;
    case 'bolt': fx.sparks(x, y, z, 10, 0xff8fb8); fx.ring(x, y, z, 0xff8fb8, 1.2, 0.2, n.clone()); break;
    case 'pellet': fx.burst(x, y, z, 5, [0xff9cf0, 0xffffff, 0x33d6ff], 3, 0.4, 0.05, 0.9, 1); break; // glitter
    case 'pinFire': fx.burst(x, y, z, 14, [0xff7a1a, 0xffd54a, 0x141016], 6, 0.5, 0.1, 0.8, 6); break;
    case 'pinIce': fx.burst(x, y, z, 14, [0x33d6ff, 0xeaffff, 0xffffff], 6, 0.5, 0.09, 0.9, 3); fx.ring(x, y, z, 0x7fe0ff, 1.8, 0.3, n.clone()); break;
    case 'plane': fx.burst(x, y, z, 12, [0xffffff, 0xdfe8ff, 0x9ab8ff], 4, 0.5, 0.12, 1.2, 2); break; // paper unfolds
    case 'hook': fx.burst(x, y, z, 10, [0xe0b84a, 0xf3e7cc], 4, 0.4, 0.12, 0.9, 4); break;
    case 'spring': fx.ring(x, y, z, 0xffd54a, 4, 0.4, n.clone()); fx.sparks(x, y, z, 24, 0xffd54a); break;
    case 'stamp': fx.blot(x, y, z, n.x, n.y, n.z, 0xc92b2b, 3.0); fx.ring(x, y, z, 0xc92b2b, 3.8, 0.35, n.clone()); fx.burst(x, y, z, 14, [0xc92b2b, 0xf3e7cc], 6, 0.5, 0.12, 0.8, 8); break; // red ink stamp mark
    case 'hitscan': fx.sparks(x, y, z, 6, color); break;
    case 'zap': fx.sparks(x, y, z, 12, 0x33d6ff); fx.sparks(x, y, z, 6, 0xffffff); break;
    case 'burst_balloon': fx.burst(x, 0.2, z, 36, [0x9fe0ff, 0xff9cf0, 0xffffff], 7, 0.6, 0.09, 1.0, 9); fx.ring(x, 0.1, z, 0xff6fa8, 3.2, 0.4); break; // splash
    case 'burst_bubble': fx.burst(x, y, z, 26, [0xaee6ff, 0xffffff], 5, 0.4, 0.12, 1.2, -1); fx.ring(x, y, z, 0xaee6ff, 3.2, 0.3); break;
    case 'burst_mini': {
      const hex = color, cols = [hex, 0xffffff];
      for (let i = 0; i < 70; i++) { const a = Math.random() * TAU, e = Math.acos(2 * Math.random() - 1), s = 6 + Math.random() * 4; fx.emit(x, y, z, Math.sin(e) * Math.cos(a) * s, Math.cos(e) * s, Math.sin(e) * Math.sin(a) * s, 0.09, 1.1, 5, 1.4, cols[i % 2]); } // spherical starburst
      fx.ring(x, y, z, hex, 3.4, 0.35); break;
    }
    case 'burst_stamp': fx.ring(x, Math.max(y, 0.1), z, 0xc92b2b, 4.2, 0.4); break;
    default: break;
  }
}
