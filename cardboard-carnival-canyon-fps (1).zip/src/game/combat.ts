/**
 * Combat: pooled projectiles (player + enemy), per-weapon firing patterns, explosions,
 * tape traps, parry/deflect and the party-horn cone. Allocation-free in the hot loop.
 */
import * as THREE from 'three';
import { TAU, aabbNormal, clamp, segAABB, segSphere, type Collider, type Crate, type EProjSpec, type HurtKind } from './core';
import type { Enemy } from './enemies';
import { CONFETTI, Ribbon, type Fx } from './fx';
import type { Sfx } from './audio';
import { M, T, gradientMap } from './textures';
import { impactFx } from './weaponfx';
import { extrude, mk, petalShape } from './models';
import type { WeaponDef } from './weapons';
import { WEAPON_ELEM } from './elements';

/** Element of the weapon currently firing / the projectile currently detonating (read by the engine's damage code). */
let curElem = '';
let expElem = '';

export interface CombatHost {
  /** Element applied to damage dealt right now (empty = neutral). */
  hitElem: string;
  flash(x: number, y: number, z: number, color: number, intensity: number, dur: number, range?: number): void;
  fx: Fx; sfx: Sfx;
  enemies: Enemy[]; colliders: Collider[]; crates: Crate[];
  playerPos: THREE.Vector3; playerVel: THREE.Vector3; playerRadius: number;
  eye: THREE.Vector3;
  damageEnemy(e: Enemy, dmg: number, silent?: boolean, crit?: boolean, at?: THREE.Vector3): void;
  hurtPlayer(dmg: number, from: THREE.Vector3, kind: HurtKind): void;
  damageCrate(c: Crate, dmg: number): void;
  shake(a: number): void;
  grapple(target: THREE.Vector3): void;
  blast(x: number, y: number, z: number, radius: number, dmg: number, hurtEnemies?: boolean, color?: number): void;
  caption(t: string): void;
  stickyZone(x: number, z: number, r: number, life: number, ice?: boolean): void;
}

export interface FireOpts {
  muzzle: THREE.Vector3; dir: THREE.Vector3; dmgMul: number; crit: boolean; flower: boolean; jackpot: boolean; charge: number;
}

class Proj {
  active = false; friendly = false; key = ''; kind = ''; weapon = '';
  pos = new THREE.Vector3(); prev = new THREE.Vector3(); vel = new THREE.Vector3(); off = new THREE.Vector3();
  life = 0; dmg = 0; radius = 0.1; gravity = 0; bounce = 0; ricochet = 0; pierce = 0; homing = 0;
  explode = 0; explodeDmg = 0; stun = 0; burn = 0; slow = 0; blind = 0; fuse = -1; stuck: Enemy | null = null; stuckWorld = false;
  returning = false; yoyoT = 0; hitIds: number[] = []; crit = false; grapple = false; spin = 0; color = 0xffffff;
  /** Air drag (bubbles), proximity-mine flag, and puddle colour left on burst (balloons). */
  drag = 0; mine = false; puddle = 0;
  mesh: THREE.Object3D | null = null; ribbon: Ribbon | null = null;
}
class Trap { active = false; pos = new THREE.Vector3(); ttl = 0; age = 0; r = 3; dps = 0; tick = 0; mesh!: THREE.Mesh; }
/** A short-lived glowing line segment (marker, pencil and zapper beams). */
class Beam { mesh!: THREE.Mesh; ttl = 0; life = 0.1; w = 0.1; }

const V = () => new THREE.Vector3();

export class Combat {
  private projs: Proj[] = [];
  private traps: Trap[] = [];
  private meshFree = new Map<string, THREE.Object3D[]>();
  private ribbons: Ribbon[] = [];
  private ribbonFree: Ribbon[] = [];
  private nrm = V(); private tmpA = V(); private tmpB = V(); private tmpC = V(); private hitAt = V();
  private pinAlt = false;
  private beams: Beam[] = [];
  private scan: { e: Enemy; t: number }[] = [];
  private chainSet: Enemy[] = [];
  bigProj = false;

  constructor(private scene: THREE.Scene, private host: CombatHost) {
    for (let i = 0; i < 220; i++) this.projs.push(new Proj());
    for (let i = 0; i < 48; i++) { const r = new Ribbon(); scene.add(r.mesh); this.ribbons.push(r); this.ribbonFree.push(r); }
    const bg = new THREE.CylinderGeometry(1, 1, 1, 6); bg.rotateX(Math.PI / 2); bg.translate(0, 0, 0.5);
    for (let i = 0; i < 40; i++) {
      const b = new Beam(); b.mesh = new THREE.Mesh(bg, new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, toneMapped: false, depthWrite: false }));
      b.mesh.visible = false; b.mesh.frustumCulled = false; scene.add(b.mesh); this.beams.push(b);
    }
    const tg = new THREE.CylinderGeometry(1, 1, 0.04, 28);
    for (let i = 0; i < 6; i++) {
      const t = new Trap(); t.mesh = new THREE.Mesh(tg, new THREE.MeshToonMaterial({ map: T.tape('#ffffff'), gradientMap: gradientMap() }));
      t.mesh.visible = false; scene.add(t.mesh); this.traps.push(t);
    }
  }

  // ------------------------------------------------------------ meshes
  private makeMesh(key: string): THREE.Object3D {
    const free = this.meshFree.get(key);
    const hit = free?.pop();
    if (hit) { hit.visible = true; return hit; }
    const g = new THREE.Group();
    const glow = (c: THREE.ColorRepresentation, boost = 2) => { const m = new THREE.MeshBasicMaterial({ color: c, toneMapped: false }); m.color.multiplyScalar(boost); return m; };
    const cyl = (r: number, l: number, mat: THREE.Material | THREE.Material[]) => { const geo = new THREE.CylinderGeometry(r, r, l, 10); geo.rotateX(Math.PI / 2); return mk(geo, mat, { cast: false, receive: false, outline: 0.015 }); };
    switch (key) {
      case 'p_kernel': { g.add(mk(new THREE.IcosahedronGeometry(0.11, 0), new THREE.MeshToonMaterial({ color: 0xfff3c0 }), { cast: false, outline: 0.02 })); break; }
      case 'p_sticker': { const m = mk(new THREE.BoxGeometry(0.34, 0.34, 0.07), [M.paper('#f3e7cc'), M.paper('#f3e7cc'), M.paper('#f3e7cc'), M.paper('#f3e7cc'), M.tex(T.smiley(), 'smileyS'), M.tex(T.flowerSticker(), 'flowerS')], { cast: false, outline: 0.02 }); g.add(m); break; }
      case 'p_rocket': { g.add(cyl(0.14, 0.6, [M.tex(T.stripesRW(), 'rwRocket'), M.paper('#f3e7cc'), M.paper('#f3e7cc')])); const n = mk(new THREE.ConeGeometry(0.14, 0.26, 12), M.paper('#c92b2b'), { cast: false, outline: 0.015 }); n.rotation.x = Math.PI / 2; n.position.z = 0.43; g.add(n); const f = mk(new THREE.BoxGeometry(0.4, 0.03, 0.2), M.paper('#c92b2b'), { cast: false }); f.position.z = -0.28; g.add(f); break; }
      case 'p_bolt': { g.add(cyl(0.035, 1.0, M.paper('#9c703a'))); const h = mk(new THREE.ConeGeometry(0.08, 0.22, 6), M.paper('#e8b830'), { cast: false, outline: 0.012 }); h.rotation.x = Math.PI / 2; h.position.z = 0.6; g.add(h); const f = mk(new THREE.BoxGeometry(0.2, 0.02, 0.2), glow(0xff8fb8, 1.4), { cast: false }); f.position.z = -0.45; g.add(f); break; }
      case 'p_hook': { const h = mk(new THREE.ConeGeometry(0.1, 0.3, 8), M.paper('#e8b830'), { cast: false, outline: 0.015 }); h.rotation.x = Math.PI / 2; g.add(h); const t = mk(new THREE.TorusGeometry(0.12, 0.05, 6, 12), M.paper('#e0b84a'), { cast: false }); t.position.z = -0.2; g.add(t); break; }
      case 'p_pellet': { g.add(new THREE.Mesh(new THREE.OctahedronGeometry(0.08, 0), glow(0xff9cf0, 2.4))); break; }
      case 'p_yoyo': { const geo = new THREE.CylinderGeometry(0.5, 0.5, 0.1, 24); const star = M.tex(T.star(), 'starD'); g.add(mk(geo, [M.edge(), star, star], { cast: false, outline: 0.03 })); break; }
      case 'p_pinFire': case 'p_pinIce': {
        const cols = key === 'p_pinFire' ? [0xff7a1a, 0xffd54a] : [0x33d6ff, 0xeaffff];
        for (let i = 0; i < 4; i++) { const b = extrude(petalShape(), 0.02, new THREE.MeshBasicMaterial({ color: new THREE.Color(cols[i % 2]).multiplyScalar(1.6), side: THREE.DoubleSide, toneMapped: false }), 0.01); b.scale.set(0.3, 0.45, 1); b.rotation.z = (i / 4) * TAU; g.add(b); }
        break;
      }
      case 'p_spring': { g.add(mk(new THREE.SphereGeometry(0.32, 14, 10), M.paper('#e8b830'), { cast: false, outline: 0.03 })); const r = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.04, 6, 20), glow(0xffd54a, 2.2)); g.add(r); break; }
      case 'p_plane': { const pg = new THREE.ConeGeometry(0.16, 0.55, 3); pg.rotateX(Math.PI / 2); pg.scale(1.8, 0.25, 1); g.add(mk(pg, M.paper('#f3e7cc'), { cast: false, outline: 0.01 })); const fin = mk(new THREE.BoxGeometry(0.02, 0.14, 0.16), M.paper('#9ab8ff'), { cast: false }); fin.position.set(0, 0.05, -0.18); g.add(fin); break; }
      case 'p_balloon': { const bm = new THREE.MeshToonMaterial({ color: 0xff6fa8, transparent: true, opacity: 0.9, gradientMap: gradientMap() }); g.add(mk(new THREE.SphereGeometry(0.22, 14, 10), bm, { cast: false, outline: 0.02 })); const kn = mk(new THREE.ConeGeometry(0.05, 0.1, 6), bm, { cast: false }); kn.position.y = -0.26; kn.rotation.x = Math.PI; g.add(kn); break; }
      case 'p_stamp': { g.add(mk(new THREE.BoxGeometry(0.55, 0.55, 0.14), M.paper('#c4935a'), { cast: false, outline: 0.02 })); const pad = mk(new THREE.BoxGeometry(0.5, 0.5, 0.04), M.paper('#c92b2b'), { cast: false }); pad.position.z = 0.09; g.add(pad); const kn = mk(new THREE.SphereGeometry(0.12, 8, 6), M.paper('#c92b2b'), { cast: false }); kn.position.z = -0.2; g.add(kn); break; }
      case 'p_mini': { g.add(cyl(0.05, 0.45, [M.tex(T.stripesRW(), 'rwRocket'), M.paper('#f3e7cc'), M.paper('#f3e7cc')])); const tip = new THREE.Mesh(new THREE.SphereGeometry(0.07, 6, 4), glow(0xffd54a, 2.6)); tip.position.z = -0.27; g.add(tip); const nose = mk(new THREE.ConeGeometry(0.05, 0.12, 8), M.paper('#c92b2b'), { cast: false }); nose.rotation.x = Math.PI / 2; nose.position.z = 0.28; g.add(nose); break; }
      case 'p_bubble': { g.add(new THREE.Mesh(new THREE.SphereGeometry(0.34, 14, 10), new THREE.MeshBasicMaterial({ color: 0xaee6ff, transparent: true, opacity: 0.32, depthWrite: false }))); const hl = new THREE.Mesh(new THREE.SphereGeometry(0.06, 6, 4), new THREE.MeshBasicMaterial({ color: 0xffffff })); hl.position.set(-0.14, 0.14, 0.2); g.add(hl); g.add(new THREE.Mesh(new THREE.TorusGeometry(0.34, 0.012, 6, 24), new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.6 }))); break; }
      case 'e_seed': g.add(mk(new THREE.SphereGeometry(0.16, 8, 6), glow(0xb4f03a, 1.4), { cast: false, outline: 0.04 })); g.children[0].scale.z = 1.6; break;
      case 'e_fire': g.add(mk(new THREE.IcosahedronGeometry(0.24, 0), glow(0xff6a1a, 2.6), { cast: false, outline: 0.04 })); break;
      case 'e_ice': g.add(mk(new THREE.OctahedronGeometry(0.24, 0), glow(0x7fe0ff, 2.4), { cast: false, outline: 0.04 })); break;
      case 'e_bolt': { const c = mk(new THREE.ConeGeometry(0.12, 0.6, 5), glow(0x38e8d0, 2), { cast: false, outline: 0.04 }); c.rotation.x = Math.PI / 2; g.add(c); break; }
      case 'e_plasma': g.add(mk(new THREE.SphereGeometry(0.3, 10, 8), glow(0xff40e0, 2.4), { cast: false, outline: 0.04 })); break;
      case 'e_orb': { g.add(mk(new THREE.SphereGeometry(0.26, 10, 8), glow(0xff7aa8, 2.4), { cast: false, outline: 0.04 })); const r = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.04, 6, 16), glow(0xffffff, 2)); g.add(r); break; }
      default: g.add(new THREE.Mesh(new THREE.SphereGeometry(0.1, 6, 4), glow(0xffffff)));
    }
    g.userData.key = key;
    this.scene.add(g);
    return g;
  }

  private acquire(): Proj | null {
    for (let i = 0; i < this.projs.length; i++) if (!this.projs[i].active) return this.projs[i];
    return null;
  }

  private spawn(key: string, friendly: boolean, x: number, y: number, z: number, dx: number, dy: number, dz: number, speed: number, dmg: number, life: number, radius: number, ribbonW = 0, color = 0xffffff): Proj | null {
    const p = this.acquire();
    if (!p) return null;
    p.active = true; p.friendly = friendly; p.key = key; p.kind = key.slice(2);
    p.pos.set(x, y, z); p.prev.copy(p.pos); p.vel.set(dx * speed, dy * speed, dz * speed);
    p.life = life; p.dmg = dmg; p.radius = radius; p.gravity = 0; p.bounce = 0; p.ricochet = 0; p.pierce = 0; p.homing = 0;
    p.explode = 0; p.explodeDmg = 0; p.stun = 0; p.burn = 0; p.slow = 0; p.blind = 0; p.fuse = -1; p.stuck = null; p.stuckWorld = false;
    p.drag = 0; p.mine = false; p.puddle = 0; p.weapon = friendly ? curElem : '';
    p.returning = false; p.yoyoT = 0; p.hitIds.length = 0; p.crit = false; p.grapple = false; p.spin = Math.random() * TAU; p.color = color;
    p.mesh = this.makeMesh(key);
    p.mesh.scale.setScalar(this.bigProj && !friendly ? 1.5 : 1);
    p.mesh.position.copy(p.pos);
    p.ribbon = null;
    if (ribbonW > 0) { const r = this.ribbonFree.pop(); if (r) { r.start(x, y, z, color, ribbonW); p.ribbon = r; } }
    return p;
  }

  private release(p: Proj) {
    p.active = false;
    if (p.mesh) { p.mesh.visible = false; const k = p.mesh.userData.key as string; let l = this.meshFree.get(k); if (!l) { l = []; this.meshFree.set(k, l); } l.push(p.mesh); p.mesh = null; }
    if (p.ribbon) { p.ribbon.stop(); this.ribbonFree.push(p.ribbon); p.ribbon = null; }
  }

  // ------------------------------------------------------------ firing
  private spreadDir(dir: THREE.Vector3, spread: number, out: THREE.Vector3) {
    if (spread <= 0) return out.copy(dir);
    const up = Math.abs(dir.y) > 0.95 ? this.tmpC.set(1, 0, 0) : this.tmpC.set(0, 1, 0);
    const r = this.tmpA.crossVectors(dir, up).normalize(), u = this.tmpB.crossVectors(r, dir).normalize();
    const a = Math.random() * TAU, m = Math.sqrt(Math.random()) * spread;
    return out.copy(dir).addScaledVector(r, Math.cos(a) * m).addScaledVector(u, Math.sin(a) * m).normalize();
  }
  private d2 = V();
  private mods(p: Proj | null, o: FireOpts, base: number) {
    if (!p) return;
    if (o.crit) { p.crit = true; p.radius *= 1.3; }
    if (o.flower) { p.burn = Math.max(p.burn, 3); if (!p.explode) { p.explode = 2; p.explodeDmg = base * 0.4; } }
    if (o.jackpot) { p.pierce += 3; p.explode = Math.max(p.explode, 3.6); p.explodeDmg = Math.max(p.explodeDmg, base * 1.2); p.stun = Math.max(p.stun, 0.5); }
  }

  fire(w: WeaponDef, o: FireOpts) {
    curElem = WEAPON_ELEM[w.id] ?? 'impact'; this.host.hitElem = curElem;
    this.fireInner(w, o);
    this.host.hitElem = ''; curElem = '';
  }

  private fireInner(w: WeaponDef, o: FireOpts) {
    const base = w.dmg * o.dmgMul, m = o.muzzle, d = o.dir, h = this.host;
    const sp = (key: string, spread: number, speed: number, dmg: number, life: number, r: number, rib = 0) => {
      this.spreadDir(d, spread, this.d2);
      return this.spawn(key, true, m.x, m.y, m.z, this.d2.x, this.d2.y, this.d2.z, speed, dmg, life, r, rib, w.color);
    };
    switch (w.id) {
      case 'gatling': { const p = sp('p_kernel', 0.035, 60, base, 1.3, 0.14, 0.05); if (p) { p.gravity = 6; p.bounce = 1; p.explode = 0.9; p.explodeDmg = base * 0.5; this.mods(p, o, base); } break; }
      case 'slinger': { const p = sp('p_sticker', 0, 36, base, 4, 0.2, 0.08); if (p) { p.gravity = 8; p.explode = 3.4; p.explodeDmg = 45 * o.dmgMul; p.fuse = 1.1; this.mods(p, o, base); } break; }
      case 'bazooka': { const p = sp('p_rocket', 0, 22, base, 4, 0.3, 0.22); if (p) { p.explode = 5.2; p.explodeDmg = 70 * o.dmgMul; p.stun = 1.2; this.mods(p, o, base); } break; }
      case 'crossbow': { const c = o.charge; const p = sp('p_bolt', 0, 55 + c * 40, base * (1 + c * 2.4), 2.6, 0.18, 0.1 + c * 0.1); if (p) { p.pierce = 1 + Math.floor(c * 4); p.ricochet = 2; this.mods(p, o, base); } break; }
      case 'grappler': { const p = sp('p_hook', 0, 62, base, 0.8, 0.22, 0.06); if (p) { p.grapple = true; p.slow = 1.5; } break; }
      case 'shotgun': { for (let i = 0; i < 12; i++) { const p = sp('p_pellet', 0.11, 55 + Math.random() * 12, base, 0.38, 0.12); if (p) { p.blind = 1.6; if (i % 3 === 0) this.mods(p, o, base); } } break; }
      case 'yoyo': { let n = 0; for (const p of this.projs) if (p.active && p.key === 'p_yoyo') n++; if (n < 2) { const p = sp('p_yoyo', 0, 30, base, 4.5, 0.55, 0.2); if (p) { p.pierce = 999; this.mods(p, o, base); } } break; }
      case 'planes': {
        for (let i = -1; i <= 1; i++) {
          this.rotY(d, i * 0.17, this.d2);
          const p = this.spawn('p_plane', true, m.x, m.y, m.z, this.d2.x, this.d2.y, this.d2.z, 24 + Math.random() * 3, base, 3.2, 0.24, 0.06, 0xdfe8ff);
          if (p) { p.homing = 2.4; this.mods(p, o, base); }
        }
        break;
      }
      case 'marker': this.hitscan(o, base, 0, 70, 0x5a3aff, 0.045, false, 0.07); break;
      case 'balloon': { const p = sp('p_balloon', 0.01, 22, base, 3.5, 0.32, 0.06); if (p) { p.gravity = 13; p.explode = 2.8; p.explodeDmg = base * 1.4; p.puddle = 0xff6fa8; this.mods(p, o, base); } break; }
      case 'stamp': { const p = sp('p_stamp', 0, 44, base, 0.5, 0.55, 0.25); if (p) { p.explode = 3.6; p.explodeDmg = base; p.stun = 1.0; this.mods(p, o, base); } break; }
      case 'fireworks': {
        const cs = [0xff3b5c, 0xffd54a, 0x33d6ff, 0xff35c8];
        for (let i = 0; i < 4; i++) { const p = sp('p_mini', 0.14, 30 + Math.random() * 10, base, 0.5 + Math.random() * 0.55, 0.22, 0.1); if (p) { p.color = cs[i]; p.gravity = 3; p.explode = 3.1; p.explodeDmg = base * 1.2; p.stun = 0.2; this.mods(p, o, base); } }
        break;
      }
      case 'zapper': this.chain(o, base); break;
      case 'pencil': this.hitscan(o, base, o.jackpot ? 5 : 3, 160, 0x9a9aaa, 0.07, true, 0.2); break;
      case 'bubble': { for (let i = 0; i < 2; i++) { const p = sp('p_bubble', 0.1, 20 + i * 3, base, 9, 0.42, 0); if (p) { p.drag = 2.4; p.mine = true; p.explode = 3.1; p.explodeDmg = base * 1.3; p.stun = 0.7; this.mods(p, o, base); } } break; }
      case 'horn': this.blast(o, base); break;
      case 'pinwheel': { this.pinAlt = !this.pinAlt; const p = sp(this.pinAlt ? 'p_pinFire' : 'p_pinIce', 0.02, 22, base, 3.6, 0.3, 0.1); if (p) { p.homing = 2.8; if (this.pinAlt) p.burn = 3; else p.slow = 3; this.mods(p, o, base); } break; }
      case 'spring': { const p = sp('p_spring', 0, 74, base, 2.4, 0.4, 0.35); if (p) { p.pierce = 2; p.explode = 3.2; p.explodeDmg = 40 * o.dmgMul; p.stun = 0.6; this.mods(p, o, base); } break; }
    }
    h.fx.sparks(m.x, m.y, m.z, 4, w.color);
  }

  private rotY(d: THREE.Vector3, a: number, out: THREE.Vector3) { const c = Math.cos(a), s = Math.sin(a); return out.set(d.x * c - d.z * s, d.y, d.x * s + d.z * c); }

  /** True when a knight's raised shield faces an incoming shot travelling along (vx, vz). */
  private shieldBlocks(e: Enemy, vx: number, vz: number): boolean {
    if (!e.def.shielded || !e.shieldUp) return false;
    const l = Math.hypot(vx, vz) || 1;
    return (-vx / l) * Math.sin(e.yaw) + (-vz / l) * Math.cos(e.yaw) > 0.4;
  }

  private worldDist(m: THREE.Vector3, d: THREE.Vector3, max: number): number {
    let best = 1; const dx = d.x * max, dy = d.y * max, dz = d.z * max;
    for (const c of this.host.colliders) { if (!c.alive) continue; const t = segAABB(m.x, m.y, m.z, dx, dy, dz, c); if (t >= 0 && t < best) best = t; }
    if (dy < 0 && m.y + dy <= 0.03) { const t = (m.y - 0.03) / -dy; if (t >= 0 && t < best) best = t; }
    return best * max;
  }

  /** Draw a glowing beam (optionally jagged like lightning). */
  beam(ax: number, ay: number, az: number, bx: number, by: number, bz: number, color: number, width: number, life: number, jag = 0) {
    const len = Math.hypot(bx - ax, by - ay, bz - az);
    if (len < 0.01) return;
    const segs = jag > 0 ? Math.max(2, Math.min(8, Math.floor(len / 1.1))) : 1;
    let px = ax, py = ay, pz = az;
    for (let i = 1; i <= segs; i++) {
      const u = i / segs;
      let x = ax + (bx - ax) * u, y = ay + (by - ay) * u, z = az + (bz - az) * u;
      if (jag > 0 && i < segs) { x += (Math.random() - 0.5) * jag; y += (Math.random() - 0.5) * jag; z += (Math.random() - 0.5) * jag; }
      let b = this.beams[0];
      for (let k = 0; k < this.beams.length; k++) if (this.beams[k].ttl <= 0) { b = this.beams[k]; break; }
      b.mesh.position.set(px, py, pz); b.mesh.lookAt(x, y, z); b.mesh.scale.set(width, width, Math.max(0.01, Math.hypot(x - px, y - py, z - pz)));
      (b.mesh.material as THREE.MeshBasicMaterial).color.setHex(color).multiplyScalar(1.8);
      b.ttl = b.life = life; b.w = width; b.mesh.visible = true;
      px = x; py = y; pz = z;
    }
  }

  /** Instant ray weapon (marker, pencil): damages up to pierce+1 enemies, draws a beam, marks the scenery it hits. */
  private hitscan(o: FireOpts, dmg: number, pierce: number, maxD: number, color: number, width: number, distScale: boolean, life: number) {
    const h = this.host, m = o.muzzle, d = o.dir, dx = d.x * maxD, dy = d.y * maxD, dz = d.z * maxD;
    let wt = 1, wc: Collider | null = null, floor = false;
    for (const c of h.colliders) { if (!c.alive) continue; const t = segAABB(m.x, m.y, m.z, dx, dy, dz, c); if (t >= 0 && t < wt) { wt = t; wc = c; } }
    if (dy < 0 && m.y + dy <= 0.03) { const t = (m.y - 0.03) / -dy; if (t >= 0 && t < wt) { wt = t; wc = null; floor = true; } }
    this.scan.length = 0;
    for (const e of h.enemies) { if (!e.alive) continue; const t = segSphere(m.x, m.y, m.z, dx, dy, dz, e.pos.x, e.pos.y + e.hitCenterY, e.pos.z, e.hitR + 0.06); if (t >= 0 && t < wt) this.scan.push({ e, t }); }
    this.scan.sort((a, b) => a.t - b.t);
    let end = wt, hits = 0, blocked = false;
    for (const s of this.scan) {
      if (hits > pierce) break;
      this.tmpA.set(m.x + dx * s.t, m.y + dy * s.t, m.z + dz * s.t); end = s.t;
      if (this.shieldBlocks(s.e, d.x, d.z)) { h.fx.sparks(this.tmpA.x, this.tmpA.y, this.tmpA.z, 10, 0xffffff); h.sfx.play('click', 0.5); h.damageEnemy(s.e, dmg * 0.06, true); blocked = true; break; }
      h.damageEnemy(s.e, dmg * (distScale ? 1 + Math.min(1.5, (s.t * maxD) / 60) : 1), false, o.crit, this.tmpA);
      impactFx('hitscan', h.fx, this.tmpA, this.nrm.set(-d.x, -d.y, -d.z), color);
      if (o.flower) s.e.addBurn(3);
      hits++;
    }
    if (!blocked && hits <= pierce) end = wt;
    const ex = m.x + dx * end, ey = m.y + dy * end, ez = m.z + dz * end;
    this.beam(m.x, m.y, m.z, ex, ey, ez, color, width, life);
    if (!blocked && hits <= pierce && wt < 1) {
      if (floor) this.nrm.set(0, 1, 0); else aabbNormal(wc!, ex, ey, ez, this.nrm);
      if (wc?.crate) h.damageCrate(wc.crate, dmg);
      h.fx.blot(ex, ey, ez, this.nrm.x, this.nrm.y, this.nrm.z, color, 0.35 + width * 3); h.fx.sparks(ex, ey, ez, 5, color);
    }
    if (o.jackpot || o.flower) this.explode(ex, ey, ez, o.jackpot ? 3.6 : 2, dmg * (o.jackpot ? 1.2 : 0.4), o.jackpot ? 0.5 : 0, color, false);
  }

  /** Paperclip Zapper: lightning that picks the target nearest the crosshair, then arcs on through nearby enemies. */
  private chain(o: FireOpts, dmg: number) {
    const h = this.host, m = o.muzzle, d = o.dir, wd = this.worldDist(m, d, 45);
    let first: Enemy | null = null, bestScore = 1e9;
    for (const e of h.enemies) {
      if (!e.alive) continue;
      const rx = e.pos.x - m.x, ry = e.pos.y + e.hitCenterY - m.y, rz = e.pos.z - m.z, t = rx * d.x + ry * d.y + rz * d.z;
      if (t < 0 || t > Math.min(wd, 28)) continue;
      const perp = Math.hypot(rx - d.x * t, ry - d.y * t, rz - d.z * t);
      if (perp > e.hitR + 1.6) continue;
      const score = perp * 3 + t * 0.1;
      if (score < bestScore) { bestScore = score; first = e; }
    }
    if (!first) { const L = Math.min(wd, 14); this.beam(m.x, m.y, m.z, m.x + d.x * L, m.y + d.y * L, m.z + d.z * L, 0x33d6ff, 0.05, 0.12, 0.8); return; }
    let cur: Enemy | null = first, px = m.x, py = m.y, pz = m.z, dm = dmg;
    this.chainSet.length = 0;
    const jumps = o.jackpot ? 9 : 5;
    for (let j = 0; j < jumps && cur; j++) {
      const cx = cur.pos.x, cy = cur.pos.y + cur.hitCenterY, cz = cur.pos.z;
      this.beam(px, py, pz, cx, cy, cz, j % 2 ? 0xffffff : 0x33d6ff, 0.05, 0.14, 0.5);
      this.tmpA.set(cx, cy, cz);
      if (j === 0 && this.shieldBlocks(cur, d.x, d.z)) { h.damageEnemy(cur, dm * 0.06, true); h.fx.sparks(cx, cy, cz, 10, 0xffffff); break; }
      h.damageEnemy(cur, dm, false, o.crit, this.tmpA); cur.addStun(0.3);
      if (o.flower) cur.addBurn(3);
      impactFx('zap', h.fx, this.tmpA, this.nrm.set(0, 1, 0), 0x33d6ff);
      this.chainSet.push(cur); px = cx; py = cy; pz = cz; dm *= 0.82;
      let next: Enemy | null = null, bd = 9;
      for (const e of h.enemies) {
        if (!e.alive || this.chainSet.indexOf(e) >= 0) continue;
        const dist = Math.hypot(e.pos.x - cx, e.pos.y + e.hitCenterY - cy, e.pos.z - cz);
        if (dist < bd) { bd = dist; next = e; }
      }
      cur = next;
    }
  }

  /** Party-horn: instant shock cone. Pushes crowds, stuns, breaks crates, deflects projectiles. */
  private blast(o: FireOpts, base: number) {
    const h = this.host, ex = o.muzzle, d = o.dir, R = 11, cosA = Math.cos(0.5);
    for (const e of h.enemies) {
      if (!e.alive) continue;
      const dx = e.pos.x - ex.x, dy = e.pos.y + e.hitCenterY - ex.y, dz = e.pos.z - ex.z, dist = Math.hypot(dx, dy, dz) - e.hitR;
      if (dist > R) continue;
      const len = Math.hypot(dx, dy, dz) || 1;
      if ((dx * d.x + dy * d.y + dz * d.z) / len < cosA) continue;
      h.damageEnemy(e, base * (1 - dist / R * 0.5), false, o.crit, this.tmpA.set(e.pos.x, e.pos.y + e.hitCenterY, e.pos.z));
      e.addStun(0.7); e.knock(dx, dz, 22 * (1 - dist / R * 0.6));
    }
    for (const c of h.crates) {
      if (!c.collider.alive) continue;
      const cx = (c.collider.minX + c.collider.maxX) / 2 - ex.x, cz = (c.collider.minZ + c.collider.maxZ) / 2 - ex.z, dist = Math.hypot(cx, cz);
      if (dist < R && (cx * d.x + cz * d.z) / (dist || 1) > Math.cos(0.7)) h.damageCrate(c, 45);
    }
    for (const p of this.projs) {
      if (!p.active || p.friendly) continue;
      const dx = p.pos.x - ex.x, dy = p.pos.y - ex.y, dz = p.pos.z - ex.z, dist = Math.hypot(dx, dy, dz);
      if (dist < R && (dx * d.x + dy * d.y + dz * d.z) / (dist || 1) > cosA) this.reflect(p, d, 1.3);
    }
    for (let i = 0; i < 3; i++) h.fx.ring(ex.x + d.x * (1 + i), ex.y + d.y * (1 + i), ex.z + d.z * (1 + i), i % 2 ? 0xffd54a : 0xff3b5c, 2.5 + i * 2.5, 0.35 + i * 0.1, d.clone().normalize());
    for (let i = 0; i < 40; i++) { const sp = 12 + Math.random() * 14, a = (Math.random() - 0.5) * 0.9, b = (Math.random() - 0.5) * 0.9; h.fx.emit(ex.x, ex.y, ex.z, (d.x + a) * sp, (d.y + b) * sp, (d.z + a * b) * sp, 0.15, 0.9, 6, 1.5, CONFETTI[i % CONFETTI.length]); }
    h.shake(0.15);
  }

  private reflect(p: Proj, dir: THREE.Vector3, mul: number) {
    const sp = p.vel.length() * mul;
    p.friendly = true; p.dmg *= 2.5; p.vel.copy(dir).setLength(sp); p.hitIds.length = 0; p.homing = 0; p.life = Math.max(p.life, 2);
    p.crit = true;
    this.host.fx.sparks(p.pos.x, p.pos.y, p.pos.z, 10, 0xffffff);
  }

  /** Deflect enemy projectiles near the player. Returns how many were returned to sender. */
  parry(pos: THREE.Vector3, fwd: THREE.Vector3, radius: number): number {
    let n = 0;
    for (const p of this.projs) {
      if (!p.active || p.friendly) continue;
      const dx = p.pos.x - pos.x, dy = p.pos.y - (pos.y + 1.2), dz = p.pos.z - pos.z, dist = Math.hypot(dx, dy, dz);
      if (dist < radius && (dx * fwd.x + dy * fwd.y + dz * fwd.z) / (dist || 1) > -0.25) { this.reflect(p, fwd, 1.6); n++; }
    }
    return n;
  }

  /** Super: erase every hostile projectile in a shower of confetti. */
  clearHostile() {
    for (const p of this.projs) if (p.active && !p.friendly) { this.host.fx.confetti(p.pos.x, p.pos.y, p.pos.z, 4, 3); this.release(p); }
  }

  fireEnemy(s: EProjSpec) {
    const colors: Record<string, number> = { seed: 0xb4f03a, fire: 0xff6a1a, ice: 0x7fe0ff, bolt: 0x38e8d0, plasma: 0xff40e0, orb: 0xff7aa8 };
    const p = this.spawn('e_' + s.kind, false, s.x, s.y, s.z, s.dx, s.dy, s.dz, s.speed, s.dmg, s.life ?? 6, s.radius ?? (s.kind === 'plasma' || s.kind === 'orb' ? 0.4 : 0.25), this.ribbonFree.length > 12 ? (s.kind === 'bolt' && s.speed > 30 ? 0.12 : 0.07) : 0, colors[s.kind]); // every enemy shot leaves a readable ink trail
    if (p) { p.homing = s.homing ?? 0; p.gravity = s.gravity ?? 0; p.explode = s.explode ?? 0; p.explodeDmg = s.dmg; }
  }

  // ------------------------------------------------------------ explosions & traps
  explode(x: number, y: number, z: number, R: number, dmg: number, stun: number, color: number, big: boolean) {
    const h = this.host, prev = h.hitElem;
    h.hitElem = expElem || h.hitElem || 'blast'; expElem = '';
    h.flash(x, Math.max(y, 0.6), z, color, big ? 260 : 140, 0.3, R * 3 + 8);
    this.explodeInner(x, y, z, R, dmg, stun, color, big);
    h.hitElem = prev;
  }

  private explodeInner(x: number, y: number, z: number, R: number, dmg: number, stun: number, color: number, big: boolean) {
    const h = this.host;
    for (const e of h.enemies) {
      if (!e.alive) continue;
      const dx = e.pos.x - x, dy = e.pos.y + e.hitCenterY - y, dz = e.pos.z - z, dist = Math.hypot(dx, dy, dz) - e.hitR;
      if (dist > R) continue;
      const f = 1 - clamp(dist / R, 0, 1) * 0.6;
      this.tmpA.set(e.pos.x, e.pos.y + e.hitCenterY, e.pos.z);
      h.damageEnemy(e, dmg * f, false, false, this.tmpA);
      if (stun) e.addStun(stun);
      e.knock(dx, dz, 14 * f);
    }
    for (const c of h.crates) {
      if (!c.collider.alive) continue;
      const cx = (c.collider.minX + c.collider.maxX) / 2 - x, cz = (c.collider.minZ + c.collider.maxZ) / 2 - z;
      if (Math.hypot(cx, cz) < R + 0.8) h.damageCrate(c, dmg * 1.5);
    }
    h.fx.confetti(x, y, z, big ? 110 : 45, big ? 12 : 8);
    h.fx.ring(x, Math.max(0.1, y), z, color, R, 0.45); h.fx.ring(x, Math.max(0.1, y), z, 0xffffff, R * 0.6, 0.3);
    h.fx.sparks(x, y, z, 16, color);
    h.sfx.play(big ? 'boom' : 'confetti');
    const dp = Math.hypot(h.playerPos.x - x, h.playerPos.z - z);
    h.shake(clamp((big ? 0.7 : 0.25) * (1 - dp / 30), 0, 0.8));
  }

  plantTrap(x: number, z: number, r = 3.2, ttl = 6, color = 0xe0b84a, dps = 0) {
    const t = this.traps.find((q) => !q.active) ?? this.traps[0];
    t.active = true; t.pos.set(x, 0.03, z); t.ttl = ttl; t.age = 0; t.r = r; t.dps = dps; t.tick = 0.4; t.mesh.position.copy(t.pos); t.mesh.visible = true; t.mesh.scale.set(0.01, 1, 0.01);
    (t.mesh.material as THREE.MeshToonMaterial).color.setHex(color);
  }

  // ------------------------------------------------------------ simulation
  update(dt: number) {
    const h = this.host;
    for (const t of this.traps) {
      if (!t.active) continue;
      t.ttl -= dt;
      if (t.ttl <= 0) { t.active = false; t.mesh.visible = false; continue; }
      t.age += dt;
      const s = t.r * Math.min(1, t.age * 6 + 0.01) * (t.ttl < 0.6 ? t.ttl / 0.6 : 1);
      t.mesh.scale.set(s, 1, s);
      t.tick -= dt;
      const hurt = t.dps > 0 && t.tick <= 0; if (hurt) t.tick = 0.5;
      for (const e of h.enemies) {
        if (!e.alive || Math.hypot(e.pos.x - t.pos.x, e.pos.z - t.pos.z) >= t.r || e.pos.y > 1.5) continue;
        e.addTape(0.35);
        if (hurt) { h.damageEnemy(e, t.dps * 0.5, true); h.fx.burst(e.pos.x, 0.3, e.pos.z, 3, [0xff9cf0, 0x9fe0ff], 2.5, 0.5, 0.07, 0.6, 6); }
      }
    }
    for (const b of this.beams) {
      if (b.ttl <= 0) continue;
      b.ttl -= dt; const k = Math.max(0, b.ttl / b.life); b.mesh.scale.x = b.mesh.scale.y = b.w * k;
      if (b.ttl <= 0) b.mesh.visible = false;
    }
    for (const p of this.projs) if (p.active) this.step(p, dt);
  }

  private step(p: Proj, dt: number) {
    const h = this.host;
    p.prev.copy(p.pos);
    p.life -= dt;
    // stuck sticker bomb: ride the enemy until the fuse pops
    if (p.stuck || p.stuckWorld) {
      if (p.stuck) { if (!p.stuck.alive) { this.detonate(p); return; } p.pos.set(p.stuck.pos.x + p.off.x, p.stuck.pos.y + p.off.y, p.stuck.pos.z + p.off.z); }
      p.fuse -= dt;
      if (p.fuse <= 0) this.detonate(p);
      return;
    }
    if (p.life <= 0) { if (p.explode > 0 && p.kind !== 'yoyo') this.detonate(p); else this.release(p); return; }

    if (p.kind === 'yoyo') {
      p.yoyoT += dt;
      if (!p.returning && p.yoyoT > 0.55) { p.returning = true; p.hitIds.length = 0; }
      if (p.returning) {
        const dx = h.eye.x - p.pos.x, dy = h.eye.y - 0.3 - p.pos.y, dz = h.eye.z - p.pos.z, d = Math.hypot(dx, dy, dz);
        if (d < 1.3) { this.release(p); return; }
        p.vel.set((dx / d) * 40, (dy / d) * 40, (dz / d) * 40);
      }
    }
    if (p.homing > 0) this.steerHoming(p, dt);
    if (p.drag > 0) p.vel.multiplyScalar(Math.max(0, 1 - p.drag * dt));
    if (p.mine && p.vel.lengthSq() < 9) {
      for (const e of h.enemies) {
        if (e.alive && Math.hypot(e.pos.x - p.pos.x, e.pos.y + e.hitCenterY - p.pos.y, e.pos.z - p.pos.z) < e.hitR + 1.5) { this.detonate(p); return; }
      }
    }
    if (p.gravity) p.vel.y -= p.gravity * dt;

    const dx = p.vel.x * dt, dy = p.vel.y * dt, dz = p.vel.z * dt;
    let bestT = 2, which = 0, bc: Collider | null = null, be: Enemy | null = null;
    const ox = p.prev.x, oy = p.prev.y, oz = p.prev.z;
    const cols = h.colliders;
    for (let i = 0; i < cols.length; i++) {
      const c = cols[i];
      if (!c.alive) continue;
      const t = segAABB(ox, oy, oz, dx, dy, dz, c);
      if (t >= 0 && t < bestT) { bestT = t; which = 1; bc = c; }
    }
    if (dy < 0 && oy + dy <= 0.03) { const t = (oy - 0.03) / -dy; if (t >= 0 && t < bestT) { bestT = t; which = 2; bc = null; } }
    if (p.friendly) {
      const es = h.enemies;
      for (let i = 0; i < es.length; i++) {
        const e = es[i];
        if (!e.alive || p.hitIds.indexOf(e.id) >= 0) continue;
        const t = segSphere(ox, oy, oz, dx, dy, dz, e.pos.x, e.pos.y + e.hitCenterY, e.pos.z, e.hitR + p.radius);
        if (t >= 0 && t < bestT) { bestT = t; which = 3; be = e; }
      }
    } else {
      const t = segSphere(ox, oy, oz, dx, dy, dz, h.playerPos.x, h.playerPos.y + 0.9, h.playerPos.z, h.playerRadius + p.radius);
      if (t >= 0 && t < bestT) { bestT = t; which = 4; }
    }
    if (which === 0) { p.pos.set(ox + dx, oy + dy, oz + dz); p.ribbon?.push(p.pos.x, p.pos.y, p.pos.z); return; }
    this.hitAt.set(ox + dx * bestT, oy + dy * bestT, oz + dz * bestT);
    p.pos.copy(this.hitAt);
    p.ribbon?.push(p.pos.x, p.pos.y, p.pos.z);
    if (which === 4) {
      if (p.explode > 0) { this.detonate(p); } else {
        h.hurtPlayer(p.dmg, p.prev, p.kind === 'fire' ? 'fire' : p.kind === 'ice' ? 'ice' : 'hit');
        h.fx.scraps(p.pos.x, p.pos.y, p.pos.z, 6, p.color, 3);
        this.release(p);
      }
    } else if (which === 3 && be) this.hitEnemy(p, be);
    else this.hitWorld(p, bc, which === 2);
  }

  private steerHoming(p: Proj, dt: number) {
    const h = this.host, sp = p.vel.length() || 1;
    let tx = 0, ty = 0, tz = 0, found = false;
    if (p.friendly) {
      let best = 1e9;
      for (const e of h.enemies) {
        if (!e.alive) continue;
        const dx = e.pos.x - p.pos.x, dy = e.pos.y + e.hitCenterY - p.pos.y, dz = e.pos.z - p.pos.z, d = Math.hypot(dx, dy, dz);
        if (d < best && d < 40 && (dx * p.vel.x + dy * p.vel.y + dz * p.vel.z) / (d * sp) > 0.55) { best = d; tx = e.pos.x; ty = e.pos.y + e.hitCenterY; tz = e.pos.z; found = true; }
      }
    } else { tx = h.playerPos.x; ty = h.playerPos.y + 1.0; tz = h.playerPos.z; found = true; }
    if (!found) return;
    const to = this.tmpA.set(tx - p.pos.x, ty - p.pos.y, tz - p.pos.z).normalize();
    const dir = this.tmpB.copy(p.vel).divideScalar(sp);
    dir.lerp(to, Math.min(1, p.homing * dt)).normalize();
    p.vel.copy(dir).multiplyScalar(sp);
  }

  private hitEnemy(p: Proj, e: Enemy) {
    const h = this.host;
    if (p.hitIds.length < 14) p.hitIds.push(e.id);
    if (this.shieldBlocks(e, p.vel.x, p.vel.z)) {
      h.fx.sparks(this.hitAt.x, this.hitAt.y, this.hitAt.z, 10, 0xffffff); h.fx.ring(this.hitAt.x, this.hitAt.y, this.hitAt.z, 0xffd54a, 1.3, 0.2); h.sfx.play('click', 0.5);
      h.damageEnemy(e, p.dmg * 0.06, true);
      if (p.explode > 0) this.detonate(p); else if (p.kind !== 'yoyo') this.release(p);
      return;
    }
    this.tmpC.copy(this.hitAt);
    h.hitElem = p.kind === 'pinFire' ? 'fire' : p.kind === 'pinIce' ? 'ice' : p.weapon;
    h.damageEnemy(e, p.dmg, false, p.crit, this.tmpC);
    h.hitElem = '';
    impactFx(p.kind, h.fx, this.hitAt, this.nrm.set(-p.vel.x, -p.vel.y, -p.vel.z).normalize(), p.color);
    if (p.stun) e.addStun(p.stun);
    if (p.burn) e.addBurn(p.burn);
    if (p.slow) e.addSlow(p.slow);
    if (p.blind) e.addBlind(p.blind);
    e.knock(p.vel.x, p.vel.z, p.kind === 'pellet' ? 2 : 4);
    h.fx.scraps(this.hitAt.x, this.hitAt.y, this.hitAt.z, 5, p.color, 3);
    if (p.kind === 'sticker') { p.stuck = e; p.off.set(this.hitAt.x - e.pos.x, this.hitAt.y - e.pos.y, this.hitAt.z - e.pos.z); p.vel.set(0, 0, 0); return; }
    if (p.kind === 'hook') {
      e.knock(h.playerPos.x - e.pos.x, h.playerPos.z - e.pos.z, 34); e.addTape(1.5);
      this.plantTrap(e.pos.x, e.pos.z, 3, 5); h.sfx.play('crunch'); this.release(p); return;
    }
    if (p.kind === 'yoyo') return; // buzzsaw keeps cutting
    if (p.kind === 'kernel') h.sfx.play('pop', 1.3);
    if (p.pierce > 0) { p.pierce--; if (p.explode > 0 && p.kind === 'spring') this.explode(this.hitAt.x, this.hitAt.y, this.hitAt.z, p.explode, p.explodeDmg, p.stun, p.color, true); return; }
    if (p.explode > 0) { this.detonate(p); return; }
    this.release(p);
  }

  private hitWorld(p: Proj, c: Collider | null, floor: boolean) {
    const h = this.host, a = this.hitAt;
    if (floor) this.nrm.set(0, 1, 0); else aabbNormal(c!, a.x, a.y, a.z, this.nrm);
    const n = this.nrm;
    if (p.friendly) impactFx(p.kind, h.fx, a, n, p.color);
    if (p.friendly && c?.crate && p.kind !== 'yoyo') h.damageCrate(c.crate, p.dmg);
    else if (p.friendly && c?.crate) h.damageCrate(c.crate, p.dmg * 0.5);
    const reflectV = (k: number) => { const d = p.vel.dot(n); p.vel.addScaledVector(n, -2 * d).multiplyScalar(k); p.pos.addScaledVector(n, 0.06); };
    switch (p.kind) {
      case 'kernel':
        if (p.bounce > 0) { p.bounce--; reflectV(0.55); h.sfx.play('pop', 1.4); h.fx.scraps(a.x, a.y, a.z, 3, 0xfff3c0, 2); return; }
        h.fx.blot(a.x, a.y, a.z, n.x, n.y, n.z, 0xffe9a0, 0.45); this.detonate(p); return;
      case 'bolt':
        if (p.friendly && p.ricochet > 0) { p.ricochet--; reflectV(0.95); h.sfx.play('click', 1.5); h.fx.sparks(a.x, a.y, a.z, 8, 0xff8fb8); return; }
        break;
      case 'sticker': p.stuckWorld = true; p.vel.set(0, 0, 0); p.pos.addScaledVector(n, 0.12); h.sfx.play('click', 0.8); return;
      case 'hook':
        this.plantTrap(a.x, a.z, 3.2, 6);
        if (!c?.crate) h.grapple(a);
        h.sfx.play('crunch'); this.release(p); return;
      case 'yoyo': if (!p.returning) { p.returning = true; p.hitIds.length = 0; } reflectV(0.4); h.fx.sparks(a.x, a.y, a.z, 6, 0x33d6ff); return;
      default: break;
    }
    h.fx.blot(a.x, a.y, a.z, n.x, n.y, n.z, p.friendly ? p.color : 0x141016, p.friendly ? 0.5 : 0.35);
    h.fx.scraps(a.x, a.y, a.z, 6, p.color, 3);
    if (p.explode > 0) this.detonate(p); else this.release(p);
  }

  private detonate(p: Proj) {
    const h = this.host;
    if (!p.friendly && p.kind === 'seed' && p.explode > 0) { // glue blob: leaves a sticky puddle instead of a blast
      h.stickyZone(p.pos.x, p.pos.z, p.explode, 7); h.fx.burst(p.pos.x, 0.3, p.pos.z, 14, [0xd8e04a, 0xf3e7cc], 4, 0.5, 0.1, 0.8, 8); this.release(p); return;
    }
    if (!p.friendly && p.explode > 0) { h.blast(p.pos.x, Math.max(p.pos.y, 0.2), p.pos.z, p.explode, p.dmg, false, p.color); this.release(p); return; }
    const big = p.explode >= 4 || p.kind === 'spring' || p.kind === 'rocket' || p.kind === 'stamp';
    if (p.explode > 0) {
      expElem = p.kind === 'pinFire' ? 'fire' : p.kind === 'pinIce' ? 'ice' : p.weapon;
      this.explode(p.pos.x, p.pos.y, p.pos.z, p.explode, p.explodeDmg, p.stun, p.color, big);
    }
    if (p.puddle) this.plantTrap(p.pos.x, p.pos.z, 3.1, 7, p.puddle, 7);
    impactFx('burst_' + p.kind, h.fx, p.pos, this.nrm.set(0, 1, 0), p.color);
    if (p.kind === 'stamp') h.shake(0.35);
    this.release(p);
  }

  // ------------------------------------------------------------ render
  render(alpha: number, cam: THREE.Vector3, t: number) {
    for (const p of this.projs) {
      if (!p.active || !p.mesh) continue;
      const m = p.mesh;
      m.position.lerpVectors(p.prev, p.pos, alpha);
      if (p.stuck || p.stuckWorld) { m.rotation.z += 0.02; continue; }
      const sp = p.vel.lengthSq();
      switch (p.kind) {
        case 'yoyo': m.rotation.set(0.35, t * 24, 0); break;
        case 'pinFire': case 'pinIce': m.lookAt(m.position.x + p.vel.x, m.position.y + p.vel.y, m.position.z + p.vel.z); m.rotateZ(t * 18); break;
        case 'kernel': m.rotation.set(t * 9 + p.spin, t * 7, 0); break;
        case 'pellet': m.rotation.set(t * 15 + p.spin, t * 11, 0); break;
        case 'plane': m.lookAt(m.position.x + p.vel.x, m.position.y + p.vel.y, m.position.z + p.vel.z); m.rotateZ(Math.sin(t * 9 + p.spin) * 0.5); break;
        case 'bubble': m.scale.setScalar(1 + Math.sin(t * 6 + p.spin) * 0.07); break;
        case 'balloon': m.rotation.set(Math.sin(t * 5 + p.spin) * 0.25, 0, Math.cos(t * 4 + p.spin) * 0.25); break;
        case 'orb': case 'spring': m.rotation.y = t * 6; m.rotation.x = t * 3; break;
        case 'fire': case 'ice': case 'plasma': m.rotation.set(t * 8 + p.spin, t * 6, 0); break;
        default: if (sp > 0.01) m.lookAt(m.position.x + p.vel.x, m.position.y + p.vel.y, m.position.z + p.vel.z);
      }
    }
    for (const r of this.ribbons) if (r.mesh.visible) r.rebuild(cam);
  }

  /** Remove everything (stage change / restart). */
  clear() {
    for (const p of this.projs) if (p.active) this.release(p);
    for (const t of this.traps) { t.active = false; t.mesh.visible = false; }
  }
}
