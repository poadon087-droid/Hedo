/**
 * Unified input: keyboard + mouse (rebindable), gamepad (hot-plug via polling) and
 * virtual touch controls all resolve into the same per-frame action table.
 */
export type Action = 'forward' | 'back' | 'left' | 'right' | 'jump' | 'dash' | 'fire' | 'parry' | 'reload' | 'ex' | 'super' | 'inspect' | 'next' | 'prev' | 'pause';
export const ACTIONS: Action[] = ['forward', 'back', 'left', 'right', 'jump', 'dash', 'fire', 'parry', 'reload', 'ex', 'super', 'inspect', 'next', 'prev', 'pause'];
export const ACTION_LABEL: Record<Action, string> = {
  forward: 'Move forward', back: 'Move back', left: 'Strafe left', right: 'Strafe right', jump: 'Jump', dash: 'Dash', fire: 'Fire', parry: 'Parry',
  reload: 'Reload', ex: 'EX move', super: 'Super', inspect: 'Inspect weapon', next: 'Next weapon', prev: 'Previous weapon', pause: 'Pause',
};
const rec = (v: boolean): Record<Action, boolean> => Object.fromEntries(ACTIONS.map((a) => [a, v])) as Record<Action, boolean>;
const PAD_MAP: Partial<Record<Action, number>> = { jump: 0, dash: 1, reload: 2, inspect: 3, prev: 4, next: 5, parry: 6, fire: 7, pause: 9, super: 10, ex: 11 };

export function prettyCode(code: string): string {
  if (code.startsWith('Mouse')) return ['Left Click', 'Middle Click', 'Right Click'][+code.slice(5)] ?? code;
  return code.replace('Key', '').replace('Digit', '').replace('Arrow', 'Arrow ').replace('ShiftLeft', 'L-Shift').replace('ShiftRight', 'R-Shift');
}

export class Input {
  bindings: Record<string, string[]> = {};
  down = rec(false);
  pressed = rec(false);
  private prev = rec(false);
  private keys = new Set<string>();
  private virt = new Set<Action>();
  private padDown = new Set<Action>();
  lookX = 0; lookY = 0;
  moveX = 0; moveY = 0;
  touchMove = { x: 0, y: 0 };
  slotPressed = -1;
  wheel = 0;
  /** True while gameplay owns the keyboard/mouse. */
  capture = false;
  locked = false;
  softLook = false;
  padConnected = false;
  onRebind: ((code: string) => void) | null = null;
  onPadChange: ((connected: boolean) => void) | null = null;
  private arrowX = 0; private arrowY = 0;
  private cleanup: (() => void)[] = [];

  constructor(private el: HTMLElement) {
    const on = <K extends keyof WindowEventMap>(t: K, f: (e: WindowEventMap[K]) => void, target: Window | Document = window) => {
      target.addEventListener(t, f as EventListener);
      this.cleanup.push(() => target.removeEventListener(t, f as EventListener));
    };
    on('keydown', (e) => {
      if (this.onRebind) { e.preventDefault(); const cb = this.onRebind; this.onRebind = null; cb(e.code); return; }
      if (!this.capture) return;
      if (['Space', 'Tab', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
      if (e.repeat) return;
      this.keys.add(e.code);
      const m = /^Digit(\d)$/.exec(e.code);
      if (m) this.slotPressed = (+m[1] + 9) % 10;
    });
    on('keyup', (e) => { this.keys.delete(e.code); });
    on('mousedown', (e) => {
      if (this.onRebind) { e.preventDefault(); const cb = this.onRebind; this.onRebind = null; cb('Mouse' + e.button); return; }
      if (this.capture && (this.locked || this.softLook) && (e.target as HTMLElement)?.closest?.('[data-game-surface]')) { this.keys.add('Mouse' + e.button); e.preventDefault(); }
    });
    on('mouseup', (e) => { this.keys.delete('Mouse' + e.button); });
    on('contextmenu', (e) => { if (this.capture) e.preventDefault(); });
    on('mousemove', (e) => {
      if (this.capture && (this.locked || this.softLook)) { this.lookX += e.movementX; this.lookY += e.movementY; }
    });
    on('wheel', (e) => { if (this.capture) this.wheel += Math.sign(e.deltaY); }, window);
    on('blur', () => this.releaseAll());
    const onLockChange = () => { this.locked = document.pointerLockElement === this.el; if (!this.locked) this.keys.delete('Mouse0'); };
    const onLockError = () => { this.softLook = true; };
    document.addEventListener('pointerlockchange', onLockChange);
    document.addEventListener('pointerlockerror', onLockError);
    this.cleanup.push(() => { document.removeEventListener('pointerlockchange', onLockChange); document.removeEventListener('pointerlockerror', onLockError); });
  }

  dispose() { this.cleanup.forEach((f) => f()); this.cleanup = []; }

  requestLock() {
    if (this.locked) return;
    try {
      const p = (this.el as HTMLElement & { requestPointerLock: () => Promise<void> | void }).requestPointerLock();
      if (p && typeof (p as Promise<void>).catch === 'function') (p as Promise<void>).catch(() => { this.softLook = true; });
    } catch { this.softLook = true; }
  }
  exitLock() { if (document.pointerLockElement) document.exitPointerLock(); }

  /** Drop every held key/button (tab hide, pause, blur) so nothing sticks. */
  releaseAll() {
    this.keys.clear(); this.virt.clear(); this.padDown.clear();
    this.lookX = 0; this.lookY = 0; this.touchMove.x = 0; this.touchMove.y = 0; this.wheel = 0; this.slotPressed = -1;
    for (const a of ACTIONS) { this.down[a] = false; this.prev[a] = false; this.pressed[a] = false; }
  }

  setVirtual(a: Action, on: boolean) { if (on) this.virt.add(a); else this.virt.delete(a); }
  addLook(dx: number, dy: number) { this.lookX += dx; this.lookY += dy; }

  private pollPad(dt: number) {
    const pads = typeof navigator.getGamepads === 'function' ? navigator.getGamepads() : [];
    let pad: Gamepad | null = null;
    for (const p of pads) if (p && p.connected) { pad = p; break; }
    if (!!pad !== this.padConnected) { this.padConnected = !!pad; this.onPadChange?.(this.padConnected); }
    this.padDown.clear();
    if (!pad) return { mx: 0, my: 0 };
    const dz = (v: number) => (Math.abs(v) < 0.18 ? 0 : v);
    for (const [a, b] of Object.entries(PAD_MAP) as [Action, number][]) { const btn = pad.buttons[b]; if (btn && (btn.pressed || btn.value > 0.5)) this.padDown.add(a); }
    const rx = dz(pad.axes[2] ?? 0), ry = dz(pad.axes[3] ?? 0);
    this.lookX += rx * Math.abs(rx) * 900 * dt; this.lookY += ry * Math.abs(ry) * 700 * dt;
    return { mx: dz(pad.axes[0] ?? 0), my: -dz(pad.axes[1] ?? 0) };
  }

  /** Called once per rendered frame before simulation. */
  poll(dt: number) {
    const pad = this.pollPad(dt);
    for (const a of ACTIONS) {
      const codes = this.bindings[a] ?? [];
      let d = this.virt.has(a) || this.padDown.has(a);
      if (!d) for (let i = 0; i < codes.length; i++) if (this.keys.has(codes[i])) { d = true; break; }
      if (d && !this.prev[a]) this.pressed[a] = true; // latched until a simulation step consumes it
      this.prev[a] = d; this.down[a] = d;
    }
    let mx = (this.down.right ? 1 : 0) - (this.down.left ? 1 : 0);
    let my = (this.down.forward ? 1 : 0) - (this.down.back ? 1 : 0);
    if (!mx && !my) { mx = pad.mx + this.touchMove.x; my = pad.my + this.touchMove.y; }
    const l = Math.hypot(mx, my);
    if (l > 1) { mx /= l; my /= l; }
    this.moveX = mx; this.moveY = my;
    // arrow keys always turn the camera (also the fallback when pointer lock is unavailable)
    this.arrowX = (this.keys.has('ArrowRight') ? 1 : 0) - (this.keys.has('ArrowLeft') ? 1 : 0);
    this.arrowY = (this.keys.has('ArrowDown') ? 1 : 0) - (this.keys.has('ArrowUp') ? 1 : 0);
    this.lookX += this.arrowX * 700 * dt; this.lookY += this.arrowY * 500 * dt;
  }

  endFrame() { this.lookX = 0; this.lookY = 0; }

  /** Edge-triggered presses live until the fixed-step simulation has seen them (fast displays skip sim steps). */
  consumePressed() { this.wheel = 0; this.slotPressed = -1; for (const a of ACTIONS) this.pressed[a] = false; }
}
