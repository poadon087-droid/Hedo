/** Wave composition: budget-based, smoothly scaling, deterministic for a given RNG, biased towards each arena's resident creatures. */
import type { Rng } from './core';
import { ENEMY_DEFS } from './enemies';

const RESIDENTS: Record<string, string[]> = {
  canyon: ['sun', 'leaf', 'blob', 'snake', 'scissors'],
  night: ['moth', 'ghost', 'crane', 'leafSniper', 'bomb', 'drummer'],
  snow: ['globe', 'leafIce', 'ghost', 'snake', 'crane', 'knight'],
  toy: ['jack', 'drummer', 'mimic', 'glue', 'scissors', 'magnet'],
  ember: ['sunFire', 'bomb', 'tank', 'knight', 'blobSpike', 'magnet'],
};

export function composeWave(rng: Rng, wave: number, stage: number, map = ''): string[] {
  const eff = wave + stage * 2;
  const fav = RESIDENTS[map] ?? [];
  let budget = 4 + eff * 2.4;
  const out: string[] = [];
  const defs = Object.values(ENEMY_DEFS).filter((d) => !d.boss);
  if (eff >= 6 && (wave % 3 === 0 || wave % 5 === 0)) {
    const minis = defs.filter((d) => d.mini && d.minWave <= eff);
    if (minis.length) { const m = rng.pick(minis); out.push(m.id); budget -= m.cost * 0.7; }
  }
  const pool = defs.filter((d) => !d.mini && d.minWave <= eff);
  let guard = 0;
  while (budget >= 1 && guard++ < 80) {
    const cand = pool.filter((d) => d.cost <= budget);
    if (!cand.length) break;
    const wt = (id: string, cost: number) => (1 / cost) * (fav.includes(id) ? 2.4 : 1);
    let total = 0;
    for (const d of cand) total += wt(d.id, d.cost);
    let r = rng.next() * total, pick = cand[0];
    for (const d of cand) { r -= wt(d.id, d.cost); if (r <= 0) { pick = d; break; } }
    const group = pick.id === 'leaf' || pick.id === 'blob' ? rng.int(2, 3) : pick.id === 'moth' || pick.id === 'bomb' || pick.id === 'crane' ? 2 : 1;
    for (let k = 0; k < group && budget >= pick.cost; k++) { out.push(pick.id); budget -= pick.cost; }
  }
  // shuffle so groups do not always arrive in a row
  for (let i = out.length - 1; i > 0; i--) { const j = rng.int(0, i); [out[i], out[j]] = [out[j], out[i]]; }
  return out;
}
