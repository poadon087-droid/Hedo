import type { ReactNode } from 'react';

export function Ticket({ children, className = '', dark = false }: { children: ReactNode; className?: string; dark?: boolean }) {
  return <div className={`ticket ${dark ? 'ticket-dark' : ''} ${className}`}>{children}</div>;
}

export function Btn({ children, onClick, primary, gold, disabled, className = '', title }: { children: ReactNode; onClick?: () => void; primary?: boolean; gold?: boolean; disabled?: boolean; className?: string; title?: string }) {
  return (
    <button type="button" title={title} disabled={disabled} onClick={onClick} className={`btn ${primary ? 'btn-primary' : ''} ${gold ? 'btn-gold' : ''} ${className}`}>
      {children}
    </button>
  );
}

export function Slider({ label, value, min, max, step, onChange, fmt }: { label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; fmt?: (v: number) => string }) {
  return (
    <label className="flex items-center gap-3 py-1 text-sm uppercase tracking-wide">
      <span className="w-40 shrink-0 font-bold">{label}</span>
      <input className="flex-1" type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(+e.target.value)} aria-label={label} />
      <span className="w-14 text-right tabular-nums">{fmt ? fmt(value) : value.toFixed(2)}</span>
    </label>
  );
}

export function Toggle({ label, value, onChange, hint }: { label: string; value: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <button type="button" role="switch" aria-checked={value} onClick={() => onChange(!value)} className="flex min-h-[44px] w-full items-center gap-3 py-1 text-left text-sm uppercase tracking-wide">
      <span className={`flex h-6 w-11 shrink-0 items-center border-2 border-[#141016] p-0.5 ${value ? 'bg-[#c92b2b]' : 'bg-[#cdbf9d]'}`}>
        <span className={`block h-4 w-4 border-2 border-[#141016] bg-[#f3e7cc] transition-transform ${value ? 'translate-x-5' : ''}`} />
      </span>
      <span className="font-bold">{label}</span>
      {hint && <span className="text-xs normal-case opacity-70">{hint}</span>}
    </button>
  );
}

export const Pips = ({ n, max }: { n: number; max: number }) => (
  <span className="inline-flex gap-1">{Array.from({ length: max }, (_, i) => <span key={i} className={`h-3 w-3 border border-[#141016] ${i < n ? 'bg-[#c92b2b]' : 'bg-[#cdbf9d]'}`} />)}</span>
);
