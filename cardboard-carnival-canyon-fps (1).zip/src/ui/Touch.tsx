import { useRef, useState } from 'react';
import type { Game } from '../game/game';
import type { Action } from '../game/input';

/** Dual virtual sticks + action buttons for phones/tablets. */
export function Touch({ game }: { game: Game }) {
  const stick = useRef<{ id: number; x: number; y: number } | null>(null);
  const look = useRef<{ id: number; x: number; y: number } | null>(null);
  const [knob, setKnob] = useState<{ x: number; y: number } | null>(null);
  const [auto, setAuto] = useState(game.settings.autofire);
  const input = game.input;

  // plain function (not a component) so the DOM buttons survive the HUD's 12 Hz re-renders and keep pointer capture
  const Btn = ({ a, label, cls = '' }: { a: Action; label: string; cls?: string }) => (
    <button
      key={a}
      type="button"
      className={`touch-none pointer-events-auto flex h-14 w-14 items-center justify-center border-2 border-[#141016] bg-[#f3e7cc]/90 text-xs font-bold uppercase text-[#141016] shadow-[3px_3px_0_#000] active:translate-x-[2px] active:translate-y-[2px] ${cls}`}
      onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); input.setVirtual(a, true); }}
      onPointerUp={() => input.setVirtual(a, false)}
      onPointerCancel={() => input.setVirtual(a, false)}
      aria-label={label}
    >{label}</button>
  );

  return (
    <div className="absolute inset-0 touch-none">
      {/* left half: move stick */}
      <div
        className="pointer-events-auto absolute bottom-0 left-0 h-[55%] w-[40%] touch-none"
        onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); stick.current = { id: e.pointerId, x: e.clientX, y: e.clientY }; setKnob({ x: 0, y: 0 }); }}
        onPointerMove={(e) => {
          const s = stick.current; if (!s || s.id !== e.pointerId) return;
          let dx = e.clientX - s.x, dy = e.clientY - s.y; const l = Math.hypot(dx, dy), max = 55;
          if (l > max) { dx = (dx / l) * max; dy = (dy / l) * max; }
          input.touchMove.x = dx / max; input.touchMove.y = -dy / max; setKnob({ x: dx, y: dy });
        }}
        onPointerUp={() => { stick.current = null; input.touchMove.x = 0; input.touchMove.y = 0; setKnob(null); }}
        onPointerCancel={() => { stick.current = null; input.touchMove.x = 0; input.touchMove.y = 0; setKnob(null); }}
      >
        {knob && stick.current && (
          <div className="fixed h-28 w-28 -translate-x-1/2 -translate-y-1/2 rounded-full border-4 border-[#f3e7cc]/60" style={{ left: stick.current.x, top: stick.current.y }}>
            <div className="absolute left-1/2 top-1/2 h-12 w-12 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-[#141016] bg-[#c92b2b]/80" style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }} />
          </div>
        )}
      </div>
      {/* right side: look drag */}
      <div
        className="pointer-events-auto absolute right-0 top-[12%] h-[88%] w-[60%] touch-none"
        onPointerDown={(e) => { e.currentTarget.setPointerCapture(e.pointerId); look.current = { id: e.pointerId, x: e.clientX, y: e.clientY }; }}
        onPointerMove={(e) => { const l = look.current; if (!l || l.id !== e.pointerId) return; input.addLook((e.clientX - l.x) * 1.8, (e.clientY - l.y) * 1.8); l.x = e.clientX; l.y = e.clientY; }}
        onPointerUp={() => { look.current = null; }}
        onPointerCancel={() => { look.current = null; }}
      />
      {/* buttons */}
      <div className="pointer-events-none absolute bottom-[max(16px,env(safe-area-inset-bottom))] right-[max(16px,env(safe-area-inset-right))] flex flex-col items-end gap-2">
        <div className="flex gap-2">{Btn({ a: 'super', label: 'Super' })}{Btn({ a: 'ex', label: 'EX' })}{Btn({ a: 'next', label: 'Swap' })}</div>
        <div className="flex items-end gap-2">{Btn({ a: 'parry', label: 'Parry' })}{Btn({ a: 'dash', label: 'Dash' })}{Btn({ a: 'jump', label: 'Jump' })}</div>
        <div className="flex items-end gap-2">
          {Btn({ a: 'reload', label: 'Load' })}
          {Btn({ a: 'fire', label: 'Fire', cls: '!h-20 !w-20 !bg-[#c92b2b] !text-[#f3e7cc] text-sm' })}
        </div>
      </div>
      <div className="pointer-events-auto absolute right-[max(12px,env(safe-area-inset-right))] top-[max(70px,env(safe-area-inset-top))] flex gap-2">
        <button type="button" className={`btn !px-2 !text-xs ${auto ? 'btn-primary' : ''}`} onClick={() => { const v = !auto; setAuto(v); game.setAutofire(v); }}>Auto-fire {auto ? 'ON' : 'OFF'}</button>
        <button type="button" className="btn !px-3 !text-xs" onClick={() => game.pause()}>Pause</button>
      </div>
    </div>
  );
}
