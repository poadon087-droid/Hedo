import { useState } from 'react';
import type { Game } from '../game/game';
import type { MapId } from '../game/maps';
import { MAP_INFO } from '../game/progression';

/** Arena chooser used by Endless Survival and Time Attack. Stores the choice on the game object. */
export function MapPicker({ game }: { game: Game }) {
  const [pick, setPick] = useState<MapId | 'auto'>(game.mapPick);
  const choose = (p: MapId | 'auto') => { game.mapPick = p; setPick(p); game.sfx.play('ui'); };
  const card = (selected: boolean) => `flex min-h-[44px] flex-col gap-1 border-2 p-2 text-left shadow-[3px_3px_0_#000] transition-transform hover:-translate-y-0.5 ${selected ? 'border-[#c92b2b] bg-[#ffe9a0]' : 'border-[#141016] bg-[#e9dcc0]'}`;
  return (
    <div className="mb-3">
      <div className="mb-1 flex flex-wrap items-baseline gap-2">
        <h3 className="font-display text-2xl leading-none text-[#c92b2b]">Choose your arena</h3>
        <span className="text-xs">Used by Endless Survival and Time Attack. Campaign and Boss Rush use their own stages; Daily picks a seeded arena.</span>
      </div>
      <div className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-6">
        <button type="button" className={card(pick === 'auto')} onClick={() => choose('auto')} aria-pressed={pick === 'auto'}>
          <span className="h-10 border-2 border-[#141016]" style={{ background: 'linear-gradient(90deg,#ffd9a0,#c83a6c,#f2c8e8,#8fc8ff,#ff6a2a)' }} />
          <span className="font-bold uppercase leading-tight">Surprise me</span>
          <span className="text-[11px] leading-tight">Cycles through every arena</span>
        </button>
        {MAP_INFO.map((m) => (
          <button key={m.id} type="button" className={card(pick === m.id)} onClick={() => choose(m.id)} aria-pressed={pick === m.id}>
            <span className="h-10 border-2 border-[#141016]" style={{ background: `linear-gradient(180deg,${m.grad[0]},${m.grad[1]})` }} />
            <span className="font-bold uppercase leading-tight">{m.name}</span>
            <span className="text-[11px] leading-tight">{m.tag}</span>
            <span className="text-[11px] font-bold uppercase leading-tight text-[#c92b2b]">{m.hazard}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
