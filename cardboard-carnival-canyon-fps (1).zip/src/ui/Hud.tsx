import type { HudState } from '../game/game';
import { WEAPONS } from '../game/weapons';
import { ELEM_INFO, RELOAD_ZONE, type Elem } from '../game/elements';

const SYM = ['✿', '◎', '★', '☺'];
const SYM_NAME = ['flower', 'bullseye', 'star', 'smiley'];

function Bar({ frac, color, h = 14 }: { frac: number; color: string; h?: number }) {
  return (
    <div className="relative border-2 border-[#141016] bg-[#2a2230]" style={{ height: h }}>
      <div className="h-full" style={{ width: `${Math.max(0, Math.min(1, frac)) * 100}%`, background: color, transition: 'width 120ms linear' }} />
    </div>
  );
}

export function Hud({ h, colorblind }: { h: HudState; colorblind: boolean }) {
  const low = h.hp / h.maxHp < 0.3;
  const special = h.reelLabel && h.reelT > 0;
  const mag = h.mag;
  return (
    <div className="pointer-events-none absolute inset-0 safe font-[Oswald] text-[#f3e7cc]" aria-live="off">
      {/* top-left: vitals */}
      <div className="absolute left-[max(12px,env(safe-area-inset-left))] top-[max(10px,env(safe-area-inset-top))] w-[min(300px,46vw)] slide-in">
        <div className={`ticket ${low ? 'pulse' : ''}`}>
          <div className="flex items-center justify-between text-sm font-bold uppercase"><span>♥ Health</span><span className="tabular-nums">{Math.ceil(h.hp)}/{h.maxHp}</span></div>
          <Bar frac={h.hp / h.maxHp} color="#c92b2b" h={16} />
          {h.shield > 0 && <div className="mt-1"><Bar frac={h.shield / 20} color="#3f8cf0" h={8} /></div>}
          <div className="mt-2 flex items-center gap-2 text-[11px] font-bold uppercase">
            <span title="Dash" className="flex items-center gap-1"><span className={`h-3 w-3 border-2 border-[#141016] ${h.dashCd <= 0 ? 'bg-[#34c3b0]' : 'bg-[#8a8070]'}`} />Dash</span>
            <span title="Parry" className="flex items-center gap-1"><span className={`h-3 w-3 border-2 border-[#141016] ${h.parryCd <= 0 ? 'bg-[#ffd54a]' : 'bg-[#8a8070]'}`} />Parry</span>
            <span className={h.canEx ? 'text-[#c92b2b]' : 'opacity-50'}>EX 3¢</span>
            <span className={h.canSuper ? 'text-[#c92b2b]' : 'opacity-50'}>SUPER 5¢</span>
          </div>
          {h.exT > 0 && <div className="mt-1 text-xs font-bold text-[#c92b2b]">PERFECT AIM {h.exT.toFixed(1)}s</div>}
        </div>
      </div>

      {/* top-center: stage + boss */}
      <div className="absolute left-1/2 top-[max(10px,env(safe-area-inset-top))] w-[min(420px,50vw)] -translate-x-1/2 text-center slide-in">
        <div className="ticket py-1">
          <div className="font-display text-lg leading-none">{h.stage}</div>
          <div className="text-xs font-bold uppercase tracking-widest">
            {h.waves > 0 ? `Wave ${h.wave}/${h.waves}` : 'Boss'}
            {(h.mode === 'timeattack' || h.mode === 'endless') && <span className="ml-3 tabular-nums">⏱ {h.time.toFixed(1)}s</span>}
            {h.modName && <span className="ml-3 text-[#c92b2b]">{h.modName}</span>}
          </div>
        </div>
        {h.boss && (
          <div className="ticket ticket-dark mt-2 pop-in">
            <div className="flex justify-between text-sm font-bold uppercase"><span>{h.boss.name}</span><span>Phase {h.boss.phase}/3</span></div>
            <Bar frac={h.boss.frac} color="#ff5a3c" h={14} />
          </div>
        )}
      </div>

      {/* top-right: score + coins */}
      <div className="absolute right-[max(12px,env(safe-area-inset-right))] top-[max(10px,env(safe-area-inset-top))] text-right slide-in">
        <div className="ticket">
          <div className="font-display text-2xl leading-none tabular-nums">{h.score.toLocaleString()}</div>
          <div className="text-xs font-bold uppercase tracking-widest">Score</div>
          <div className="mt-1 text-sm font-bold">🪙 <span className="tabular-nums">{h.coins}</span></div>
        </div>
        {h.combo > 1 && (
          <div className="ticket ticket-dark mt-2 pop-in">
            <div className="font-display text-xl text-[#ffd54a]">x{(1 + Math.min(h.combo, 40) * 0.1).toFixed(1)} COMBO</div>
            <Bar frac={h.comboT} color="#ffd54a" h={6} />
          </div>
        )}
      </div>

      {/* crosshair + hit marker */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2" aria-hidden>
        <div className="relative h-10 w-10">
          <span className={`absolute left-1/2 top-1/2 h-[10px] w-[10px] -translate-x-1/2 -translate-y-1/2 rounded-full border-2 ${h.over ? 'border-[#c92b2b] bg-[#c92b2b]/40' : 'border-[#f3e7cc]'}`} style={{ boxShadow: '0 0 0 1.5px #141016' }} />
          {[0, 90, 180, 270].map((a) => <span key={a} className="absolute left-1/2 top-1/2 h-2.5 w-[3px] bg-[#f3e7cc]" style={{ transform: `translate(-50%,-50%) rotate(${a}deg) translateY(-14px)`, boxShadow: '0 0 0 1px #141016' }} />)}
          {h.hitT > 0 && [45, 135, 225, 315].map((a) => <span key={a} className={`absolute left-1/2 top-1/2 h-3.5 w-1 ${h.critHit ? 'bg-[#ffd54a]' : 'bg-[#fff]'}`} style={{ transform: `translate(-50%,-50%) rotate(${a}deg) translateY(-${h.killT > 0 ? 20 : 14}px)`, boxShadow: '0 0 0 1px #141016' }} />)}
        </div>
        {h.charge > 0 && <div className="mx-auto mt-3 w-24"><Bar frac={h.charge} color="#ff8fb8" h={8} /></div>}
      </div>

      {/* damage direction: triangle chevrons (shape cue, not colour only) */}
      {h.hurt.map((d, i) => (
        <div key={i} className="absolute left-1/2 top-1/2 h-0 w-0" style={{ transform: `rotate(${d.ang}rad)`, opacity: Math.min(1, d.t) }}>
          <div className="absolute -left-6 -top-[min(38vh,260px)] h-0 w-0 border-x-[24px] border-b-[40px] border-x-transparent border-b-[#c92b2b]" style={{ filter: 'drop-shadow(2px 2px 0 #000)' }} />
          <span className="absolute -left-2 -top-[calc(min(38vh,260px)-12px)] font-display text-2xl text-[#f3e7cc]">!</span>
        </div>
      ))}
      {h.parryT > 0 && <div className="absolute left-1/2 top-1/2 h-40 w-40 -translate-x-1/2 -translate-y-1/2 rounded-full border-4 border-[#f3e7cc] opacity-70" />}

      {/* banner */}
      {h.bannerT > 0 && (
        <div className="absolute left-1/2 top-[22%] -translate-x-1/2 text-center" style={{ opacity: Math.min(1, h.bannerT * 2) }}>
          <div className="font-display pop-in text-5xl text-[#f3e7cc] ink-text md:text-7xl">{h.banner}</div>
          {h.bannerSub && <div className="font-script mt-1 text-3xl text-[#ffd54a] ink-text">{h.bannerSub}</div>}
        </div>
      )}

      {/* reel + captions */}
      <div className="absolute bottom-[max(12px,env(safe-area-inset-bottom))] left-1/2 flex -translate-x-1/2 flex-col items-center gap-2">
        {h.captions.map((c, i) => <div key={i} className="max-w-[80vw] bg-black/75 px-3 py-1 text-sm text-white">{c.text}</div>)}
        <div className="flex items-center gap-2">
          <div className="flex gap-1" aria-label={'Capsule reel: ' + h.reel.map((s) => SYM_NAME[s]).join(', ')}>
            {h.reel.map((s, i) => <span key={i} className={`flex h-10 w-10 items-center justify-center border-2 border-[#141016] bg-[#f3e7cc] text-2xl text-[#141016] shadow-[3px_3px_0_#000] ${h.reelT > 1.3 ? 'pop-in' : ''}`}>{SYM[s]}</span>)}
          </div>
          {special && <div className="ticket ticket-dark pop-in py-1 font-display text-lg text-[#ffd54a]">{h.reelLabel}</div>}
        </div>
      </div>

      {/* bottom-left: weapon */}
      <div className="absolute bottom-[max(12px,env(safe-area-inset-bottom))] left-[max(12px,env(safe-area-inset-left))] w-[min(320px,48vw)] slide-up">
        <div className="ticket">
          <div className="flex items-baseline justify-between"><span className="font-display text-xl leading-none">{h.weaponName}</span><span className="font-display text-3xl tabular-nums leading-none">{h.ammo}<span className="text-base opacity-60">/{mag}</span></span></div>
          <div className="mt-1 flex flex-wrap gap-[3px]">
            {mag <= 12 ? Array.from({ length: mag }, (_, i) => <span key={i} className={`h-3 w-3 rounded-full border border-[#141016] ${i < h.ammo ? 'bg-[#ffd54a]' : 'bg-[#cdbf9d]'}`} />) : <div className="w-full"><Bar frac={h.ammo / mag} color="#ffd54a" h={8} /></div>}
          </div>
          {h.reload > 0 && (
            <div className="mt-1">
              <div className="text-[11px] font-bold uppercase">Refilling… tap reload in the gold zone!</div>
              <div className="relative">
                <Bar frac={h.reload} color="#34c3b0" h={10} />
                <span className="absolute top-0 h-full border-x-2 border-[#141016] bg-[#ffd54a]/70" style={{ left: `${RELOAD_ZONE[0] * 100}%`, width: `${(RELOAD_ZONE[1] - RELOAD_ZONE[0]) * 100}%` }} />
              </div>
            </div>
          )}
          {(h.perfect ?? 0) > 0 && <div className="mt-1 text-[11px] font-bold uppercase text-[#c92b2b]">Perfect load: +25% damage {(h.perfect ?? 0).toFixed(1)}s</div>}
          {h.elem && (
            <div className="mt-1 flex flex-wrap items-center gap-1 text-[11px] font-bold uppercase">
              Damage:
              {h.elem.split('+').map((k) => { const e = ELEM_INFO[k as Elem]; return <span key={k} className="border-2 border-[#141016] px-1" style={{ background: e.css }}>{e.icon} {e.name}</span>; })}
            </div>
          )}
          <div className="mt-2 flex flex-wrap gap-1">
            {WEAPONS.map((w, i) => <span key={w.id} title={w.name} className={`flex h-6 w-6 items-center justify-center border-2 border-[#141016] text-xs font-bold ${i === h.weapon ? 'bg-[#c92b2b] text-[#f3e7cc]' : 'bg-[#cdbf9d]'}`}>{(i % 10 + 1) % 10}{i >= 10 ? '′' : ''}</span>)}
          </div>
        </div>
      </div>

      {/* toasts */}
      <div className="absolute right-[max(12px,env(safe-area-inset-right))] top-[40%] flex flex-col items-end gap-2">
        {h.toasts.map((t, i) => <div key={i} className="ticket slide-in py-1 text-sm font-bold uppercase">{t.text}</div>)}
      </div>
      {colorblind && h.hurtFlash > 0.3 && <div className="absolute inset-0 border-[10px] border-dashed border-white/70" />}
    </div>
  );
}
