import type { Game } from '../game/game';
import { hashString } from '../game/core';
import { WEAPONS } from '../game/weapons';
import { ACHIEVEMENTS, CAMPAIGN, CHARMS, DAILY_MODS, MODES, UPGRADES, WEAPON_MAX_LV, todayKey, weaponUpgradeCost, type ModeId } from '../game/progression';
import { Btn, Pips, Ticket } from './kit';
import { MapPicker } from './MapPicker';
import { ENEMY_DEFS } from '../game/enemies';
import { AFFINITY, ELEM_INFO, TIPS } from '../game/elements';

export type Screen = 'main' | 'modes' | 'shop' | 'armory' | 'ach' | 'scores' | 'help';

function Frame({ title, onBack, children, wide = false }: { title: string; onBack: () => void; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/60 p-3">
      <Ticket className={`slide-up flex max-h-full w-full flex-col ${wide ? 'max-w-5xl' : 'max-w-3xl'}`}>
        <div className="mb-2 flex items-center justify-between gap-2">
          <h2 className="font-display text-4xl leading-none">{title}</h2>
          <Btn onClick={onBack}>← Back</Btn>
        </div>
        <div className="scroll-y flex-1 pr-2">{children}</div>
      </Ticket>
    </div>
  );
}

export function Menu({ game, screen, setScreen, openOptions, refresh }: { game: Game; screen: Screen; setScreen: (s: Screen) => void; openOptions: () => void; refresh: () => void }) {
  const save = game.save;
  const back = () => setScreen('main');
  const play = (m: ModeId, stage = 0) => { game.start(m, stage); setScreen('main'); };
  const dailySeed = hashString(todayKey());
  const dailyMod = DAILY_MODS[dailySeed % DAILY_MODS.length];

  if (screen === 'main') {
    return (
      <div className="absolute inset-0 z-10 flex items-center safe">
        <div className="flex w-full max-w-md flex-col gap-3 pl-2 md:pl-10">
          <div className="slide-in">
            <div className="font-script text-3xl text-[#ffd54a] ink-text">a handmade shooter</div>
            <h1 className="font-display text-6xl leading-[0.9] text-[#f3e7cc] ink-text md:text-7xl">Cardboard<br />Carnival<br /><span className="text-[#c92b2b]">Canyon</span></h1>
          </div>
          <Btn primary onClick={() => setScreen('modes')} className="slide-in !text-xl">▶ Play</Btn>
          <div className="grid grid-cols-2 gap-2">
            <Btn onClick={() => setScreen('shop')}>Upgrade stand</Btn>
            <Btn onClick={() => setScreen('armory')}>Armory</Btn>
            <Btn onClick={() => setScreen('ach')}>Achievements</Btn>
            <Btn onClick={() => setScreen('scores')}>High scores</Btn>
            <Btn onClick={openOptions}>Options</Btn>
            <Btn onClick={() => setScreen('help')}>How to play</Btn>
          </div>
          <Ticket className="slide-up text-sm"><b>🪙 {save.coins}</b> coins banked · Daily twist: <b>{dailyMod.name}</b> — {dailyMod.desc}</Ticket>
        </div>
      </div>
    );
  }

  if (screen === 'modes') {
    const unlocked = Math.min(CAMPAIGN.length - 1, save.campaign);
    return (
      <Frame title="Choose a mode" onBack={back} wide>
        <MapPicker game={game} />
        <div className="grid gap-3 md:grid-cols-2">
          {MODES.map((m) => (
            <Ticket key={m.id} className="slide-in flex flex-col gap-2">
              <div className="font-display text-2xl leading-none">{m.name}</div>
              <p className="text-sm">{m.desc}</p>
              {m.id === 'campaign' ? (
                <div className="flex flex-wrap gap-2">
                  {CAMPAIGN.map((st, i) => <Btn key={st.name} primary={i === unlocked} disabled={i > unlocked} onClick={() => play('campaign', i)} title={st.name}>{i > unlocked ? '🔒' : ''} {i + 1}</Btn>)}
                </div>
              ) : <div className="flex items-center gap-3"><Btn primary onClick={() => play(m.id)}>Play</Btn>
                {m.id === 'daily' && <span className="text-xs"><b>{dailyMod.name}</b> — {dailyMod.desc}. Today's best: {save.daily.date === todayKey() ? save.daily.score.toLocaleString() : '—'}</span>}
                {m.id === 'timeattack' && <span className="text-xs">Best: {save.scores.timeattack_best ? save.scores.timeattack_best + 's' : '—'}</span>}
                {m.id !== 'daily' && m.id !== 'timeattack' && <span className="text-xs">Best: {(save.scores[m.id] ?? 0).toLocaleString()}</span>}
              </div>}
            </Ticket>
          ))}
        </div>
      </Frame>
    );
  }

  if (screen === 'shop') {
    const buy = (cost: number, apply: () => void) => { if (save.coins < cost) return; save.coins -= cost; apply(); game.persist(); refresh(); };
    return (
      <Frame title="Upgrade stand" onBack={back} wide>
        <div className="mb-2 font-display text-2xl">🪙 {save.coins} coins</div>
        <h3 className="font-display text-xl text-[#c92b2b]">Perks</h3>
        <div className="grid gap-2 md:grid-cols-2">
          {UPGRADES.map((u) => {
            const lv = save.upgrades[u.id] ?? 0, cost = u.cost(lv), maxed = lv >= u.max;
            return (
              <div key={u.id} className="flex items-center justify-between gap-2 border-2 border-[#141016] bg-[#e9dcc0] p-2">
                <div><div className="font-bold uppercase">{u.name}</div><div className="text-xs">{u.desc}</div><Pips n={lv} max={u.max} /></div>
                <Btn disabled={maxed || save.coins < cost} onClick={() => buy(cost, () => { save.upgrades[u.id] = lv + 1; })}>{maxed ? 'Max' : `${cost}¢`}</Btn>
              </div>
            );
          })}
        </div>
        <h3 className="font-display mt-3 text-xl text-[#c92b2b]">Weapon tuning (+12% damage per level)</h3>
        <div className="grid gap-2 md:grid-cols-2">
          {WEAPONS.map((w) => {
            const lv = save.weaponLv[w.id] ?? 0, cost = weaponUpgradeCost(lv), maxed = lv >= WEAPON_MAX_LV;
            return (
              <div key={w.id} className="flex items-center justify-between gap-2 border-2 border-[#141016] bg-[#e9dcc0] p-2">
                <div><div className="font-bold uppercase">{w.name}</div><Pips n={lv} max={WEAPON_MAX_LV} /></div>
                <Btn disabled={maxed || save.coins < cost} onClick={() => buy(cost, () => { save.weaponLv[w.id] = lv + 1; })}>{maxed ? 'Max' : `${cost}¢`}</Btn>
              </div>
            );
          })}
        </div>
        <h3 className="font-display mt-3 text-xl text-[#c92b2b]">Charms (equip up to 2)</h3>
        <div className="grid gap-2 md:grid-cols-2">
          {CHARMS.map((c) => {
            const owned = save.ownedCharms.includes(c.id), equipped = save.charms.includes(c.id);
            return (
              <div key={c.id} className="flex items-center justify-between gap-2 border-2 border-[#141016] bg-[#e9dcc0] p-2">
                <div><div className="font-bold uppercase">{c.name}</div><div className="text-xs">{c.desc}</div></div>
                {!owned ? <Btn disabled={save.coins < c.cost} onClick={() => buy(c.cost, () => { save.ownedCharms.push(c.id); })}>{c.cost}¢</Btn>
                  : <Btn primary={equipped} onClick={() => { if (equipped) save.charms = save.charms.filter((x) => x !== c.id); else if (save.charms.length < 2) save.charms.push(c.id); game.persist(); refresh(); }}>{equipped ? 'Equipped' : save.charms.length >= 2 ? 'Full' : 'Equip'}</Btn>}
              </div>
            );
          })}
        </div>
      </Frame>
    );
  }

  if (screen === 'armory') {
    return (
      <Frame title="Armory — all unlocked" onBack={back} wide>
        <div className="grid gap-2 md:grid-cols-2">
          {WEAPONS.map((w, i) => (
            <div key={w.id} className="flex gap-3 border-2 border-[#141016] bg-[#e9dcc0] p-2">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center border-2 border-[#141016] bg-[#c92b2b] font-display text-2xl text-[#f3e7cc]">{(i % 10 + 1) % 10}{i >= 10 ? '′' : ''}</div>
              <div><div className="font-display text-xl leading-none">{w.name}</div><div className="text-sm">{w.desc}</div>
                <div className="mt-1 text-xs uppercase opacity-70">Damage {w.dmg} · {w.auto ? 'full auto' : w.charge ? 'charge' : 'semi'} · {w.mag} capsules · reload {w.reload}s · tuning Lv {save.weaponLv[w.id] ?? 0}</div></div>
            </div>
          ))}
        </div>
        <h3 className="font-display mt-4 text-3xl text-[#c92b2b]">Bestiary: weaknesses</h3>
        <p className="mb-2 text-sm">Hit a creature with its <b>weak</b> element for x1.6 damage (gold numbers); resisted elements do x0.55. Elites carry a coloured aura and a name tag. Each gun's damage type is shown in the HUD.</p>
        <div className="grid gap-2 md:grid-cols-2">
          {Object.values(ENEMY_DEFS).map((d) => {
            const a = AFFINITY[d.id];
            const chip = (k: 'weak' | 'resist') => {
              const e = a?.[k];
              return e ? <span className={`border-2 border-[#141016] px-1 text-[11px] font-bold uppercase ${k === 'resist' ? 'opacity-60' : ''}`} style={{ background: ELEM_INFO[e].css }}>{k === 'weak' ? 'Weak' : 'Resists'} {ELEM_INFO[e].icon} {ELEM_INFO[e].name}</span> : null;
            };
            return (
              <div key={d.id} className="border-2 border-[#141016] bg-[#e9dcc0] p-2">
                <div className="flex flex-wrap items-center gap-2"><span className="font-display text-xl leading-none">{d.name}</span><span className="text-xs">HP {d.hp}</span>{chip('weak')}{chip('resist')}</div>
                <div className="mt-1 text-xs">{TIPS[d.id]}</div>
              </div>
            );
          })}
        </div>
      </Frame>
    );
  }

  if (screen === 'ach') {
    return (
      <Frame title="Achievements" onBack={back}>
        <div className="mb-2 text-sm">{save.achievements.length}/{ACHIEVEMENTS.length} unlocked · {save.stats.kills} creatures defeated · {save.stats.jackpots} jackpots · {save.stats.bosses} bosses</div>
        <div className="grid gap-2">
          {ACHIEVEMENTS.map((a) => { const got = save.achievements.includes(a.id); return (
            <div key={a.id} className={`flex items-center gap-3 border-2 border-[#141016] p-2 ${got ? 'bg-[#ffe9a0]' : 'bg-[#cdbf9d] opacity-70'}`}>
              <span className="text-2xl">{got ? '★' : '🔒'}</span><div><div className="font-bold uppercase">{a.name}</div><div className="text-xs">{a.desc}</div></div>
            </div>); })}
        </div>
      </Frame>
    );
  }

  if (screen === 'scores') {
    return (
      <Frame title="High scores" onBack={back}>
        <table className="w-full text-left text-lg">
          <tbody>
            {MODES.map((m) => (
              <tr key={m.id} className="border-b-2 border-[#141016]/30"><td className="py-2 font-bold uppercase">{m.name}</td>
                <td className="py-2 text-right font-display text-2xl tabular-nums">{m.id === 'timeattack' ? (save.scores.timeattack_best ? save.scores.timeattack_best + 's' : '—') : m.id === 'daily' ? (save.daily.date ? save.daily.score.toLocaleString() + ' (' + save.daily.date + ')' : '—') : (save.scores[m.id] ?? 0).toLocaleString()}</td></tr>
            ))}
          </tbody>
        </table>
        <div className="mt-2 text-sm">Runs: {save.stats.runs} · Coins collected: {save.stats.coinsEver}</div>
      </Frame>
    );
  }

  return (
    <Frame title="How to play" onBack={back}>
      <div className="space-y-2 text-base">
        <p><b>Goal:</b> clear every wave of cardboard creatures, collect coins, beat the bosses.</p>
        <p><b>Move</b> WASD · <b>Look</b> mouse (or arrow keys) · <b>Fire</b> left click · <b>Jump</b> Space · <b>Dash</b> Shift (brief invulnerability) · <b>Parry</b> right click / V (deflect projectiles back) · <b>Reload</b> R · <b>Swap</b> 1-0 (press the key of the weapon in hand again for its second-bank partner, 11-18) / wheel / Z X · <b>Inspect</b> F</p>
        <p><b>Capsule reel:</b> every shot spins the three drums. Triple <b>flower</b> = burning petal burst, triple <b>bullseye</b> = crit, triple <b>star</b> = jackpot super shot with slow-mo.</p>
        <p><b>EX (E, 3 coins):</b> five seconds of perfect aim. <b>Super (Q, 5 coins):</b> carnival finale that blasts everything nearby.</p>
        <p><b>Read the telegraphs:</b> a yellow ⚠ triangle and lowered eyebrows mean an attack is coming. Blobs squash before they leap. Ground rings mark UFO beams.</p>
        <p><b>Power-ups:</b> gift boxes drop from defeated creatures and after every cleared wave. Rapid Reels, Double Dip, Paper Shield, Slow-Mo Syrup, Coin Vacuum and Confetti Bomb. Some waves roll a <b>twist</b> (Swarm, Sugar Rush, Armor Parade, Gold Rush).</p>
        <p><b>Hazards:</b> glowing trampolines launch you skyward, ice patches are slippery, lava vents flash then erupt, glue and frost puddles slow you, and red TNT crates blow up everything nearby. Shoot them from a distance.</p>
        <p><b>Touch:</b> left stick moves, drag the right side to look, buttons act. <b>Gamepad:</b> plug in and go.</p>
      </div>
    </Frame>
  );
}
