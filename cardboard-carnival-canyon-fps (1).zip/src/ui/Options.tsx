import { useState } from 'react';
import type { Game } from '../game/game';
import { ACTIONS, ACTION_LABEL, prettyCode, type Action } from '../game/input';
import { DEFAULT_BINDINGS, defaultSave, storeSave, type Settings } from '../game/save';
import { runSelfTests, type TestResult } from '../game/selftest';
import { Btn, Slider, Toggle, Ticket } from './kit';

export function Options({ game, onClose, refresh }: { game: Game; onClose: () => void; refresh: () => void }) {
  const s = game.settings;
  const [, tick] = useState(0);
  const [rebind, setRebind] = useState<Action | null>(null);
  const [tests, setTests] = useState<TestResult[] | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);
  const set = <K extends keyof Settings>(k: K, v: Settings[K]) => { s[k] = v; game.applySettings(); tick((n) => n + 1); };

  const startRebind = (a: Action) => {
    setRebind(a);
    game.input.onRebind = (code) => {
      setRebind(null);
      if (code === 'Escape') return;
      // a key can only live on one action: steal it from any other
      for (const k of ACTIONS) s.bindings[k] = s.bindings[k].filter((c) => c !== code);
      s.bindings[a] = [code, ...s.bindings[a].filter((c) => c !== code)].slice(0, 2);
      for (const k of ACTIONS) if (!s.bindings[k].length) s.bindings[k] = [...DEFAULT_BINDINGS[k]];
      game.applySettings(); tick((n) => n + 1);
    };
  };

  const fullscreen = () => { if (document.fullscreenElement) void document.exitFullscreen(); else void document.documentElement.requestFullscreen?.(); };

  return (
    <div className="absolute inset-0 z-30 flex items-center justify-center bg-black/70 p-3">
      <Ticket className="slide-up flex max-h-full w-full max-w-3xl flex-col">
        <div className="mb-2 flex items-center justify-between">
          <h2 className="font-display text-4xl leading-none">Options</h2>
          <Btn onClick={onClose} primary>Done</Btn>
        </div>
        <div className="scroll-y grid flex-1 gap-x-8 gap-y-1 pr-2 md:grid-cols-2">
          <div>
            <h3 className="font-display text-xl text-[#c92b2b]">Audio</h3>
            <Slider label="Master" value={s.master} min={0} max={1} step={0.05} onChange={(v) => set('master', v)} fmt={(v) => Math.round(v * 100) + '%'} />
            <Slider label="Music" value={s.music} min={0} max={1} step={0.05} onChange={(v) => set('music', v)} fmt={(v) => Math.round(v * 100) + '%'} />
            <Slider label="Effects" value={s.sfx} min={0} max={1} step={0.05} onChange={(v) => set('sfx', v)} fmt={(v) => Math.round(v * 100) + '%'} />
            <Toggle label="Mute all" value={s.muted} onChange={(v) => set('muted', v)} />
            <h3 className="font-display mt-2 text-xl text-[#c92b2b]">Video</h3>
            <label className="flex items-center gap-3 py-1 text-sm font-bold uppercase">
              <span className="w-40">Quality</span>
              <select className="min-h-[44px] flex-1 border-2 border-[#141016] bg-[#f3e7cc] px-2" value={s.quality} onChange={(e) => set('quality', e.target.value as Settings['quality'])}>
                <option value="auto">Auto (downgrades if slow)</option><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option>
              </select>
            </label>
            <Slider label="Resolution" value={s.resScale} min={0.5} max={1.5} step={0.05} onChange={(v) => set('resScale', v)} fmt={(v) => Math.round(v * 100) + '%'} />
            <Slider label="Field of view" value={s.fov} min={60} max={110} step={1} onChange={(v) => set('fov', v)} fmt={(v) => v + '°'} />
            <Btn onClick={fullscreen} className="mt-1">Toggle fullscreen</Btn>
            <h3 className="font-display mt-2 text-xl text-[#c92b2b]">Gameplay & access</h3>
            <Slider label="Look sensitivity" value={s.sens} min={0.2} max={3} step={0.05} onChange={(v) => set('sens', v)} fmt={(v) => v.toFixed(2) + 'x'} />
            <Slider label="Screen shake" value={s.shake} min={0} max={1.5} step={0.1} onChange={(v) => set('shake', v)} fmt={(v) => Math.round(v * 100) + '%'} />
            <label className="flex items-center gap-3 py-1 text-sm font-bold uppercase">
              <span className="w-40">Difficulty</span>
              <select className="min-h-[44px] flex-1 border-2 border-[#141016] bg-[#f3e7cc] px-2" value={s.difficulty} onChange={(e) => set('difficulty', e.target.value as Settings['difficulty'])}>
                <option value="easy">Easy (-40% damage taken)</option><option value="normal">Normal</option><option value="hard">Hard (+40% damage taken)</option>
              </select>
            </label>
            <Toggle label="Colorblind-safe cues" value={s.colorblind} onChange={(v) => set('colorblind', v)} hint="bigger warning icons and shapes" />
            <Toggle label="Subtitles / sound captions" value={s.subtitles} onChange={(v) => set('subtitles', v)} />
            <Toggle label="Reduced motion" value={s.reducedMotion} onChange={(v) => set('reducedMotion', v)} hint="less shake, bob and FOV kick" />
            <Toggle label="Auto-fire (needs a target)" value={s.autofire} onChange={(v) => { set('autofire', v); game.setAutofire(v); }} />
          </div>
          <div>
            <h3 className="font-display text-xl text-[#c92b2b]">Controls <span className="font-[Oswald] text-xs font-normal normal-case text-[#141016]/70">(click an action, then press a key or mouse button; Esc cancels)</span></h3>
            <div className="grid grid-cols-1 gap-1">
              {ACTIONS.map((a) => (
                <div key={a} className="flex items-center justify-between gap-2 text-sm font-bold uppercase">
                  <span>{ACTION_LABEL[a]}</span>
                  <button type="button" className="btn !min-w-[120px] !py-1 !text-xs" onClick={() => startRebind(a)}>{rebind === a ? 'Press a key…' : (s.bindings[a] ?? []).map(prettyCode).join(' / ')}</button>
                </div>
              ))}
              <p className="text-xs">Weapons: number keys 1-0, mouse wheel, or the swap keys. Arrow keys always turn the camera. Gamepad: sticks, RT fire, A jump, B dash, X reload, LT parry, LB/RB swap.</p>
              <Btn onClick={() => { s.bindings = JSON.parse(JSON.stringify(DEFAULT_BINDINGS)); game.applySettings(); tick((n) => n + 1); }} className="mt-1">Reset controls</Btn>
            </div>
            <h3 className="font-display mt-3 text-xl text-[#c92b2b]">Diagnostics</h3>
            <Btn onClick={() => setTests(runSelfTests())}>Run self-tests</Btn>
            {tests && (
              <ul className="mt-2 space-y-0.5 text-xs">
                {tests.map((t) => <li key={t.name} className={t.ok ? '' : 'font-bold text-[#c92b2b]'}>{t.ok ? '✔' : '✘'} {t.name} {t.info && <span className="opacity-70">— {t.info}</span>}</li>)}
                <li className="font-bold">{tests.filter((t) => t.ok).length}/{tests.length} passed</li>
              </ul>
            )}
            <h3 className="font-display mt-3 text-xl text-[#c92b2b]">Save data</h3>
            {!confirmReset ? <Btn onClick={() => setConfirmReset(true)}>Reset all progress…</Btn> : (
              <div className="flex gap-2"><Btn primary onClick={() => { Object.assign(game.save, defaultSave()); storeSave(game.save); setConfirmReset(false); refresh(); }}>Yes, erase everything</Btn><Btn onClick={() => setConfirmReset(false)}>Cancel</Btn></div>
            )}
          </div>
        </div>
      </Ticket>
    </div>
  );
}
