# Changelog

All entries below were found by **code review and type-checking** while building (no browser was available for live playtesting — see README, Known limitations).

## 1.3.0 — lighting, map looks, guns and creatures

### Added
* Lighting: per-arena split-tone colour grade + exposure, fresnel rim light on every toon material (arena-tinted), raymarched sun / moon / volcano shafts, pooled dynamic point lights (muzzle flash, explosions, kills), lava-vent glow, light flicker, contact shadows under props, creatures and crates.
* Map looks (`scenery.ts`): terraced cut-paper horizon ridges, night cloud sea, shooting stars, wind-swept grass, rocks, flowers, runway studs, confetti litter, ice crystals, snow mounds, toy blocks, marbles, embers, ash, floor decals.
* Guns (`weapons.ts` rewritten): all 18 have their own silhouette and animated parts driven by a per-frame `tick` (kick, charge, ammo, reload progress, time since the last shot).
* Weakness system (`elements.ts`): six damage types, per-creature weakness (x1.6) / resistance (x0.55), damage numbers, health bars with weakness badge, damage type in the HUD, Bestiary with field notes.
* Elite affixes (`enemyfx.ts`): Golden, Volatile, Regenerating, Swift, Shielded.
* Reload mini-game: tap reload inside the gold zone for an instant reload and +25% damage for 6 s; tapping outside jams the gun briefly.
* Enemy projectile ink trails, per-species death effects.
* New self-test for the weakness table and reload zone.

### Bugs found and fixed while building
1. **Clones lost the rim light.** `Material.clone()` does not copy `onBeforeCompile`, which would have left every creature (their materials are clones) without it. The patch is installed on `MeshToonMaterial.prototype` instead, so clones and directly constructed materials get it too.
2. **Dying creatures could keep a floating health bar / shadow.** The presentation sync runs from both the normal and the dying branch of `Enemy.sync`, and hides itself when the creature is dead.
3. **Elite tint was overwritten by the hit-flash state.** The tint is applied last, after the emissive state, and skipped only while a hit flash or burn is active.
4. **Pending explosions took the wrong element.** `explode()` wraps an inner function that sets and restores the host's current element, so a Bazooka blast is Blast, a Firework is Fire, and nothing leaks into later damage calls.
5. **Shader variable shadowing a GLSL built-in** (`step`) in the lens shader was renamed.
6. Wind clock is the existing outline clock instead of a second one that nothing would have updated.

### Still not verified
* No live playtest, no screenshots, in-app self-tests not executed by the author. The new GLSL patches (rim light, grass sway, sun shafts, colour grade) compile-checked only by the bundler; a driver-specific shader error would show up in the browser console. Balance of weakness multipliers, elites and the reload window is untested.

## 1.2.0 — more arenas, more enemies, more fun

### Added
* Three new arenas (`maps2.ts`): Frostbite Fold, Toybox Takeover, Ember Foundry; arena picker in the menu; campaign extended to 8 stages; arena look (bloom, dust, weapon lighting, music mood) now comes from each map's data.
* Eight new enemies (`enemies3.ts`) with unique mechanics; wave composition favours each arena's residents (`director.ts`).
* Power-up gift boxes, wave twists, kill-streak call-outs, trampolines, slippery ice, lava vents, glue / frost zones, chain-exploding TNT crates (`gameplay.ts`).
* New self-test covering arena tables, campaign references, new roster and wave composition on every arena.

### Design notes / bugs avoided while building
1. Edits to the same source file were applied one at a time this round (the previous round lost edits to parallel patches), and the type-checker was consulted after each batch.
2. Circular imports between `enemies` / `enemies2` / `enemies3` were checked: none of them touches another module's exports at load time.
3. The wave director had no arena parameter; caught in review and wired through `composeWave(rng, wave, stage, map)`.
4. Crates are culled from under new scenery and trampolines so nothing spawns inside props.

### Still not verified
* No live playtest, no screenshots, in-app self-tests not executed by the author. Balance of the new enemies, hazards and twists is untested.

## 1.1.0 — weapons, enemies and maps expansion

### Added
* 8 new prop-style weapons (Paper-Plane Volley, Giant Marker, Balloon Pump, Rubber Stamp Slammer, Firework Rack, Paperclip Zapper, Pencil Sniper, Bubble-Wrap Mines) with new sounds, hitscan/chain-lightning beams, puddle traps, proximity mines.
* Per-weapon muzzle and impact effects for all 18 weapons (`weaponfx.ts`), per-weapon muzzle-flash size/colour, lens chromatic punch on heavy weapons.
* 9 new enemy types (`enemies2.ts`) with unique AI; knight frontal shields; enemy mortar shells with area blasts; chain-reaction bombs; ally haste/heal.
* Large map-dressing pass for both maps (`decor.ts`), distant fireworks at night, painted cliff doodles, climbable lookout platforms.

### Bugs found and fixed during this update
1. **Lost edits from parallel file patches** — several edits applied at the same time to one file overwrote each other (missing `Beam`/`Trap` fields and imports in `combat.ts`, the `blast` method in `game.ts`). Found with the type-checker (the bundler alone does not catch it), re-applied one at a time.
2. **Corrupted tail of `combat.ts`** (duplicated fragment after a fuzzy patch) — repaired.
3. **Vector aliasing in muzzle effects** — the cone-basis helper used the same scratch vector as the negated direction, which zeroed the axis for back-blast particles; separate scratch vectors now.
4. Crates generated under the new scenery are removed (`cullCrates`) so nothing spawns inside platforms and stalls.
5. Dead flying enemies (moths) now fall to the ground while their fold-flat animation plays.

### Still not verified
* No live playtest, no screenshots, in-app self-tests not executed by the author (no browser available). New enemy and weapon balance is untested.

## 1.0.0 — first complete build

### Bugs found and fixed
1. **Boss bullets could never hit.** King spiral/ring and Marigold rings were fired at 2.7–4.2 m, over the player's head. They are now waist height (jump/dash to dodge); the UFO's spin attack now fires converging plasma toward the area around the player instead of a flat ring at 10 m.
2. **Infinite recursion on kill.** With the Confetti Popper charm (or the boss-death wipe) the dying enemy was still "alive" while its own area damage ran. `die()` now runs first in `killEnemy`.
3. **Lost / duplicated input.** Edge presses (jump, parry, swap, super…) were cleared every rendered frame, so on 120–144 Hz displays a press could land on a frame with no simulation step and vanish, and on slow frames a press could trigger twice. Presses are now latched until the first fixed step consumes them.
4. **Touch buttons dropped held presses.** Buttons were defined as a component inside the render function, so React re-created them on every 12 Hz HUD refresh and pointer capture was lost. They are now plain elements.
5. **Retrying a stage kept destroyed crates / hidden dome.** Maps are always rebuilt when a stage loads.
6. **Dome laser orientation.** Rotating the root with the player made the sweep drift; only the pivot yaws now so the laser stays in world space.
7. **King slam bounced repeatedly** because of overlapping timer/gravity conditions; rewritten as launch → drift → land → shockwave.
8. **Corrugation stretched onto disc faces.** Cylinder UV scaling also hit the caps (faces repeated 6×); now torso only.
9. **Arrow keys collided with movement bindings.** Arrows now always turn the camera (also the fallback when pointer lock is unavailable).
10. **Stuck enemies.** Added stuck detection with a sidestep detour, spawn points validated against colliders, enemy separation, and arena clamping.
11. **Audio pile-ups.** Per-sound throttling and a global voice cap in the SFX engine.
12. **Save corruption.** Every field is validated; unreadable JSON is preserved under a `.bak` key rather than destroyed.
13. **Input stuck on focus loss.** `blur`, tab-hide, pause and stage transitions call `releaseAll()`.

### Verified
* `npm run build` succeeds and produces a single-file `dist/index.html`.
* TypeScript strict mode with unused-symbol checks passes for all game and UI files.

### Not verified (honest)
* No live playtest of any mode, no console-error sweep, no multi-resolution/touch/gamepad runs, no screenshots, and the in-app self-tests were not executed by the author.
